module.exports = {
    apps: [{
        name: 'mongodb',
        cwd: '/opt/keus-iot-code',
        interpreter: '/bin/bash',
        script: './start-mongodb.sh',
        output: '/opt/keus-iot-code/logs/mongo-out.log',
        error: '/opt/keus-iot-code/logs/mongo-out.log',
        env: {
            NODE_ENV: 'production'
        }
    }, {
        name: 'communication_service_minigateway',
        cwd: '/opt/keus-iot-code/keus-iot-gateway',
        interpreter: '/root/n/bin/node',
        script: './src/app/services-manager/minigateway-communication-service.js',
        output: '/opt/keus-iot-code/logs/minigateway-communication-service-out.log',
        error: '/opt/keus-iot-code/logs/minigateway-communication-service-out.log',
        env: {
            NODE_ENV: 'production',
            LOG_PATH: '/opt/keus-iot-code/logs/kiot_comm_app.log'
        }
    }, {
        name: 'device_manager',
        cwd: '/opt/keus-iot-code/keus-iot-gateway',
        interpreter: '/root/n/bin/node',
        script: './src/app/device-manager/index.js',
        output: '/opt/keus-iot-code/logs/device_manager-out.log',
        error: '/opt/keus-iot-code/logs/device_manager-out.log',
        env: {
            NODE_ENV: 'production',
            LOG_PATH: '/opt/keus-iot-code/logs/kiot_device_manager_app.log',
            MOCK_ZC: false,
            USB_DISABLED: false,
            USE_CC2652: true,
            ZIGBEE_CC2652_USB: '/dev/ttyAMA0',
            ZIGBEE_CHANNEL: 26,
            DEBUG: 'zigbee-herdsman*,-agenda:internal:*,-axm:*',
            ALLOWED_DEVICES: [],
            DEPLOYMENT_DEVICE: 1,
            DISABLE_DB: true
        }
    }],

    deploy: {
    }
}