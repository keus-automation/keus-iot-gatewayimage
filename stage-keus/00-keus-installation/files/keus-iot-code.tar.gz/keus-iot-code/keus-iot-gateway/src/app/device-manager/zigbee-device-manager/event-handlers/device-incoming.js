"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_globals_1 = require("../../../../constants/gateway/zigbee-globals");
const providers_manager_1 = require("../../providers-manager");
const index_1 = __importDefault(require("../../../../services/logger-service/index"));
const keus_dm_device_zigbee_1 = __importDefault(require("../../../../models/database-models/keus-dm-device-zigbee"));
const general_1 = require("../../../../utilities/general");
const device_pb_1 = require("../../../hub-request-manager/protos/generated/hub/devices/device_pb");
const any_pb_1 = require("google-protobuf/google/protobuf/any_pb");
const system_constants_1 = require("../../../../constants/gateway/system-constants");
const device_1 = require("../../../../utilities/device-manager/device");
const zigbee_globals_2 = require("../../../../constants/gateway/zigbee-globals");
const logInst = new index_1.default({ enable: true, namespace: 'DEVICE_INCOMING' });
async function default_1(deviceInterviewData) {
    logInst.log('New Device Joining Completed', deviceInterviewData);
    let device = deviceInterviewData.device;
    let interviewStatus = deviceInterviewData.status;
    let that = this;
    if (interviewStatus === 'successful') {
        console.log('Got the device', device, device.keusDevice, that.uniqueId, that.zigbeeConfig.uniqueId);
        if (device.keusDevice) {
            console.log('It is a keus device');
            let endpoint = device.getEndpoint(zigbee_globals_1.KEUS_DEVICE_ENDPOINT);
            let deviceId = endpoint.deviceID;
            let deviceType = general_1.GetUint16LowByte(deviceId);
            let deviceCategory = general_1.GetUint16HighByte(deviceId);
            let currentTimestamp = new Date().valueOf();
            let mappedDeviceType = device_1.getMappedDeviceType(deviceCategory, deviceType);
            console.log('=========================================================');
            console.log(endpoint, deviceId, deviceType, deviceCategory, currentTimestamp);
            console.log('=========================================================');
            let deviceProperties = {};
            // Device Defaults
            if (deviceCategory === zigbee_globals_2.DEVICE_META_INFO.deviceCategories.EMBEDDEDSWITCH.id) {
                deviceProperties = device_1.getDefaultEmbeddedConfiguration(deviceCategory, deviceType);
            }
            else if (deviceCategory === zigbee_globals_2.DEVICE_META_INFO.deviceCategories.RGBWWA.id) {
                deviceProperties = device_1.getDefaultRGBWWAConfiguration(deviceCategory, deviceType);
            }
            else if (deviceCategory === zigbee_globals_2.DEVICE_META_INFO.deviceCategories.SCENESWITCH.id) {
                deviceProperties = device_1.getDefaultSceneSwitchConfiguration(deviceCategory, deviceType);
            }
            let deviceInfo = {
                deviceId: device.ieeeAddr,
                minigatewayId: that.zigbeeConfig.uniqueId,
                shortAddr: device.networkAddress,
                deviceType: deviceType,
                deviceCategory: deviceCategory,
                firmwareVersion: endpoint.deviceVersion,
                registeredTimestamp: currentTimestamp,
                lastSentMsg: currentTimestamp,
                lastReceivedMsg: currentTimestamp,
                areaId: null,
                areaMemberAddr: null,
                isAreaServer: false,
                isDaliMaster: false,
                deviceProperties: deviceProperties
            };
            console.log(deviceInfo);
            try {
                await keus_dm_device_zigbee_1.default.insertDevice(deviceInfo);
                console.log('Done inserting into database');
                const request = new device_pb_1.RegisterDevice();
                request.setDeviceId(deviceInfo.deviceId);
                request.setDeviceType(mappedDeviceType);
                request.setFirmwareVersion(deviceInfo.firmwareVersion + '');
                request.setMasterId(that.zigbeeConfig.uniqueId);
                const anyObj = new any_pb_1.Any();
                anyObj.pack(request.serializeBinary(), system_constants_1.ProtoPackageName + '.RegisterDevice');
                await providers_manager_1.providersManager.makeRPC(providers_manager_1.providersManager.getMainGatewayServiceName(), anyObj);
                logInst.log('Added New Device to Database');
            }
            catch (err) {
                logInst.log('Failed to add entry to database ', err);
            }
        }
        else {
            logInst.log('Not a Keus Device');
        }
    }
    else if (interviewStatus === 'failed') {
        // if device failed, kick the device out of network
        let adapter = that.zigbeeController.getZstackAdapter();
        await adapter.removeDevice(device.networkAddress, device.ieeeAddr);
    }
}
exports.default = default_1;
;
//# sourceMappingURL=device-incoming.js.map