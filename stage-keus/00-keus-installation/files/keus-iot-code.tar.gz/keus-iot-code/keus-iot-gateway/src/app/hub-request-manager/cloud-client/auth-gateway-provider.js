"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const protoRpcRegistry = __importStar(require("../protos/proto-rpc-registry"));
const logger_service_1 = __importDefault(require("../../../services/logger-service"));
const system_constants_1 = require("../../../constants/gateway/system-constants");
const request_handlers_1 = require("../request-handlers");
const any_pb_1 = require("google-protobuf/google/protobuf/any_pb");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (requestType, requestData, clientMetadata) => {
    console.log('came to gateway file', requestType);
    let phone = clientMetadata.phone;
    switch (requestType) {
        //Minigateway Handlers
        case protoRpcRegistry.miniGatewaySetupRpcTypes.GetMiniGatewayList:
            return await request_handlers_1.MiniGatewayHandlers.GetMiniGatewayList(requestData);
            break;
        case protoRpcRegistry.miniGatewaySetupRpcTypes.UpdateMiniGatewayInfo:
            return await request_handlers_1.MiniGatewayHandlers.UpdateMiniGatewayInfo(requestData);
            break;
        //ActivityHandlers
        case protoRpcRegistry.activityRpcTypes.GetActivityLog:
            return await request_handlers_1.ActivityHandlers.GetActivity(requestData);
            break;
        case protoRpcRegistry.jobCompletionRpcTypes.ReportJobCompletion:
            return await request_handlers_1.ActivityHandlers.ReportJobCompletion(requestData);
            break;
        case protoRpcRegistry.activityRpcTypes.ReportSystemActivity:
            return await request_handlers_1.ActivityHandlers.ReportSystemActivity(requestData);
            break;
        //Device Common
        case protoRpcRegistry.deviceRpcTypes.RegisterDevice:
            return await request_handlers_1.DeviceHandlers.DeviceCommon.RegisterDevice(requestData, phone);
            break;
        case protoRpcRegistry.deviceRpcTypes.EnterPairMode:
            return await request_handlers_1.DeviceHandlers.DeviceCommon.EnterPairMode(requestData, phone);
            break;
        //Embedded Switch
        case protoRpcRegistry.zigbeeEmbeddedSwitchTypes.AddEditAppliance:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSwitchControllers.AddEditAppliance(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeEmbeddedSwitchTypes.ConfigureEmbeddedSwitches:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSwitchControllers.ConfigureEmbeddedSwitches(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeEmbeddedSwitchTypes.DeleteAppliance:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSwitchControllers.DeleteAppliance(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeEmbeddedSwitchTypes.EditEmbeddedSwitchDetails:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSwitchControllers.EditEmbeddedSwitchDetails(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeEmbeddedSwitchTypes.MoveEmbeddedSwitchRoom:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSwitchControllers.MoveZigbeeEmbeddedSwitchesRoom(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeEmbeddedSwitchTypes.UpdateApplianceState:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSwitchControllers.UpdateApplianceState(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeEmbeddedSwitchTypes.UpdatePortState:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSwitchControllers.UpdateEmbeddedPortState(requestData, phone);
            break;
        //Dimmable Drivers
        case protoRpcRegistry.zigbeeDimmableDriverTypes.ConfigureZigbeeDimmableDriver:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.ConfigureZigbeeDimmableDriver(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeDimmableDriverTypes.UpdateZigbeeDimmableDriverState:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.UpdateZigbeeDimmableDriverState(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeDimmableDriverTypes.MoveZigbeeDimmableDriverRoom:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.MoveZigbeeDimmableDriverRoom(requestData, phone);
            break;
        case protoRpcRegistry.daliDimmableDriverTypes.ConfigureDaliDimmableDriver:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.ConfigureDaliDimmableDriver(requestData, phone);
            break;
        case protoRpcRegistry.daliDimmableDriverTypes.UpdateDaliDimmableDriverState:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.UpdateDaliDimmableDriverState(requestData, phone);
            break;
        case protoRpcRegistry.daliDimmableDriverTypes.MoveDaliDimmableDriverRoom:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.MoveDaliDimmableDriverRoom(requestData, phone);
            break;
        //dali ct
        case protoRpcRegistry.daliColorTunableDriverTypes.CheckDaliDriverType:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.checkDaliDriverType(requestData, phone);
            break;
        case protoRpcRegistry.daliColorTunableDriverTypes.ConfigureDaliColorTunableProperties:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.configureDaliColorTunableProperties(requestData, phone);
            break;
        case protoRpcRegistry.daliColorTunableDriverTypes.MoveDaliColorTunableDriverRoom:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.moveDaliColorTunableDriverRoom(requestData, phone);
            break;
        case protoRpcRegistry.daliColorTunableDriverTypes.SetDaliColorTunableDriverNameLocation:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.setDaliColorTunableDriverNameLocation(requestData, phone);
            break;
        case protoRpcRegistry.daliColorTunableDriverTypes.UpdateDaliDriverType:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.updateDaliDriverType(requestData, phone);
            break;
        case protoRpcRegistry.daliColorTunableDriverTypes.UpdateDaliColorTunableDriverState:
            return await request_handlers_1.DeviceHandlers.DimmableDrivers.updateDaliColorTunableDriverState(requestData, phone);
            break;
        //Scene Wizard
        case protoRpcRegistry.sceneWizardTypes.ConfigureSceneWizardButtons:
            return await request_handlers_1.DeviceHandlers.SceneWizard.ConfigureSceneWizardButtons(requestData);
            break;
        case protoRpcRegistry.sceneWizardTypes.MoveSceneWizardRoom:
            return await request_handlers_1.DeviceHandlers.SceneWizard.MoveSceneWizardRoom(requestData);
            break;
        case protoRpcRegistry.sceneWizardTypes.ConfigureSceneWizard:
            return await request_handlers_1.DeviceHandlers.SceneWizard.ConfigureSceneWizard(requestData);
            break;
        //Scene Switch
        case protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.ConfigureZigbeeEmbeddedSceneSwitch:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSceneSwitchControllers.ConfigureZigbeeEmbeddedSceneSwitch(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.ConfigureZigbeeEmbeddedSceneSwitchButtons:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSceneSwitchControllers.ConfigureZigbeeEmbeddedSceneSwitchButtons(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.ConfigureZigbeeEmbeddedGlobalSceneSwitchButtons:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSceneSwitchControllers.ConfigureZigbeeEmbeddedGlobalSceneSwitchButtons(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.MoveZigbeeEmbeddedSceneSwitchRoom:
            return await request_handlers_1.DeviceHandlers.ZigbeeEmbeddedSceneSwitchControllers.MoveZigbeeEmbeddedSceneSwitchRoom(requestData, phone);
            break;
        // RGBWWA 
        case protoRpcRegistry.zigbeeRgbwwaTypes.MoveZigbeeRgbwwaRoom:
            return await request_handlers_1.DeviceHandlers.ZigbeeRGBWWAControllers.MoveZigbeeRGBWWARoom(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeRgbwwaTypes.UpdateZigbeeRgbwwaState:
            return await request_handlers_1.DeviceHandlers.ZigbeeRGBWWAControllers.UpdateRGBWWAState(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeRgbwwaTypes.ConfigureZigbeeRgbwwa:
            return await request_handlers_1.DeviceHandlers.ZigbeeRGBWWAControllers.ConfigureRGBWWADriver(requestData, phone);
            break;
        //Smart Consoles
        case protoRpcRegistry.smartConsoleTypes.ClearConsoleData:
            return await request_handlers_1.DeviceHandlers.SmartConsole.ClearConsoleData(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.ConfigureConsoleButtons:
            return await request_handlers_1.DeviceHandlers.SmartConsole.ConfigureConsoleButtons(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.ConfigureSmartConsole:
            return await request_handlers_1.DeviceHandlers.SmartConsole.ConfigureSmartConsole(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.ConfigureSmartConsoleRelay:
            return await request_handlers_1.DeviceHandlers.SmartConsole.ConfigureSmartConsoleRelay(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.DaliSetRestoreLastLevel:
            return await request_handlers_1.DeviceHandlers.SmartConsole.DaliSetRestoreLastLevel(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.DiscoverDaliDevices:
            return await request_handlers_1.DeviceHandlers.SmartConsole.DiscoverDaliDevices(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.FlashConsoleButtons:
            return await request_handlers_1.DeviceHandlers.SmartConsole.FlashConsoleButtons(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.MoveSmartConsoleRoom:
            return await request_handlers_1.DeviceHandlers.SmartConsole.MoveSmartConsoleRoom(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.SetAreaMaster:
            return await request_handlers_1.DeviceHandlers.SmartConsole.SetAreaMaster(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.SetConsoleRelayState:
            return await request_handlers_1.DeviceHandlers.SmartConsole.SetConsoleRelayState(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.SetDaliMaster:
            return await request_handlers_1.DeviceHandlers.SmartConsole.SetDaliMaster(requestData, phone);
            break;
        case protoRpcRegistry.smartConsoleTypes.SyncSceneUIData:
            return await request_handlers_1.DeviceHandlers.SmartConsole.SyncSceneUIData(requestData, phone);
            break;
        //Zigbee Curtain Controllers
        case protoRpcRegistry.zigbeeCurtainControllerTypes.ConfigureZigbeeCurtainController:
            return await request_handlers_1.DeviceHandlers.ZigbeeCurtainControllers.ConfigureZigbeeCurtainController(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeCurtainControllerTypes.MoveZigbeeCurtainControllerRoom:
            return await request_handlers_1.DeviceHandlers.ZigbeeCurtainControllers.MoveZigbeeCurtainControllerRoom(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeCurtainControllerTypes.UpdateZigbeeCurtainControllerState:
            return await request_handlers_1.DeviceHandlers.ZigbeeCurtainControllers.UpdateZigbeeCurtainControllerState(requestData, phone);
            break;
        //Zigbee AC Fan Controllers
        case protoRpcRegistry.zigbeeAcFanControlerTypes.ConfigureZigbeeACFanController:
            return await request_handlers_1.DeviceHandlers.ZigbeeFanControllers.ConfigureZigbeeACFanController(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeAcFanControlerTypes.UpdateZigbeeACFanControllerState:
            return await request_handlers_1.DeviceHandlers.ZigbeeFanControllers.UpdateZigbeeACFanControllerState(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeAcFanControlerTypes.MoveZigbeeACFanControllerRoom:
            return await request_handlers_1.DeviceHandlers.ZigbeeFanControllers.MoveZigbeeACFanControllerRoom(requestData, phone);
            break;
        // Zigbee DC Fan Controller
        case protoRpcRegistry.zigbeeDcFanControlerTypes.ConfigureZigbeeDCFanController:
            return await request_handlers_1.DeviceHandlers.ZigbeeFanControllers.ConfigureZigbeeDCFanController(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeDcFanControlerTypes.UpdateZigbeeDCFanControllerState:
            return await request_handlers_1.DeviceHandlers.ZigbeeFanControllers.UpdateZigbeeDCFanControllerState(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeDcFanControlerTypes.MoveZigbeeDCFanControllerRoom:
            return await request_handlers_1.DeviceHandlers.ZigbeeFanControllers.MoveZigbeeDCFanControllerRoom(requestData, phone);
            break;
        //Zigbee IR Blasters
        case protoRpcRegistry.zigbeeIRBlasterTypes.GetIRRemoteList:
            return await request_handlers_1.DeviceHandlers.ZigbeeIRBlasterControllers.GetIRRemoteList(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeIRBlasterTypes.ConfigureZigbeeIRBlaster:
            return await request_handlers_1.DeviceHandlers.ZigbeeIRBlasterControllers.ConfigureZigbeeIRBlaster(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeIRBlasterTypes.AddRemoteToZigbeeIRBlaster:
            return await request_handlers_1.DeviceHandlers.ZigbeeIRBlasterControllers.AddRemoteToZigbeeIRBlaster(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeIRBlasterTypes.BlastIRCommand:
            return await request_handlers_1.DeviceHandlers.ZigbeeIRBlasterControllers.BlastIRCommand(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeIRBlasterTypes.MoveZigbeeIRBlasterRoom:
            return await request_handlers_1.DeviceHandlers.ZigbeeIRBlasterControllers.MoveZigbeeIRBlasterRoom(requestData, phone);
            break;
        case protoRpcRegistry.zigbeeIRBlasterTypes.RemoveRemoteFromZigbeeIRBlaster:
            return await request_handlers_1.DeviceHandlers.ZigbeeIRBlasterControllers.RemoveRemoteFromIRBlaster(requestData, phone);
            break;
        //Group Handlers
        case protoRpcRegistry.groupRpcTypes.AddDeviceToGroup:
            return await request_handlers_1.GroupHandlers.AddDeviceToGroup(requestData, phone);
            break;
        case protoRpcRegistry.groupRpcTypes.ChangeGroupName:
            return await request_handlers_1.GroupHandlers.ChangeGroupName(requestData, phone);
            break;
        case protoRpcRegistry.groupRpcTypes.ConfigureGroupProperties:
            return await request_handlers_1.GroupHandlers.ConfigureGroupProperties(requestData, phone);
            break;
        case protoRpcRegistry.groupRpcTypes.CreateGroup:
            return await request_handlers_1.GroupHandlers.CreateGroup(requestData, phone);
            break;
        case protoRpcRegistry.groupRpcTypes.DeleteGroup:
            return await request_handlers_1.GroupHandlers.DeleteGroup(requestData, phone);
            break;
        case protoRpcRegistry.groupRpcTypes.RemoveDeviceFromGroup:
            return await request_handlers_1.GroupHandlers.RemoveDeviceFromGroup(requestData, phone);
            break;
        case protoRpcRegistry.groupRpcTypes.UpdateGroupState:
            return await request_handlers_1.GroupHandlers.UpdateGroupState(requestData, phone);
            break;
        //Home Handlers
        case protoRpcRegistry.homeRpcTypes.AddSection:
            return await request_handlers_1.HomeHandlers.AddSection(requestData, phone);
            break;
        case protoRpcRegistry.permissionRpcTypes.AssignSuperUser:
            return await request_handlers_1.HomeHandlers.AssignSuperUser(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.CreateArea:
            return await request_handlers_1.HomeHandlers.CreateArea(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.CreateFloor:
            return await request_handlers_1.HomeHandlers.CreateFloor(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.CreateRoom:
            return await request_handlers_1.HomeHandlers.CreateRoom(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.DeleteArea:
            return await request_handlers_1.HomeHandlers.DeleteArea(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.DeleteFloor:
            return await request_handlers_1.HomeHandlers.DeleteFloor(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.DeleteRoom:
            return await request_handlers_1.HomeHandlers.DeleteRoom(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.DeleteSection:
            return await request_handlers_1.HomeHandlers.DeleteSection(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.EditArea:
            return await request_handlers_1.HomeHandlers.EditArea(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.EditFloor:
            return await request_handlers_1.HomeHandlers.EditFloor(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.EditRoom:
            return await request_handlers_1.HomeHandlers.EditRoom(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.EditSection:
            return await request_handlers_1.HomeHandlers.EditSection(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.GetAreas:
            return await request_handlers_1.HomeHandlers.GetAreas(requestData);
            break;
        case protoRpcRegistry.homeRpcTypes.GetFloors:
            return await request_handlers_1.HomeHandlers.GetFloors(requestData);
            break;
        case protoRpcRegistry.homeRpcTypes.GetHubData:
            return await request_handlers_1.HomeHandlers.GetHubData(requestData);
            break;
        case protoRpcRegistry.homeRpcTypes.UpdateGatewayColor:
            return await request_handlers_1.HomeHandlers.UpdateGatewayColor(requestData, phone);
            break;
        case protoRpcRegistry.homeRpcTypes.GetRooms:
            return await request_handlers_1.HomeHandlers.GetRooms(requestData);
            break;
        case protoRpcRegistry.userRpcTypes.GetUserInfo:
            return await request_handlers_1.HomeHandlers.GetUserInfo(requestData);
            break;
        case protoRpcRegistry.permissionRpcTypes.GrantUserPermission:
            return await request_handlers_1.HomeHandlers.GrantUserPermission(requestData, phone);
            break;
        case protoRpcRegistry.GatewaySetupRpcTypes.RegisterGatewayToCloud:
            return await request_handlers_1.HomeHandlers.RegisterGatewayToCloud(requestData, phone);
            break;
        case protoRpcRegistry.permissionRpcTypes.RemoveUserPermission:
            return await request_handlers_1.HomeHandlers.RemoveUserPermission(requestData, phone);
            break;
        case protoRpcRegistry.permissionRpcTypes.GetUserPermissionList:
            return await request_handlers_1.HomeHandlers.GetUserPermissionList(requestData, phone);
            break;
        case protoRpcRegistry.userRpcTypes.RequestOtp:
            return await request_handlers_1.HomeHandlers.RequestGatewayOtp(requestData, phone);
            break;
        // Scenes
        case protoRpcRegistry.sceneRpcTypes.AddActionToScene:
            return await request_handlers_1.SceneHandlers.AddActionToScene(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.AddTimeslotToScene:
            return await request_handlers_1.SceneHandlers.AddTimeslotToScene(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.AdjustTimeslotDelay:
            return await request_handlers_1.SceneHandlers.AdjustTimeslotDelay(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.CreateScene:
            return await request_handlers_1.SceneHandlers.CreateScene(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.DeleteScene:
            return await request_handlers_1.SceneHandlers.DeleteScene(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.EditSceneName:
            return await request_handlers_1.SceneHandlers.EditSceneName(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.ExecuteScene:
            return await request_handlers_1.SceneHandlers.ExecuteScene(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.MoveSceneToRoom:
            return await request_handlers_1.SceneHandlers.MoveSceneToRoom(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.RemoveActionFromScene:
            return await request_handlers_1.SceneHandlers.RemoveActionFromScene(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.RemoveTimeslotFromScene:
            return await request_handlers_1.SceneHandlers.RemoveTimeslotFromScene(requestData, phone);
            break;
        case protoRpcRegistry.sceneRpcTypes.SyncAreaSceneUIData:
            return await request_handlers_1.SceneHandlers.SyncAreaSceneUIData(requestData, phone);
            break;
        // Schedules
        case protoRpcRegistry.scheduleRpcTypes.CreateSchedule:
            console.log('this is create schedule came here');
            return await request_handlers_1.ScheduleHandlers.CreateSchedule(requestData, phone);
            break;
        case protoRpcRegistry.scheduleRpcTypes.EditSchedule:
            return await request_handlers_1.ScheduleHandlers.EditSchedule(requestData, phone);
            break;
        case protoRpcRegistry.scheduleRpcTypes.EditScheduleProperties:
            return await request_handlers_1.ScheduleHandlers.EditScheduleProperties(requestData, phone);
            break;
        case protoRpcRegistry.scheduleRpcTypes.DeleteSchedule:
            return await request_handlers_1.ScheduleHandlers.DeleteSchedule(requestData, phone);
            break;
        case protoRpcRegistry.scheduleRpcTypes.EnableDisableSchedule:
            console.log('THIS IS ENABLE DISABLE');
            return await request_handlers_1.ScheduleHandlers.EnableDisableSchedule(requestData, phone);
            break;
        //Voice handlers
        case protoRpcRegistry.googleVoiceTypes.GoogleHomeSyncDevices:
            return await request_handlers_1.VoiceHandlers.GoogleHomeSyncDevices(requestData);
            break;
        case protoRpcRegistry.googleVoiceTypes.GoogleHomeExecuteCommand:
            return await request_handlers_1.VoiceHandlers.GoogleHomeExecuteCommand(requestData);
            break;
        case protoRpcRegistry.googleVoiceTypes.GoogleHomeDisconnectDevices:
            return await request_handlers_1.VoiceHandlers.GoogleHomeDisconnectDevices(requestData);
            break;
        case protoRpcRegistry.googleVoiceTypes.GoogleHomeQueryState:
            return await request_handlers_1.VoiceHandlers.GoogleHomeQueryState(requestData);
            break;
        case protoRpcRegistry.alexaRpcTypes.AlexaDiscoverDevices:
            return await request_handlers_1.VoiceHandlers.AlexaDiscoverDevices(requestData);
            break;
        case protoRpcRegistry.alexaRpcTypes.AlexaExecuteCommand:
            return await request_handlers_1.VoiceHandlers.AlexaExecuteCommand(requestData);
            break;
        default:
            //default handler
            return new any_pb_1.Any();
    }
};
//# sourceMappingURL=auth-gateway-provider.js.map