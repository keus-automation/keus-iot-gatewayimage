"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = __importDefault(require("../../../services/logger-service/index"));
const index_2 = require("../../../services/communication-service/index");
const communication_service_1 = __importDefault(require("../../../configs/communication-service"));
const kiott_nodeclient_1 = require("kiott-nodeclient");
const type_registry_1 = __importDefault(require("../protos/type-registry"));
const auth_gateway_provider_1 = __importDefault(require("./auth-gateway-provider"));
const errors_1 = require("../../../errors/errors");
const logInst = new index_1.default({ enable: true, namespace: 'HUB_REQUEST_HANDLER' });
class ProvidersManager {
    constructor() {
        this.communicationClientInstance = null;
        this.mainGatewayServiceName = null;
        console.log(communication_service_1.default);
        this.communicationClientInstance = new index_2.CommunicationClient({
            host: communication_service_1.default.cloud_host,
            port: communication_service_1.default.cloud_port
        });
        this.communicationClientInstance.registerTypes(type_registry_1.default);
    }
    setMainGatewayServiceName(gatewayId) {
        this.mainGatewayServiceName = gatewayId;
    }
    getMainGatewayServiceName() {
        return this.mainGatewayServiceName;
    }
    async start(loginDetails) {
        let _this = this;
        if (_this.communicationClientInstance) {
            try {
                let resp = await _this.communicationClientInstance.login(loginDetails);
                return resp;
            }
            catch (err) {
                console.log('ERROR IS ', err);
                throw new errors_1.GeneralErrors.CloudClientConnectionError();
            }
        }
    }
    getTypeConversionUtils() {
        return kiott_nodeclient_1.TypeConversionUtils.getInstance();
    }
    registerHubClientService(serviceId) {
        let _this = this;
        return new Promise(async (resolve, reject) => {
            try {
                if (_this.communicationClientInstance) {
                    logInst.log('Registering Cloud Gateway', serviceId);
                    await _this.communicationClientInstance.registerService(serviceId, async function (arg, callerMetadata) {
                        let unpackedObj = kiott_nodeclient_1.TypeConversionUtils.getInstance().unpackFromAny(arg);
                        return auth_gateway_provider_1.default(unpackedObj.constructor, unpackedObj, callerMetadata);
                    });
                    resolve();
                }
                else {
                    reject();
                }
            }
            catch (e) {
                console.log('ERROR_WHILE_UNPACKING: ', e);
                reject(e);
            }
        });
    }
    async makeRPC(serviceName, paramsObj) {
        let that = this;
        const res = await that.communicationClientInstance.makeRPC(serviceName, paramsObj);
        return res;
    }
    publishEvent(eventName, paramsObj) {
        this.communicationClientInstance.publishEvent(eventName, paramsObj);
        return;
    }
}
exports.CloudProvidersManager = new ProvidersManager();
//# sourceMappingURL=index.js.map