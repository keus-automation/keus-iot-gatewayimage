"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger_service_1 = __importDefault(require("../../services/logger-service"));
const cloud_client_1 = require("./cloud-client");
const local_client_1 = require("./local-client");
const mongo_implementation_1 = __importDefault(require("../../services/database-service/mongo-implementation"));
const database_service_1 = __importDefault(require("../../configs/database-service"));
const errors_1 = require("../../errors/errors");
const system_constants_1 = require("../../constants/gateway/system-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: 'HUB_CLIENT' });
const keus_gateway_1 = __importDefault(require("../../models/database-models/keus-gateway"));
const local_api_server_1 = require("../../app/local-api-server");
const schedules_manager_1 = require("./schedules-manager");
const jobs_1 = __importDefault(require("./jobs"));
const startup = async () => {
    try {
        // await mdnsManager.start();
        await mongo_implementation_1.default.getInstance().connect(database_service_1.default);
        logInst.log('Database Connection Established');
        await registerLocalAPIServer();
        await registerLocalUnAuthGateway();
        const gatewayList = await keus_gateway_1.default.getGateway();
        if (gatewayList.length) {
            const mainGateway = gatewayList.find(function (gtw) {
                return gtw.gatewayMode == system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY;
            });
            if (mainGateway) {
                registerCloudAuthGateway(mainGateway);
                registerLocalAuthGateway(mainGateway);
                await schedules_manager_1.SchedulesManager.getInstance().start();
                jobs_1.default();
                logInst.log('Jobs Manager Started');
            }
        }
    }
    catch (e) {
        logInst.log('Failed to connect to database or launch mdns');
        throw e;
    }
};
const registerLocalAPIServer = async () => {
    try {
        await local_api_server_1.startApiServer();
        logInst.log('Started Api Server');
    }
    catch (e) {
        logInst.log('Failed to Register Local Api Server');
    }
};
const registerLocalUnAuthGateway = async () => {
    try {
        await local_client_1.GatewayProvidersManager.registerUnAuthGatewayService();
        logInst.log('Registered Local Unauthenticated Gateway');
    }
    catch (e) {
        logInst.log('Failed to Register Local Unauth Gateway');
    }
};
const registerLocalAuthGateway = async (mainGateway) => {
    try {
        local_client_1.GatewayProvidersManager.setMainGatewayServiceName(system_constants_1.getGatewayManagerServiceName(mainGateway.gatewayId));
        await local_client_1.GatewayProvidersManager.start(JSON.stringify({
            type: 'GATEWAY',
            gatewayId: mainGateway.gatewayId,
            gatewayKey: mainGateway.gatewayKey
        }));
        await local_client_1.GatewayProvidersManager.registerHubClientService(system_constants_1.getGatewayManagerServiceName(mainGateway.gatewayId));
        await registerScheduler();
        logInst.log('Registered Local Authenticated Gateway');
    }
    catch (e) {
        logInst.log('Failed to Register Local Auth Gateway');
    }
};
const registerCloudAuthGateway = async (mainGateway) => {
    try {
        console.log('Starting cloud providers gateway');
        cloud_client_1.CloudProvidersManager.setMainGatewayServiceName(system_constants_1.getGatewayManagerServiceName(mainGateway.gatewayId));
        await cloud_client_1.CloudProvidersManager.start(JSON.stringify({
            type: 'GATEWAY',
            gatewayId: mainGateway.gatewayId,
            gatewayKey: mainGateway.gatewayKey
        }));
        await cloud_client_1.CloudProvidersManager.registerHubClientService(system_constants_1.getGatewayManagerServiceName(mainGateway.gatewayId));
        logInst.log('Registered Cloud Authenticated Gateway');
    }
    catch (e) {
        logInst.log('Failed to Register Cloud Auth Gateway');
    }
};
const registerScheduler = async () => {
    try {
        console.log('Starting scheduler');
        jobs_1.default();
        await schedules_manager_1.SchedulesManager.getInstance().start();
        console.log('Registered Scheduler');
    }
    catch (e) {
        logInst.log('Failed to Start Scheduler');
    }
};
try {
    startup();
    console.log('Starting up');
}
catch (e) {
    switch (e) {
        case errors_1.DatabaseErrors.DatabaseConnectionError:
            logInst.log('Unable to connect to Database');
            break;
        case errors_1.GeneralErrors.CloudClientConnectionError:
            logInst.log('Unable to connect to cloud rpc server');
            break;
        default:
            logInst.log('Random error', e);
    }
}
//# sourceMappingURL=index.js.map