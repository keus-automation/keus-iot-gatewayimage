"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_request_manager_1 = require("../../../models/job-models/gateway-request-manager");
const system_constants_1 = require("../../../constants/gateway/system-constants");
const rpc_maker_util_1 = require("../../../utilities/gateway/rpc-maker-util");
const zigbee_ir_blaster_pb_1 = require("../protos/generated/hub/devices/zigbee_ir_blaster_pb");
const device_constants_pb_1 = require("../protos/generated/hub/devices/device_constants_pb");
const schedules_manager_1 = require("../schedules-manager");
const zigbee_ir_blaster_1 = require("../request-handlers/device-handlers/zigbee-ir-blaster");
let jobDef = {
    jobHandler: async function (jobInstance) {
        let jobData = jobInstance.data;
        let jobId = jobInstance.id;
        try {
            await gateway_request_manager_1.BlastIRCommand.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.BlastIRCommand.stage.REQUEST_PENDING,
                message: 'Job Execution Started'
            });
            const blastIRCommandReq = new zigbee_ir_blaster_pb_1.BlastIRCommand();
            const irAction = jobData.irBlastAction;
            blastIRCommandReq.setRemoteId(irAction.remoteId);
            blastIRCommandReq.setRemoteType(irAction.remoteType);
            switch (irAction.remoteType) {
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                    const acActionInt = irAction.irBlastAction;
                    const acAction = new zigbee_ir_blaster_pb_1.IRACBlast();
                    acAction.setPowerOn(acActionInt.powerOn);
                    acAction.setTemperature(acActionInt.temperature);
                    acAction.setSwingVLevel(acActionInt.swingVLevel);
                    acAction.setSwingHLevel(acActionInt.swingHLevel);
                    acAction.setMode(acActionInt.mode);
                    acAction.setFanLevel(acActionInt.fanLevel);
                    acAction.setUpdateType(zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_ONOFF); //Needs to change to allow full action
                    blastIRCommandReq.setAcBlastInfo(acAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                    const tvActionInt = irAction.irBlastAction;
                    const tvAction = new zigbee_ir_blaster_pb_1.IRTVBlast();
                    tvAction.setPowerOn(tvActionInt.powerOn);
                    tvAction.setChannelNumber(tvActionInt.channelNumber);
                    tvAction.setMode(tvActionInt.mode);
                    tvAction.setSource(tvActionInt.source);
                    tvAction.setUpdateType(tvActionInt.updateType);
                    blastIRCommandReq.setTvBlastInfo(tvAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                    const ampActionInt = irAction.irBlastAction;
                    const ampAction = new zigbee_ir_blaster_pb_1.IRAMPBlast();
                    ampAction.setPowerOn(ampActionInt.powerOn);
                    ampAction.setMode(ampActionInt.mode);
                    ampAction.setSource(ampActionInt.source);
                    ampAction.setUpdateType(ampActionInt.updateType);
                    blastIRCommandReq.setAmpBlastInfo(ampAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                    const prActionInt = irAction.irBlastAction;
                    const prAction = new zigbee_ir_blaster_pb_1.IRPRBlast();
                    prAction.setPowerOn(prActionInt.powerOn);
                    prAction.setMode(prActionInt.mode);
                    prAction.setSource(prActionInt.source);
                    prAction.setUpdateType(prActionInt.updateType);
                    blastIRCommandReq.setPrBlastInfo(prAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                    const fanActionInt = irAction.irBlastAction;
                    const fanAction = new zigbee_ir_blaster_pb_1.IRFANBlast();
                    fanAction.setPowerOn(fanActionInt.powerOn);
                    fanAction.setMode(fanActionInt.mode);
                    fanAction.setSpeedLevel(fanActionInt.speedLevel);
                    fanAction.setLedState(fanActionInt.ledState);
                    fanAction.setUpdateType(zigbee_ir_blaster_pb_1.FAN_BLAST_TYPES.FAN_ONOFF);
                    blastIRCommandReq.setFanBlastInfo(fanAction);
                    break;
            }
            const blastIRCommandResp = rpc_maker_util_1.UnPackFromAny(await zigbee_ir_blaster_1.BlastIRCommand(blastIRCommandReq, system_constants_1.SystemNumber));
            // const blastIRCommandResp: BlastIRCommandResponse = await MakeAuthLocalRpc(anyObj);
            if (blastIRCommandResp.getSuccess()) {
                await gateway_request_manager_1.BlastIRCommand.updateStatusFn(jobInstance, {
                    stage: gateway_request_manager_1.BlastIRCommand.stage.REQUEST_SUCCESS,
                    message: 'Job Execution Completed'
                });
            }
            else {
                throw blastIRCommandResp.getMessage();
            }
            jobInstance.done(null);
        }
        catch (err) {
            console.log('Blast IR Command Schedule Error:', err);
            await gateway_request_manager_1.BlastIRCommand.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.BlastIRCommand.stage.REQUEST_FAILED,
                message: err
            });
            jobInstance.done(err);
        }
    },
    timeoutHandler: async function (jobInstance) {
        await gateway_request_manager_1.BlastIRCommand.updateStatusFn(jobInstance, {
            stage: gateway_request_manager_1.BlastIRCommand.stage.RESPONSE_TIMEDOUT,
            message: 'Timed Out'
        });
    },
    onCompleteCbk: async function (jobInstance) { },
    options: {
        concurrency: 20,
        timeout: 30000
    }
};
exports.default = () => {
    schedules_manager_1.SchedulesManager.getInstance().defineJob(gateway_request_manager_1.BlastIRCommand.name, jobDef);
};
//# sourceMappingURL=blast-ir-command.js.map