"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_request_manager_1 = require("../../../models/job-models/gateway-request-manager");
const scene_structures_pb_1 = require("../protos/generated/hub/scenes/scene_structures_pb");
const system_constants_1 = require("../../../constants/gateway/system-constants");
const rpc_maker_util_1 = require("../../../utilities/gateway/rpc-maker-util");
const schedules_manager_1 = require("../schedules-manager");
const scene_handlers_1 = require("../request-handlers/scene-handlers");
let jobDef = {
    jobHandler: async function (jobInstance) {
        let jobData = jobInstance.data;
        let jobId = jobInstance.id;
        try {
            await gateway_request_manager_1.ExecuteScene.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.ExecuteScene.stage.REQUEST_PENDING,
                message: 'Job Execution Started'
            });
            const executeSceneReq = new scene_structures_pb_1.ExecuteScene();
            executeSceneReq.setSceneId(jobData.sceneId);
            executeSceneReq.setSceneRoom(jobData.sceneRoom);
            const executeSceneResp = rpc_maker_util_1.UnPackFromAny(await scene_handlers_1.ExecuteScene(executeSceneReq, system_constants_1.SystemNumber));
            // const anyObj = new Any();
            // anyObj.pack(executeSceneReq.serializeBinary(), ProtoPackageName + '.ExecuteScene');
            // const executeSceneResp: ExecuteSceneResponse = await MakeAuthLocalRpc(anyObj);
            if (executeSceneResp.getSuccess()) {
                await gateway_request_manager_1.ExecuteScene.updateStatusFn(jobInstance, {
                    stage: gateway_request_manager_1.ExecuteScene.stage.REQUEST_SUCCESS,
                    message: 'Job Execution Completed'
                });
            }
            else {
                throw executeSceneResp.getMessage();
            }
            jobInstance.done(null);
        }
        catch (err) {
            console.log('Execute Scene Schedule Error:', err);
            await gateway_request_manager_1.ExecuteScene.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.ExecuteScene.stage.REQUEST_FAILED,
                message: err
            });
            jobInstance.done(err);
        }
    },
    timeoutHandler: async function (jobInstance) {
        await gateway_request_manager_1.ExecuteScene.updateStatusFn(jobInstance, {
            stage: gateway_request_manager_1.ExecuteScene.stage.RESPONSE_TIMEDOUT,
            message: 'Timed Out'
        });
    },
    onCompleteCbk: async function (jobInstance) { },
    options: {
        concurrency: 20,
        timeout: 30000
    }
};
exports.default = () => {
    schedules_manager_1.SchedulesManager.getInstance().defineJob(gateway_request_manager_1.ExecuteScene.name, jobDef);
};
//# sourceMappingURL=execute-scene.js.map