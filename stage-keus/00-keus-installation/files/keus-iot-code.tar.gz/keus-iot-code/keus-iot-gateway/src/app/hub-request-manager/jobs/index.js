"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const update_group_state_1 = __importDefault(require("./update-group-state"));
const execute_scene_1 = __importDefault(require("./execute-scene"));
const update_zigbee_ac_fan_controller_state_1 = __importDefault(require("./update-zigbee-ac-fan-controller-state"));
const update_zigbee_dc_fan_controller_state_1 = __importDefault(require("./update-zigbee-dc-fan-controller-state"));
const set_console_relay_state_1 = __importDefault(require("./set-console-relay-state"));
const update_zigbee_rgbwwa_state_1 = __importDefault(require("./update-zigbee-rgbwwa-state"));
const update_zigbee_curtain_controller_state_1 = __importDefault(require("./update-zigbee-curtain-controller-state"));
const blast_ir_command_1 = __importDefault(require("./blast-ir-command"));
const update_appliance_state_1 = __importDefault(require("./update-appliance-state"));
exports.default = () => {
    update_group_state_1.default();
    execute_scene_1.default();
    update_zigbee_ac_fan_controller_state_1.default();
    update_zigbee_dc_fan_controller_state_1.default();
    set_console_relay_state_1.default();
    update_zigbee_rgbwwa_state_1.default();
    update_zigbee_curtain_controller_state_1.default();
    blast_ir_command_1.default();
    update_appliance_state_1.default();
};
//# sourceMappingURL=index.js.map