"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_request_manager_1 = require("../../../models/job-models/gateway-request-manager");
const system_constants_1 = require("../../../constants/gateway/system-constants");
const rpc_maker_util_1 = require("../../../utilities/gateway/rpc-maker-util");
const smart_console_pb_1 = require("../protos/generated/hub/devices/smart_console_pb");
const schedules_manager_1 = require("../schedules-manager");
const smart_consoles_1 = require("../request-handlers/device-handlers/smart-consoles");
let jobDef = {
    jobHandler: async function (jobInstance) {
        let jobData = jobInstance.data;
        let jobId = jobInstance.id;
        try {
            await gateway_request_manager_1.SetConsoleRelayState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.SetConsoleRelayState.stage.REQUEST_PENDING,
                message: 'Job Execution Started'
            });
            const smartConsoleRelayAction = jobData.relayAction;
            const setConsoleRelayStateReq = new smart_console_pb_1.SetConsoleRelayState();
            setConsoleRelayStateReq.setDeviceId(smartConsoleRelayAction.deviceId);
            setConsoleRelayStateReq.setRelayId(smartConsoleRelayAction.relayId);
            setConsoleRelayStateReq.setRelayState(smartConsoleRelayAction.relayState);
            const setConsoleRelayStateResp = rpc_maker_util_1.UnPackFromAny(await smart_consoles_1.SetConsoleRelayState(setConsoleRelayStateReq, system_constants_1.SystemNumber));
            // const anyObj = new Any();
            // anyObj.pack(setConsoleRelayStateReq.serializeBinary(), ProtoPackageName + '.SetConsoleRelayState');
            // const setConsoleRelayStateResp: SetConsoleRelayStateResponse = await MakeAuthLocalRpc(anyObj);
            if (setConsoleRelayStateResp.getSuccess()) {
                await gateway_request_manager_1.SetConsoleRelayState.updateStatusFn(jobInstance, {
                    stage: gateway_request_manager_1.SetConsoleRelayState.stage.REQUEST_SUCCESS,
                    message: 'Job Execution Completed'
                });
            }
            else {
                throw setConsoleRelayStateResp.getMessage();
            }
            jobInstance.done(null);
        }
        catch (err) {
            console.log('Set Console Relay State Schedule Error:', err);
            await gateway_request_manager_1.SetConsoleRelayState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.SetConsoleRelayState.stage.REQUEST_FAILED,
                message: err
            });
            jobInstance.done(err);
        }
    },
    timeoutHandler: async function (jobInstance) {
        await gateway_request_manager_1.SetConsoleRelayState.updateStatusFn(jobInstance, {
            stage: gateway_request_manager_1.SetConsoleRelayState.stage.RESPONSE_TIMEDOUT,
            message: 'Timed Out'
        });
    },
    onCompleteCbk: async function (jobInstance) { },
    options: {
        concurrency: 20,
        timeout: 30000
    }
};
exports.default = () => {
    schedules_manager_1.SchedulesManager.getInstance().defineJob(gateway_request_manager_1.SetConsoleRelayState.name, jobDef);
};
//# sourceMappingURL=set-console-relay-state.js.map