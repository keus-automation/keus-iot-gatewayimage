"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_request_manager_1 = require("../../../models/job-models/gateway-request-manager");
const system_constants_1 = require("../../../constants/gateway/system-constants");
const rpc_maker_util_1 = require("../../../utilities/gateway/rpc-maker-util");
const schedules_manager_1 = require("../schedules-manager");
const zigbee_embedded_switch_pb_1 = require("../protos/generated/hub/devices/zigbee_embedded_switch_pb");
const device_constants_pb_1 = require("../protos/generated/hub/devices/device_constants_pb");
const errors_1 = require("../../../errors/errors");
const zigbee_embedded_switches_1 = require("../request-handlers/device-handlers/zigbee-embedded-switches");
let jobDef = {
    jobHandler: async function (jobInstance) {
        let jobData = jobInstance.data;
        let jobId = jobInstance.id;
        try {
            console.log("Update Appliance State Job Executing");
            await gateway_request_manager_1.UpdateApplianceState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateApplianceState.stage.REQUEST_PENDING,
                message: 'Job Execution Started'
            });
            const eApplianceAction = jobData.applianceAction;
            const updateApplianceStateReq = new zigbee_embedded_switch_pb_1.UpdateApplianceState();
            updateApplianceStateReq.setApplianceId(eApplianceAction.applianceId);
            updateApplianceStateReq.setDeviceId(eApplianceAction.deviceId);
            switch (eApplianceAction.applianceType) {
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                    const eOnOffApplianceState = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
                    const eOnOffApplianceInfo = eApplianceAction.applianceState;
                    eOnOffApplianceState.setSwitchState(eOnOffApplianceInfo.switchState);
                    updateApplianceStateReq.setOnOffState(eOnOffApplianceState);
                    break;
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                    const eFanApplianceState = new zigbee_embedded_switch_pb_1.FanApplianceState();
                    const eFanApplianceInfo = eApplianceAction.applianceState;
                    eFanApplianceState.setFanState(eFanApplianceInfo.fanState);
                    updateApplianceStateReq.setFanState(eFanApplianceState);
                    break;
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                    const eSingleDimmerApplianceState = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
                    const eSingleDimmerApplianceInfo = (eApplianceAction.applianceState);
                    eSingleDimmerApplianceState.setSwitchState(eSingleDimmerApplianceInfo.switchState);
                    updateApplianceStateReq.setSingleDimmerState(eSingleDimmerApplianceState);
                    break;
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                    const eColorTunableApplianceState = new zigbee_embedded_switch_pb_1.ColorTunableApplianceState();
                    const eColorTunableApplianceInfo = (eApplianceAction.applianceState);
                    eColorTunableApplianceState.setLightState(eColorTunableApplianceInfo.lightState);
                    eColorTunableApplianceState.setCoolWhiteState(eColorTunableApplianceInfo.coolWhiteState);
                    eColorTunableApplianceState.setWarmWhiteState(eColorTunableApplianceInfo.warmWhiteState);
                    updateApplianceStateReq.setColorTunableState(eColorTunableApplianceState);
                    break;
                default:
                    throw new errors_1.DeviceErrors.InvalidDeviceType();
            }
            const updateApplianceStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_embedded_switches_1.UpdateApplianceState(updateApplianceStateReq, system_constants_1.SystemNumber));
            // const anyObj = new Any();
            // anyObj.pack(updateApplianceStateReq.serializeBinary(), ProtoPackageName + '.UpdateApplianceState');
            // const updateApplianceStateResp: UpdateApplianceStateResponse = await MakeAuthLocalRpc(anyObj);
            if (updateApplianceStateResp.getSuccess()) {
                await gateway_request_manager_1.UpdateApplianceState.updateStatusFn(jobInstance, {
                    stage: gateway_request_manager_1.UpdateApplianceState.stage.REQUEST_SUCCESS,
                    message: 'Job Execution Completed'
                });
            }
            else {
                throw updateApplianceStateResp.getMessage();
            }
            jobInstance.done(null);
        }
        catch (err) {
            console.log('Update Group State Schedule Error:', err);
            await gateway_request_manager_1.UpdateApplianceState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateApplianceState.stage.REQUEST_FAILED,
                message: err
            });
            jobInstance.done(err);
        }
    },
    timeoutHandler: async function (jobInstance) {
        await gateway_request_manager_1.UpdateApplianceState.updateStatusFn(jobInstance, {
            stage: gateway_request_manager_1.UpdateApplianceState.stage.RESPONSE_TIMEDOUT,
            message: 'Timed Out'
        });
    },
    onCompleteCbk: async function (jobInstance) { },
    options: {
        concurrency: 20,
        timeout: 30000
    }
};
exports.default = () => {
    schedules_manager_1.SchedulesManager.getInstance().defineJob(gateway_request_manager_1.UpdateApplianceState.name, jobDef);
};
//# sourceMappingURL=update-appliance-state.js.map