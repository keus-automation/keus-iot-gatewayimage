"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_request_manager_1 = require("../../../models/job-models/gateway-request-manager");
const group_structures_pb_1 = require("../protos/generated/hub/groups/group_structures_pb");
const dali_dimmable_driver_pb_1 = require("../protos/generated/hub/devices/dali_dimmable_driver_pb");
const dali_nondimmable_driver_pb_1 = require("../protos/generated/hub/devices/dali_nondimmable_driver_pb");
const system_constants_1 = require("../../../constants/gateway/system-constants");
const rpc_maker_util_1 = require("../../../utilities/gateway/rpc-maker-util");
const schedules_manager_1 = require("../schedules-manager");
const zigbee_embedded_switch_pb_1 = require("../protos/generated/hub/devices/zigbee_embedded_switch_pb");
const group_handlers_1 = require("../request-handlers/group-handlers");
const zigbee_rgbwwa_driver_pb_1 = require("../protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const device_constants_pb_1 = require("../protos/generated/hub/devices/device_constants_pb");
const dali_color_tunable_driver_pb_1 = require("../protos/generated/hub/devices/dali_color_tunable_driver_pb");
let jobDef = {
    jobHandler: async function (jobInstance) {
        let jobData = jobInstance.data;
        let jobId = jobInstance.id;
        try {
            await gateway_request_manager_1.UpdateGroupState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateGroupState.stage.REQUEST_PENDING,
                message: 'Job Execution Started'
            });
            const updateGroupStateReq = new group_structures_pb_1.UpdateGroupState();
            updateGroupStateReq.setGroupId(jobData.groupId);
            updateGroupStateReq.setGroupRoom(jobData.groupRoom);
            switch (jobData.groupType) {
                case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
                    const daliDimmableState = new dali_dimmable_driver_pb_1.DaliDimmableDriverState();
                    const daliDimmableInfo = jobData.groupState;
                    daliDimmableState.setDriverState(daliDimmableInfo.driverState);
                    updateGroupStateReq.setDdimmableDriverState(daliDimmableState);
                    break;
                case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
                    const daliColorTunableState = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverState();
                    const daliCtInfo = jobData.groupState;
                    daliColorTunableState.setDriverState(daliCtInfo.driverState.driverState);
                    daliColorTunableState.setColorTemperature(daliCtInfo.driverState.colorTemperature);
                    daliColorTunableState.setLastUpdateBy(daliCtInfo.driverState.lastUpdateBy);
                    daliColorTunableState.setLastUpdateSource(daliCtInfo.driverState.lastUpdateSource);
                    daliColorTunableState.setLastUpdateTime(daliCtInfo.driverState.lastUpdateTime);
                    daliColorTunableState.setLastUpdateUser(daliCtInfo.driverState.lastUpdateUser);
                    updateGroupStateReq.setDcolortunableDriverState(daliColorTunableState);
                    break;
                case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
                    const zigbeeDimmableState = new dali_dimmable_driver_pb_1.DaliDimmableDriverState();
                    const zigbeeDimmableInfo = jobData.groupState;
                    zigbeeDimmableState.setDriverState(zigbeeDimmableInfo.driverState);
                    updateGroupStateReq.setZdimmableDriverState(zigbeeDimmableState);
                    break;
                case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
                    const daliNonDimmableState = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverState();
                    const daliNonDimmableInfo = jobData.groupState;
                    daliNonDimmableState.setDriverState(daliNonDimmableInfo.driverState);
                    updateGroupStateReq.setDnondimmableDriverState(daliNonDimmableState);
                    break;
                case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
                    const zigbeeNonDimmableState = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverState();
                    const zigbeeNonDimmableInfo = jobData.groupState;
                    zigbeeNonDimmableState.setDriverState(zigbeeNonDimmableInfo.driverState);
                    updateGroupStateReq.setZnondimmableDriverState(zigbeeNonDimmableState);
                    break;
                case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
                    const eApplianceOnOffState = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
                    const eApplianceOnOffInfo = jobData.groupState;
                    eApplianceOnOffState.setSwitchState(eApplianceOnOffInfo.switchState);
                    updateGroupStateReq.setAppOnffState(eApplianceOnOffState);
                    break;
                case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                    const eApplianceSDimmerState = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
                    const eApplianceSDimmerInfo = jobData.groupState;
                    eApplianceSDimmerState.setSwitchState(eApplianceSDimmerInfo.switchState);
                    updateGroupStateReq.setAppOnffState(eApplianceSDimmerState);
                    break;
                case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                    const eApplianceFanState = new zigbee_embedded_switch_pb_1.FanApplianceState();
                    const eApplianceFanInfo = jobData.groupState;
                    eApplianceFanState.setFanState(eApplianceFanInfo.fanState);
                    updateGroupStateReq.setAppFanState(eApplianceFanState);
                    break;
                case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                    const eApplianceColorTunableState = new zigbee_embedded_switch_pb_1.ColorTunableApplianceState();
                    const eApplianceColorTunableInfo = jobData.groupState;
                    eApplianceColorTunableState.setLightState(eApplianceColorTunableInfo.lightState);
                    eApplianceColorTunableState.setCoolWhiteState(eApplianceColorTunableInfo.coolWhiteState);
                    eApplianceColorTunableState.setWarmWhiteState(eApplianceColorTunableInfo.warmWhiteState);
                    updateGroupStateReq.setAppColorTunableState(eApplianceColorTunableState);
                    break;
                case group_structures_pb_1.GROUP_TYPES.RGBWWA:
                    const grpRgbwwaState = new zigbee_rgbwwa_driver_pb_1.GroupZigbeeRgbwwaState();
                    const grpDbRgbwwaState = jobData.groupState;
                    grpRgbwwaState.setUpdateType(grpDbRgbwwaState.updateType);
                    grpRgbwwaState.setDeviceState(grpDbRgbwwaState.deviceState);
                    switch (grpDbRgbwwaState.updateType) {
                        case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE:
                            const rgbUpdate = new zigbee_rgbwwa_driver_pb_1.RGB();
                            rgbUpdate.setDeviceState(grpDbRgbwwaState.rgbState.deviceState);
                            rgbUpdate.setBlue(grpDbRgbwwaState.rgbState.blue);
                            rgbUpdate.setRed(grpDbRgbwwaState.rgbState.red);
                            rgbUpdate.setGreen(grpDbRgbwwaState.rgbState.green);
                            rgbUpdate.setPattern(grpDbRgbwwaState.rgbState.pattern);
                            grpRgbwwaState.setRgbState(rgbUpdate);
                            break;
                        case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE:
                            const wwaUpdate = new zigbee_rgbwwa_driver_pb_1.WWA();
                            wwaUpdate.setDeviceState(grpDbRgbwwaState.wwaState.deviceState);
                            wwaUpdate.setAmber(grpDbRgbwwaState.wwaState.amber);
                            wwaUpdate.setCoolWhite(grpDbRgbwwaState.wwaState.coolWhite);
                            wwaUpdate.setWarmWhite(grpDbRgbwwaState.wwaState.warmWhite);
                            grpRgbwwaState.setWwaState(wwaUpdate);
                            break;
                    }
                    updateGroupStateReq.setZrgbwwaState(grpRgbwwaState);
                    break;
            }
            const updateGroupResp = rpc_maker_util_1.UnPackFromAny(await group_handlers_1.UpdateGroupState(updateGroupStateReq, system_constants_1.SystemNumber));
            // const anyObj = new Any();
            // anyObj.pack(updateGroupStateReq.serializeBinary(), ProtoPackageName + '.UpdateGroupState');
            // const updateGroupResp: UpdateGroupStateResponse = await MakeAuthLocalRpc(anyObj);
            if (updateGroupResp.getSuccess()) {
                await gateway_request_manager_1.UpdateGroupState.updateStatusFn(jobInstance, {
                    stage: gateway_request_manager_1.UpdateGroupState.stage.REQUEST_SUCCESS,
                    message: 'Job Execution Completed'
                });
            }
            else {
                throw updateGroupResp.getMessage();
            }
            jobInstance.done(null);
        }
        catch (err) {
            console.log('Update Group State Schedule Error:', err);
            await gateway_request_manager_1.UpdateGroupState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateGroupState.stage.REQUEST_FAILED,
                message: err
            });
            jobInstance.done(err);
        }
    },
    timeoutHandler: async function (jobInstance) {
        await gateway_request_manager_1.UpdateGroupState.updateStatusFn(jobInstance, {
            stage: gateway_request_manager_1.UpdateGroupState.stage.RESPONSE_TIMEDOUT,
            message: 'Timed Out'
        });
    },
    onCompleteCbk: async function (jobInstance) { },
    options: {
        concurrency: 20,
        timeout: 30000
    }
};
exports.default = () => {
    schedules_manager_1.SchedulesManager.getInstance().defineJob(gateway_request_manager_1.UpdateGroupState.name, jobDef);
};
//# sourceMappingURL=update-group-state.js.map