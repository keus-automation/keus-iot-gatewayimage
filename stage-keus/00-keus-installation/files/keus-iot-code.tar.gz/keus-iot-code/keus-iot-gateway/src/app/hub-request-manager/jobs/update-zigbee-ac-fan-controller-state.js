"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_request_manager_1 = require("../../../models/job-models/gateway-request-manager");
const schedules_manager_1 = require("../schedules-manager");
const system_constants_1 = require("../../../constants/gateway/system-constants");
const rpc_maker_util_1 = require("../../../utilities/gateway/rpc-maker-util");
const zigbee_ac_fan_controller_pb_1 = require("../protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const zigbee_fan_controllers_1 = require("../request-handlers/device-handlers/zigbee-fan-controllers");
let jobDef = {
    jobHandler: async function (jobInstance) {
        console.log('----RUNNINNG THE AC FAN CONTROLLER JOBS HERE____', jobInstance.data);
        let jobData = jobInstance.data;
        let jobId = jobInstance.id;
        try {
            await gateway_request_manager_1.UpdateZigbeeACFanControllerState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateZigbeeACFanControllerState.stage.REQUEST_PENDING,
                message: 'Job Execution Started'
            });
            const updateZACFCStateReq = new zigbee_ac_fan_controller_pb_1.UpdateZigbeeACFanControllerState();
            updateZACFCStateReq.setDeviceId(jobData.deviceId);
            const zACFCState = jobData.deviceState;
            updateZACFCStateReq.setUpdateType(zACFCState.updateType);
            updateZACFCStateReq.setFanState(zACFCState.fanState);
            updateZACFCStateReq.setLightState(zACFCState.lightState);
            const updateZACFCStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_fan_controllers_1.UpdateZigbeeACFanControllerState(updateZACFCStateReq, system_constants_1.SystemNumber));
            // const updateZACFCStateResp: UpdateZigbeeACFanControllerStateResponse = await MakeAuthLocalRpc(anyObj);
            if (updateZACFCStateResp.getSuccess()) {
                await gateway_request_manager_1.UpdateZigbeeACFanControllerState.updateStatusFn(jobInstance, {
                    stage: gateway_request_manager_1.UpdateZigbeeACFanControllerState.stage.REQUEST_SUCCESS,
                    message: 'Job Execution Completed'
                });
            }
            else {
                throw updateZACFCStateResp.getMessage();
            }
            jobInstance.done(null);
        }
        catch (err) {
            console.log('Update ZACFC State Schedule Error:', err);
            await gateway_request_manager_1.UpdateZigbeeACFanControllerState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateZigbeeACFanControllerState.stage.REQUEST_FAILED,
                message: err
            });
            jobInstance.done(err);
        }
    },
    timeoutHandler: async function (jobInstance) {
        await gateway_request_manager_1.UpdateZigbeeACFanControllerState.updateStatusFn(jobInstance, {
            stage: gateway_request_manager_1.UpdateZigbeeACFanControllerState.stage.RESPONSE_TIMEDOUT,
            message: 'Timed Out'
        });
    },
    onCompleteCbk: async function (jobInstance) { },
    options: {
        concurrency: 20,
        timeout: 30000
    }
};
exports.default = () => {
    schedules_manager_1.SchedulesManager.getInstance().defineJob(gateway_request_manager_1.UpdateZigbeeACFanControllerState.name, jobDef);
};
//# sourceMappingURL=update-zigbee-ac-fan-controller-state.js.map