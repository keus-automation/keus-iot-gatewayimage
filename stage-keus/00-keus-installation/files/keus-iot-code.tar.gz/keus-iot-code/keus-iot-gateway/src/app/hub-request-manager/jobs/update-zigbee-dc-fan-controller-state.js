"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_request_manager_1 = require("../../../models/job-models/gateway-request-manager");
const system_constants_1 = require("../../../constants/gateway/system-constants");
const rpc_maker_util_1 = require("../../../utilities/gateway/rpc-maker-util");
const zigbee_dc_fan_controller_pb_1 = require("../protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const schedules_manager_1 = require("../schedules-manager");
const zigbee_fan_controllers_1 = require("../request-handlers/device-handlers/zigbee-fan-controllers");
let jobDef = {
    jobHandler: async function (jobInstance) {
        let jobData = jobInstance.data;
        let jobId = jobInstance.id;
        try {
            await gateway_request_manager_1.UpdateZigbeeDCFanControllerState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateZigbeeDCFanControllerState.stage.REQUEST_PENDING,
                message: 'Job Execution Started'
            });
            const updateZDCFCStateReq = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerState();
            updateZDCFCStateReq.setDeviceId(jobData.deviceId);
            const zDCFCState = jobData.deviceState;
            updateZDCFCStateReq.setUpdateType(zDCFCState.updateType);
            updateZDCFCStateReq.setFanState(zDCFCState.fanState);
            const lightState = new zigbee_dc_fan_controller_pb_1.DCFanControllerLightState();
            lightState.setLightState(zDCFCState.lightState ? zDCFCState.lightState.lightState : 0);
            lightState.setLightTemperature(zDCFCState.lightState ? zDCFCState.lightState.lightTemperature : 0);
            updateZDCFCStateReq.setLightState(lightState);
            const updateZDCFCStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_fan_controllers_1.UpdateZigbeeDCFanControllerState(updateZDCFCStateReq, system_constants_1.SystemNumber));
            // const anyObj = new Any();
            // anyObj.pack(updateZDCFCStateReq.serializeBinary(), ProtoPackageName + '.UpdateZigbeeDCFanControllerState');
            // const updateZDCFCStateResp: UpdateZigbeeDCFanControllerStateResponse = await MakeAuthLocalRpc(anyObj);
            if (updateZDCFCStateResp.getSuccess()) {
                await gateway_request_manager_1.UpdateZigbeeDCFanControllerState.updateStatusFn(jobInstance, {
                    stage: gateway_request_manager_1.UpdateZigbeeDCFanControllerState.stage.REQUEST_SUCCESS,
                    message: 'Job Execution Completed'
                });
            }
            else {
                throw updateZDCFCStateResp.getMessage();
            }
            jobInstance.done(null);
        }
        catch (err) {
            console.log('Update ZDCFC State Schedule Error:', err);
            await gateway_request_manager_1.UpdateZigbeeDCFanControllerState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateZigbeeDCFanControllerState.stage.REQUEST_FAILED,
                message: err
            });
            jobInstance.done(err);
        }
    },
    timeoutHandler: async function (jobInstance) {
        await gateway_request_manager_1.UpdateZigbeeDCFanControllerState.updateStatusFn(jobInstance, {
            stage: gateway_request_manager_1.UpdateZigbeeDCFanControllerState.stage.RESPONSE_TIMEDOUT,
            message: 'Timed Out'
        });
    },
    onCompleteCbk: async function (jobInstance) { },
    options: {
        concurrency: 20,
        timeout: 30000
    }
};
exports.default = () => {
    schedules_manager_1.SchedulesManager.getInstance().defineJob(gateway_request_manager_1.UpdateZigbeeDCFanControllerState.name, jobDef);
};
//# sourceMappingURL=update-zigbee-dc-fan-controller-state.js.map