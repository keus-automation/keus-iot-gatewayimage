"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_request_manager_1 = require("../../../models/job-models/gateway-request-manager");
const system_constants_1 = require("../../../constants/gateway/system-constants");
const rpc_maker_util_1 = require("../../../utilities/gateway/rpc-maker-util");
const zigbee_rgbwwa_driver_pb_1 = require("../protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const device_constants_pb_1 = require("../protos/generated/hub/devices/device_constants_pb");
const schedules_manager_1 = require("../schedules-manager");
const update_rgbwwa_state_1 = __importDefault(require("../request-handlers/device-handlers/zigbee-rgbwwa-drivers/update-rgbwwa-state"));
let jobDef = {
    jobHandler: async function (jobInstance) {
        let jobData = jobInstance.data;
        let jobId = jobInstance.id;
        try {
            await gateway_request_manager_1.UpdateZigbeeRGBWWAState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateZigbeeRGBWWAState.stage.REQUEST_PENDING,
                message: 'Job Execution Started'
            });
            const updateRGBWWAstateReq = new zigbee_rgbwwa_driver_pb_1.UpdateZigbeeRgbwwaState();
            const zRGBWWAAction = jobData.rgbwwaAction;
            updateRGBWWAstateReq.setDeviceId(zRGBWWAAction.deviceId);
            updateRGBWWAstateReq.setUpdateType(zRGBWWAAction.updateType);
            switch (zRGBWWAAction.updateType) {
                case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE:
                    const rgbUpdate = new zigbee_rgbwwa_driver_pb_1.RGB();
                    updateRGBWWAstateReq.setDeviceState(zRGBWWAAction.rgbState.deviceState);
                    rgbUpdate.setDeviceState(zRGBWWAAction.rgbState.deviceState);
                    rgbUpdate.setBlue(zRGBWWAAction.rgbState.blue);
                    rgbUpdate.setRed(zRGBWWAAction.rgbState.red);
                    rgbUpdate.setGreen(zRGBWWAAction.rgbState.green);
                    rgbUpdate.setPattern(zRGBWWAAction.rgbState.pattern);
                    updateRGBWWAstateReq.setRgbState(rgbUpdate);
                    break;
                case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE:
                    const wwaUpdate = new zigbee_rgbwwa_driver_pb_1.WWA();
                    updateRGBWWAstateReq.setDeviceState(zRGBWWAAction.wwaState.deviceState);
                    wwaUpdate.setDeviceState(zRGBWWAAction.wwaState.deviceState);
                    wwaUpdate.setAmber(zRGBWWAAction.wwaState.amber);
                    wwaUpdate.setCoolWhite(zRGBWWAAction.wwaState.coolWhite);
                    wwaUpdate.setWarmWhite(zRGBWWAAction.wwaState.warmWhite);
                    updateRGBWWAstateReq.setWwaState(wwaUpdate);
                    break;
            }
            console.log('THIS IS DEVICE STATE', updateRGBWWAstateReq.getDeviceState());
            const updateRGBWWAstateResp = rpc_maker_util_1.UnPackFromAny(await update_rgbwwa_state_1.default(updateRGBWWAstateReq, system_constants_1.SystemNumber));
            // const anyObj = new Any();
            // anyObj.pack(updateRGBWWAstateReq.serializeBinary(), ProtoPackageName + '.UpdateZigbeeRgbwwaState');
            // const updateRGBWWAstateResp: UpdateZigbeeRgbwwaStateResponse = await MakeAuthLocalRpc(anyObj);
            if (updateRGBWWAstateResp.getSuccess()) {
                await gateway_request_manager_1.UpdateZigbeeRGBWWAState.updateStatusFn(jobInstance, {
                    stage: gateway_request_manager_1.UpdateZigbeeRGBWWAState.stage.REQUEST_SUCCESS,
                    message: 'Job Execution Completed'
                });
            }
            else {
                throw updateRGBWWAstateResp.getMessage();
            }
            jobInstance.done(null);
        }
        catch (err) {
            console.log('Update ZRGBWWA State Schedule Error:', err);
            await gateway_request_manager_1.UpdateZigbeeRGBWWAState.updateStatusFn(jobInstance, {
                stage: gateway_request_manager_1.UpdateZigbeeRGBWWAState.stage.REQUEST_FAILED,
                message: err
            });
            jobInstance.done(err);
        }
    },
    timeoutHandler: async function (jobInstance) {
        await gateway_request_manager_1.UpdateZigbeeRGBWWAState.updateStatusFn(jobInstance, {
            stage: gateway_request_manager_1.UpdateZigbeeRGBWWAState.stage.RESPONSE_TIMEDOUT,
            message: 'Timed Out'
        });
    },
    onCompleteCbk: async function (jobInstance) { },
    options: {
        concurrency: 20,
        timeout: 30000
    }
};
exports.default = () => {
    schedules_manager_1.SchedulesManager.getInstance().defineJob(gateway_request_manager_1.UpdateZigbeeRGBWWAState.name, jobDef);
};
//# sourceMappingURL=update-zigbee-rgbwwa-state.js.map