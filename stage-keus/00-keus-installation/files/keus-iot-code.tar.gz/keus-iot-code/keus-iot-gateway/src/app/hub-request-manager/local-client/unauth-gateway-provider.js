"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const protoRpcRegistry = __importStar(require("../protos/proto-rpc-registry"));
const logger_service_1 = __importDefault(require("../../../services/logger-service"));
const system_constants_1 = require("../../../constants/gateway/system-constants");
const request_handlers_1 = require("../request-handlers");
const any_pb_1 = require("google-protobuf/google/protobuf/any_pb");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (requestType, requestData) => {
    console.log('came to gateway file');
    switch (requestType) {
        case protoRpcRegistry.GatewaySetupRpcTypes.ConfigureGateway:
            return await request_handlers_1.UnauthHandlers.ConfigureGateway(requestData);
            break;
        case protoRpcRegistry.GatewaySetupRpcTypes.GetGatewayStatus:
            return await request_handlers_1.UnauthHandlers.GetGatewayStatus(requestData);
            break;
        case protoRpcRegistry.GatewaySetupRpcTypes.ServiceLogin:
            return await request_handlers_1.UnauthHandlers.ServiceLogin(requestData);
            break;
        case protoRpcRegistry.userRpcTypes.TotpLogin:
            return await request_handlers_1.UnauthHandlers.TotpLogin(requestData);
            break;
        default:
            //default handler
            return new any_pb_1.Any();
    }
};
//# sourceMappingURL=unauth-gateway-provider.js.map