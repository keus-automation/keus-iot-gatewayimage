"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../constants/gateway/system-constants");
const communication_service_1 = __importDefault(require("../../configs/communication-service"));
const net = __importStar(require("net"));
class MDNSManager {
    constructor() {
        if (communication_service_1.default.mdns.useTcp) {
            this.mdns = require('mdns');
        }
        else {
        }
    }
    async start() {
        if (communication_service_1.default.mdns.useTcp) {
            await this.startTCPClient();
            await this.startTCPMDNSServer();
        }
        else {
            this.startNativeMDNS();
        }
    }
    async stop() {
        if (communication_service_1.default.mdns.useTcp) {
            await this.stopTCPMDNSServer();
        }
        else {
            this.stopNativeMDNS();
        }
    }
    async startTCPClient() {
        return new Promise((resolve, reject) => {
            this.tcpClient = new net.Socket();
            this.tcpClient.connect(communication_service_1.default.mdns.serverPort, communication_service_1.default.mdns.serverHost, () => {
                resolve({});
            });
            this.tcpClient.on('data', function (data) {
                console.log('Data ::: ', data);
            });
            this.tcpClient.on('close', function () {
                console.log('Connection Closed');
            });
        });
    }
    async startTCPMDNSServer() {
        let startMsg = {
            name: system_constants_1.MDNS.StartServerEvent,
            txtRecord: {
                gateway_id: '-',
                gateway_type: 'MAIN'
            }
        };
        this.tcpClient.write(JSON.stringify(startMsg));
    }
    async stopTCPMDNSServer() {
        if (this.tcpClient) {
            let stopMsg = {
                name: system_constants_1.MDNS.StopServerEvent
            };
            this.tcpClient.write(JSON.stringify(stopMsg));
        }
    }
    startNativeMDNS() {
        if (!communication_service_1.default.mdns.useTcp) {
            this.advertisement = this.mdns.createAdvertisement(this.mdns.tcp('http'), system_constants_1.MDNS.MDNSPort, {
                name: system_constants_1.MDNS.MDNSName,
                txtRecord: {
                    gateway_id: '-',
                    gateway_type: 'MAIN'
                }
            });
            console.log('Created ad');
            this.advertisement.start();
        }
    }
    stopNativeMDNS() {
        this.advertisement.stop();
    }
}
const mdnsManager = new MDNSManager();
exports.mdnsManager = mdnsManager;
//# sourceMappingURL=mdns-manager.js.map