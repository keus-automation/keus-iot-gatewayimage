// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=gateway_to_cloud_grpc_pb.js.map