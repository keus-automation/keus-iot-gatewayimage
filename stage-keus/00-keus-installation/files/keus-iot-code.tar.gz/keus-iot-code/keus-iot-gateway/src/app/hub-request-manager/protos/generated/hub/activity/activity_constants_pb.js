// source: hub/activity/activity_constants.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!
var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();
goog.exportSymbol('proto.com.keus.hub.ACTIVITY_SOURCE_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.REPORT_ACTIVITY_TYPES', null, global);
/**
 * @enum {number}
 */
proto.com.keus.hub.ACTIVITY_SOURCE_TYPES = {
    MANUAL_TRIGGER: 0,
    ANDROID_TRIGGER: 1,
    IOS_TRIGGER: 2,
    SCHEDULE_TRIGGER: 3,
    SCENE_TRIGGER: 4,
    SYSTEM_TRIGGER: 5,
    ALEXA_TRIGGER: 6,
    GOOGLEASSISTANT_TRIGGER: 7,
    DEVICESYNC_TRIGGER: 8,
    SCENESWITCH_TRIGGER: 9
};
/**
 * @enum {number}
 */
proto.com.keus.hub.REPORT_ACTIVITY_TYPES = {
    CURTAIN_DEVICE: 0,
    ACFAN_DEVICE: 1,
    DCFAN_DEVICE: 2,
    SCRELAY_DEVICE: 3,
    ESAPPL_DEVICE: 4,
    UPDATE_GROUP: 5,
    EXECUTE_SCENE: 6
};
goog.object.extend(exports, proto.com.keus.hub);
//# sourceMappingURL=activity_constants_pb.js.map