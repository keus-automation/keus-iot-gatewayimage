// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=activity_structures_grpc_pb.js.map