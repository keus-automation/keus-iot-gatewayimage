// source: hub/activity/activity_structures.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!
var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();
var hub_devices_zigbee_curtain_controller_pb = require('../../hub/devices/zigbee_curtain_controller_pb.js');
goog.object.extend(proto, hub_devices_zigbee_curtain_controller_pb);
var hub_devices_zigbee_dimmable_driver_pb = require('../../hub/devices/zigbee_dimmable_driver_pb.js');
goog.object.extend(proto, hub_devices_zigbee_dimmable_driver_pb);
var hub_devices_zigbee_nondimmable_driver_pb = require('../../hub/devices/zigbee_nondimmable_driver_pb.js');
goog.object.extend(proto, hub_devices_zigbee_nondimmable_driver_pb);
var hub_devices_dali_dimmable_driver_pb = require('../../hub/devices/dali_dimmable_driver_pb.js');
goog.object.extend(proto, hub_devices_dali_dimmable_driver_pb);
var hub_devices_dali_nondimmable_driver_pb = require('../../hub/devices/dali_nondimmable_driver_pb.js');
goog.object.extend(proto, hub_devices_dali_nondimmable_driver_pb);
var hub_devices_smart_console_pb = require('../../hub/devices/smart_console_pb.js');
goog.object.extend(proto, hub_devices_smart_console_pb);
var hub_devices_scene_wizard_pb = require('../../hub/devices/scene_wizard_pb.js');
goog.object.extend(proto, hub_devices_scene_wizard_pb);
var hub_devices_zigbee_embedded_switch_pb = require('../../hub/devices/zigbee_embedded_switch_pb.js');
goog.object.extend(proto, hub_devices_zigbee_embedded_switch_pb);
var hub_devices_zigbee_ac_fan_controller_pb = require('../../hub/devices/zigbee_ac_fan_controller_pb.js');
goog.object.extend(proto, hub_devices_zigbee_ac_fan_controller_pb);
var hub_devices_zigbee_dc_fan_controller_pb = require('../../hub/devices/zigbee_dc_fan_controller_pb.js');
goog.object.extend(proto, hub_devices_zigbee_dc_fan_controller_pb);
var hub_devices_zigbee_rgbwwa_driver_pb = require('../../hub/devices/zigbee_rgbwwa_driver_pb.js');
goog.object.extend(proto, hub_devices_zigbee_rgbwwa_driver_pb);
var hub_devices_zigbee_embedded_scene_switch_pb = require('../../hub/devices/zigbee_embedded_scene_switch_pb.js');
goog.object.extend(proto, hub_devices_zigbee_embedded_scene_switch_pb);
var hub_devices_zigbee_inline_dimmer_pb = require('../../hub/devices/zigbee_inline_dimmer_pb.js');
goog.object.extend(proto, hub_devices_zigbee_inline_dimmer_pb);
var hub_devices_device_constants_pb = require('../../hub/devices/device_constants_pb.js');
goog.object.extend(proto, hub_devices_device_constants_pb);
var hub_devices_zigbee_ir_blaster_pb = require('../../hub/devices/zigbee_ir_blaster_pb.js');
goog.object.extend(proto, hub_devices_zigbee_ir_blaster_pb);
var hub_scenes_scene_structures_pb = require('../../hub/scenes/scene_structures_pb.js');
goog.object.extend(proto, hub_scenes_scene_structures_pb);
var hub_groups_group_structures_pb = require('../../hub/groups/group_structures_pb.js');
goog.object.extend(proto, hub_groups_group_structures_pb);
var hub_activity_activity_constants_pb = require('../../hub/activity/activity_constants_pb.js');
goog.object.extend(proto, hub_activity_activity_constants_pb);
goog.exportSymbol('proto.com.keus.hub.ACTIVITY_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.AcFancontrollerActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.Activity', null, global);
goog.exportSymbol('proto.com.keus.hub.Activity.ActivityActionCase', null, global);
goog.exportSymbol('proto.com.keus.hub.ContactSensorActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.CurtainActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.DcFancontrollerActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.DeviceActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.DeviceActivityAction.DeviceActionCase', null, global);
goog.exportSymbol('proto.com.keus.hub.DriverActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.EmbeddedSwitchActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.GetActivityLog', null, global);
goog.exportSymbol('proto.com.keus.hub.GetActivityLogResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.GroupActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.GroupStateActivity', null, global);
goog.exportSymbol('proto.com.keus.hub.InlineDimmerActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.ReportSystemActivity', null, global);
goog.exportSymbol('proto.com.keus.hub.ReportSystemActivityResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.RgbwwaActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.SceneActivityAction', null, global);
goog.exportSymbol('proto.com.keus.hub.SystemActivity', null, global);
goog.exportSymbol('proto.com.keus.hub.SystemActivity.SystemActivityCase', null, global);
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.EmbeddedSwitchActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.EmbeddedSwitchActivityAction.displayName = 'proto.com.keus.hub.EmbeddedSwitchActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.RgbwwaActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.RgbwwaActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.RgbwwaActivityAction.displayName = 'proto.com.keus.hub.RgbwwaActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.DriverActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.DriverActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.DriverActivityAction.displayName = 'proto.com.keus.hub.DriverActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.CurtainActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.CurtainActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.CurtainActivityAction.displayName = 'proto.com.keus.hub.CurtainActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.ContactSensorActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.ContactSensorActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.ContactSensorActivityAction.displayName = 'proto.com.keus.hub.ContactSensorActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.AcFancontrollerActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.AcFancontrollerActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.AcFancontrollerActivityAction.displayName = 'proto.com.keus.hub.AcFancontrollerActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.DcFancontrollerActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.DcFancontrollerActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.DcFancontrollerActivityAction.displayName = 'proto.com.keus.hub.DcFancontrollerActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.InlineDimmerActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.InlineDimmerActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.InlineDimmerActivityAction.displayName = 'proto.com.keus.hub.InlineDimmerActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.DeviceActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, proto.com.keus.hub.DeviceActivityAction.oneofGroups_);
};
goog.inherits(proto.com.keus.hub.DeviceActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.DeviceActivityAction.displayName = 'proto.com.keus.hub.DeviceActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.SceneActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.SceneActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.SceneActivityAction.displayName = 'proto.com.keus.hub.SceneActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.GroupStateActivity = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.GroupStateActivity, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.GroupStateActivity.displayName = 'proto.com.keus.hub.GroupStateActivity';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.GroupActivityAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.GroupActivityAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.GroupActivityAction.displayName = 'proto.com.keus.hub.GroupActivityAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.Activity = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, proto.com.keus.hub.Activity.oneofGroups_);
};
goog.inherits(proto.com.keus.hub.Activity, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.Activity.displayName = 'proto.com.keus.hub.Activity';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.GetActivityLog = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.GetActivityLog, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.GetActivityLog.displayName = 'proto.com.keus.hub.GetActivityLog';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.GetActivityLogResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, proto.com.keus.hub.GetActivityLogResponse.repeatedFields_, null);
};
goog.inherits(proto.com.keus.hub.GetActivityLogResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.GetActivityLogResponse.displayName = 'proto.com.keus.hub.GetActivityLogResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.SystemActivity = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, proto.com.keus.hub.SystemActivity.oneofGroups_);
};
goog.inherits(proto.com.keus.hub.SystemActivity, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.SystemActivity.displayName = 'proto.com.keus.hub.SystemActivity';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.ReportSystemActivity = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, proto.com.keus.hub.ReportSystemActivity.repeatedFields_, null);
};
goog.inherits(proto.com.keus.hub.ReportSystemActivity, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.ReportSystemActivity.displayName = 'proto.com.keus.hub.ReportSystemActivity';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.ReportSystemActivityResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.ReportSystemActivityResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.ReportSystemActivityResponse.displayName = 'proto.com.keus.hub.ReportSystemActivityResponse';
}
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.EmbeddedSwitchActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.EmbeddedSwitchActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.EmbeddedSwitchActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.EmbeddedSwitchActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            switchId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            switchState: jspb.Message.getFieldWithDefault(msg, 2, 0),
            switchName: jspb.Message.getFieldWithDefault(msg, 3, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.EmbeddedSwitchActivityAction}
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.EmbeddedSwitchActivityAction;
    return proto.com.keus.hub.EmbeddedSwitchActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.EmbeddedSwitchActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.EmbeddedSwitchActivityAction}
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSwitchId(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSwitchState(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setSwitchName(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.EmbeddedSwitchActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.EmbeddedSwitchActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSwitchId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSwitchState();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getSwitchName();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
};
/**
 * optional int32 switch_id = 1;
 * @return {number}
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.prototype.getSwitchId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.EmbeddedSwitchActivityAction} returns this
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.prototype.setSwitchId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional int32 switch_state = 2;
 * @return {number}
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.prototype.getSwitchState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.EmbeddedSwitchActivityAction} returns this
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.prototype.setSwitchState = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string switch_name = 3;
 * @return {string}
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.prototype.getSwitchName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.EmbeddedSwitchActivityAction} returns this
 */
proto.com.keus.hub.EmbeddedSwitchActivityAction.prototype.setSwitchName = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.RgbwwaActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.RgbwwaActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.RgbwwaActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.RgbwwaActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            deviceState: jspb.Message.getFieldWithDefault(msg, 1, 0),
            red: jspb.Message.getFieldWithDefault(msg, 2, 0),
            green: jspb.Message.getFieldWithDefault(msg, 3, 0),
            blue: jspb.Message.getFieldWithDefault(msg, 4, 0),
            warmWhite: jspb.Message.getFieldWithDefault(msg, 5, 0),
            coolWhite: jspb.Message.getFieldWithDefault(msg, 6, 0),
            amber: jspb.Message.getFieldWithDefault(msg, 7, 0),
            pattern: jspb.Message.getFieldWithDefault(msg, 8, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.RgbwwaActivityAction}
 */
proto.com.keus.hub.RgbwwaActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.RgbwwaActivityAction;
    return proto.com.keus.hub.RgbwwaActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.RgbwwaActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.RgbwwaActivityAction}
 */
proto.com.keus.hub.RgbwwaActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setDeviceState(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setRed(value);
                break;
            case 3:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setGreen(value);
                break;
            case 4:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setBlue(value);
                break;
            case 5:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setWarmWhite(value);
                break;
            case 6:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCoolWhite(value);
                break;
            case 7:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setAmber(value);
                break;
            case 8:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setPattern(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.RgbwwaActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.RgbwwaActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.RgbwwaActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getDeviceState();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getRed();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getGreen();
    if (f !== 0) {
        writer.writeInt32(3, f);
    }
    f = message.getBlue();
    if (f !== 0) {
        writer.writeInt32(4, f);
    }
    f = message.getWarmWhite();
    if (f !== 0) {
        writer.writeInt32(5, f);
    }
    f = message.getCoolWhite();
    if (f !== 0) {
        writer.writeInt32(6, f);
    }
    f = message.getAmber();
    if (f !== 0) {
        writer.writeInt32(7, f);
    }
    f = message.getPattern();
    if (f !== 0) {
        writer.writeInt32(8, f);
    }
};
/**
 * optional int32 device_state = 1;
 * @return {number}
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.getDeviceState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RgbwwaActivityAction} returns this
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.setDeviceState = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional int32 red = 2;
 * @return {number}
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.getRed = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RgbwwaActivityAction} returns this
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.setRed = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional int32 green = 3;
 * @return {number}
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.getGreen = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RgbwwaActivityAction} returns this
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.setGreen = function (value) {
    return jspb.Message.setProto3IntField(this, 3, value);
};
/**
 * optional int32 blue = 4;
 * @return {number}
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.getBlue = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 4, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RgbwwaActivityAction} returns this
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.setBlue = function (value) {
    return jspb.Message.setProto3IntField(this, 4, value);
};
/**
 * optional int32 warm_white = 5;
 * @return {number}
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.getWarmWhite = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 5, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RgbwwaActivityAction} returns this
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.setWarmWhite = function (value) {
    return jspb.Message.setProto3IntField(this, 5, value);
};
/**
 * optional int32 cool_white = 6;
 * @return {number}
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.getCoolWhite = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 6, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RgbwwaActivityAction} returns this
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.setCoolWhite = function (value) {
    return jspb.Message.setProto3IntField(this, 6, value);
};
/**
 * optional int32 amber = 7;
 * @return {number}
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.getAmber = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 7, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RgbwwaActivityAction} returns this
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.setAmber = function (value) {
    return jspb.Message.setProto3IntField(this, 7, value);
};
/**
 * optional int32 pattern = 8;
 * @return {number}
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.getPattern = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 8, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RgbwwaActivityAction} returns this
 */
proto.com.keus.hub.RgbwwaActivityAction.prototype.setPattern = function (value) {
    return jspb.Message.setProto3IntField(this, 8, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.DriverActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.DriverActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.DriverActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.DriverActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            driverState: jspb.Message.getFieldWithDefault(msg, 1, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.DriverActivityAction}
 */
proto.com.keus.hub.DriverActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.DriverActivityAction;
    return proto.com.keus.hub.DriverActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.DriverActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.DriverActivityAction}
 */
proto.com.keus.hub.DriverActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setDriverState(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.DriverActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.DriverActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.DriverActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.DriverActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getDriverState();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
};
/**
 * optional int32 driver_state = 1;
 * @return {number}
 */
proto.com.keus.hub.DriverActivityAction.prototype.getDriverState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.DriverActivityAction} returns this
 */
proto.com.keus.hub.DriverActivityAction.prototype.setDriverState = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.CurtainActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.CurtainActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.CurtainActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.CurtainActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            curtainState: jspb.Message.getFieldWithDefault(msg, 1, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.CurtainActivityAction}
 */
proto.com.keus.hub.CurtainActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.CurtainActivityAction;
    return proto.com.keus.hub.CurtainActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.CurtainActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.CurtainActivityAction}
 */
proto.com.keus.hub.CurtainActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCurtainState(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.CurtainActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.CurtainActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.CurtainActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.CurtainActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getCurtainState();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
};
/**
 * optional int32 curtain_state = 1;
 * @return {number}
 */
proto.com.keus.hub.CurtainActivityAction.prototype.getCurtainState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.CurtainActivityAction} returns this
 */
proto.com.keus.hub.CurtainActivityAction.prototype.setCurtainState = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.ContactSensorActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.ContactSensorActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.ContactSensorActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.ContactSensorActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            deviceState: jspb.Message.getFieldWithDefault(msg, 1, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.ContactSensorActivityAction}
 */
proto.com.keus.hub.ContactSensorActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.ContactSensorActivityAction;
    return proto.com.keus.hub.ContactSensorActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.ContactSensorActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.ContactSensorActivityAction}
 */
proto.com.keus.hub.ContactSensorActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setDeviceState(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.ContactSensorActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.ContactSensorActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.ContactSensorActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.ContactSensorActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getDeviceState();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
};
/**
 * optional int32 device_state = 1;
 * @return {number}
 */
proto.com.keus.hub.ContactSensorActivityAction.prototype.getDeviceState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.ContactSensorActivityAction} returns this
 */
proto.com.keus.hub.ContactSensorActivityAction.prototype.setDeviceState = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.AcFancontrollerActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.AcFancontrollerActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.AcFancontrollerActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.AcFancontrollerActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            fanState: jspb.Message.getFieldWithDefault(msg, 1, 0),
            lightState: jspb.Message.getFieldWithDefault(msg, 2, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.AcFancontrollerActivityAction}
 */
proto.com.keus.hub.AcFancontrollerActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.AcFancontrollerActivityAction;
    return proto.com.keus.hub.AcFancontrollerActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.AcFancontrollerActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.AcFancontrollerActivityAction}
 */
proto.com.keus.hub.AcFancontrollerActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setFanState(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setLightState(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.AcFancontrollerActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.AcFancontrollerActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.AcFancontrollerActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.AcFancontrollerActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getFanState();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getLightState();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
};
/**
 * optional int32 fan_state = 1;
 * @return {number}
 */
proto.com.keus.hub.AcFancontrollerActivityAction.prototype.getFanState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AcFancontrollerActivityAction} returns this
 */
proto.com.keus.hub.AcFancontrollerActivityAction.prototype.setFanState = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional int32 light_state = 2;
 * @return {number}
 */
proto.com.keus.hub.AcFancontrollerActivityAction.prototype.getLightState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AcFancontrollerActivityAction} returns this
 */
proto.com.keus.hub.AcFancontrollerActivityAction.prototype.setLightState = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.DcFancontrollerActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.DcFancontrollerActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.DcFancontrollerActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.DcFancontrollerActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            fanState: jspb.Message.getFieldWithDefault(msg, 1, 0),
            lightState: jspb.Message.getFieldWithDefault(msg, 2, 0),
            lightTemperature: jspb.Message.getFieldWithDefault(msg, 3, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.DcFancontrollerActivityAction}
 */
proto.com.keus.hub.DcFancontrollerActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.DcFancontrollerActivityAction;
    return proto.com.keus.hub.DcFancontrollerActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.DcFancontrollerActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.DcFancontrollerActivityAction}
 */
proto.com.keus.hub.DcFancontrollerActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setFanState(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setLightState(value);
                break;
            case 3:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setLightTemperature(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.DcFancontrollerActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.DcFancontrollerActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.DcFancontrollerActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.DcFancontrollerActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getFanState();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getLightState();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getLightTemperature();
    if (f !== 0) {
        writer.writeInt32(3, f);
    }
};
/**
 * optional int32 fan_state = 1;
 * @return {number}
 */
proto.com.keus.hub.DcFancontrollerActivityAction.prototype.getFanState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.DcFancontrollerActivityAction} returns this
 */
proto.com.keus.hub.DcFancontrollerActivityAction.prototype.setFanState = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional int32 light_state = 2;
 * @return {number}
 */
proto.com.keus.hub.DcFancontrollerActivityAction.prototype.getLightState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.DcFancontrollerActivityAction} returns this
 */
proto.com.keus.hub.DcFancontrollerActivityAction.prototype.setLightState = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional int32 light_temperature = 3;
 * @return {number}
 */
proto.com.keus.hub.DcFancontrollerActivityAction.prototype.getLightTemperature = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.DcFancontrollerActivityAction} returns this
 */
proto.com.keus.hub.DcFancontrollerActivityAction.prototype.setLightTemperature = function (value) {
    return jspb.Message.setProto3IntField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.InlineDimmerActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.InlineDimmerActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.InlineDimmerActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.InlineDimmerActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            deviceState: jspb.Message.getFieldWithDefault(msg, 1, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.InlineDimmerActivityAction}
 */
proto.com.keus.hub.InlineDimmerActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.InlineDimmerActivityAction;
    return proto.com.keus.hub.InlineDimmerActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.InlineDimmerActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.InlineDimmerActivityAction}
 */
proto.com.keus.hub.InlineDimmerActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setDeviceState(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.InlineDimmerActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.InlineDimmerActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.InlineDimmerActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.InlineDimmerActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getDeviceState();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
};
/**
 * optional int32 device_state = 1;
 * @return {number}
 */
proto.com.keus.hub.InlineDimmerActivityAction.prototype.getDeviceState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.InlineDimmerActivityAction} returns this
 */
proto.com.keus.hub.InlineDimmerActivityAction.prototype.setDeviceState = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * Oneof group definitions for this message. Each group defines the field
 * numbers belonging to that group. When of these fields' value is set, all
 * other fields in the group are cleared. During deserialization, if multiple
 * fields are encountered for a group, only the last value seen will be kept.
 * @private {!Array<!Array<number>>}
 * @const
 */
proto.com.keus.hub.DeviceActivityAction.oneofGroups_ = [[21, 22, 23, 24, 25, 26, 27, 28]];
/**
 * @enum {number}
 */
proto.com.keus.hub.DeviceActivityAction.DeviceActionCase = {
    DEVICE_ACTION_NOT_SET: 0,
    INLINE_DIMMER_ACTIVITY: 21,
    DC_FAN_ACTIVITY: 22,
    AC_FAN_ACTIVITY: 23,
    CONTACT_SENSOR_ACTIVITY: 24,
    CURTAIN_ACTIVITY: 25,
    DRIVER_COMMON_ACTIVITY: 26,
    RGBWWA_ACTIVITY: 27,
    ES_ACTIVITY: 28
};
/**
 * @return {proto.com.keus.hub.DeviceActivityAction.DeviceActionCase}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDeviceActionCase = function () {
    return /** @type {proto.com.keus.hub.DeviceActivityAction.DeviceActionCase} */ (jspb.Message.computeOneofCase(this, proto.com.keus.hub.DeviceActivityAction.oneofGroups_[0]));
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.DeviceActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.DeviceActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.DeviceActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.DeviceActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            deviceId: jspb.Message.getFieldWithDefault(msg, 1, ""),
            deviceCategory: jspb.Message.getFieldWithDefault(msg, 2, ""),
            deviceName: jspb.Message.getFieldWithDefault(msg, 3, ""),
            deviceSection: jspb.Message.getFieldWithDefault(msg, 4, ""),
            deviceRoom: jspb.Message.getFieldWithDefault(msg, 5, ""),
            deviceRoomName: jspb.Message.getFieldWithDefault(msg, 6, ""),
            deviceArea: jspb.Message.getFieldWithDefault(msg, 7, 0),
            deviceSectionName: jspb.Message.getFieldWithDefault(msg, 8, ""),
            inlineDimmerActivity: (f = msg.getInlineDimmerActivity()) && proto.com.keus.hub.InlineDimmerActivityAction.toObject(includeInstance, f),
            dcFanActivity: (f = msg.getDcFanActivity()) && proto.com.keus.hub.DcFancontrollerActivityAction.toObject(includeInstance, f),
            acFanActivity: (f = msg.getAcFanActivity()) && proto.com.keus.hub.AcFancontrollerActivityAction.toObject(includeInstance, f),
            contactSensorActivity: (f = msg.getContactSensorActivity()) && proto.com.keus.hub.ContactSensorActivityAction.toObject(includeInstance, f),
            curtainActivity: (f = msg.getCurtainActivity()) && proto.com.keus.hub.CurtainActivityAction.toObject(includeInstance, f),
            driverCommonActivity: (f = msg.getDriverCommonActivity()) && proto.com.keus.hub.DriverActivityAction.toObject(includeInstance, f),
            rgbwwaActivity: (f = msg.getRgbwwaActivity()) && proto.com.keus.hub.RgbwwaActivityAction.toObject(includeInstance, f),
            esActivity: (f = msg.getEsActivity()) && proto.com.keus.hub.EmbeddedSwitchActivityAction.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.DeviceActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.DeviceActivityAction;
    return proto.com.keus.hub.DeviceActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.DeviceActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.DeviceActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {string} */ (reader.readString());
                msg.setDeviceId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setDeviceCategory(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setDeviceName(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setDeviceSection(value);
                break;
            case 5:
                var value = /** @type {string} */ (reader.readString());
                msg.setDeviceRoom(value);
                break;
            case 6:
                var value = /** @type {string} */ (reader.readString());
                msg.setDeviceRoomName(value);
                break;
            case 7:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setDeviceArea(value);
                break;
            case 8:
                var value = /** @type {string} */ (reader.readString());
                msg.setDeviceSectionName(value);
                break;
            case 21:
                var value = new proto.com.keus.hub.InlineDimmerActivityAction;
                reader.readMessage(value, proto.com.keus.hub.InlineDimmerActivityAction.deserializeBinaryFromReader);
                msg.setInlineDimmerActivity(value);
                break;
            case 22:
                var value = new proto.com.keus.hub.DcFancontrollerActivityAction;
                reader.readMessage(value, proto.com.keus.hub.DcFancontrollerActivityAction.deserializeBinaryFromReader);
                msg.setDcFanActivity(value);
                break;
            case 23:
                var value = new proto.com.keus.hub.AcFancontrollerActivityAction;
                reader.readMessage(value, proto.com.keus.hub.AcFancontrollerActivityAction.deserializeBinaryFromReader);
                msg.setAcFanActivity(value);
                break;
            case 24:
                var value = new proto.com.keus.hub.ContactSensorActivityAction;
                reader.readMessage(value, proto.com.keus.hub.ContactSensorActivityAction.deserializeBinaryFromReader);
                msg.setContactSensorActivity(value);
                break;
            case 25:
                var value = new proto.com.keus.hub.CurtainActivityAction;
                reader.readMessage(value, proto.com.keus.hub.CurtainActivityAction.deserializeBinaryFromReader);
                msg.setCurtainActivity(value);
                break;
            case 26:
                var value = new proto.com.keus.hub.DriverActivityAction;
                reader.readMessage(value, proto.com.keus.hub.DriverActivityAction.deserializeBinaryFromReader);
                msg.setDriverCommonActivity(value);
                break;
            case 27:
                var value = new proto.com.keus.hub.RgbwwaActivityAction;
                reader.readMessage(value, proto.com.keus.hub.RgbwwaActivityAction.deserializeBinaryFromReader);
                msg.setRgbwwaActivity(value);
                break;
            case 28:
                var value = new proto.com.keus.hub.EmbeddedSwitchActivityAction;
                reader.readMessage(value, proto.com.keus.hub.EmbeddedSwitchActivityAction.deserializeBinaryFromReader);
                msg.setEsActivity(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.DeviceActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.DeviceActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.DeviceActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getDeviceId();
    if (f.length > 0) {
        writer.writeString(1, f);
    }
    f = message.getDeviceCategory();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getDeviceName();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getDeviceSection();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
    f = message.getDeviceRoom();
    if (f.length > 0) {
        writer.writeString(5, f);
    }
    f = message.getDeviceRoomName();
    if (f.length > 0) {
        writer.writeString(6, f);
    }
    f = message.getDeviceArea();
    if (f !== 0) {
        writer.writeInt32(7, f);
    }
    f = message.getDeviceSectionName();
    if (f.length > 0) {
        writer.writeString(8, f);
    }
    f = message.getInlineDimmerActivity();
    if (f != null) {
        writer.writeMessage(21, f, proto.com.keus.hub.InlineDimmerActivityAction.serializeBinaryToWriter);
    }
    f = message.getDcFanActivity();
    if (f != null) {
        writer.writeMessage(22, f, proto.com.keus.hub.DcFancontrollerActivityAction.serializeBinaryToWriter);
    }
    f = message.getAcFanActivity();
    if (f != null) {
        writer.writeMessage(23, f, proto.com.keus.hub.AcFancontrollerActivityAction.serializeBinaryToWriter);
    }
    f = message.getContactSensorActivity();
    if (f != null) {
        writer.writeMessage(24, f, proto.com.keus.hub.ContactSensorActivityAction.serializeBinaryToWriter);
    }
    f = message.getCurtainActivity();
    if (f != null) {
        writer.writeMessage(25, f, proto.com.keus.hub.CurtainActivityAction.serializeBinaryToWriter);
    }
    f = message.getDriverCommonActivity();
    if (f != null) {
        writer.writeMessage(26, f, proto.com.keus.hub.DriverActivityAction.serializeBinaryToWriter);
    }
    f = message.getRgbwwaActivity();
    if (f != null) {
        writer.writeMessage(27, f, proto.com.keus.hub.RgbwwaActivityAction.serializeBinaryToWriter);
    }
    f = message.getEsActivity();
    if (f != null) {
        writer.writeMessage(28, f, proto.com.keus.hub.EmbeddedSwitchActivityAction.serializeBinaryToWriter);
    }
};
/**
 * optional string device_id = 1;
 * @return {string}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDeviceId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.setDeviceId = function (value) {
    return jspb.Message.setProto3StringField(this, 1, value);
};
/**
 * optional string device_category = 2;
 * @return {string}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDeviceCategory = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.setDeviceCategory = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional string device_name = 3;
 * @return {string}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDeviceName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.setDeviceName = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional string device_section = 4;
 * @return {string}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDeviceSection = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.setDeviceSection = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
/**
 * optional string device_room = 5;
 * @return {string}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDeviceRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.setDeviceRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 5, value);
};
/**
 * optional string device_room_name = 6;
 * @return {string}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDeviceRoomName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 6, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.setDeviceRoomName = function (value) {
    return jspb.Message.setProto3StringField(this, 6, value);
};
/**
 * optional int32 device_area = 7;
 * @return {number}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDeviceArea = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 7, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.setDeviceArea = function (value) {
    return jspb.Message.setProto3IntField(this, 7, value);
};
/**
 * optional string device_section_name = 8;
 * @return {string}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDeviceSectionName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 8, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.setDeviceSectionName = function (value) {
    return jspb.Message.setProto3StringField(this, 8, value);
};
/**
 * optional InlineDimmerActivityAction inline_dimmer_activity = 21;
 * @return {?proto.com.keus.hub.InlineDimmerActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getInlineDimmerActivity = function () {
    return /** @type{?proto.com.keus.hub.InlineDimmerActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.InlineDimmerActivityAction, 21));
};
/**
 * @param {?proto.com.keus.hub.InlineDimmerActivityAction|undefined} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
*/
proto.com.keus.hub.DeviceActivityAction.prototype.setInlineDimmerActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 21, proto.com.keus.hub.DeviceActivityAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.clearInlineDimmerActivity = function () {
    return this.setInlineDimmerActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.hasInlineDimmerActivity = function () {
    return jspb.Message.getField(this, 21) != null;
};
/**
 * optional DcFancontrollerActivityAction dc_fan_activity = 22;
 * @return {?proto.com.keus.hub.DcFancontrollerActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDcFanActivity = function () {
    return /** @type{?proto.com.keus.hub.DcFancontrollerActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.DcFancontrollerActivityAction, 22));
};
/**
 * @param {?proto.com.keus.hub.DcFancontrollerActivityAction|undefined} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
*/
proto.com.keus.hub.DeviceActivityAction.prototype.setDcFanActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 22, proto.com.keus.hub.DeviceActivityAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.clearDcFanActivity = function () {
    return this.setDcFanActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.hasDcFanActivity = function () {
    return jspb.Message.getField(this, 22) != null;
};
/**
 * optional AcFancontrollerActivityAction ac_fan_activity = 23;
 * @return {?proto.com.keus.hub.AcFancontrollerActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getAcFanActivity = function () {
    return /** @type{?proto.com.keus.hub.AcFancontrollerActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.AcFancontrollerActivityAction, 23));
};
/**
 * @param {?proto.com.keus.hub.AcFancontrollerActivityAction|undefined} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
*/
proto.com.keus.hub.DeviceActivityAction.prototype.setAcFanActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 23, proto.com.keus.hub.DeviceActivityAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.clearAcFanActivity = function () {
    return this.setAcFanActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.hasAcFanActivity = function () {
    return jspb.Message.getField(this, 23) != null;
};
/**
 * optional ContactSensorActivityAction contact_sensor_activity = 24;
 * @return {?proto.com.keus.hub.ContactSensorActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getContactSensorActivity = function () {
    return /** @type{?proto.com.keus.hub.ContactSensorActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.ContactSensorActivityAction, 24));
};
/**
 * @param {?proto.com.keus.hub.ContactSensorActivityAction|undefined} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
*/
proto.com.keus.hub.DeviceActivityAction.prototype.setContactSensorActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 24, proto.com.keus.hub.DeviceActivityAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.clearContactSensorActivity = function () {
    return this.setContactSensorActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.hasContactSensorActivity = function () {
    return jspb.Message.getField(this, 24) != null;
};
/**
 * optional CurtainActivityAction curtain_activity = 25;
 * @return {?proto.com.keus.hub.CurtainActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getCurtainActivity = function () {
    return /** @type{?proto.com.keus.hub.CurtainActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.CurtainActivityAction, 25));
};
/**
 * @param {?proto.com.keus.hub.CurtainActivityAction|undefined} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
*/
proto.com.keus.hub.DeviceActivityAction.prototype.setCurtainActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 25, proto.com.keus.hub.DeviceActivityAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.clearCurtainActivity = function () {
    return this.setCurtainActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.hasCurtainActivity = function () {
    return jspb.Message.getField(this, 25) != null;
};
/**
 * optional DriverActivityAction driver_common_activity = 26;
 * @return {?proto.com.keus.hub.DriverActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getDriverCommonActivity = function () {
    return /** @type{?proto.com.keus.hub.DriverActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.DriverActivityAction, 26));
};
/**
 * @param {?proto.com.keus.hub.DriverActivityAction|undefined} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
*/
proto.com.keus.hub.DeviceActivityAction.prototype.setDriverCommonActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 26, proto.com.keus.hub.DeviceActivityAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.clearDriverCommonActivity = function () {
    return this.setDriverCommonActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.hasDriverCommonActivity = function () {
    return jspb.Message.getField(this, 26) != null;
};
/**
 * optional RgbwwaActivityAction rgbwwa_activity = 27;
 * @return {?proto.com.keus.hub.RgbwwaActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getRgbwwaActivity = function () {
    return /** @type{?proto.com.keus.hub.RgbwwaActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.RgbwwaActivityAction, 27));
};
/**
 * @param {?proto.com.keus.hub.RgbwwaActivityAction|undefined} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
*/
proto.com.keus.hub.DeviceActivityAction.prototype.setRgbwwaActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 27, proto.com.keus.hub.DeviceActivityAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.clearRgbwwaActivity = function () {
    return this.setRgbwwaActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.hasRgbwwaActivity = function () {
    return jspb.Message.getField(this, 27) != null;
};
/**
 * optional EmbeddedSwitchActivityAction es_activity = 28;
 * @return {?proto.com.keus.hub.EmbeddedSwitchActivityAction}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.getEsActivity = function () {
    return /** @type{?proto.com.keus.hub.EmbeddedSwitchActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.EmbeddedSwitchActivityAction, 28));
};
/**
 * @param {?proto.com.keus.hub.EmbeddedSwitchActivityAction|undefined} value
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
*/
proto.com.keus.hub.DeviceActivityAction.prototype.setEsActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 28, proto.com.keus.hub.DeviceActivityAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.DeviceActivityAction} returns this
 */
proto.com.keus.hub.DeviceActivityAction.prototype.clearEsActivity = function () {
    return this.setEsActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.DeviceActivityAction.prototype.hasEsActivity = function () {
    return jspb.Message.getField(this, 28) != null;
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.SceneActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.SceneActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.SceneActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.SceneActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneName: jspb.Message.getFieldWithDefault(msg, 2, ""),
            sceneType: jspb.Message.getFieldWithDefault(msg, 3, 0),
            sceneSection: jspb.Message.getFieldWithDefault(msg, 4, ""),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 5, ""),
            sceneRoomName: jspb.Message.getFieldWithDefault(msg, 6, ""),
            sceneArea: jspb.Message.getFieldWithDefault(msg, 7, 0),
            sceneSectionName: jspb.Message.getFieldWithDefault(msg, 8, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.SceneActivityAction}
 */
proto.com.keus.hub.SceneActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.SceneActivityAction;
    return proto.com.keus.hub.SceneActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.SceneActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.SceneActivityAction}
 */
proto.com.keus.hub.SceneActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneName(value);
                break;
            case 3:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setSceneType(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneSection(value);
                break;
            case 5:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 6:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoomName(value);
                break;
            case 7:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setSceneArea(value);
                break;
            case 8:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneSectionName(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.SceneActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.SceneActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.SceneActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.SceneActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeUint32(1, f);
    }
    f = message.getSceneName();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getSceneType();
    if (f !== 0) {
        writer.writeUint32(3, f);
    }
    f = message.getSceneSection();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(5, f);
    }
    f = message.getSceneRoomName();
    if (f.length > 0) {
        writer.writeString(6, f);
    }
    f = message.getSceneArea();
    if (f !== 0) {
        writer.writeUint32(7, f);
    }
    f = message.getSceneSectionName();
    if (f.length > 0) {
        writer.writeString(8, f);
    }
};
/**
 * optional uint32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.SceneActivityAction.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SceneActivityAction} returns this
 */
proto.com.keus.hub.SceneActivityAction.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_name = 2;
 * @return {string}
 */
proto.com.keus.hub.SceneActivityAction.prototype.getSceneName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneActivityAction} returns this
 */
proto.com.keus.hub.SceneActivityAction.prototype.setSceneName = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional uint32 scene_type = 3;
 * @return {number}
 */
proto.com.keus.hub.SceneActivityAction.prototype.getSceneType = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SceneActivityAction} returns this
 */
proto.com.keus.hub.SceneActivityAction.prototype.setSceneType = function (value) {
    return jspb.Message.setProto3IntField(this, 3, value);
};
/**
 * optional string scene_section = 4;
 * @return {string}
 */
proto.com.keus.hub.SceneActivityAction.prototype.getSceneSection = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneActivityAction} returns this
 */
proto.com.keus.hub.SceneActivityAction.prototype.setSceneSection = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
/**
 * optional string scene_room = 5;
 * @return {string}
 */
proto.com.keus.hub.SceneActivityAction.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneActivityAction} returns this
 */
proto.com.keus.hub.SceneActivityAction.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 5, value);
};
/**
 * optional string scene_room_name = 6;
 * @return {string}
 */
proto.com.keus.hub.SceneActivityAction.prototype.getSceneRoomName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 6, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneActivityAction} returns this
 */
proto.com.keus.hub.SceneActivityAction.prototype.setSceneRoomName = function (value) {
    return jspb.Message.setProto3StringField(this, 6, value);
};
/**
 * optional uint32 scene_area = 7;
 * @return {number}
 */
proto.com.keus.hub.SceneActivityAction.prototype.getSceneArea = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 7, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SceneActivityAction} returns this
 */
proto.com.keus.hub.SceneActivityAction.prototype.setSceneArea = function (value) {
    return jspb.Message.setProto3IntField(this, 7, value);
};
/**
 * optional string scene_section_name = 8;
 * @return {string}
 */
proto.com.keus.hub.SceneActivityAction.prototype.getSceneSectionName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 8, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneActivityAction} returns this
 */
proto.com.keus.hub.SceneActivityAction.prototype.setSceneSectionName = function (value) {
    return jspb.Message.setProto3StringField(this, 8, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.GroupStateActivity.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.GroupStateActivity.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.GroupStateActivity} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.GroupStateActivity.toObject = function (includeInstance, msg) {
        var f, obj = {
            driverState: jspb.Message.getFieldWithDefault(msg, 1, 0),
            red: jspb.Message.getFieldWithDefault(msg, 2, 0),
            green: jspb.Message.getFieldWithDefault(msg, 3, 0),
            blue: jspb.Message.getFieldWithDefault(msg, 4, 0),
            warmWhite: jspb.Message.getFieldWithDefault(msg, 5, 0),
            coolWhite: jspb.Message.getFieldWithDefault(msg, 6, 0),
            amber: jspb.Message.getFieldWithDefault(msg, 7, 0),
            pattern: jspb.Message.getFieldWithDefault(msg, 8, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.GroupStateActivity}
 */
proto.com.keus.hub.GroupStateActivity.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.GroupStateActivity;
    return proto.com.keus.hub.GroupStateActivity.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.GroupStateActivity} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.GroupStateActivity}
 */
proto.com.keus.hub.GroupStateActivity.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setDriverState(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setRed(value);
                break;
            case 3:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setGreen(value);
                break;
            case 4:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setBlue(value);
                break;
            case 5:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setWarmWhite(value);
                break;
            case 6:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCoolWhite(value);
                break;
            case 7:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setAmber(value);
                break;
            case 8:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setPattern(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.GroupStateActivity.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.GroupStateActivity.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.GroupStateActivity} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.GroupStateActivity.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getDriverState();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getRed();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getGreen();
    if (f !== 0) {
        writer.writeInt32(3, f);
    }
    f = message.getBlue();
    if (f !== 0) {
        writer.writeInt32(4, f);
    }
    f = message.getWarmWhite();
    if (f !== 0) {
        writer.writeInt32(5, f);
    }
    f = message.getCoolWhite();
    if (f !== 0) {
        writer.writeInt32(6, f);
    }
    f = message.getAmber();
    if (f !== 0) {
        writer.writeInt32(7, f);
    }
    f = message.getPattern();
    if (f !== 0) {
        writer.writeInt32(8, f);
    }
};
/**
 * optional int32 driver_state = 1;
 * @return {number}
 */
proto.com.keus.hub.GroupStateActivity.prototype.getDriverState = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupStateActivity} returns this
 */
proto.com.keus.hub.GroupStateActivity.prototype.setDriverState = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional int32 red = 2;
 * @return {number}
 */
proto.com.keus.hub.GroupStateActivity.prototype.getRed = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupStateActivity} returns this
 */
proto.com.keus.hub.GroupStateActivity.prototype.setRed = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional int32 green = 3;
 * @return {number}
 */
proto.com.keus.hub.GroupStateActivity.prototype.getGreen = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupStateActivity} returns this
 */
proto.com.keus.hub.GroupStateActivity.prototype.setGreen = function (value) {
    return jspb.Message.setProto3IntField(this, 3, value);
};
/**
 * optional int32 blue = 4;
 * @return {number}
 */
proto.com.keus.hub.GroupStateActivity.prototype.getBlue = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 4, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupStateActivity} returns this
 */
proto.com.keus.hub.GroupStateActivity.prototype.setBlue = function (value) {
    return jspb.Message.setProto3IntField(this, 4, value);
};
/**
 * optional int32 warm_white = 5;
 * @return {number}
 */
proto.com.keus.hub.GroupStateActivity.prototype.getWarmWhite = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 5, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupStateActivity} returns this
 */
proto.com.keus.hub.GroupStateActivity.prototype.setWarmWhite = function (value) {
    return jspb.Message.setProto3IntField(this, 5, value);
};
/**
 * optional int32 cool_white = 6;
 * @return {number}
 */
proto.com.keus.hub.GroupStateActivity.prototype.getCoolWhite = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 6, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupStateActivity} returns this
 */
proto.com.keus.hub.GroupStateActivity.prototype.setCoolWhite = function (value) {
    return jspb.Message.setProto3IntField(this, 6, value);
};
/**
 * optional int32 amber = 7;
 * @return {number}
 */
proto.com.keus.hub.GroupStateActivity.prototype.getAmber = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 7, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupStateActivity} returns this
 */
proto.com.keus.hub.GroupStateActivity.prototype.setAmber = function (value) {
    return jspb.Message.setProto3IntField(this, 7, value);
};
/**
 * optional int32 pattern = 8;
 * @return {number}
 */
proto.com.keus.hub.GroupStateActivity.prototype.getPattern = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 8, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupStateActivity} returns this
 */
proto.com.keus.hub.GroupStateActivity.prototype.setPattern = function (value) {
    return jspb.Message.setProto3IntField(this, 8, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.GroupActivityAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.GroupActivityAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.GroupActivityAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.GroupActivityAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            groupId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            groupState: (f = msg.getGroupState()) && proto.com.keus.hub.GroupStateActivity.toObject(includeInstance, f),
            groupName: jspb.Message.getFieldWithDefault(msg, 3, ""),
            groupRoom: jspb.Message.getFieldWithDefault(msg, 4, ""),
            groupSection: jspb.Message.getFieldWithDefault(msg, 5, ""),
            groupType: jspb.Message.getFieldWithDefault(msg, 6, 0),
            groupRoomName: jspb.Message.getFieldWithDefault(msg, 7, ""),
            groupArea: jspb.Message.getFieldWithDefault(msg, 8, 0),
            groupSectionName: jspb.Message.getFieldWithDefault(msg, 9, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.GroupActivityAction}
 */
proto.com.keus.hub.GroupActivityAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.GroupActivityAction;
    return proto.com.keus.hub.GroupActivityAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.GroupActivityAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.GroupActivityAction}
 */
proto.com.keus.hub.GroupActivityAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setGroupId(value);
                break;
            case 2:
                var value = new proto.com.keus.hub.GroupStateActivity;
                reader.readMessage(value, proto.com.keus.hub.GroupStateActivity.deserializeBinaryFromReader);
                msg.setGroupState(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setGroupName(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setGroupRoom(value);
                break;
            case 5:
                var value = /** @type {string} */ (reader.readString());
                msg.setGroupSection(value);
                break;
            case 6:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setGroupType(value);
                break;
            case 7:
                var value = /** @type {string} */ (reader.readString());
                msg.setGroupRoomName(value);
                break;
            case 8:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setGroupArea(value);
                break;
            case 9:
                var value = /** @type {string} */ (reader.readString());
                msg.setGroupSectionName(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.GroupActivityAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.GroupActivityAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.GroupActivityAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.GroupActivityAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getGroupId();
    if (f !== 0) {
        writer.writeUint32(1, f);
    }
    f = message.getGroupState();
    if (f != null) {
        writer.writeMessage(2, f, proto.com.keus.hub.GroupStateActivity.serializeBinaryToWriter);
    }
    f = message.getGroupName();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getGroupRoom();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
    f = message.getGroupSection();
    if (f.length > 0) {
        writer.writeString(5, f);
    }
    f = message.getGroupType();
    if (f !== 0) {
        writer.writeUint32(6, f);
    }
    f = message.getGroupRoomName();
    if (f.length > 0) {
        writer.writeString(7, f);
    }
    f = message.getGroupArea();
    if (f !== 0) {
        writer.writeUint32(8, f);
    }
    f = message.getGroupSectionName();
    if (f.length > 0) {
        writer.writeString(9, f);
    }
};
/**
 * optional uint32 group_id = 1;
 * @return {number}
 */
proto.com.keus.hub.GroupActivityAction.prototype.getGroupId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
 */
proto.com.keus.hub.GroupActivityAction.prototype.setGroupId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional GroupStateActivity group_state = 2;
 * @return {?proto.com.keus.hub.GroupStateActivity}
 */
proto.com.keus.hub.GroupActivityAction.prototype.getGroupState = function () {
    return /** @type{?proto.com.keus.hub.GroupStateActivity} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.GroupStateActivity, 2));
};
/**
 * @param {?proto.com.keus.hub.GroupStateActivity|undefined} value
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
*/
proto.com.keus.hub.GroupActivityAction.prototype.setGroupState = function (value) {
    return jspb.Message.setWrapperField(this, 2, value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
 */
proto.com.keus.hub.GroupActivityAction.prototype.clearGroupState = function () {
    return this.setGroupState(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.GroupActivityAction.prototype.hasGroupState = function () {
    return jspb.Message.getField(this, 2) != null;
};
/**
 * optional string group_name = 3;
 * @return {string}
 */
proto.com.keus.hub.GroupActivityAction.prototype.getGroupName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
 */
proto.com.keus.hub.GroupActivityAction.prototype.setGroupName = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional string group_room = 4;
 * @return {string}
 */
proto.com.keus.hub.GroupActivityAction.prototype.getGroupRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
 */
proto.com.keus.hub.GroupActivityAction.prototype.setGroupRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
/**
 * optional string group_section = 5;
 * @return {string}
 */
proto.com.keus.hub.GroupActivityAction.prototype.getGroupSection = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
 */
proto.com.keus.hub.GroupActivityAction.prototype.setGroupSection = function (value) {
    return jspb.Message.setProto3StringField(this, 5, value);
};
/**
 * optional uint32 group_type = 6;
 * @return {number}
 */
proto.com.keus.hub.GroupActivityAction.prototype.getGroupType = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 6, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
 */
proto.com.keus.hub.GroupActivityAction.prototype.setGroupType = function (value) {
    return jspb.Message.setProto3IntField(this, 6, value);
};
/**
 * optional string group_room_name = 7;
 * @return {string}
 */
proto.com.keus.hub.GroupActivityAction.prototype.getGroupRoomName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 7, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
 */
proto.com.keus.hub.GroupActivityAction.prototype.setGroupRoomName = function (value) {
    return jspb.Message.setProto3StringField(this, 7, value);
};
/**
 * optional uint32 group_area = 8;
 * @return {number}
 */
proto.com.keus.hub.GroupActivityAction.prototype.getGroupArea = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 8, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
 */
proto.com.keus.hub.GroupActivityAction.prototype.setGroupArea = function (value) {
    return jspb.Message.setProto3IntField(this, 8, value);
};
/**
 * optional string group_section_name = 9;
 * @return {string}
 */
proto.com.keus.hub.GroupActivityAction.prototype.getGroupSectionName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 9, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.GroupActivityAction} returns this
 */
proto.com.keus.hub.GroupActivityAction.prototype.setGroupSectionName = function (value) {
    return jspb.Message.setProto3StringField(this, 9, value);
};
/**
 * Oneof group definitions for this message. Each group defines the field
 * numbers belonging to that group. When of these fields' value is set, all
 * other fields in the group are cleared. During deserialization, if multiple
 * fields are encountered for a group, only the last value seen will be kept.
 * @private {!Array<!Array<number>>}
 * @const
 */
proto.com.keus.hub.Activity.oneofGroups_ = [[7, 8, 9]];
/**
 * @enum {number}
 */
proto.com.keus.hub.Activity.ActivityActionCase = {
    ACTIVITY_ACTION_NOT_SET: 0,
    DEVICE_ACTION: 7,
    SCENE_ACTION: 8,
    GROUP_ACTION: 9
};
/**
 * @return {proto.com.keus.hub.Activity.ActivityActionCase}
 */
proto.com.keus.hub.Activity.prototype.getActivityActionCase = function () {
    return /** @type {proto.com.keus.hub.Activity.ActivityActionCase} */ (jspb.Message.computeOneofCase(this, proto.com.keus.hub.Activity.oneofGroups_[0]));
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.Activity.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.Activity.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.Activity} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.Activity.toObject = function (includeInstance, msg) {
        var f, obj = {
            activityId: jspb.Message.getFieldWithDefault(msg, 1, ""),
            activitySource: jspb.Message.getFieldWithDefault(msg, 2, ""),
            activityBy: jspb.Message.getFieldWithDefault(msg, 3, ""),
            activityUsername: jspb.Message.getFieldWithDefault(msg, 4, ""),
            activityTime: jspb.Message.getFieldWithDefault(msg, 5, 0),
            activityType: jspb.Message.getFieldWithDefault(msg, 6, 0),
            deviceAction: (f = msg.getDeviceAction()) && proto.com.keus.hub.DeviceActivityAction.toObject(includeInstance, f),
            sceneAction: (f = msg.getSceneAction()) && proto.com.keus.hub.SceneActivityAction.toObject(includeInstance, f),
            groupAction: (f = msg.getGroupAction()) && proto.com.keus.hub.GroupActivityAction.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.Activity}
 */
proto.com.keus.hub.Activity.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.Activity;
    return proto.com.keus.hub.Activity.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.Activity} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.Activity}
 */
proto.com.keus.hub.Activity.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {string} */ (reader.readString());
                msg.setActivityId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setActivitySource(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setActivityBy(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setActivityUsername(value);
                break;
            case 5:
                var value = /** @type {number} */ (reader.readUint64());
                msg.setActivityTime(value);
                break;
            case 6:
                var value = /** @type {!proto.com.keus.hub.ACTIVITY_TYPES} */ (reader.readEnum());
                msg.setActivityType(value);
                break;
            case 7:
                var value = new proto.com.keus.hub.DeviceActivityAction;
                reader.readMessage(value, proto.com.keus.hub.DeviceActivityAction.deserializeBinaryFromReader);
                msg.setDeviceAction(value);
                break;
            case 8:
                var value = new proto.com.keus.hub.SceneActivityAction;
                reader.readMessage(value, proto.com.keus.hub.SceneActivityAction.deserializeBinaryFromReader);
                msg.setSceneAction(value);
                break;
            case 9:
                var value = new proto.com.keus.hub.GroupActivityAction;
                reader.readMessage(value, proto.com.keus.hub.GroupActivityAction.deserializeBinaryFromReader);
                msg.setGroupAction(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.Activity.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.Activity.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.Activity} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.Activity.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getActivityId();
    if (f.length > 0) {
        writer.writeString(1, f);
    }
    f = message.getActivitySource();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getActivityBy();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getActivityUsername();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
    f = message.getActivityTime();
    if (f !== 0) {
        writer.writeUint64(5, f);
    }
    f = message.getActivityType();
    if (f !== 0.0) {
        writer.writeEnum(6, f);
    }
    f = message.getDeviceAction();
    if (f != null) {
        writer.writeMessage(7, f, proto.com.keus.hub.DeviceActivityAction.serializeBinaryToWriter);
    }
    f = message.getSceneAction();
    if (f != null) {
        writer.writeMessage(8, f, proto.com.keus.hub.SceneActivityAction.serializeBinaryToWriter);
    }
    f = message.getGroupAction();
    if (f != null) {
        writer.writeMessage(9, f, proto.com.keus.hub.GroupActivityAction.serializeBinaryToWriter);
    }
};
/**
 * optional string activity_id = 1;
 * @return {string}
 */
proto.com.keus.hub.Activity.prototype.getActivityId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Activity} returns this
 */
proto.com.keus.hub.Activity.prototype.setActivityId = function (value) {
    return jspb.Message.setProto3StringField(this, 1, value);
};
/**
 * optional string activity_source = 2;
 * @return {string}
 */
proto.com.keus.hub.Activity.prototype.getActivitySource = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Activity} returns this
 */
proto.com.keus.hub.Activity.prototype.setActivitySource = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional string activity_by = 3;
 * @return {string}
 */
proto.com.keus.hub.Activity.prototype.getActivityBy = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Activity} returns this
 */
proto.com.keus.hub.Activity.prototype.setActivityBy = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional string activity_username = 4;
 * @return {string}
 */
proto.com.keus.hub.Activity.prototype.getActivityUsername = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Activity} returns this
 */
proto.com.keus.hub.Activity.prototype.setActivityUsername = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
/**
 * optional uint64 activity_time = 5;
 * @return {number}
 */
proto.com.keus.hub.Activity.prototype.getActivityTime = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 5, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.Activity} returns this
 */
proto.com.keus.hub.Activity.prototype.setActivityTime = function (value) {
    return jspb.Message.setProto3IntField(this, 5, value);
};
/**
 * optional ACTIVITY_TYPES activity_type = 6;
 * @return {!proto.com.keus.hub.ACTIVITY_TYPES}
 */
proto.com.keus.hub.Activity.prototype.getActivityType = function () {
    return /** @type {!proto.com.keus.hub.ACTIVITY_TYPES} */ (jspb.Message.getFieldWithDefault(this, 6, 0));
};
/**
 * @param {!proto.com.keus.hub.ACTIVITY_TYPES} value
 * @return {!proto.com.keus.hub.Activity} returns this
 */
proto.com.keus.hub.Activity.prototype.setActivityType = function (value) {
    return jspb.Message.setProto3EnumField(this, 6, value);
};
/**
 * optional DeviceActivityAction device_action = 7;
 * @return {?proto.com.keus.hub.DeviceActivityAction}
 */
proto.com.keus.hub.Activity.prototype.getDeviceAction = function () {
    return /** @type{?proto.com.keus.hub.DeviceActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.DeviceActivityAction, 7));
};
/**
 * @param {?proto.com.keus.hub.DeviceActivityAction|undefined} value
 * @return {!proto.com.keus.hub.Activity} returns this
*/
proto.com.keus.hub.Activity.prototype.setDeviceAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 7, proto.com.keus.hub.Activity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.Activity} returns this
 */
proto.com.keus.hub.Activity.prototype.clearDeviceAction = function () {
    return this.setDeviceAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.Activity.prototype.hasDeviceAction = function () {
    return jspb.Message.getField(this, 7) != null;
};
/**
 * optional SceneActivityAction scene_action = 8;
 * @return {?proto.com.keus.hub.SceneActivityAction}
 */
proto.com.keus.hub.Activity.prototype.getSceneAction = function () {
    return /** @type{?proto.com.keus.hub.SceneActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.SceneActivityAction, 8));
};
/**
 * @param {?proto.com.keus.hub.SceneActivityAction|undefined} value
 * @return {!proto.com.keus.hub.Activity} returns this
*/
proto.com.keus.hub.Activity.prototype.setSceneAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 8, proto.com.keus.hub.Activity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.Activity} returns this
 */
proto.com.keus.hub.Activity.prototype.clearSceneAction = function () {
    return this.setSceneAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.Activity.prototype.hasSceneAction = function () {
    return jspb.Message.getField(this, 8) != null;
};
/**
 * optional GroupActivityAction group_action = 9;
 * @return {?proto.com.keus.hub.GroupActivityAction}
 */
proto.com.keus.hub.Activity.prototype.getGroupAction = function () {
    return /** @type{?proto.com.keus.hub.GroupActivityAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.GroupActivityAction, 9));
};
/**
 * @param {?proto.com.keus.hub.GroupActivityAction|undefined} value
 * @return {!proto.com.keus.hub.Activity} returns this
*/
proto.com.keus.hub.Activity.prototype.setGroupAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 9, proto.com.keus.hub.Activity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.Activity} returns this
 */
proto.com.keus.hub.Activity.prototype.clearGroupAction = function () {
    return this.setGroupAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.Activity.prototype.hasGroupAction = function () {
    return jspb.Message.getField(this, 9) != null;
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.GetActivityLog.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.GetActivityLog.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.GetActivityLog} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.GetActivityLog.toObject = function (includeInstance, msg) {
        var f, obj = {
            activityCount: jspb.Message.getFieldWithDefault(msg, 1, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.GetActivityLog}
 */
proto.com.keus.hub.GetActivityLog.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.GetActivityLog;
    return proto.com.keus.hub.GetActivityLog.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.GetActivityLog} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.GetActivityLog}
 */
proto.com.keus.hub.GetActivityLog.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setActivityCount(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.GetActivityLog.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.GetActivityLog.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.GetActivityLog} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.GetActivityLog.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getActivityCount();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
};
/**
 * optional int32 activity_count = 1;
 * @return {number}
 */
proto.com.keus.hub.GetActivityLog.prototype.getActivityCount = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GetActivityLog} returns this
 */
proto.com.keus.hub.GetActivityLog.prototype.setActivityCount = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.com.keus.hub.GetActivityLogResponse.repeatedFields_ = [4];
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.GetActivityLogResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.GetActivityLogResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.GetActivityLogResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.GetActivityLogResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, ""),
            activityList: jspb.Message.toObjectList(msg.getActivityList(), proto.com.keus.hub.Activity.toObject, includeInstance)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.GetActivityLogResponse}
 */
proto.com.keus.hub.GetActivityLogResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.GetActivityLogResponse;
    return proto.com.keus.hub.GetActivityLogResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.GetActivityLogResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.GetActivityLogResponse}
 */
proto.com.keus.hub.GetActivityLogResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            case 4:
                var value = new proto.com.keus.hub.Activity;
                reader.readMessage(value, proto.com.keus.hub.Activity.deserializeBinaryFromReader);
                msg.addActivity(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.GetActivityLogResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.GetActivityLogResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.GetActivityLogResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getActivityList();
    if (f.length > 0) {
        writer.writeRepeatedMessage(4, f, proto.com.keus.hub.Activity.serializeBinaryToWriter);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.GetActivityLogResponse} returns this
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.GetActivityLogResponse} returns this
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.GetActivityLogResponse} returns this
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * repeated Activity activity = 4;
 * @return {!Array<!proto.com.keus.hub.Activity>}
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.getActivityList = function () {
    return /** @type{!Array<!proto.com.keus.hub.Activity>} */ (jspb.Message.getRepeatedWrapperField(this, proto.com.keus.hub.Activity, 4));
};
/**
 * @param {!Array<!proto.com.keus.hub.Activity>} value
 * @return {!proto.com.keus.hub.GetActivityLogResponse} returns this
*/
proto.com.keus.hub.GetActivityLogResponse.prototype.setActivityList = function (value) {
    return jspb.Message.setRepeatedWrapperField(this, 4, value);
};
/**
 * @param {!proto.com.keus.hub.Activity=} opt_value
 * @param {number=} opt_index
 * @return {!proto.com.keus.hub.Activity}
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.addActivity = function (opt_value, opt_index) {
    return jspb.Message.addToRepeatedWrapperField(this, 4, opt_value, proto.com.keus.hub.Activity, opt_index);
};
/**
 * Clears the list making it empty but non-null.
 * @return {!proto.com.keus.hub.GetActivityLogResponse} returns this
 */
proto.com.keus.hub.GetActivityLogResponse.prototype.clearActivityList = function () {
    return this.setActivityList([]);
};
/**
 * Oneof group definitions for this message. Each group defines the field
 * numbers belonging to that group. When of these fields' value is set, all
 * other fields in the group are cleared. During deserialization, if multiple
 * fields are encountered for a group, only the last value seen will be kept.
 * @private {!Array<!Array<number>>}
 * @const
 */
proto.com.keus.hub.SystemActivity.oneofGroups_ = [[20, 21, 22, 23, 24, 25, 26]];
/**
 * @enum {number}
 */
proto.com.keus.hub.SystemActivity.SystemActivityCase = {
    SYSTEM_ACTIVITY_NOT_SET: 0,
    CURTAIN_ACTIVITY: 20,
    AC_FAN_ACTIVITY: 21,
    DC_FAN_ACTIVITY: 22,
    RELAY_ACTIVITY: 23,
    ES_APPLIANCE_ACTIVITY: 24,
    GROUP_ACTIVITY: 25,
    SCENE_ACTIVITY: 26
};
/**
 * @return {proto.com.keus.hub.SystemActivity.SystemActivityCase}
 */
proto.com.keus.hub.SystemActivity.prototype.getSystemActivityCase = function () {
    return /** @type {proto.com.keus.hub.SystemActivity.SystemActivityCase} */ (jspb.Message.computeOneofCase(this, proto.com.keus.hub.SystemActivity.oneofGroups_[0]));
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.SystemActivity.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.SystemActivity.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.SystemActivity} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.SystemActivity.toObject = function (includeInstance, msg) {
        var f, obj = {
            activitySourceDevice: jspb.Message.getFieldWithDefault(msg, 1, ""),
            activityType: jspb.Message.getFieldWithDefault(msg, 2, 0),
            curtainActivity: (f = msg.getCurtainActivity()) && hub_devices_zigbee_curtain_controller_pb.ReportZigbeeCurtainControllerActivity.toObject(includeInstance, f),
            acFanActivity: (f = msg.getAcFanActivity()) && hub_devices_zigbee_ac_fan_controller_pb.ReportZigbeeACFanControllerActivity.toObject(includeInstance, f),
            dcFanActivity: (f = msg.getDcFanActivity()) && hub_devices_zigbee_dc_fan_controller_pb.ReportZigbeeDCFanControllerActivity.toObject(includeInstance, f),
            relayActivity: (f = msg.getRelayActivity()) && hub_devices_smart_console_pb.ReportConsoleRelayActivity.toObject(includeInstance, f),
            esApplianceActivity: (f = msg.getEsApplianceActivity()) && hub_devices_zigbee_embedded_switch_pb.ReportZigbeeEmbeddedApplianceActivity.toObject(includeInstance, f),
            groupActivity: (f = msg.getGroupActivity()) && hub_groups_group_structures_pb.ReportUpdateGroupActivity.toObject(includeInstance, f),
            sceneActivity: (f = msg.getSceneActivity()) && hub_scenes_scene_structures_pb.ReportSceneExecutionActivity.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.SystemActivity}
 */
proto.com.keus.hub.SystemActivity.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.SystemActivity;
    return proto.com.keus.hub.SystemActivity.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.SystemActivity} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.SystemActivity}
 */
proto.com.keus.hub.SystemActivity.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {string} */ (reader.readString());
                msg.setActivitySourceDevice(value);
                break;
            case 2:
                var value = /** @type {!proto.com.keus.hub.REPORT_ACTIVITY_TYPES} */ (reader.readEnum());
                msg.setActivityType(value);
                break;
            case 20:
                var value = new hub_devices_zigbee_curtain_controller_pb.ReportZigbeeCurtainControllerActivity;
                reader.readMessage(value, hub_devices_zigbee_curtain_controller_pb.ReportZigbeeCurtainControllerActivity.deserializeBinaryFromReader);
                msg.setCurtainActivity(value);
                break;
            case 21:
                var value = new hub_devices_zigbee_ac_fan_controller_pb.ReportZigbeeACFanControllerActivity;
                reader.readMessage(value, hub_devices_zigbee_ac_fan_controller_pb.ReportZigbeeACFanControllerActivity.deserializeBinaryFromReader);
                msg.setAcFanActivity(value);
                break;
            case 22:
                var value = new hub_devices_zigbee_dc_fan_controller_pb.ReportZigbeeDCFanControllerActivity;
                reader.readMessage(value, hub_devices_zigbee_dc_fan_controller_pb.ReportZigbeeDCFanControllerActivity.deserializeBinaryFromReader);
                msg.setDcFanActivity(value);
                break;
            case 23:
                var value = new hub_devices_smart_console_pb.ReportConsoleRelayActivity;
                reader.readMessage(value, hub_devices_smart_console_pb.ReportConsoleRelayActivity.deserializeBinaryFromReader);
                msg.setRelayActivity(value);
                break;
            case 24:
                var value = new hub_devices_zigbee_embedded_switch_pb.ReportZigbeeEmbeddedApplianceActivity;
                reader.readMessage(value, hub_devices_zigbee_embedded_switch_pb.ReportZigbeeEmbeddedApplianceActivity.deserializeBinaryFromReader);
                msg.setEsApplianceActivity(value);
                break;
            case 25:
                var value = new hub_groups_group_structures_pb.ReportUpdateGroupActivity;
                reader.readMessage(value, hub_groups_group_structures_pb.ReportUpdateGroupActivity.deserializeBinaryFromReader);
                msg.setGroupActivity(value);
                break;
            case 26:
                var value = new hub_scenes_scene_structures_pb.ReportSceneExecutionActivity;
                reader.readMessage(value, hub_scenes_scene_structures_pb.ReportSceneExecutionActivity.deserializeBinaryFromReader);
                msg.setSceneActivity(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.SystemActivity.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.SystemActivity.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.SystemActivity} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.SystemActivity.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getActivitySourceDevice();
    if (f.length > 0) {
        writer.writeString(1, f);
    }
    f = message.getActivityType();
    if (f !== 0.0) {
        writer.writeEnum(2, f);
    }
    f = message.getCurtainActivity();
    if (f != null) {
        writer.writeMessage(20, f, hub_devices_zigbee_curtain_controller_pb.ReportZigbeeCurtainControllerActivity.serializeBinaryToWriter);
    }
    f = message.getAcFanActivity();
    if (f != null) {
        writer.writeMessage(21, f, hub_devices_zigbee_ac_fan_controller_pb.ReportZigbeeACFanControllerActivity.serializeBinaryToWriter);
    }
    f = message.getDcFanActivity();
    if (f != null) {
        writer.writeMessage(22, f, hub_devices_zigbee_dc_fan_controller_pb.ReportZigbeeDCFanControllerActivity.serializeBinaryToWriter);
    }
    f = message.getRelayActivity();
    if (f != null) {
        writer.writeMessage(23, f, hub_devices_smart_console_pb.ReportConsoleRelayActivity.serializeBinaryToWriter);
    }
    f = message.getEsApplianceActivity();
    if (f != null) {
        writer.writeMessage(24, f, hub_devices_zigbee_embedded_switch_pb.ReportZigbeeEmbeddedApplianceActivity.serializeBinaryToWriter);
    }
    f = message.getGroupActivity();
    if (f != null) {
        writer.writeMessage(25, f, hub_groups_group_structures_pb.ReportUpdateGroupActivity.serializeBinaryToWriter);
    }
    f = message.getSceneActivity();
    if (f != null) {
        writer.writeMessage(26, f, hub_scenes_scene_structures_pb.ReportSceneExecutionActivity.serializeBinaryToWriter);
    }
};
/**
 * optional string activity_source_device = 1;
 * @return {string}
 */
proto.com.keus.hub.SystemActivity.prototype.getActivitySourceDevice = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SystemActivity} returns this
 */
proto.com.keus.hub.SystemActivity.prototype.setActivitySourceDevice = function (value) {
    return jspb.Message.setProto3StringField(this, 1, value);
};
/**
 * optional REPORT_ACTIVITY_TYPES activity_type = 2;
 * @return {!proto.com.keus.hub.REPORT_ACTIVITY_TYPES}
 */
proto.com.keus.hub.SystemActivity.prototype.getActivityType = function () {
    return /** @type {!proto.com.keus.hub.REPORT_ACTIVITY_TYPES} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {!proto.com.keus.hub.REPORT_ACTIVITY_TYPES} value
 * @return {!proto.com.keus.hub.SystemActivity} returns this
 */
proto.com.keus.hub.SystemActivity.prototype.setActivityType = function (value) {
    return jspb.Message.setProto3EnumField(this, 2, value);
};
/**
 * optional ReportZigbeeCurtainControllerActivity curtain_activity = 20;
 * @return {?proto.com.keus.hub.ReportZigbeeCurtainControllerActivity}
 */
proto.com.keus.hub.SystemActivity.prototype.getCurtainActivity = function () {
    return /** @type{?proto.com.keus.hub.ReportZigbeeCurtainControllerActivity} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_curtain_controller_pb.ReportZigbeeCurtainControllerActivity, 20));
};
/**
 * @param {?proto.com.keus.hub.ReportZigbeeCurtainControllerActivity|undefined} value
 * @return {!proto.com.keus.hub.SystemActivity} returns this
*/
proto.com.keus.hub.SystemActivity.prototype.setCurtainActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 20, proto.com.keus.hub.SystemActivity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SystemActivity} returns this
 */
proto.com.keus.hub.SystemActivity.prototype.clearCurtainActivity = function () {
    return this.setCurtainActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SystemActivity.prototype.hasCurtainActivity = function () {
    return jspb.Message.getField(this, 20) != null;
};
/**
 * optional ReportZigbeeACFanControllerActivity ac_fan_activity = 21;
 * @return {?proto.com.keus.hub.ReportZigbeeACFanControllerActivity}
 */
proto.com.keus.hub.SystemActivity.prototype.getAcFanActivity = function () {
    return /** @type{?proto.com.keus.hub.ReportZigbeeACFanControllerActivity} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_ac_fan_controller_pb.ReportZigbeeACFanControllerActivity, 21));
};
/**
 * @param {?proto.com.keus.hub.ReportZigbeeACFanControllerActivity|undefined} value
 * @return {!proto.com.keus.hub.SystemActivity} returns this
*/
proto.com.keus.hub.SystemActivity.prototype.setAcFanActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 21, proto.com.keus.hub.SystemActivity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SystemActivity} returns this
 */
proto.com.keus.hub.SystemActivity.prototype.clearAcFanActivity = function () {
    return this.setAcFanActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SystemActivity.prototype.hasAcFanActivity = function () {
    return jspb.Message.getField(this, 21) != null;
};
/**
 * optional ReportZigbeeDCFanControllerActivity dc_fan_activity = 22;
 * @return {?proto.com.keus.hub.ReportZigbeeDCFanControllerActivity}
 */
proto.com.keus.hub.SystemActivity.prototype.getDcFanActivity = function () {
    return /** @type{?proto.com.keus.hub.ReportZigbeeDCFanControllerActivity} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_dc_fan_controller_pb.ReportZigbeeDCFanControllerActivity, 22));
};
/**
 * @param {?proto.com.keus.hub.ReportZigbeeDCFanControllerActivity|undefined} value
 * @return {!proto.com.keus.hub.SystemActivity} returns this
*/
proto.com.keus.hub.SystemActivity.prototype.setDcFanActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 22, proto.com.keus.hub.SystemActivity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SystemActivity} returns this
 */
proto.com.keus.hub.SystemActivity.prototype.clearDcFanActivity = function () {
    return this.setDcFanActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SystemActivity.prototype.hasDcFanActivity = function () {
    return jspb.Message.getField(this, 22) != null;
};
/**
 * optional ReportConsoleRelayActivity relay_activity = 23;
 * @return {?proto.com.keus.hub.ReportConsoleRelayActivity}
 */
proto.com.keus.hub.SystemActivity.prototype.getRelayActivity = function () {
    return /** @type{?proto.com.keus.hub.ReportConsoleRelayActivity} */ (jspb.Message.getWrapperField(this, hub_devices_smart_console_pb.ReportConsoleRelayActivity, 23));
};
/**
 * @param {?proto.com.keus.hub.ReportConsoleRelayActivity|undefined} value
 * @return {!proto.com.keus.hub.SystemActivity} returns this
*/
proto.com.keus.hub.SystemActivity.prototype.setRelayActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 23, proto.com.keus.hub.SystemActivity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SystemActivity} returns this
 */
proto.com.keus.hub.SystemActivity.prototype.clearRelayActivity = function () {
    return this.setRelayActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SystemActivity.prototype.hasRelayActivity = function () {
    return jspb.Message.getField(this, 23) != null;
};
/**
 * optional ReportZigbeeEmbeddedApplianceActivity es_appliance_activity = 24;
 * @return {?proto.com.keus.hub.ReportZigbeeEmbeddedApplianceActivity}
 */
proto.com.keus.hub.SystemActivity.prototype.getEsApplianceActivity = function () {
    return /** @type{?proto.com.keus.hub.ReportZigbeeEmbeddedApplianceActivity} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_embedded_switch_pb.ReportZigbeeEmbeddedApplianceActivity, 24));
};
/**
 * @param {?proto.com.keus.hub.ReportZigbeeEmbeddedApplianceActivity|undefined} value
 * @return {!proto.com.keus.hub.SystemActivity} returns this
*/
proto.com.keus.hub.SystemActivity.prototype.setEsApplianceActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 24, proto.com.keus.hub.SystemActivity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SystemActivity} returns this
 */
proto.com.keus.hub.SystemActivity.prototype.clearEsApplianceActivity = function () {
    return this.setEsApplianceActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SystemActivity.prototype.hasEsApplianceActivity = function () {
    return jspb.Message.getField(this, 24) != null;
};
/**
 * optional ReportUpdateGroupActivity group_activity = 25;
 * @return {?proto.com.keus.hub.ReportUpdateGroupActivity}
 */
proto.com.keus.hub.SystemActivity.prototype.getGroupActivity = function () {
    return /** @type{?proto.com.keus.hub.ReportUpdateGroupActivity} */ (jspb.Message.getWrapperField(this, hub_groups_group_structures_pb.ReportUpdateGroupActivity, 25));
};
/**
 * @param {?proto.com.keus.hub.ReportUpdateGroupActivity|undefined} value
 * @return {!proto.com.keus.hub.SystemActivity} returns this
*/
proto.com.keus.hub.SystemActivity.prototype.setGroupActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 25, proto.com.keus.hub.SystemActivity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SystemActivity} returns this
 */
proto.com.keus.hub.SystemActivity.prototype.clearGroupActivity = function () {
    return this.setGroupActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SystemActivity.prototype.hasGroupActivity = function () {
    return jspb.Message.getField(this, 25) != null;
};
/**
 * optional ReportSceneExecutionActivity scene_activity = 26;
 * @return {?proto.com.keus.hub.ReportSceneExecutionActivity}
 */
proto.com.keus.hub.SystemActivity.prototype.getSceneActivity = function () {
    return /** @type{?proto.com.keus.hub.ReportSceneExecutionActivity} */ (jspb.Message.getWrapperField(this, hub_scenes_scene_structures_pb.ReportSceneExecutionActivity, 26));
};
/**
 * @param {?proto.com.keus.hub.ReportSceneExecutionActivity|undefined} value
 * @return {!proto.com.keus.hub.SystemActivity} returns this
*/
proto.com.keus.hub.SystemActivity.prototype.setSceneActivity = function (value) {
    return jspb.Message.setOneofWrapperField(this, 26, proto.com.keus.hub.SystemActivity.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SystemActivity} returns this
 */
proto.com.keus.hub.SystemActivity.prototype.clearSceneActivity = function () {
    return this.setSceneActivity(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SystemActivity.prototype.hasSceneActivity = function () {
    return jspb.Message.getField(this, 26) != null;
};
/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.com.keus.hub.ReportSystemActivity.repeatedFields_ = [3];
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.ReportSystemActivity.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.ReportSystemActivity.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.ReportSystemActivity} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.ReportSystemActivity.toObject = function (includeInstance, msg) {
        var f, obj = {
            systemActivityList: jspb.Message.toObjectList(msg.getSystemActivityList(), proto.com.keus.hub.SystemActivity.toObject, includeInstance)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.ReportSystemActivity}
 */
proto.com.keus.hub.ReportSystemActivity.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.ReportSystemActivity;
    return proto.com.keus.hub.ReportSystemActivity.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.ReportSystemActivity} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.ReportSystemActivity}
 */
proto.com.keus.hub.ReportSystemActivity.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 3:
                var value = new proto.com.keus.hub.SystemActivity;
                reader.readMessage(value, proto.com.keus.hub.SystemActivity.deserializeBinaryFromReader);
                msg.addSystemActivity(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.ReportSystemActivity.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.ReportSystemActivity.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.ReportSystemActivity} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.ReportSystemActivity.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSystemActivityList();
    if (f.length > 0) {
        writer.writeRepeatedMessage(3, f, proto.com.keus.hub.SystemActivity.serializeBinaryToWriter);
    }
};
/**
 * repeated SystemActivity system_activity = 3;
 * @return {!Array<!proto.com.keus.hub.SystemActivity>}
 */
proto.com.keus.hub.ReportSystemActivity.prototype.getSystemActivityList = function () {
    return /** @type{!Array<!proto.com.keus.hub.SystemActivity>} */ (jspb.Message.getRepeatedWrapperField(this, proto.com.keus.hub.SystemActivity, 3));
};
/**
 * @param {!Array<!proto.com.keus.hub.SystemActivity>} value
 * @return {!proto.com.keus.hub.ReportSystemActivity} returns this
*/
proto.com.keus.hub.ReportSystemActivity.prototype.setSystemActivityList = function (value) {
    return jspb.Message.setRepeatedWrapperField(this, 3, value);
};
/**
 * @param {!proto.com.keus.hub.SystemActivity=} opt_value
 * @param {number=} opt_index
 * @return {!proto.com.keus.hub.SystemActivity}
 */
proto.com.keus.hub.ReportSystemActivity.prototype.addSystemActivity = function (opt_value, opt_index) {
    return jspb.Message.addToRepeatedWrapperField(this, 3, opt_value, proto.com.keus.hub.SystemActivity, opt_index);
};
/**
 * Clears the list making it empty but non-null.
 * @return {!proto.com.keus.hub.ReportSystemActivity} returns this
 */
proto.com.keus.hub.ReportSystemActivity.prototype.clearSystemActivityList = function () {
    return this.setSystemActivityList([]);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.ReportSystemActivityResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.ReportSystemActivityResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.ReportSystemActivityResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.ReportSystemActivityResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.ReportSystemActivityResponse}
 */
proto.com.keus.hub.ReportSystemActivityResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.ReportSystemActivityResponse;
    return proto.com.keus.hub.ReportSystemActivityResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.ReportSystemActivityResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.ReportSystemActivityResponse}
 */
proto.com.keus.hub.ReportSystemActivityResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.ReportSystemActivityResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.ReportSystemActivityResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.ReportSystemActivityResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.ReportSystemActivityResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.ReportSystemActivityResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.ReportSystemActivityResponse} returns this
 */
proto.com.keus.hub.ReportSystemActivityResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.ReportSystemActivityResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.ReportSystemActivityResponse} returns this
 */
proto.com.keus.hub.ReportSystemActivityResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.ReportSystemActivityResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.ReportSystemActivityResponse} returns this
 */
proto.com.keus.hub.ReportSystemActivityResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * @enum {number}
 */
proto.com.keus.hub.ACTIVITY_TYPES = {
    DEVICE: 0,
    SCENE: 1,
    GROUP: 2
};
goog.object.extend(exports, proto.com.keus.hub);
//# sourceMappingURL=activity_structures_pb.js.map