// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=job_completion_grpc_pb.js.map