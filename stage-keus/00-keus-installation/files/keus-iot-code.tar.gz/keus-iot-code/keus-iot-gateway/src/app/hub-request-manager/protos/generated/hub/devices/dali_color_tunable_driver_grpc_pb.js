// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=dali_color_tunable_driver_grpc_pb.js.map