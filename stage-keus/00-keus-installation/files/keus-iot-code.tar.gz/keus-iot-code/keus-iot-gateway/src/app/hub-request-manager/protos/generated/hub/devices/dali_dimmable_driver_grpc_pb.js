// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=dali_dimmable_driver_grpc_pb.js.map