// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=dali_scene_switch_grpc_pb.js.map