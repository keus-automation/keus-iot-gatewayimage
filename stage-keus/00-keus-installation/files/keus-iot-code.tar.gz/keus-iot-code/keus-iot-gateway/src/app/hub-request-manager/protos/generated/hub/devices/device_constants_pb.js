// source: hub/devices/device_constants.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!
var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();
goog.exportSymbol('proto.com.keus.hub.AC_FAN_CONTROLLER_UPDATE_TYPE', null, global);
goog.exportSymbol('proto.com.keus.hub.CURTAIN_CONTROLLER_ACTION', null, global);
goog.exportSymbol('proto.com.keus.hub.CURTAIN_CONTROLLER_ICON', null, global);
goog.exportSymbol('proto.com.keus.hub.DC_FAN_CONTROLLER_UPDATE_TYPE', null, global);
goog.exportSymbol('proto.com.keus.hub.DEVICE_JOB_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.DEVICE_SYNC_STATES', null, global);
goog.exportSymbol('proto.com.keus.hub.EMBEDDED_APPLIANCE_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.EMBEDDED_SWITCH_ICONS', null, global);
goog.exportSymbol('proto.com.keus.hub.EMBEDDED_SWITCH_REPORT_STATE_UPDATE_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.EMBEDDED_SWITCH_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.IR_AC_HSWING_STATES', null, global);
goog.exportSymbol('proto.com.keus.hub.IR_AC_VSWING_STATES', null, global);
goog.exportSymbol('proto.com.keus.hub.IR_REMOTE_SELECTION_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.IR_REMOTE_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.RGBWWA_DRIVER_UPDATE_TYPE', null, global);
goog.exportSymbol('proto.com.keus.hub.SMART_CONSOLE_BUTTON_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.SMART_CONSOLE_DALI_DISCOVERY_TYPES', null, global);
/**
 * @enum {number}
 */
proto.com.keus.hub.DEVICE_SYNC_STATES = {
    DEVICEINSYNC: 0,
    DEVICESYNCPENDING: 1,
    DEVICESYNCFAILED: 2
};
/**
 * @enum {number}
 */
proto.com.keus.hub.DEVICE_JOB_TYPES = {
    DEVICE_NONE: 0,
    DEVICE_SYNCSCENEUI: 1
};
/**
 * @enum {number}
 */
proto.com.keus.hub.EMBEDDED_SWITCH_TYPES = {
    APPLIANCE: 0,
    GROUP_EXECUTION: 1,
    AC_FAN: 2,
    DC_FAN: 3
};
/**
 * @enum {number}
 */
proto.com.keus.hub.EMBEDDED_SWITCH_ICONS = {
    DOWN_LIGHT: 0,
    WALL_WASHERS: 1,
    PROFILE_LIGHT: 2,
    STRIP_LIGHT: 3,
    RGB_STRIP_LIGHT: 4,
    PENDANT: 5,
    LAMP: 6,
    CHANDELIER: 7,
    TUBE_LIGHT: 8,
    FAN_DIMMER: 9,
    EXHAUST_FAN: 10,
    SOCKET: 11,
    MOSQUITO_REPELLANT: 12
};
/**
 * @enum {number}
 */
proto.com.keus.hub.EMBEDDED_SWITCH_REPORT_STATE_UPDATE_TYPES = {
    MANUAL_UPDATE: 0,
    SYNC_UPDATE: 1
};
/**
 * @enum {number}
 */
proto.com.keus.hub.AC_FAN_CONTROLLER_UPDATE_TYPE = {
    AC_FAN_UPDATE: 0,
    AC_LIGHT_UPDATE: 1,
    AC_BOTH_UPDATE: 2
};
/**
 * @enum {number}
 */
proto.com.keus.hub.DC_FAN_CONTROLLER_UPDATE_TYPE = {
    DC_FAN_UPDATE: 0,
    DC_LIGHT_UPDATE: 1,
    DC_BOTH_UPDATE: 2
};
/**
 * @enum {number}
 */
proto.com.keus.hub.RGBWWA_DRIVER_UPDATE_TYPE = {
    RGBWWA_WWA_UPDATE: 0,
    RGBWWA_RGB_UPDATE: 1
};
/**
 * @enum {number}
 */
proto.com.keus.hub.CURTAIN_CONTROLLER_ICON = {
    CC_SLIDER: 0,
    CC_ROLLER: 1,
    CC_VENETIAN: 2
};
/**
 * @enum {number}
 */
proto.com.keus.hub.CURTAIN_CONTROLLER_ACTION = {
    CC_NONE: 0,
    CC_CLOSE: 1,
    CC_PAUSE: 2,
    CC_OPEN: 3
};
/**
 * @enum {number}
 */
proto.com.keus.hub.SMART_CONSOLE_DALI_DISCOVERY_TYPES = {
    SC_ADDITIVE_DISCOVERY: 0,
    SC_FRESH_DISCOVERY: 1,
    SC_SCAN_DISCOVERY: 2
};
/**
 * @enum {number}
 */
proto.com.keus.hub.SMART_CONSOLE_BUTTON_TYPES = {
    SC_UNCONFIGURED: 0,
    SC_FANCONTROLLER: 1,
    SC_GROUP: 2,
    SC_SCENE: 3,
    SC_CURTAINCONTROLLER: 4,
    SC_INC: 5,
    SC_DEC: 6,
    SC_LIGHTINC: 7,
    SC_LIGHTDEC: 8,
    SC_RELAYCONTROLLER: 9,
    SC_REMOTERELAY: 10
};
/**
 * @enum {number}
 */
proto.com.keus.hub.IR_REMOTE_TYPES = {
    IR_AC: 0,
    IR_TV: 1,
    IR_AMP: 2,
    IR_PR: 3,
    IR_FAN: 4
};
/**
 * @enum {number}
 */
proto.com.keus.hub.IR_REMOTE_SELECTION_TYPES = {
    IR_CYCLE: 0,
    IR_SPREAD: 1
};
/**
 * @enum {number}
 */
proto.com.keus.hub.IR_AC_HSWING_STATES = {
    HSWING_NONE: 0,
    HSWING_OFF: 1,
    HSWING_AUTO: 2
};
/**
 * @enum {number}
 */
proto.com.keus.hub.IR_AC_VSWING_STATES = {
    VSWING_NONE: 0,
    VSWING_OFF: 1,
    VSWING_AUTO: 2
};
/**
 * @enum {number}
 */
proto.com.keus.hub.EMBEDDED_APPLIANCE_TYPES = {
    ON_OFF: 0,
    SINGLE_DIMMER: 1,
    FAN: 2,
    COLOR_TUNABLE: 3
};
goog.object.extend(exports, proto.com.keus.hub);
//# sourceMappingURL=device_constants_pb.js.map