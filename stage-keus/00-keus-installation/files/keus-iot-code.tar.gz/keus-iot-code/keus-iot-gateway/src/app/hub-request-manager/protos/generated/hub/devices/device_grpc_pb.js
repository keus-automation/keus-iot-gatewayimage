// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=device_grpc_pb.js.map