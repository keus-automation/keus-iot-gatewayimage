// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=scene_wizard_grpc_pb.js.map