// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=zigbee_ac_fan_controller_grpc_pb.js.map