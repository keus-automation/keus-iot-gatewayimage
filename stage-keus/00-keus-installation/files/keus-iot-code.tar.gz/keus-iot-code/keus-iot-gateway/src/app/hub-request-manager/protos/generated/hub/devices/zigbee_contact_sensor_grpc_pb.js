// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=zigbee_contact_sensor_grpc_pb.js.map