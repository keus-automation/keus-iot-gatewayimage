// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=zigbee_dc_fan_controller_grpc_pb.js.map