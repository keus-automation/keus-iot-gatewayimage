// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=zigbee_embedded_scene_switch_grpc_pb.js.map