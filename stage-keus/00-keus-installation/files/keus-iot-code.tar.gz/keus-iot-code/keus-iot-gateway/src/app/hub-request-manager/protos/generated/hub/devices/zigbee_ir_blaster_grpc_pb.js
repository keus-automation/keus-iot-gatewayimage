// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=zigbee_ir_blaster_grpc_pb.js.map