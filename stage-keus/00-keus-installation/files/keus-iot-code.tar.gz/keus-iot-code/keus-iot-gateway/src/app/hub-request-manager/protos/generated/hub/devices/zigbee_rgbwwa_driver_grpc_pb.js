// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=zigbee_rgbwwa_driver_grpc_pb.js.map