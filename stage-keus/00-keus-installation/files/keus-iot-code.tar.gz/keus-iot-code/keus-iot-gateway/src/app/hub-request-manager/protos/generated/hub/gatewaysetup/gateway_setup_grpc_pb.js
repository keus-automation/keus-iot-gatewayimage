// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=gateway_setup_grpc_pb.js.map