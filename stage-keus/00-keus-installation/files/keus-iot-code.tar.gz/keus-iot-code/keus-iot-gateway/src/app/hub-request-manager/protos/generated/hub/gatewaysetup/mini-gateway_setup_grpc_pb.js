// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=mini-gateway_setup_grpc_pb.js.map