// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=group_structures_grpc_pb.js.map