// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=home_structures_grpc_pb.js.map