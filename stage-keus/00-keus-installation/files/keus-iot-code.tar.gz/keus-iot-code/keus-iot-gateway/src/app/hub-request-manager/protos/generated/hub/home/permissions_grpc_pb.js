// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=permissions_grpc_pb.js.map