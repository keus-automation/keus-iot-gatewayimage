// source: hub/scenes/scene_constants.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!
var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();
var hub_devices_device_constants_pb = require('../../hub/devices/device_constants_pb.js');
goog.object.extend(proto, hub_devices_device_constants_pb);
goog.exportSymbol('proto.com.keus.hub.ACTION_JOB_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.ACTION_SYNC_STATES', null, global);
goog.exportSymbol('proto.com.keus.hub.SCENE_EXECTYPE', null, global);
goog.exportSymbol('proto.com.keus.hub.SCENE_JOB_TYPES', null, global);
goog.exportSymbol('proto.com.keus.hub.SCENE_SCOPE', null, global);
goog.exportSymbol('proto.com.keus.hub.SCENE_SYNC_STATES', null, global);
goog.exportSymbol('proto.com.keus.hub.SCENE_TYPE', null, global);
/**
 * @enum {number}
 */
proto.com.keus.hub.SCENE_SYNC_STATES = {
    SCENEINSYNC: 0,
    SCENESYNCPENDING: 1,
    SCENESYNCFAILED: 2
};
/**
 * @enum {number}
 */
proto.com.keus.hub.SCENE_JOB_TYPES = {
    SCENE_NONE: 0,
    SCENE_ADJTSDELAY: 1,
    SCENE_DELTS: 2,
    SCENE_DELETE: 3
};
/**
 * @enum {number}
 */
proto.com.keus.hub.ACTION_SYNC_STATES = {
    ACTIONINSYNC: 0,
    ACTIONSYNCPENDING: 1,
    ACTIONSYNCFAILED: 2,
    ACTION_NOT_ADDED: 3
};
/**
 * @enum {number}
 */
proto.com.keus.hub.ACTION_JOB_TYPES = {
    ACTION_ADD: 0,
    ACTION_DEL: 1
};
/**
 * @enum {number}
 */
proto.com.keus.hub.SCENE_EXECTYPE = {
    STANDARD: 0,
    ADVANCED: 1
};
/**
 * @enum {number}
 */
proto.com.keus.hub.SCENE_SCOPE = {
    LOCAL: 0,
    GLOBAL: 1
};
/**
 * @enum {number}
 */
proto.com.keus.hub.SCENE_TYPE = {
    MORNING: 0,
    AFTERNOON: 1,
    NIGHT: 2,
    ALLON: 3,
    ALLOFF: 4,
    BRIGHT: 5,
    DIM: 6,
    RELAX: 7,
    PARTY: 8,
    CUSTOM: 9
};
goog.object.extend(exports, proto.com.keus.hub);
//# sourceMappingURL=scene_constants_pb.js.map