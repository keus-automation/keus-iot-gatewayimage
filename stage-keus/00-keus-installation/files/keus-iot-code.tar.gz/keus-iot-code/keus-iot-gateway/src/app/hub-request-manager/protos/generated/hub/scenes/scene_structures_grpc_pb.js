// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=scene_structures_grpc_pb.js.map