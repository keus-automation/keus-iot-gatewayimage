// source: hub/scenes/scene_structures.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!
var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();
var hub_devices_zigbee_curtain_controller_pb = require('../../hub/devices/zigbee_curtain_controller_pb.js');
goog.object.extend(proto, hub_devices_zigbee_curtain_controller_pb);
var hub_devices_zigbee_dimmable_driver_pb = require('../../hub/devices/zigbee_dimmable_driver_pb.js');
goog.object.extend(proto, hub_devices_zigbee_dimmable_driver_pb);
var hub_devices_zigbee_nondimmable_driver_pb = require('../../hub/devices/zigbee_nondimmable_driver_pb.js');
goog.object.extend(proto, hub_devices_zigbee_nondimmable_driver_pb);
var hub_devices_dali_dimmable_driver_pb = require('../../hub/devices/dali_dimmable_driver_pb.js');
goog.object.extend(proto, hub_devices_dali_dimmable_driver_pb);
var hub_devices_dali_color_tunable_driver_pb = require('../../hub/devices/dali_color_tunable_driver_pb.js');
goog.object.extend(proto, hub_devices_dali_color_tunable_driver_pb);
var hub_devices_dali_nondimmable_driver_pb = require('../../hub/devices/dali_nondimmable_driver_pb.js');
goog.object.extend(proto, hub_devices_dali_nondimmable_driver_pb);
var hub_devices_zigbee_inline_dimmer_pb = require('../../hub/devices/zigbee_inline_dimmer_pb.js');
goog.object.extend(proto, hub_devices_zigbee_inline_dimmer_pb);
var hub_devices_zigbee_rgbwwa_driver_pb = require('../../hub/devices/zigbee_rgbwwa_driver_pb.js');
goog.object.extend(proto, hub_devices_zigbee_rgbwwa_driver_pb);
var hub_devices_zigbee_embedded_switch_pb = require('../../hub/devices/zigbee_embedded_switch_pb.js');
goog.object.extend(proto, hub_devices_zigbee_embedded_switch_pb);
var hub_devices_zigbee_ac_fan_controller_pb = require('../../hub/devices/zigbee_ac_fan_controller_pb.js');
goog.object.extend(proto, hub_devices_zigbee_ac_fan_controller_pb);
var hub_devices_zigbee_dc_fan_controller_pb = require('../../hub/devices/zigbee_dc_fan_controller_pb.js');
goog.object.extend(proto, hub_devices_zigbee_dc_fan_controller_pb);
var hub_scenes_scene_constants_pb = require('../../hub/scenes/scene_constants_pb.js');
goog.object.extend(proto, hub_scenes_scene_constants_pb);
var hub_devices_smart_console_pb = require('../../hub/devices/smart_console_pb.js');
goog.object.extend(proto, hub_devices_smart_console_pb);
var hub_devices_zigbee_ir_blaster_pb = require('../../hub/devices/zigbee_ir_blaster_pb.js');
goog.object.extend(proto, hub_devices_zigbee_ir_blaster_pb);
var hub_activity_activity_constants_pb = require('../../hub/activity/activity_constants_pb.js');
goog.object.extend(proto, hub_activity_activity_constants_pb);
goog.exportSymbol('proto.com.keus.hub.AddActionToScene', null, global);
goog.exportSymbol('proto.com.keus.hub.AddActionToSceneResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.AddTimeslotToScene', null, global);
goog.exportSymbol('proto.com.keus.hub.AddTimeslotToSceneResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.AdjustTimeslotDelay', null, global);
goog.exportSymbol('proto.com.keus.hub.AdjustTimeslotDelayResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.AreaSceneAction', null, global);
goog.exportSymbol('proto.com.keus.hub.CreateScene', null, global);
goog.exportSymbol('proto.com.keus.hub.CreateSceneResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.DeleteScene', null, global);
goog.exportSymbol('proto.com.keus.hub.DeleteSceneResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.EditSceneName', null, global);
goog.exportSymbol('proto.com.keus.hub.EditSceneNameResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.ExecuteScene', null, global);
goog.exportSymbol('proto.com.keus.hub.ExecuteSceneResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.MoveSceneToRoom', null, global);
goog.exportSymbol('proto.com.keus.hub.MoveSceneToRoomResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.NullRequest', null, global);
goog.exportSymbol('proto.com.keus.hub.RemoveActionFromScene', null, global);
goog.exportSymbol('proto.com.keus.hub.RemoveActionFromSceneResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.RemoveTimeslotFromScene', null, global);
goog.exportSymbol('proto.com.keus.hub.RemoveTimeslotFromSceneResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.ReportSceneExecutionActivity', null, global);
goog.exportSymbol('proto.com.keus.hub.Scene', null, global);
goog.exportSymbol('proto.com.keus.hub.SceneAction', null, global);
goog.exportSymbol('proto.com.keus.hub.SceneAction.ActionItemCase', null, global);
goog.exportSymbol('proto.com.keus.hub.SceneExecutionEvent', null, global);
goog.exportSymbol('proto.com.keus.hub.SceneIdentifier', null, global);
goog.exportSymbol('proto.com.keus.hub.SceneSyncInfo', null, global);
goog.exportSymbol('proto.com.keus.hub.SceneSyncInfo.SyncRequestParamsCase', null, global);
goog.exportSymbol('proto.com.keus.hub.SyncAreaSceneUIData', null, global);
goog.exportSymbol('proto.com.keus.hub.SyncAreaSceneUIDataResponse', null, global);
goog.exportSymbol('proto.com.keus.hub.Timeslot', null, global);
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.NullRequest = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.NullRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.NullRequest.displayName = 'proto.com.keus.hub.NullRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.SceneIdentifier = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.SceneIdentifier, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.SceneIdentifier.displayName = 'proto.com.keus.hub.SceneIdentifier';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.AreaSceneAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.AreaSceneAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.AreaSceneAction.displayName = 'proto.com.keus.hub.AreaSceneAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.SceneAction = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, proto.com.keus.hub.SceneAction.oneofGroups_);
};
goog.inherits(proto.com.keus.hub.SceneAction, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.SceneAction.displayName = 'proto.com.keus.hub.SceneAction';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.SceneSyncInfo = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, proto.com.keus.hub.SceneSyncInfo.oneofGroups_);
};
goog.inherits(proto.com.keus.hub.SceneSyncInfo, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.SceneSyncInfo.displayName = 'proto.com.keus.hub.SceneSyncInfo';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.Timeslot = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.Timeslot, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.Timeslot.displayName = 'proto.com.keus.hub.Timeslot';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.Scene = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, proto.com.keus.hub.Scene.repeatedFields_, null);
};
goog.inherits(proto.com.keus.hub.Scene, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.Scene.displayName = 'proto.com.keus.hub.Scene';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.CreateScene = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.CreateScene, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.CreateScene.displayName = 'proto.com.keus.hub.CreateScene';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.CreateSceneResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.CreateSceneResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.CreateSceneResponse.displayName = 'proto.com.keus.hub.CreateSceneResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.EditSceneName = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.EditSceneName, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.EditSceneName.displayName = 'proto.com.keus.hub.EditSceneName';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.EditSceneNameResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.EditSceneNameResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.EditSceneNameResponse.displayName = 'proto.com.keus.hub.EditSceneNameResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.AddTimeslotToScene = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.AddTimeslotToScene, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.AddTimeslotToScene.displayName = 'proto.com.keus.hub.AddTimeslotToScene';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.AddTimeslotToSceneResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.AddTimeslotToSceneResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.AddTimeslotToSceneResponse.displayName = 'proto.com.keus.hub.AddTimeslotToSceneResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.RemoveTimeslotFromScene = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.RemoveTimeslotFromScene, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.RemoveTimeslotFromScene.displayName = 'proto.com.keus.hub.RemoveTimeslotFromScene';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.RemoveTimeslotFromSceneResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.RemoveTimeslotFromSceneResponse.displayName = 'proto.com.keus.hub.RemoveTimeslotFromSceneResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.AdjustTimeslotDelay = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.AdjustTimeslotDelay, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.AdjustTimeslotDelay.displayName = 'proto.com.keus.hub.AdjustTimeslotDelay';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.AdjustTimeslotDelayResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.AdjustTimeslotDelayResponse.displayName = 'proto.com.keus.hub.AdjustTimeslotDelayResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.AddActionToScene = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.AddActionToScene, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.AddActionToScene.displayName = 'proto.com.keus.hub.AddActionToScene';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.AddActionToSceneResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.AddActionToSceneResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.AddActionToSceneResponse.displayName = 'proto.com.keus.hub.AddActionToSceneResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.RemoveActionFromScene = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.RemoveActionFromScene, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.RemoveActionFromScene.displayName = 'proto.com.keus.hub.RemoveActionFromScene';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.RemoveActionFromSceneResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.RemoveActionFromSceneResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.RemoveActionFromSceneResponse.displayName = 'proto.com.keus.hub.RemoveActionFromSceneResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.ExecuteScene = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.ExecuteScene, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.ExecuteScene.displayName = 'proto.com.keus.hub.ExecuteScene';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.ExecuteSceneResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.ExecuteSceneResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.ExecuteSceneResponse.displayName = 'proto.com.keus.hub.ExecuteSceneResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.MoveSceneToRoom = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.MoveSceneToRoom, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.MoveSceneToRoom.displayName = 'proto.com.keus.hub.MoveSceneToRoom';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.MoveSceneToRoomResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.MoveSceneToRoomResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.MoveSceneToRoomResponse.displayName = 'proto.com.keus.hub.MoveSceneToRoomResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.DeleteScene = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.DeleteScene, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.DeleteScene.displayName = 'proto.com.keus.hub.DeleteScene';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.DeleteSceneResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.DeleteSceneResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.DeleteSceneResponse.displayName = 'proto.com.keus.hub.DeleteSceneResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.SyncAreaSceneUIData = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.SyncAreaSceneUIData, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.SyncAreaSceneUIData.displayName = 'proto.com.keus.hub.SyncAreaSceneUIData';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.SyncAreaSceneUIDataResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.SyncAreaSceneUIDataResponse.displayName = 'proto.com.keus.hub.SyncAreaSceneUIDataResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.ReportSceneExecutionActivity = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.ReportSceneExecutionActivity, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.ReportSceneExecutionActivity.displayName = 'proto.com.keus.hub.ReportSceneExecutionActivity';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.com.keus.hub.SceneExecutionEvent = function (opt_data) {
    jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.com.keus.hub.SceneExecutionEvent, jspb.Message);
if (goog.DEBUG && !COMPILED) {
    /**
     * @public
     * @override
     */
    proto.com.keus.hub.SceneExecutionEvent.displayName = 'proto.com.keus.hub.SceneExecutionEvent';
}
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.NullRequest.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.NullRequest.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.NullRequest} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.NullRequest.toObject = function (includeInstance, msg) {
        var f, obj = {};
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.NullRequest}
 */
proto.com.keus.hub.NullRequest.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.NullRequest;
    return proto.com.keus.hub.NullRequest.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.NullRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.NullRequest}
 */
proto.com.keus.hub.NullRequest.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.NullRequest.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.NullRequest.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.NullRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.NullRequest.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.SceneIdentifier.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.SceneIdentifier.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.SceneIdentifier} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.SceneIdentifier.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            areaId: jspb.Message.getFieldWithDefault(msg, 2, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.SceneIdentifier}
 */
proto.com.keus.hub.SceneIdentifier.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.SceneIdentifier;
    return proto.com.keus.hub.SceneIdentifier.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.SceneIdentifier} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.SceneIdentifier}
 */
proto.com.keus.hub.SceneIdentifier.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setAreaId(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.SceneIdentifier.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.SceneIdentifier.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.SceneIdentifier} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.SceneIdentifier.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeUint32(1, f);
    }
    f = message.getAreaId();
    if (f !== 0) {
        writer.writeUint32(2, f);
    }
};
/**
 * optional uint32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.SceneIdentifier.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SceneIdentifier} returns this
 */
proto.com.keus.hub.SceneIdentifier.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional uint32 area_id = 2;
 * @return {number}
 */
proto.com.keus.hub.SceneIdentifier.prototype.getAreaId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SceneIdentifier} returns this
 */
proto.com.keus.hub.SceneIdentifier.prototype.setAreaId = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.AreaSceneAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.AreaSceneAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.AreaSceneAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.AreaSceneAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            roomId: jspb.Message.getFieldWithDefault(msg, 2, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.AreaSceneAction}
 */
proto.com.keus.hub.AreaSceneAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.AreaSceneAction;
    return proto.com.keus.hub.AreaSceneAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.AreaSceneAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.AreaSceneAction}
 */
proto.com.keus.hub.AreaSceneAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setRoomId(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.AreaSceneAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.AreaSceneAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.AreaSceneAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.AreaSceneAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeUint32(1, f);
    }
    f = message.getRoomId();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
};
/**
 * optional uint32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.AreaSceneAction.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AreaSceneAction} returns this
 */
proto.com.keus.hub.AreaSceneAction.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string room_id = 2;
 * @return {string}
 */
proto.com.keus.hub.AreaSceneAction.prototype.getRoomId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.AreaSceneAction} returns this
 */
proto.com.keus.hub.AreaSceneAction.prototype.setRoomId = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * Oneof group definitions for this message. Each group defines the field
 * numbers belonging to that group. When of these fields' value is set, all
 * other fields in the group are cleared. During deserialization, if multiple
 * fields are encountered for a group, only the last value seen will be kept.
 * @private {!Array<!Array<number>>}
 * @const
 */
proto.com.keus.hub.SceneAction.oneofGroups_ = [[10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27]];
/**
 * @enum {number}
 */
proto.com.keus.hub.SceneAction.ActionItemCase = {
    ACTION_ITEM_NOT_SET: 0,
    ZDIMMABLE_DRIVER_ACTION: 10,
    ZNONDIMMABLE_DRIVER_ACTION: 11,
    DDIMMABLE_DRIVER_ACTION: 12,
    DNONDIMMABLE_DRIVER_ACTION: 13,
    ZCURTAIN_CONTROLLER_ACTION: 14,
    EMBEDDED_APPLIANCE_ACTION: 15,
    ZACFAN_CONTROLLER_ACTION: 16,
    ZDCFAN_CONTROLLER_ACTION: 17,
    ZRGBWWWA_DRIVER_ACTION: 18,
    ZSC_RELAY_ACTION: 19,
    ZIR_BLASTER_ACTION: 20,
    GRP_ONOFF_ACTION: 21,
    GRP_SINGLEDIMMER_ACTION: 22,
    GRP_FAN_ACTION: 23,
    GRP_COLORTUNABLE_ACTION: 24,
    AREA_SCENE_ACTION: 25,
    GRP_ZRGBWWA_ACTION: 26,
    DCOLORTUNABLE_DRIVER_ACTION: 27
};
/**
 * @return {proto.com.keus.hub.SceneAction.ActionItemCase}
 */
proto.com.keus.hub.SceneAction.prototype.getActionItemCase = function () {
    return /** @type {proto.com.keus.hub.SceneAction.ActionItemCase} */ (jspb.Message.computeOneofCase(this, proto.com.keus.hub.SceneAction.oneofGroups_[0]));
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.SceneAction.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.SceneAction.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.SceneAction} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.SceneAction.toObject = function (includeInstance, msg) {
        var f, obj = {
            actionId: jspb.Message.getFieldWithDefault(msg, 5, ""),
            actionType: jspb.Message.getFieldWithDefault(msg, 1, ""),
            timeslotId: jspb.Message.getFieldWithDefault(msg, 2, 0),
            syncStatus: jspb.Message.getFieldWithDefault(msg, 3, 0),
            syncRequestType: jspb.Message.getFieldWithDefault(msg, 4, 0),
            syncRequestId: jspb.Message.getFieldWithDefault(msg, 6, ""),
            zdimmableDriverAction: (f = msg.getZdimmableDriverAction()) && hub_devices_zigbee_dimmable_driver_pb.ZigbeeDimmableDriverAction.toObject(includeInstance, f),
            znondimmableDriverAction: (f = msg.getZnondimmableDriverAction()) && hub_devices_zigbee_nondimmable_driver_pb.ZigbeeNonDimmableDriverAction.toObject(includeInstance, f),
            ddimmableDriverAction: (f = msg.getDdimmableDriverAction()) && hub_devices_dali_dimmable_driver_pb.DaliDimmableDriverAction.toObject(includeInstance, f),
            dnondimmableDriverAction: (f = msg.getDnondimmableDriverAction()) && hub_devices_dali_nondimmable_driver_pb.DaliNonDimmableDriverAction.toObject(includeInstance, f),
            zcurtainControllerAction: (f = msg.getZcurtainControllerAction()) && hub_devices_zigbee_curtain_controller_pb.ZigbeeCurtainControllerAction.toObject(includeInstance, f),
            embeddedApplianceAction: (f = msg.getEmbeddedApplianceAction()) && hub_devices_zigbee_embedded_switch_pb.EmbeddedApplianceAction.toObject(includeInstance, f),
            zacfanControllerAction: (f = msg.getZacfanControllerAction()) && hub_devices_zigbee_ac_fan_controller_pb.ZigbeeACFanControllerAction.toObject(includeInstance, f),
            zdcfanControllerAction: (f = msg.getZdcfanControllerAction()) && hub_devices_zigbee_dc_fan_controller_pb.ZigbeeDCFanControllerAction.toObject(includeInstance, f),
            zrgbwwwaDriverAction: (f = msg.getZrgbwwwaDriverAction()) && hub_devices_zigbee_rgbwwa_driver_pb.ZigbeeRgbwwaAction.toObject(includeInstance, f),
            zscRelayAction: (f = msg.getZscRelayAction()) && hub_devices_smart_console_pb.SmartConsoleRelayAction.toObject(includeInstance, f),
            zirBlasterAction: (f = msg.getZirBlasterAction()) && hub_devices_zigbee_ir_blaster_pb.ZigbeeIRBlasterAction.toObject(includeInstance, f),
            grpOnoffAction: (f = msg.getGrpOnoffAction()) && hub_devices_zigbee_embedded_switch_pb.GroupOnOffApplianceAction.toObject(includeInstance, f),
            grpSingledimmerAction: (f = msg.getGrpSingledimmerAction()) && hub_devices_zigbee_embedded_switch_pb.GroupSingleDimmerApplianceAction.toObject(includeInstance, f),
            grpFanAction: (f = msg.getGrpFanAction()) && hub_devices_zigbee_embedded_switch_pb.GroupFanApplianceAction.toObject(includeInstance, f),
            grpColortunableAction: (f = msg.getGrpColortunableAction()) && hub_devices_zigbee_embedded_switch_pb.GroupColorTunableApplianceAction.toObject(includeInstance, f),
            areaSceneAction: (f = msg.getAreaSceneAction()) && proto.com.keus.hub.AreaSceneAction.toObject(includeInstance, f),
            grpZrgbwwaAction: (f = msg.getGrpZrgbwwaAction()) && hub_devices_zigbee_rgbwwa_driver_pb.GroupZigbeeRgbwwaAction.toObject(includeInstance, f),
            dcolortunableDriverAction: (f = msg.getDcolortunableDriverAction()) && hub_devices_dali_color_tunable_driver_pb.DaliColorTunableDriverGroupSceneAction.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.SceneAction}
 */
proto.com.keus.hub.SceneAction.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.SceneAction;
    return proto.com.keus.hub.SceneAction.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.SceneAction} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.SceneAction}
 */
proto.com.keus.hub.SceneAction.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 5:
                var value = /** @type {string} */ (reader.readString());
                msg.setActionId(value);
                break;
            case 1:
                var value = /** @type {string} */ (reader.readString());
                msg.setActionType(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setTimeslotId(value);
                break;
            case 3:
                var value = /** @type {!proto.com.keus.hub.ACTION_SYNC_STATES} */ (reader.readEnum());
                msg.setSyncStatus(value);
                break;
            case 4:
                var value = /** @type {!proto.com.keus.hub.ACTION_JOB_TYPES} */ (reader.readEnum());
                msg.setSyncRequestType(value);
                break;
            case 6:
                var value = /** @type {string} */ (reader.readString());
                msg.setSyncRequestId(value);
                break;
            case 10:
                var value = new hub_devices_zigbee_dimmable_driver_pb.ZigbeeDimmableDriverAction;
                reader.readMessage(value, hub_devices_zigbee_dimmable_driver_pb.ZigbeeDimmableDriverAction.deserializeBinaryFromReader);
                msg.setZdimmableDriverAction(value);
                break;
            case 11:
                var value = new hub_devices_zigbee_nondimmable_driver_pb.ZigbeeNonDimmableDriverAction;
                reader.readMessage(value, hub_devices_zigbee_nondimmable_driver_pb.ZigbeeNonDimmableDriverAction.deserializeBinaryFromReader);
                msg.setZnondimmableDriverAction(value);
                break;
            case 12:
                var value = new hub_devices_dali_dimmable_driver_pb.DaliDimmableDriverAction;
                reader.readMessage(value, hub_devices_dali_dimmable_driver_pb.DaliDimmableDriverAction.deserializeBinaryFromReader);
                msg.setDdimmableDriverAction(value);
                break;
            case 13:
                var value = new hub_devices_dali_nondimmable_driver_pb.DaliNonDimmableDriverAction;
                reader.readMessage(value, hub_devices_dali_nondimmable_driver_pb.DaliNonDimmableDriverAction.deserializeBinaryFromReader);
                msg.setDnondimmableDriverAction(value);
                break;
            case 14:
                var value = new hub_devices_zigbee_curtain_controller_pb.ZigbeeCurtainControllerAction;
                reader.readMessage(value, hub_devices_zigbee_curtain_controller_pb.ZigbeeCurtainControllerAction.deserializeBinaryFromReader);
                msg.setZcurtainControllerAction(value);
                break;
            case 15:
                var value = new hub_devices_zigbee_embedded_switch_pb.EmbeddedApplianceAction;
                reader.readMessage(value, hub_devices_zigbee_embedded_switch_pb.EmbeddedApplianceAction.deserializeBinaryFromReader);
                msg.setEmbeddedApplianceAction(value);
                break;
            case 16:
                var value = new hub_devices_zigbee_ac_fan_controller_pb.ZigbeeACFanControllerAction;
                reader.readMessage(value, hub_devices_zigbee_ac_fan_controller_pb.ZigbeeACFanControllerAction.deserializeBinaryFromReader);
                msg.setZacfanControllerAction(value);
                break;
            case 17:
                var value = new hub_devices_zigbee_dc_fan_controller_pb.ZigbeeDCFanControllerAction;
                reader.readMessage(value, hub_devices_zigbee_dc_fan_controller_pb.ZigbeeDCFanControllerAction.deserializeBinaryFromReader);
                msg.setZdcfanControllerAction(value);
                break;
            case 18:
                var value = new hub_devices_zigbee_rgbwwa_driver_pb.ZigbeeRgbwwaAction;
                reader.readMessage(value, hub_devices_zigbee_rgbwwa_driver_pb.ZigbeeRgbwwaAction.deserializeBinaryFromReader);
                msg.setZrgbwwwaDriverAction(value);
                break;
            case 19:
                var value = new hub_devices_smart_console_pb.SmartConsoleRelayAction;
                reader.readMessage(value, hub_devices_smart_console_pb.SmartConsoleRelayAction.deserializeBinaryFromReader);
                msg.setZscRelayAction(value);
                break;
            case 20:
                var value = new hub_devices_zigbee_ir_blaster_pb.ZigbeeIRBlasterAction;
                reader.readMessage(value, hub_devices_zigbee_ir_blaster_pb.ZigbeeIRBlasterAction.deserializeBinaryFromReader);
                msg.setZirBlasterAction(value);
                break;
            case 21:
                var value = new hub_devices_zigbee_embedded_switch_pb.GroupOnOffApplianceAction;
                reader.readMessage(value, hub_devices_zigbee_embedded_switch_pb.GroupOnOffApplianceAction.deserializeBinaryFromReader);
                msg.setGrpOnoffAction(value);
                break;
            case 22:
                var value = new hub_devices_zigbee_embedded_switch_pb.GroupSingleDimmerApplianceAction;
                reader.readMessage(value, hub_devices_zigbee_embedded_switch_pb.GroupSingleDimmerApplianceAction.deserializeBinaryFromReader);
                msg.setGrpSingledimmerAction(value);
                break;
            case 23:
                var value = new hub_devices_zigbee_embedded_switch_pb.GroupFanApplianceAction;
                reader.readMessage(value, hub_devices_zigbee_embedded_switch_pb.GroupFanApplianceAction.deserializeBinaryFromReader);
                msg.setGrpFanAction(value);
                break;
            case 24:
                var value = new hub_devices_zigbee_embedded_switch_pb.GroupColorTunableApplianceAction;
                reader.readMessage(value, hub_devices_zigbee_embedded_switch_pb.GroupColorTunableApplianceAction.deserializeBinaryFromReader);
                msg.setGrpColortunableAction(value);
                break;
            case 25:
                var value = new proto.com.keus.hub.AreaSceneAction;
                reader.readMessage(value, proto.com.keus.hub.AreaSceneAction.deserializeBinaryFromReader);
                msg.setAreaSceneAction(value);
                break;
            case 26:
                var value = new hub_devices_zigbee_rgbwwa_driver_pb.GroupZigbeeRgbwwaAction;
                reader.readMessage(value, hub_devices_zigbee_rgbwwa_driver_pb.GroupZigbeeRgbwwaAction.deserializeBinaryFromReader);
                msg.setGrpZrgbwwaAction(value);
                break;
            case 27:
                var value = new hub_devices_dali_color_tunable_driver_pb.DaliColorTunableDriverGroupSceneAction;
                reader.readMessage(value, hub_devices_dali_color_tunable_driver_pb.DaliColorTunableDriverGroupSceneAction.deserializeBinaryFromReader);
                msg.setDcolortunableDriverAction(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.SceneAction.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.SceneAction.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.SceneAction} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.SceneAction.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getActionId();
    if (f.length > 0) {
        writer.writeString(5, f);
    }
    f = message.getActionType();
    if (f.length > 0) {
        writer.writeString(1, f);
    }
    f = message.getTimeslotId();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getSyncStatus();
    if (f !== 0.0) {
        writer.writeEnum(3, f);
    }
    f = message.getSyncRequestType();
    if (f !== 0.0) {
        writer.writeEnum(4, f);
    }
    f = message.getSyncRequestId();
    if (f.length > 0) {
        writer.writeString(6, f);
    }
    f = message.getZdimmableDriverAction();
    if (f != null) {
        writer.writeMessage(10, f, hub_devices_zigbee_dimmable_driver_pb.ZigbeeDimmableDriverAction.serializeBinaryToWriter);
    }
    f = message.getZnondimmableDriverAction();
    if (f != null) {
        writer.writeMessage(11, f, hub_devices_zigbee_nondimmable_driver_pb.ZigbeeNonDimmableDriverAction.serializeBinaryToWriter);
    }
    f = message.getDdimmableDriverAction();
    if (f != null) {
        writer.writeMessage(12, f, hub_devices_dali_dimmable_driver_pb.DaliDimmableDriverAction.serializeBinaryToWriter);
    }
    f = message.getDnondimmableDriverAction();
    if (f != null) {
        writer.writeMessage(13, f, hub_devices_dali_nondimmable_driver_pb.DaliNonDimmableDriverAction.serializeBinaryToWriter);
    }
    f = message.getZcurtainControllerAction();
    if (f != null) {
        writer.writeMessage(14, f, hub_devices_zigbee_curtain_controller_pb.ZigbeeCurtainControllerAction.serializeBinaryToWriter);
    }
    f = message.getEmbeddedApplianceAction();
    if (f != null) {
        writer.writeMessage(15, f, hub_devices_zigbee_embedded_switch_pb.EmbeddedApplianceAction.serializeBinaryToWriter);
    }
    f = message.getZacfanControllerAction();
    if (f != null) {
        writer.writeMessage(16, f, hub_devices_zigbee_ac_fan_controller_pb.ZigbeeACFanControllerAction.serializeBinaryToWriter);
    }
    f = message.getZdcfanControllerAction();
    if (f != null) {
        writer.writeMessage(17, f, hub_devices_zigbee_dc_fan_controller_pb.ZigbeeDCFanControllerAction.serializeBinaryToWriter);
    }
    f = message.getZrgbwwwaDriverAction();
    if (f != null) {
        writer.writeMessage(18, f, hub_devices_zigbee_rgbwwa_driver_pb.ZigbeeRgbwwaAction.serializeBinaryToWriter);
    }
    f = message.getZscRelayAction();
    if (f != null) {
        writer.writeMessage(19, f, hub_devices_smart_console_pb.SmartConsoleRelayAction.serializeBinaryToWriter);
    }
    f = message.getZirBlasterAction();
    if (f != null) {
        writer.writeMessage(20, f, hub_devices_zigbee_ir_blaster_pb.ZigbeeIRBlasterAction.serializeBinaryToWriter);
    }
    f = message.getGrpOnoffAction();
    if (f != null) {
        writer.writeMessage(21, f, hub_devices_zigbee_embedded_switch_pb.GroupOnOffApplianceAction.serializeBinaryToWriter);
    }
    f = message.getGrpSingledimmerAction();
    if (f != null) {
        writer.writeMessage(22, f, hub_devices_zigbee_embedded_switch_pb.GroupSingleDimmerApplianceAction.serializeBinaryToWriter);
    }
    f = message.getGrpFanAction();
    if (f != null) {
        writer.writeMessage(23, f, hub_devices_zigbee_embedded_switch_pb.GroupFanApplianceAction.serializeBinaryToWriter);
    }
    f = message.getGrpColortunableAction();
    if (f != null) {
        writer.writeMessage(24, f, hub_devices_zigbee_embedded_switch_pb.GroupColorTunableApplianceAction.serializeBinaryToWriter);
    }
    f = message.getAreaSceneAction();
    if (f != null) {
        writer.writeMessage(25, f, proto.com.keus.hub.AreaSceneAction.serializeBinaryToWriter);
    }
    f = message.getGrpZrgbwwaAction();
    if (f != null) {
        writer.writeMessage(26, f, hub_devices_zigbee_rgbwwa_driver_pb.GroupZigbeeRgbwwaAction.serializeBinaryToWriter);
    }
    f = message.getDcolortunableDriverAction();
    if (f != null) {
        writer.writeMessage(27, f, hub_devices_dali_color_tunable_driver_pb.DaliColorTunableDriverGroupSceneAction.serializeBinaryToWriter);
    }
};
/**
 * optional string action_id = 5;
 * @return {string}
 */
proto.com.keus.hub.SceneAction.prototype.getActionId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.setActionId = function (value) {
    return jspb.Message.setProto3StringField(this, 5, value);
};
/**
 * optional string action_type = 1;
 * @return {string}
 */
proto.com.keus.hub.SceneAction.prototype.getActionType = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.setActionType = function (value) {
    return jspb.Message.setProto3StringField(this, 1, value);
};
/**
 * optional int32 timeslot_id = 2;
 * @return {number}
 */
proto.com.keus.hub.SceneAction.prototype.getTimeslotId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.setTimeslotId = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional ACTION_SYNC_STATES sync_status = 3;
 * @return {!proto.com.keus.hub.ACTION_SYNC_STATES}
 */
proto.com.keus.hub.SceneAction.prototype.getSyncStatus = function () {
    return /** @type {!proto.com.keus.hub.ACTION_SYNC_STATES} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};
/**
 * @param {!proto.com.keus.hub.ACTION_SYNC_STATES} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.setSyncStatus = function (value) {
    return jspb.Message.setProto3EnumField(this, 3, value);
};
/**
 * optional ACTION_JOB_TYPES sync_request_type = 4;
 * @return {!proto.com.keus.hub.ACTION_JOB_TYPES}
 */
proto.com.keus.hub.SceneAction.prototype.getSyncRequestType = function () {
    return /** @type {!proto.com.keus.hub.ACTION_JOB_TYPES} */ (jspb.Message.getFieldWithDefault(this, 4, 0));
};
/**
 * @param {!proto.com.keus.hub.ACTION_JOB_TYPES} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.setSyncRequestType = function (value) {
    return jspb.Message.setProto3EnumField(this, 4, value);
};
/**
 * optional string sync_request_id = 6;
 * @return {string}
 */
proto.com.keus.hub.SceneAction.prototype.getSyncRequestId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 6, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.setSyncRequestId = function (value) {
    return jspb.Message.setProto3StringField(this, 6, value);
};
/**
 * optional ZigbeeDimmableDriverAction zdimmable_driver_action = 10;
 * @return {?proto.com.keus.hub.ZigbeeDimmableDriverAction}
 */
proto.com.keus.hub.SceneAction.prototype.getZdimmableDriverAction = function () {
    return /** @type{?proto.com.keus.hub.ZigbeeDimmableDriverAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_dimmable_driver_pb.ZigbeeDimmableDriverAction, 10));
};
/**
 * @param {?proto.com.keus.hub.ZigbeeDimmableDriverAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setZdimmableDriverAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 10, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearZdimmableDriverAction = function () {
    return this.setZdimmableDriverAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasZdimmableDriverAction = function () {
    return jspb.Message.getField(this, 10) != null;
};
/**
 * optional ZigbeeNonDimmableDriverAction znondimmable_driver_action = 11;
 * @return {?proto.com.keus.hub.ZigbeeNonDimmableDriverAction}
 */
proto.com.keus.hub.SceneAction.prototype.getZnondimmableDriverAction = function () {
    return /** @type{?proto.com.keus.hub.ZigbeeNonDimmableDriverAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_nondimmable_driver_pb.ZigbeeNonDimmableDriverAction, 11));
};
/**
 * @param {?proto.com.keus.hub.ZigbeeNonDimmableDriverAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setZnondimmableDriverAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 11, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearZnondimmableDriverAction = function () {
    return this.setZnondimmableDriverAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasZnondimmableDriverAction = function () {
    return jspb.Message.getField(this, 11) != null;
};
/**
 * optional DaliDimmableDriverAction ddimmable_driver_action = 12;
 * @return {?proto.com.keus.hub.DaliDimmableDriverAction}
 */
proto.com.keus.hub.SceneAction.prototype.getDdimmableDriverAction = function () {
    return /** @type{?proto.com.keus.hub.DaliDimmableDriverAction} */ (jspb.Message.getWrapperField(this, hub_devices_dali_dimmable_driver_pb.DaliDimmableDriverAction, 12));
};
/**
 * @param {?proto.com.keus.hub.DaliDimmableDriverAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setDdimmableDriverAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 12, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearDdimmableDriverAction = function () {
    return this.setDdimmableDriverAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasDdimmableDriverAction = function () {
    return jspb.Message.getField(this, 12) != null;
};
/**
 * optional DaliNonDimmableDriverAction dnondimmable_driver_action = 13;
 * @return {?proto.com.keus.hub.DaliNonDimmableDriverAction}
 */
proto.com.keus.hub.SceneAction.prototype.getDnondimmableDriverAction = function () {
    return /** @type{?proto.com.keus.hub.DaliNonDimmableDriverAction} */ (jspb.Message.getWrapperField(this, hub_devices_dali_nondimmable_driver_pb.DaliNonDimmableDriverAction, 13));
};
/**
 * @param {?proto.com.keus.hub.DaliNonDimmableDriverAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setDnondimmableDriverAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 13, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearDnondimmableDriverAction = function () {
    return this.setDnondimmableDriverAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasDnondimmableDriverAction = function () {
    return jspb.Message.getField(this, 13) != null;
};
/**
 * optional ZigbeeCurtainControllerAction zcurtain_controller_action = 14;
 * @return {?proto.com.keus.hub.ZigbeeCurtainControllerAction}
 */
proto.com.keus.hub.SceneAction.prototype.getZcurtainControllerAction = function () {
    return /** @type{?proto.com.keus.hub.ZigbeeCurtainControllerAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_curtain_controller_pb.ZigbeeCurtainControllerAction, 14));
};
/**
 * @param {?proto.com.keus.hub.ZigbeeCurtainControllerAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setZcurtainControllerAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 14, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearZcurtainControllerAction = function () {
    return this.setZcurtainControllerAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasZcurtainControllerAction = function () {
    return jspb.Message.getField(this, 14) != null;
};
/**
 * optional EmbeddedApplianceAction embedded_appliance_action = 15;
 * @return {?proto.com.keus.hub.EmbeddedApplianceAction}
 */
proto.com.keus.hub.SceneAction.prototype.getEmbeddedApplianceAction = function () {
    return /** @type{?proto.com.keus.hub.EmbeddedApplianceAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_embedded_switch_pb.EmbeddedApplianceAction, 15));
};
/**
 * @param {?proto.com.keus.hub.EmbeddedApplianceAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setEmbeddedApplianceAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 15, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearEmbeddedApplianceAction = function () {
    return this.setEmbeddedApplianceAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasEmbeddedApplianceAction = function () {
    return jspb.Message.getField(this, 15) != null;
};
/**
 * optional ZigbeeACFanControllerAction zACFan_controller_action = 16;
 * @return {?proto.com.keus.hub.ZigbeeACFanControllerAction}
 */
proto.com.keus.hub.SceneAction.prototype.getZacfanControllerAction = function () {
    return /** @type{?proto.com.keus.hub.ZigbeeACFanControllerAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_ac_fan_controller_pb.ZigbeeACFanControllerAction, 16));
};
/**
 * @param {?proto.com.keus.hub.ZigbeeACFanControllerAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setZacfanControllerAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 16, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearZacfanControllerAction = function () {
    return this.setZacfanControllerAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasZacfanControllerAction = function () {
    return jspb.Message.getField(this, 16) != null;
};
/**
 * optional ZigbeeDCFanControllerAction zDCFan_controller_action = 17;
 * @return {?proto.com.keus.hub.ZigbeeDCFanControllerAction}
 */
proto.com.keus.hub.SceneAction.prototype.getZdcfanControllerAction = function () {
    return /** @type{?proto.com.keus.hub.ZigbeeDCFanControllerAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_dc_fan_controller_pb.ZigbeeDCFanControllerAction, 17));
};
/**
 * @param {?proto.com.keus.hub.ZigbeeDCFanControllerAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setZdcfanControllerAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 17, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearZdcfanControllerAction = function () {
    return this.setZdcfanControllerAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasZdcfanControllerAction = function () {
    return jspb.Message.getField(this, 17) != null;
};
/**
 * optional ZigbeeRgbwwaAction zRgbwwwa_driver_action = 18;
 * @return {?proto.com.keus.hub.ZigbeeRgbwwaAction}
 */
proto.com.keus.hub.SceneAction.prototype.getZrgbwwwaDriverAction = function () {
    return /** @type{?proto.com.keus.hub.ZigbeeRgbwwaAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_rgbwwa_driver_pb.ZigbeeRgbwwaAction, 18));
};
/**
 * @param {?proto.com.keus.hub.ZigbeeRgbwwaAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setZrgbwwwaDriverAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 18, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearZrgbwwwaDriverAction = function () {
    return this.setZrgbwwwaDriverAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasZrgbwwwaDriverAction = function () {
    return jspb.Message.getField(this, 18) != null;
};
/**
 * optional SmartConsoleRelayAction zsc_relay_action = 19;
 * @return {?proto.com.keus.hub.SmartConsoleRelayAction}
 */
proto.com.keus.hub.SceneAction.prototype.getZscRelayAction = function () {
    return /** @type{?proto.com.keus.hub.SmartConsoleRelayAction} */ (jspb.Message.getWrapperField(this, hub_devices_smart_console_pb.SmartConsoleRelayAction, 19));
};
/**
 * @param {?proto.com.keus.hub.SmartConsoleRelayAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setZscRelayAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 19, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearZscRelayAction = function () {
    return this.setZscRelayAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasZscRelayAction = function () {
    return jspb.Message.getField(this, 19) != null;
};
/**
 * optional ZigbeeIRBlasterAction zir_blaster_action = 20;
 * @return {?proto.com.keus.hub.ZigbeeIRBlasterAction}
 */
proto.com.keus.hub.SceneAction.prototype.getZirBlasterAction = function () {
    return /** @type{?proto.com.keus.hub.ZigbeeIRBlasterAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_ir_blaster_pb.ZigbeeIRBlasterAction, 20));
};
/**
 * @param {?proto.com.keus.hub.ZigbeeIRBlasterAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setZirBlasterAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 20, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearZirBlasterAction = function () {
    return this.setZirBlasterAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasZirBlasterAction = function () {
    return jspb.Message.getField(this, 20) != null;
};
/**
 * optional GroupOnOffApplianceAction grp_onoff_action = 21;
 * @return {?proto.com.keus.hub.GroupOnOffApplianceAction}
 */
proto.com.keus.hub.SceneAction.prototype.getGrpOnoffAction = function () {
    return /** @type{?proto.com.keus.hub.GroupOnOffApplianceAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_embedded_switch_pb.GroupOnOffApplianceAction, 21));
};
/**
 * @param {?proto.com.keus.hub.GroupOnOffApplianceAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setGrpOnoffAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 21, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearGrpOnoffAction = function () {
    return this.setGrpOnoffAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasGrpOnoffAction = function () {
    return jspb.Message.getField(this, 21) != null;
};
/**
 * optional GroupSingleDimmerApplianceAction grp_singledimmer_action = 22;
 * @return {?proto.com.keus.hub.GroupSingleDimmerApplianceAction}
 */
proto.com.keus.hub.SceneAction.prototype.getGrpSingledimmerAction = function () {
    return /** @type{?proto.com.keus.hub.GroupSingleDimmerApplianceAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_embedded_switch_pb.GroupSingleDimmerApplianceAction, 22));
};
/**
 * @param {?proto.com.keus.hub.GroupSingleDimmerApplianceAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setGrpSingledimmerAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 22, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearGrpSingledimmerAction = function () {
    return this.setGrpSingledimmerAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasGrpSingledimmerAction = function () {
    return jspb.Message.getField(this, 22) != null;
};
/**
 * optional GroupFanApplianceAction grp_fan_action = 23;
 * @return {?proto.com.keus.hub.GroupFanApplianceAction}
 */
proto.com.keus.hub.SceneAction.prototype.getGrpFanAction = function () {
    return /** @type{?proto.com.keus.hub.GroupFanApplianceAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_embedded_switch_pb.GroupFanApplianceAction, 23));
};
/**
 * @param {?proto.com.keus.hub.GroupFanApplianceAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setGrpFanAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 23, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearGrpFanAction = function () {
    return this.setGrpFanAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasGrpFanAction = function () {
    return jspb.Message.getField(this, 23) != null;
};
/**
 * optional GroupColorTunableApplianceAction grp_colortunable_action = 24;
 * @return {?proto.com.keus.hub.GroupColorTunableApplianceAction}
 */
proto.com.keus.hub.SceneAction.prototype.getGrpColortunableAction = function () {
    return /** @type{?proto.com.keus.hub.GroupColorTunableApplianceAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_embedded_switch_pb.GroupColorTunableApplianceAction, 24));
};
/**
 * @param {?proto.com.keus.hub.GroupColorTunableApplianceAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setGrpColortunableAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 24, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearGrpColortunableAction = function () {
    return this.setGrpColortunableAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasGrpColortunableAction = function () {
    return jspb.Message.getField(this, 24) != null;
};
/**
 * optional AreaSceneAction area_scene_action = 25;
 * @return {?proto.com.keus.hub.AreaSceneAction}
 */
proto.com.keus.hub.SceneAction.prototype.getAreaSceneAction = function () {
    return /** @type{?proto.com.keus.hub.AreaSceneAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.AreaSceneAction, 25));
};
/**
 * @param {?proto.com.keus.hub.AreaSceneAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setAreaSceneAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 25, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearAreaSceneAction = function () {
    return this.setAreaSceneAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasAreaSceneAction = function () {
    return jspb.Message.getField(this, 25) != null;
};
/**
 * optional GroupZigbeeRgbwwaAction grp_zrgbwwa_action = 26;
 * @return {?proto.com.keus.hub.GroupZigbeeRgbwwaAction}
 */
proto.com.keus.hub.SceneAction.prototype.getGrpZrgbwwaAction = function () {
    return /** @type{?proto.com.keus.hub.GroupZigbeeRgbwwaAction} */ (jspb.Message.getWrapperField(this, hub_devices_zigbee_rgbwwa_driver_pb.GroupZigbeeRgbwwaAction, 26));
};
/**
 * @param {?proto.com.keus.hub.GroupZigbeeRgbwwaAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setGrpZrgbwwaAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 26, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearGrpZrgbwwaAction = function () {
    return this.setGrpZrgbwwaAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasGrpZrgbwwaAction = function () {
    return jspb.Message.getField(this, 26) != null;
};
/**
 * optional DaliColorTunableDriverGroupSceneAction dcolortunable_driver_action = 27;
 * @return {?proto.com.keus.hub.DaliColorTunableDriverGroupSceneAction}
 */
proto.com.keus.hub.SceneAction.prototype.getDcolortunableDriverAction = function () {
    return /** @type{?proto.com.keus.hub.DaliColorTunableDriverGroupSceneAction} */ (jspb.Message.getWrapperField(this, hub_devices_dali_color_tunable_driver_pb.DaliColorTunableDriverGroupSceneAction, 27));
};
/**
 * @param {?proto.com.keus.hub.DaliColorTunableDriverGroupSceneAction|undefined} value
 * @return {!proto.com.keus.hub.SceneAction} returns this
*/
proto.com.keus.hub.SceneAction.prototype.setDcolortunableDriverAction = function (value) {
    return jspb.Message.setOneofWrapperField(this, 27, proto.com.keus.hub.SceneAction.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneAction} returns this
 */
proto.com.keus.hub.SceneAction.prototype.clearDcolortunableDriverAction = function () {
    return this.setDcolortunableDriverAction(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneAction.prototype.hasDcolortunableDriverAction = function () {
    return jspb.Message.getField(this, 27) != null;
};
/**
 * Oneof group definitions for this message. Each group defines the field
 * numbers belonging to that group. When of these fields' value is set, all
 * other fields in the group are cleared. During deserialization, if multiple
 * fields are encountered for a group, only the last value seen will be kept.
 * @private {!Array<!Array<number>>}
 * @const
 */
proto.com.keus.hub.SceneSyncInfo.oneofGroups_ = [[10, 11, 12]];
/**
 * @enum {number}
 */
proto.com.keus.hub.SceneSyncInfo.SyncRequestParamsCase = {
    SYNC_REQUEST_PARAMS_NOT_SET: 0,
    NULL_REQUEST_PARAMS: 10,
    ADJUST_TIMESLOT_DELAY_PARAMS: 11,
    REMOVE_TIMESLOT_PARAMS: 12
};
/**
 * @return {proto.com.keus.hub.SceneSyncInfo.SyncRequestParamsCase}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.getSyncRequestParamsCase = function () {
    return /** @type {proto.com.keus.hub.SceneSyncInfo.SyncRequestParamsCase} */ (jspb.Message.computeOneofCase(this, proto.com.keus.hub.SceneSyncInfo.oneofGroups_[0]));
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.SceneSyncInfo.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.SceneSyncInfo.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.SceneSyncInfo} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.SceneSyncInfo.toObject = function (includeInstance, msg) {
        var f, obj = {
            syncStatus: jspb.Message.getFieldWithDefault(msg, 1, 0),
            syncRequestType: jspb.Message.getFieldWithDefault(msg, 2, 0),
            syncRequestId: jspb.Message.getFieldWithDefault(msg, 3, ""),
            syncRequestTime: jspb.Message.getFieldWithDefault(msg, 4, 0),
            nullRequestParams: (f = msg.getNullRequestParams()) && proto.com.keus.hub.NullRequest.toObject(includeInstance, f),
            adjustTimeslotDelayParams: (f = msg.getAdjustTimeslotDelayParams()) && proto.com.keus.hub.AdjustTimeslotDelay.toObject(includeInstance, f),
            removeTimeslotParams: (f = msg.getRemoveTimeslotParams()) && proto.com.keus.hub.RemoveTimeslotFromScene.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.SceneSyncInfo}
 */
proto.com.keus.hub.SceneSyncInfo.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.SceneSyncInfo;
    return proto.com.keus.hub.SceneSyncInfo.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.SceneSyncInfo} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.SceneSyncInfo}
 */
proto.com.keus.hub.SceneSyncInfo.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {!proto.com.keus.hub.SCENE_SYNC_STATES} */ (reader.readEnum());
                msg.setSyncStatus(value);
                break;
            case 2:
                var value = /** @type {!proto.com.keus.hub.SCENE_JOB_TYPES} */ (reader.readEnum());
                msg.setSyncRequestType(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setSyncRequestId(value);
                break;
            case 4:
                var value = /** @type {number} */ (reader.readInt64());
                msg.setSyncRequestTime(value);
                break;
            case 10:
                var value = new proto.com.keus.hub.NullRequest;
                reader.readMessage(value, proto.com.keus.hub.NullRequest.deserializeBinaryFromReader);
                msg.setNullRequestParams(value);
                break;
            case 11:
                var value = new proto.com.keus.hub.AdjustTimeslotDelay;
                reader.readMessage(value, proto.com.keus.hub.AdjustTimeslotDelay.deserializeBinaryFromReader);
                msg.setAdjustTimeslotDelayParams(value);
                break;
            case 12:
                var value = new proto.com.keus.hub.RemoveTimeslotFromScene;
                reader.readMessage(value, proto.com.keus.hub.RemoveTimeslotFromScene.deserializeBinaryFromReader);
                msg.setRemoveTimeslotParams(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.SceneSyncInfo.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.SceneSyncInfo} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.SceneSyncInfo.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSyncStatus();
    if (f !== 0.0) {
        writer.writeEnum(1, f);
    }
    f = message.getSyncRequestType();
    if (f !== 0.0) {
        writer.writeEnum(2, f);
    }
    f = message.getSyncRequestId();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getSyncRequestTime();
    if (f !== 0) {
        writer.writeInt64(4, f);
    }
    f = message.getNullRequestParams();
    if (f != null) {
        writer.writeMessage(10, f, proto.com.keus.hub.NullRequest.serializeBinaryToWriter);
    }
    f = message.getAdjustTimeslotDelayParams();
    if (f != null) {
        writer.writeMessage(11, f, proto.com.keus.hub.AdjustTimeslotDelay.serializeBinaryToWriter);
    }
    f = message.getRemoveTimeslotParams();
    if (f != null) {
        writer.writeMessage(12, f, proto.com.keus.hub.RemoveTimeslotFromScene.serializeBinaryToWriter);
    }
};
/**
 * optional SCENE_SYNC_STATES sync_status = 1;
 * @return {!proto.com.keus.hub.SCENE_SYNC_STATES}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.getSyncStatus = function () {
    return /** @type {!proto.com.keus.hub.SCENE_SYNC_STATES} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {!proto.com.keus.hub.SCENE_SYNC_STATES} value
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
 */
proto.com.keus.hub.SceneSyncInfo.prototype.setSyncStatus = function (value) {
    return jspb.Message.setProto3EnumField(this, 1, value);
};
/**
 * optional SCENE_JOB_TYPES sync_request_type = 2;
 * @return {!proto.com.keus.hub.SCENE_JOB_TYPES}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.getSyncRequestType = function () {
    return /** @type {!proto.com.keus.hub.SCENE_JOB_TYPES} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {!proto.com.keus.hub.SCENE_JOB_TYPES} value
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
 */
proto.com.keus.hub.SceneSyncInfo.prototype.setSyncRequestType = function (value) {
    return jspb.Message.setProto3EnumField(this, 2, value);
};
/**
 * optional string sync_request_id = 3;
 * @return {string}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.getSyncRequestId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
 */
proto.com.keus.hub.SceneSyncInfo.prototype.setSyncRequestId = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional int64 sync_request_time = 4;
 * @return {number}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.getSyncRequestTime = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 4, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
 */
proto.com.keus.hub.SceneSyncInfo.prototype.setSyncRequestTime = function (value) {
    return jspb.Message.setProto3IntField(this, 4, value);
};
/**
 * optional NullRequest null_request_params = 10;
 * @return {?proto.com.keus.hub.NullRequest}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.getNullRequestParams = function () {
    return /** @type{?proto.com.keus.hub.NullRequest} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.NullRequest, 10));
};
/**
 * @param {?proto.com.keus.hub.NullRequest|undefined} value
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
*/
proto.com.keus.hub.SceneSyncInfo.prototype.setNullRequestParams = function (value) {
    return jspb.Message.setOneofWrapperField(this, 10, proto.com.keus.hub.SceneSyncInfo.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
 */
proto.com.keus.hub.SceneSyncInfo.prototype.clearNullRequestParams = function () {
    return this.setNullRequestParams(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.hasNullRequestParams = function () {
    return jspb.Message.getField(this, 10) != null;
};
/**
 * optional AdjustTimeslotDelay adjust_timeslot_delay_params = 11;
 * @return {?proto.com.keus.hub.AdjustTimeslotDelay}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.getAdjustTimeslotDelayParams = function () {
    return /** @type{?proto.com.keus.hub.AdjustTimeslotDelay} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.AdjustTimeslotDelay, 11));
};
/**
 * @param {?proto.com.keus.hub.AdjustTimeslotDelay|undefined} value
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
*/
proto.com.keus.hub.SceneSyncInfo.prototype.setAdjustTimeslotDelayParams = function (value) {
    return jspb.Message.setOneofWrapperField(this, 11, proto.com.keus.hub.SceneSyncInfo.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
 */
proto.com.keus.hub.SceneSyncInfo.prototype.clearAdjustTimeslotDelayParams = function () {
    return this.setAdjustTimeslotDelayParams(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.hasAdjustTimeslotDelayParams = function () {
    return jspb.Message.getField(this, 11) != null;
};
/**
 * optional RemoveTimeslotFromScene remove_timeslot_params = 12;
 * @return {?proto.com.keus.hub.RemoveTimeslotFromScene}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.getRemoveTimeslotParams = function () {
    return /** @type{?proto.com.keus.hub.RemoveTimeslotFromScene} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.RemoveTimeslotFromScene, 12));
};
/**
 * @param {?proto.com.keus.hub.RemoveTimeslotFromScene|undefined} value
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
*/
proto.com.keus.hub.SceneSyncInfo.prototype.setRemoveTimeslotParams = function (value) {
    return jspb.Message.setOneofWrapperField(this, 12, proto.com.keus.hub.SceneSyncInfo.oneofGroups_[0], value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.SceneSyncInfo} returns this
 */
proto.com.keus.hub.SceneSyncInfo.prototype.clearRemoveTimeslotParams = function () {
    return this.setRemoveTimeslotParams(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.SceneSyncInfo.prototype.hasRemoveTimeslotParams = function () {
    return jspb.Message.getField(this, 12) != null;
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.Timeslot.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.Timeslot.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.Timeslot} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.Timeslot.toObject = function (includeInstance, msg) {
        var f, obj = {
            timeslotId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            timeslotDelay: jspb.Message.getFieldWithDefault(msg, 2, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.Timeslot}
 */
proto.com.keus.hub.Timeslot.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.Timeslot;
    return proto.com.keus.hub.Timeslot.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.Timeslot} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.Timeslot}
 */
proto.com.keus.hub.Timeslot.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setTimeslotId(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setTimeslotDelay(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.Timeslot.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.Timeslot.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.Timeslot} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.Timeslot.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getTimeslotId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getTimeslotDelay();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
};
/**
 * optional int32 timeslot_id = 1;
 * @return {number}
 */
proto.com.keus.hub.Timeslot.prototype.getTimeslotId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.Timeslot} returns this
 */
proto.com.keus.hub.Timeslot.prototype.setTimeslotId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional int32 timeslot_delay = 2;
 * @return {number}
 */
proto.com.keus.hub.Timeslot.prototype.getTimeslotDelay = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.Timeslot} returns this
 */
proto.com.keus.hub.Timeslot.prototype.setTimeslotDelay = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.com.keus.hub.Scene.repeatedFields_ = [8, 9];
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.Scene.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.Scene.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.Scene} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.Scene.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneName: jspb.Message.getFieldWithDefault(msg, 2, ""),
            sceneType: jspb.Message.getFieldWithDefault(msg, 3, 0),
            sceneSection: jspb.Message.getFieldWithDefault(msg, 4, ""),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 5, ""),
            sceneScope: jspb.Message.getFieldWithDefault(msg, 6, 0),
            sceneExecutionType: jspb.Message.getFieldWithDefault(msg, 7, 0),
            actionList: jspb.Message.toObjectList(msg.getActionList(), proto.com.keus.hub.SceneAction.toObject, includeInstance),
            timeslotList: jspb.Message.toObjectList(msg.getTimeslotList(), proto.com.keus.hub.Timeslot.toObject, includeInstance),
            lastUpdateTime: jspb.Message.getFieldWithDefault(msg, 50, 0),
            lastUpdateBy: jspb.Message.getFieldWithDefault(msg, 51, ""),
            lastUpdateUser: jspb.Message.getFieldWithDefault(msg, 52, ""),
            lastUpdateSource: jspb.Message.getFieldWithDefault(msg, 53, ""),
            sceneSyncInfo: (f = msg.getSceneSyncInfo()) && proto.com.keus.hub.SceneSyncInfo.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.Scene}
 */
proto.com.keus.hub.Scene.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.Scene;
    return proto.com.keus.hub.Scene.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.Scene} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.Scene}
 */
proto.com.keus.hub.Scene.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneName(value);
                break;
            case 3:
                var value = /** @type {!proto.com.keus.hub.SCENE_TYPE} */ (reader.readEnum());
                msg.setSceneType(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneSection(value);
                break;
            case 5:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 6:
                var value = /** @type {!proto.com.keus.hub.SCENE_SCOPE} */ (reader.readEnum());
                msg.setSceneScope(value);
                break;
            case 7:
                var value = /** @type {!proto.com.keus.hub.SCENE_EXECTYPE} */ (reader.readEnum());
                msg.setSceneExecutionType(value);
                break;
            case 8:
                var value = new proto.com.keus.hub.SceneAction;
                reader.readMessage(value, proto.com.keus.hub.SceneAction.deserializeBinaryFromReader);
                msg.addAction(value);
                break;
            case 9:
                var value = new proto.com.keus.hub.Timeslot;
                reader.readMessage(value, proto.com.keus.hub.Timeslot.deserializeBinaryFromReader);
                msg.addTimeslot(value);
                break;
            case 50:
                var value = /** @type {number} */ (reader.readInt64());
                msg.setLastUpdateTime(value);
                break;
            case 51:
                var value = /** @type {string} */ (reader.readString());
                msg.setLastUpdateBy(value);
                break;
            case 52:
                var value = /** @type {string} */ (reader.readString());
                msg.setLastUpdateUser(value);
                break;
            case 53:
                var value = /** @type {string} */ (reader.readString());
                msg.setLastUpdateSource(value);
                break;
            case 54:
                var value = new proto.com.keus.hub.SceneSyncInfo;
                reader.readMessage(value, proto.com.keus.hub.SceneSyncInfo.deserializeBinaryFromReader);
                msg.setSceneSyncInfo(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.Scene.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.Scene.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.Scene} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.Scene.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSceneName();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getSceneType();
    if (f !== 0.0) {
        writer.writeEnum(3, f);
    }
    f = message.getSceneSection();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(5, f);
    }
    f = message.getSceneScope();
    if (f !== 0.0) {
        writer.writeEnum(6, f);
    }
    f = message.getSceneExecutionType();
    if (f !== 0.0) {
        writer.writeEnum(7, f);
    }
    f = message.getActionList();
    if (f.length > 0) {
        writer.writeRepeatedMessage(8, f, proto.com.keus.hub.SceneAction.serializeBinaryToWriter);
    }
    f = message.getTimeslotList();
    if (f.length > 0) {
        writer.writeRepeatedMessage(9, f, proto.com.keus.hub.Timeslot.serializeBinaryToWriter);
    }
    f = message.getLastUpdateTime();
    if (f !== 0) {
        writer.writeInt64(50, f);
    }
    f = message.getLastUpdateBy();
    if (f.length > 0) {
        writer.writeString(51, f);
    }
    f = message.getLastUpdateUser();
    if (f.length > 0) {
        writer.writeString(52, f);
    }
    f = message.getLastUpdateSource();
    if (f.length > 0) {
        writer.writeString(53, f);
    }
    f = message.getSceneSyncInfo();
    if (f != null) {
        writer.writeMessage(54, f, proto.com.keus.hub.SceneSyncInfo.serializeBinaryToWriter);
    }
};
/**
 * optional int32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.Scene.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_name = 2;
 * @return {string}
 */
proto.com.keus.hub.Scene.prototype.getSceneName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setSceneName = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional SCENE_TYPE scene_type = 3;
 * @return {!proto.com.keus.hub.SCENE_TYPE}
 */
proto.com.keus.hub.Scene.prototype.getSceneType = function () {
    return /** @type {!proto.com.keus.hub.SCENE_TYPE} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};
/**
 * @param {!proto.com.keus.hub.SCENE_TYPE} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setSceneType = function (value) {
    return jspb.Message.setProto3EnumField(this, 3, value);
};
/**
 * optional string scene_section = 4;
 * @return {string}
 */
proto.com.keus.hub.Scene.prototype.getSceneSection = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setSceneSection = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
/**
 * optional string scene_room = 5;
 * @return {string}
 */
proto.com.keus.hub.Scene.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 5, value);
};
/**
 * optional SCENE_SCOPE scene_scope = 6;
 * @return {!proto.com.keus.hub.SCENE_SCOPE}
 */
proto.com.keus.hub.Scene.prototype.getSceneScope = function () {
    return /** @type {!proto.com.keus.hub.SCENE_SCOPE} */ (jspb.Message.getFieldWithDefault(this, 6, 0));
};
/**
 * @param {!proto.com.keus.hub.SCENE_SCOPE} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setSceneScope = function (value) {
    return jspb.Message.setProto3EnumField(this, 6, value);
};
/**
 * optional SCENE_EXECTYPE scene_execution_type = 7;
 * @return {!proto.com.keus.hub.SCENE_EXECTYPE}
 */
proto.com.keus.hub.Scene.prototype.getSceneExecutionType = function () {
    return /** @type {!proto.com.keus.hub.SCENE_EXECTYPE} */ (jspb.Message.getFieldWithDefault(this, 7, 0));
};
/**
 * @param {!proto.com.keus.hub.SCENE_EXECTYPE} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setSceneExecutionType = function (value) {
    return jspb.Message.setProto3EnumField(this, 7, value);
};
/**
 * repeated SceneAction action = 8;
 * @return {!Array<!proto.com.keus.hub.SceneAction>}
 */
proto.com.keus.hub.Scene.prototype.getActionList = function () {
    return /** @type{!Array<!proto.com.keus.hub.SceneAction>} */ (jspb.Message.getRepeatedWrapperField(this, proto.com.keus.hub.SceneAction, 8));
};
/**
 * @param {!Array<!proto.com.keus.hub.SceneAction>} value
 * @return {!proto.com.keus.hub.Scene} returns this
*/
proto.com.keus.hub.Scene.prototype.setActionList = function (value) {
    return jspb.Message.setRepeatedWrapperField(this, 8, value);
};
/**
 * @param {!proto.com.keus.hub.SceneAction=} opt_value
 * @param {number=} opt_index
 * @return {!proto.com.keus.hub.SceneAction}
 */
proto.com.keus.hub.Scene.prototype.addAction = function (opt_value, opt_index) {
    return jspb.Message.addToRepeatedWrapperField(this, 8, opt_value, proto.com.keus.hub.SceneAction, opt_index);
};
/**
 * Clears the list making it empty but non-null.
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.clearActionList = function () {
    return this.setActionList([]);
};
/**
 * repeated Timeslot timeslot = 9;
 * @return {!Array<!proto.com.keus.hub.Timeslot>}
 */
proto.com.keus.hub.Scene.prototype.getTimeslotList = function () {
    return /** @type{!Array<!proto.com.keus.hub.Timeslot>} */ (jspb.Message.getRepeatedWrapperField(this, proto.com.keus.hub.Timeslot, 9));
};
/**
 * @param {!Array<!proto.com.keus.hub.Timeslot>} value
 * @return {!proto.com.keus.hub.Scene} returns this
*/
proto.com.keus.hub.Scene.prototype.setTimeslotList = function (value) {
    return jspb.Message.setRepeatedWrapperField(this, 9, value);
};
/**
 * @param {!proto.com.keus.hub.Timeslot=} opt_value
 * @param {number=} opt_index
 * @return {!proto.com.keus.hub.Timeslot}
 */
proto.com.keus.hub.Scene.prototype.addTimeslot = function (opt_value, opt_index) {
    return jspb.Message.addToRepeatedWrapperField(this, 9, opt_value, proto.com.keus.hub.Timeslot, opt_index);
};
/**
 * Clears the list making it empty but non-null.
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.clearTimeslotList = function () {
    return this.setTimeslotList([]);
};
/**
 * optional int64 last_update_time = 50;
 * @return {number}
 */
proto.com.keus.hub.Scene.prototype.getLastUpdateTime = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 50, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setLastUpdateTime = function (value) {
    return jspb.Message.setProto3IntField(this, 50, value);
};
/**
 * optional string last_update_by = 51;
 * @return {string}
 */
proto.com.keus.hub.Scene.prototype.getLastUpdateBy = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 51, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setLastUpdateBy = function (value) {
    return jspb.Message.setProto3StringField(this, 51, value);
};
/**
 * optional string last_update_user = 52;
 * @return {string}
 */
proto.com.keus.hub.Scene.prototype.getLastUpdateUser = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 52, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setLastUpdateUser = function (value) {
    return jspb.Message.setProto3StringField(this, 52, value);
};
/**
 * optional string last_update_source = 53;
 * @return {string}
 */
proto.com.keus.hub.Scene.prototype.getLastUpdateSource = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 53, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.setLastUpdateSource = function (value) {
    return jspb.Message.setProto3StringField(this, 53, value);
};
/**
 * optional SceneSyncInfo scene_sync_info = 54;
 * @return {?proto.com.keus.hub.SceneSyncInfo}
 */
proto.com.keus.hub.Scene.prototype.getSceneSyncInfo = function () {
    return /** @type{?proto.com.keus.hub.SceneSyncInfo} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.SceneSyncInfo, 54));
};
/**
 * @param {?proto.com.keus.hub.SceneSyncInfo|undefined} value
 * @return {!proto.com.keus.hub.Scene} returns this
*/
proto.com.keus.hub.Scene.prototype.setSceneSyncInfo = function (value) {
    return jspb.Message.setWrapperField(this, 54, value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.Scene} returns this
 */
proto.com.keus.hub.Scene.prototype.clearSceneSyncInfo = function () {
    return this.setSceneSyncInfo(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.Scene.prototype.hasSceneSyncInfo = function () {
    return jspb.Message.getField(this, 54) != null;
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.CreateScene.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.CreateScene.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.CreateScene} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.CreateScene.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneName: jspb.Message.getFieldWithDefault(msg, 1, ""),
            sceneType: jspb.Message.getFieldWithDefault(msg, 2, 0),
            sceneSection: jspb.Message.getFieldWithDefault(msg, 4, ""),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 5, ""),
            sceneExecutionType: jspb.Message.getFieldWithDefault(msg, 6, 0),
            sceneScope: jspb.Message.getFieldWithDefault(msg, 7, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.CreateScene}
 */
proto.com.keus.hub.CreateScene.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.CreateScene;
    return proto.com.keus.hub.CreateScene.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.CreateScene} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.CreateScene}
 */
proto.com.keus.hub.CreateScene.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneName(value);
                break;
            case 2:
                var value = /** @type {!proto.com.keus.hub.SCENE_TYPE} */ (reader.readEnum());
                msg.setSceneType(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneSection(value);
                break;
            case 5:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 6:
                var value = /** @type {!proto.com.keus.hub.SCENE_EXECTYPE} */ (reader.readEnum());
                msg.setSceneExecutionType(value);
                break;
            case 7:
                var value = /** @type {!proto.com.keus.hub.SCENE_SCOPE} */ (reader.readEnum());
                msg.setSceneScope(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.CreateScene.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.CreateScene.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.CreateScene} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.CreateScene.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneName();
    if (f.length > 0) {
        writer.writeString(1, f);
    }
    f = message.getSceneType();
    if (f !== 0.0) {
        writer.writeEnum(2, f);
    }
    f = message.getSceneSection();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(5, f);
    }
    f = message.getSceneExecutionType();
    if (f !== 0.0) {
        writer.writeEnum(6, f);
    }
    f = message.getSceneScope();
    if (f !== 0.0) {
        writer.writeEnum(7, f);
    }
};
/**
 * optional string scene_name = 1;
 * @return {string}
 */
proto.com.keus.hub.CreateScene.prototype.getSceneName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.CreateScene} returns this
 */
proto.com.keus.hub.CreateScene.prototype.setSceneName = function (value) {
    return jspb.Message.setProto3StringField(this, 1, value);
};
/**
 * optional SCENE_TYPE scene_type = 2;
 * @return {!proto.com.keus.hub.SCENE_TYPE}
 */
proto.com.keus.hub.CreateScene.prototype.getSceneType = function () {
    return /** @type {!proto.com.keus.hub.SCENE_TYPE} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {!proto.com.keus.hub.SCENE_TYPE} value
 * @return {!proto.com.keus.hub.CreateScene} returns this
 */
proto.com.keus.hub.CreateScene.prototype.setSceneType = function (value) {
    return jspb.Message.setProto3EnumField(this, 2, value);
};
/**
 * optional string scene_section = 4;
 * @return {string}
 */
proto.com.keus.hub.CreateScene.prototype.getSceneSection = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.CreateScene} returns this
 */
proto.com.keus.hub.CreateScene.prototype.setSceneSection = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
/**
 * optional string scene_room = 5;
 * @return {string}
 */
proto.com.keus.hub.CreateScene.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.CreateScene} returns this
 */
proto.com.keus.hub.CreateScene.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 5, value);
};
/**
 * optional SCENE_EXECTYPE scene_execution_type = 6;
 * @return {!proto.com.keus.hub.SCENE_EXECTYPE}
 */
proto.com.keus.hub.CreateScene.prototype.getSceneExecutionType = function () {
    return /** @type {!proto.com.keus.hub.SCENE_EXECTYPE} */ (jspb.Message.getFieldWithDefault(this, 6, 0));
};
/**
 * @param {!proto.com.keus.hub.SCENE_EXECTYPE} value
 * @return {!proto.com.keus.hub.CreateScene} returns this
 */
proto.com.keus.hub.CreateScene.prototype.setSceneExecutionType = function (value) {
    return jspb.Message.setProto3EnumField(this, 6, value);
};
/**
 * optional SCENE_SCOPE scene_scope = 7;
 * @return {!proto.com.keus.hub.SCENE_SCOPE}
 */
proto.com.keus.hub.CreateScene.prototype.getSceneScope = function () {
    return /** @type {!proto.com.keus.hub.SCENE_SCOPE} */ (jspb.Message.getFieldWithDefault(this, 7, 0));
};
/**
 * @param {!proto.com.keus.hub.SCENE_SCOPE} value
 * @return {!proto.com.keus.hub.CreateScene} returns this
 */
proto.com.keus.hub.CreateScene.prototype.setSceneScope = function (value) {
    return jspb.Message.setProto3EnumField(this, 7, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.CreateSceneResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.CreateSceneResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.CreateSceneResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.CreateSceneResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, ""),
            scene: (f = msg.getScene()) && proto.com.keus.hub.Scene.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.CreateSceneResponse}
 */
proto.com.keus.hub.CreateSceneResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.CreateSceneResponse;
    return proto.com.keus.hub.CreateSceneResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.CreateSceneResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.CreateSceneResponse}
 */
proto.com.keus.hub.CreateSceneResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            case 4:
                var value = new proto.com.keus.hub.Scene;
                reader.readMessage(value, proto.com.keus.hub.Scene.deserializeBinaryFromReader);
                msg.setScene(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.CreateSceneResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.CreateSceneResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.CreateSceneResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.CreateSceneResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getScene();
    if (f != null) {
        writer.writeMessage(4, f, proto.com.keus.hub.Scene.serializeBinaryToWriter);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.CreateSceneResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.CreateSceneResponse} returns this
 */
proto.com.keus.hub.CreateSceneResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.CreateSceneResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.CreateSceneResponse} returns this
 */
proto.com.keus.hub.CreateSceneResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.CreateSceneResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.CreateSceneResponse} returns this
 */
proto.com.keus.hub.CreateSceneResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional Scene scene = 4;
 * @return {?proto.com.keus.hub.Scene}
 */
proto.com.keus.hub.CreateSceneResponse.prototype.getScene = function () {
    return /** @type{?proto.com.keus.hub.Scene} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.Scene, 4));
};
/**
 * @param {?proto.com.keus.hub.Scene|undefined} value
 * @return {!proto.com.keus.hub.CreateSceneResponse} returns this
*/
proto.com.keus.hub.CreateSceneResponse.prototype.setScene = function (value) {
    return jspb.Message.setWrapperField(this, 4, value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.CreateSceneResponse} returns this
 */
proto.com.keus.hub.CreateSceneResponse.prototype.clearScene = function () {
    return this.setScene(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.CreateSceneResponse.prototype.hasScene = function () {
    return jspb.Message.getField(this, 4) != null;
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.EditSceneName.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.EditSceneName.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.EditSceneName} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.EditSceneName.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 5, ""),
            sceneName: jspb.Message.getFieldWithDefault(msg, 6, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.EditSceneName}
 */
proto.com.keus.hub.EditSceneName.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.EditSceneName;
    return proto.com.keus.hub.EditSceneName.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.EditSceneName} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.EditSceneName}
 */
proto.com.keus.hub.EditSceneName.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSceneId(value);
                break;
            case 5:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 6:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneName(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.EditSceneName.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.EditSceneName.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.EditSceneName} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.EditSceneName.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(5, f);
    }
    f = message.getSceneName();
    if (f.length > 0) {
        writer.writeString(6, f);
    }
};
/**
 * optional int32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.EditSceneName.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.EditSceneName} returns this
 */
proto.com.keus.hub.EditSceneName.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 5;
 * @return {string}
 */
proto.com.keus.hub.EditSceneName.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.EditSceneName} returns this
 */
proto.com.keus.hub.EditSceneName.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 5, value);
};
/**
 * optional string scene_name = 6;
 * @return {string}
 */
proto.com.keus.hub.EditSceneName.prototype.getSceneName = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 6, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.EditSceneName} returns this
 */
proto.com.keus.hub.EditSceneName.prototype.setSceneName = function (value) {
    return jspb.Message.setProto3StringField(this, 6, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.EditSceneNameResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.EditSceneNameResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.EditSceneNameResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.EditSceneNameResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.EditSceneNameResponse}
 */
proto.com.keus.hub.EditSceneNameResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.EditSceneNameResponse;
    return proto.com.keus.hub.EditSceneNameResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.EditSceneNameResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.EditSceneNameResponse}
 */
proto.com.keus.hub.EditSceneNameResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.EditSceneNameResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.EditSceneNameResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.EditSceneNameResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.EditSceneNameResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.EditSceneNameResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.EditSceneNameResponse} returns this
 */
proto.com.keus.hub.EditSceneNameResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.EditSceneNameResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.EditSceneNameResponse} returns this
 */
proto.com.keus.hub.EditSceneNameResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.EditSceneNameResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.EditSceneNameResponse} returns this
 */
proto.com.keus.hub.EditSceneNameResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.AddTimeslotToScene.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.AddTimeslotToScene.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.AddTimeslotToScene} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.AddTimeslotToScene.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 2, ""),
            timeslotDelay: jspb.Message.getFieldWithDefault(msg, 3, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.AddTimeslotToScene}
 */
proto.com.keus.hub.AddTimeslotToScene.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.AddTimeslotToScene;
    return proto.com.keus.hub.AddTimeslotToScene.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.AddTimeslotToScene} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.AddTimeslotToScene}
 */
proto.com.keus.hub.AddTimeslotToScene.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 3:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setTimeslotDelay(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.AddTimeslotToScene.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.AddTimeslotToScene.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.AddTimeslotToScene} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.AddTimeslotToScene.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getTimeslotDelay();
    if (f !== 0) {
        writer.writeInt32(3, f);
    }
};
/**
 * optional int32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.AddTimeslotToScene.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AddTimeslotToScene} returns this
 */
proto.com.keus.hub.AddTimeslotToScene.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 2;
 * @return {string}
 */
proto.com.keus.hub.AddTimeslotToScene.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.AddTimeslotToScene} returns this
 */
proto.com.keus.hub.AddTimeslotToScene.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional int32 timeslot_delay = 3;
 * @return {number}
 */
proto.com.keus.hub.AddTimeslotToScene.prototype.getTimeslotDelay = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AddTimeslotToScene} returns this
 */
proto.com.keus.hub.AddTimeslotToScene.prototype.setTimeslotDelay = function (value) {
    return jspb.Message.setProto3IntField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.AddTimeslotToSceneResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.AddTimeslotToSceneResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.AddTimeslotToSceneResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, ""),
            timeslot: (f = msg.getTimeslot()) && proto.com.keus.hub.Timeslot.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.AddTimeslotToSceneResponse}
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.AddTimeslotToSceneResponse;
    return proto.com.keus.hub.AddTimeslotToSceneResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.AddTimeslotToSceneResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.AddTimeslotToSceneResponse}
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            case 4:
                var value = new proto.com.keus.hub.Timeslot;
                reader.readMessage(value, proto.com.keus.hub.Timeslot.deserializeBinaryFromReader);
                msg.setTimeslot(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.AddTimeslotToSceneResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.AddTimeslotToSceneResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getTimeslot();
    if (f != null) {
        writer.writeMessage(4, f, proto.com.keus.hub.Timeslot.serializeBinaryToWriter);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.AddTimeslotToSceneResponse} returns this
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AddTimeslotToSceneResponse} returns this
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.AddTimeslotToSceneResponse} returns this
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional Timeslot timeslot = 4;
 * @return {?proto.com.keus.hub.Timeslot}
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.getTimeslot = function () {
    return /** @type{?proto.com.keus.hub.Timeslot} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.Timeslot, 4));
};
/**
 * @param {?proto.com.keus.hub.Timeslot|undefined} value
 * @return {!proto.com.keus.hub.AddTimeslotToSceneResponse} returns this
*/
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.setTimeslot = function (value) {
    return jspb.Message.setWrapperField(this, 4, value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.AddTimeslotToSceneResponse} returns this
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.clearTimeslot = function () {
    return this.setTimeslot(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.AddTimeslotToSceneResponse.prototype.hasTimeslot = function () {
    return jspb.Message.getField(this, 4) != null;
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.RemoveTimeslotFromScene.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.RemoveTimeslotFromScene.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.RemoveTimeslotFromScene} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.RemoveTimeslotFromScene.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 2, ""),
            timeslotId: jspb.Message.getFieldWithDefault(msg, 3, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.RemoveTimeslotFromScene}
 */
proto.com.keus.hub.RemoveTimeslotFromScene.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.RemoveTimeslotFromScene;
    return proto.com.keus.hub.RemoveTimeslotFromScene.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.RemoveTimeslotFromScene} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.RemoveTimeslotFromScene}
 */
proto.com.keus.hub.RemoveTimeslotFromScene.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 3:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setTimeslotId(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.RemoveTimeslotFromScene.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.RemoveTimeslotFromScene.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.RemoveTimeslotFromScene} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.RemoveTimeslotFromScene.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getTimeslotId();
    if (f !== 0) {
        writer.writeInt32(3, f);
    }
};
/**
 * optional int32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.RemoveTimeslotFromScene.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RemoveTimeslotFromScene} returns this
 */
proto.com.keus.hub.RemoveTimeslotFromScene.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 2;
 * @return {string}
 */
proto.com.keus.hub.RemoveTimeslotFromScene.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.RemoveTimeslotFromScene} returns this
 */
proto.com.keus.hub.RemoveTimeslotFromScene.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional int32 timeslot_id = 3;
 * @return {number}
 */
proto.com.keus.hub.RemoveTimeslotFromScene.prototype.getTimeslotId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RemoveTimeslotFromScene} returns this
 */
proto.com.keus.hub.RemoveTimeslotFromScene.prototype.setTimeslotId = function (value) {
    return jspb.Message.setProto3IntField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.RemoveTimeslotFromSceneResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.RemoveTimeslotFromSceneResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.RemoveTimeslotFromSceneResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.RemoveTimeslotFromSceneResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.RemoveTimeslotFromSceneResponse}
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.RemoveTimeslotFromSceneResponse;
    return proto.com.keus.hub.RemoveTimeslotFromSceneResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.RemoveTimeslotFromSceneResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.RemoveTimeslotFromSceneResponse}
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.RemoveTimeslotFromSceneResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.RemoveTimeslotFromSceneResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.RemoveTimeslotFromSceneResponse} returns this
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RemoveTimeslotFromSceneResponse} returns this
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.RemoveTimeslotFromSceneResponse} returns this
 */
proto.com.keus.hub.RemoveTimeslotFromSceneResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.AdjustTimeslotDelay.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.AdjustTimeslotDelay.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.AdjustTimeslotDelay} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.AdjustTimeslotDelay.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 2, ""),
            timeslotId: jspb.Message.getFieldWithDefault(msg, 3, 0),
            timeslotDelay: jspb.Message.getFieldWithDefault(msg, 4, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.AdjustTimeslotDelay}
 */
proto.com.keus.hub.AdjustTimeslotDelay.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.AdjustTimeslotDelay;
    return proto.com.keus.hub.AdjustTimeslotDelay.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.AdjustTimeslotDelay} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.AdjustTimeslotDelay}
 */
proto.com.keus.hub.AdjustTimeslotDelay.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 3:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setTimeslotId(value);
                break;
            case 4:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setTimeslotDelay(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.AdjustTimeslotDelay.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.AdjustTimeslotDelay.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.AdjustTimeslotDelay} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.AdjustTimeslotDelay.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getTimeslotId();
    if (f !== 0) {
        writer.writeInt32(3, f);
    }
    f = message.getTimeslotDelay();
    if (f !== 0) {
        writer.writeInt32(4, f);
    }
};
/**
 * optional int32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.AdjustTimeslotDelay.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AdjustTimeslotDelay} returns this
 */
proto.com.keus.hub.AdjustTimeslotDelay.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 2;
 * @return {string}
 */
proto.com.keus.hub.AdjustTimeslotDelay.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.AdjustTimeslotDelay} returns this
 */
proto.com.keus.hub.AdjustTimeslotDelay.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional int32 timeslot_id = 3;
 * @return {number}
 */
proto.com.keus.hub.AdjustTimeslotDelay.prototype.getTimeslotId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AdjustTimeslotDelay} returns this
 */
proto.com.keus.hub.AdjustTimeslotDelay.prototype.setTimeslotId = function (value) {
    return jspb.Message.setProto3IntField(this, 3, value);
};
/**
 * optional int32 timeslot_delay = 4;
 * @return {number}
 */
proto.com.keus.hub.AdjustTimeslotDelay.prototype.getTimeslotDelay = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 4, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AdjustTimeslotDelay} returns this
 */
proto.com.keus.hub.AdjustTimeslotDelay.prototype.setTimeslotDelay = function (value) {
    return jspb.Message.setProto3IntField(this, 4, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.AdjustTimeslotDelayResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.AdjustTimeslotDelayResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.AdjustTimeslotDelayResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, ""),
            timeslot: (f = msg.getTimeslot()) && proto.com.keus.hub.Timeslot.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.AdjustTimeslotDelayResponse}
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.AdjustTimeslotDelayResponse;
    return proto.com.keus.hub.AdjustTimeslotDelayResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.AdjustTimeslotDelayResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.AdjustTimeslotDelayResponse}
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            case 4:
                var value = new proto.com.keus.hub.Timeslot;
                reader.readMessage(value, proto.com.keus.hub.Timeslot.deserializeBinaryFromReader);
                msg.setTimeslot(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.AdjustTimeslotDelayResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.AdjustTimeslotDelayResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getTimeslot();
    if (f != null) {
        writer.writeMessage(4, f, proto.com.keus.hub.Timeslot.serializeBinaryToWriter);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.AdjustTimeslotDelayResponse} returns this
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AdjustTimeslotDelayResponse} returns this
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.AdjustTimeslotDelayResponse} returns this
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional Timeslot timeslot = 4;
 * @return {?proto.com.keus.hub.Timeslot}
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.getTimeslot = function () {
    return /** @type{?proto.com.keus.hub.Timeslot} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.Timeslot, 4));
};
/**
 * @param {?proto.com.keus.hub.Timeslot|undefined} value
 * @return {!proto.com.keus.hub.AdjustTimeslotDelayResponse} returns this
*/
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.setTimeslot = function (value) {
    return jspb.Message.setWrapperField(this, 4, value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.AdjustTimeslotDelayResponse} returns this
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.clearTimeslot = function () {
    return this.setTimeslot(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.AdjustTimeslotDelayResponse.prototype.hasTimeslot = function () {
    return jspb.Message.getField(this, 4) != null;
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.AddActionToScene.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.AddActionToScene.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.AddActionToScene} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.AddActionToScene.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 2, ""),
            actionItem: (f = msg.getActionItem()) && proto.com.keus.hub.SceneAction.toObject(includeInstance, f)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.AddActionToScene}
 */
proto.com.keus.hub.AddActionToScene.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.AddActionToScene;
    return proto.com.keus.hub.AddActionToScene.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.AddActionToScene} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.AddActionToScene}
 */
proto.com.keus.hub.AddActionToScene.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 4:
                var value = new proto.com.keus.hub.SceneAction;
                reader.readMessage(value, proto.com.keus.hub.SceneAction.deserializeBinaryFromReader);
                msg.setActionItem(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.AddActionToScene.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.AddActionToScene.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.AddActionToScene} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.AddActionToScene.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getActionItem();
    if (f != null) {
        writer.writeMessage(4, f, proto.com.keus.hub.SceneAction.serializeBinaryToWriter);
    }
};
/**
 * optional int32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.AddActionToScene.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AddActionToScene} returns this
 */
proto.com.keus.hub.AddActionToScene.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 2;
 * @return {string}
 */
proto.com.keus.hub.AddActionToScene.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.AddActionToScene} returns this
 */
proto.com.keus.hub.AddActionToScene.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional SceneAction action_item = 4;
 * @return {?proto.com.keus.hub.SceneAction}
 */
proto.com.keus.hub.AddActionToScene.prototype.getActionItem = function () {
    return /** @type{?proto.com.keus.hub.SceneAction} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.SceneAction, 4));
};
/**
 * @param {?proto.com.keus.hub.SceneAction|undefined} value
 * @return {!proto.com.keus.hub.AddActionToScene} returns this
*/
proto.com.keus.hub.AddActionToScene.prototype.setActionItem = function (value) {
    return jspb.Message.setWrapperField(this, 4, value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.AddActionToScene} returns this
 */
proto.com.keus.hub.AddActionToScene.prototype.clearActionItem = function () {
    return this.setActionItem(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.AddActionToScene.prototype.hasActionItem = function () {
    return jspb.Message.getField(this, 4) != null;
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.AddActionToSceneResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.AddActionToSceneResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.AddActionToSceneResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.AddActionToSceneResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, ""),
            actionId: jspb.Message.getFieldWithDefault(msg, 4, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.AddActionToSceneResponse}
 */
proto.com.keus.hub.AddActionToSceneResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.AddActionToSceneResponse;
    return proto.com.keus.hub.AddActionToSceneResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.AddActionToSceneResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.AddActionToSceneResponse}
 */
proto.com.keus.hub.AddActionToSceneResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setActionId(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.AddActionToSceneResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.AddActionToSceneResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.AddActionToSceneResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.AddActionToSceneResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getActionId();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.AddActionToSceneResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.AddActionToSceneResponse} returns this
 */
proto.com.keus.hub.AddActionToSceneResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.AddActionToSceneResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.AddActionToSceneResponse} returns this
 */
proto.com.keus.hub.AddActionToSceneResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.AddActionToSceneResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.AddActionToSceneResponse} returns this
 */
proto.com.keus.hub.AddActionToSceneResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional string action_id = 4;
 * @return {string}
 */
proto.com.keus.hub.AddActionToSceneResponse.prototype.getActionId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.AddActionToSceneResponse} returns this
 */
proto.com.keus.hub.AddActionToSceneResponse.prototype.setActionId = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.RemoveActionFromScene.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.RemoveActionFromScene.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.RemoveActionFromScene} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.RemoveActionFromScene.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 2, ""),
            actionId: jspb.Message.getFieldWithDefault(msg, 3, ""),
            forceDelete: jspb.Message.getBooleanFieldWithDefault(msg, 4, false)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.RemoveActionFromScene}
 */
proto.com.keus.hub.RemoveActionFromScene.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.RemoveActionFromScene;
    return proto.com.keus.hub.RemoveActionFromScene.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.RemoveActionFromScene} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.RemoveActionFromScene}
 */
proto.com.keus.hub.RemoveActionFromScene.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setActionId(value);
                break;
            case 4:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setForceDelete(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.RemoveActionFromScene.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.RemoveActionFromScene.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.RemoveActionFromScene} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.RemoveActionFromScene.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getActionId();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getForceDelete();
    if (f) {
        writer.writeBool(4, f);
    }
};
/**
 * optional int32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.RemoveActionFromScene.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RemoveActionFromScene} returns this
 */
proto.com.keus.hub.RemoveActionFromScene.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 2;
 * @return {string}
 */
proto.com.keus.hub.RemoveActionFromScene.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.RemoveActionFromScene} returns this
 */
proto.com.keus.hub.RemoveActionFromScene.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional string action_id = 3;
 * @return {string}
 */
proto.com.keus.hub.RemoveActionFromScene.prototype.getActionId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.RemoveActionFromScene} returns this
 */
proto.com.keus.hub.RemoveActionFromScene.prototype.setActionId = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional bool force_delete = 4;
 * @return {boolean}
 */
proto.com.keus.hub.RemoveActionFromScene.prototype.getForceDelete = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 4, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.RemoveActionFromScene} returns this
 */
proto.com.keus.hub.RemoveActionFromScene.prototype.setForceDelete = function (value) {
    return jspb.Message.setProto3BooleanField(this, 4, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.RemoveActionFromSceneResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.RemoveActionFromSceneResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.RemoveActionFromSceneResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.RemoveActionFromSceneResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.RemoveActionFromSceneResponse}
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.RemoveActionFromSceneResponse;
    return proto.com.keus.hub.RemoveActionFromSceneResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.RemoveActionFromSceneResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.RemoveActionFromSceneResponse}
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.RemoveActionFromSceneResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.RemoveActionFromSceneResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.RemoveActionFromSceneResponse} returns this
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.RemoveActionFromSceneResponse} returns this
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.RemoveActionFromSceneResponse} returns this
 */
proto.com.keus.hub.RemoveActionFromSceneResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.ExecuteScene.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.ExecuteScene.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.ExecuteScene} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.ExecuteScene.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 2, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.ExecuteScene}
 */
proto.com.keus.hub.ExecuteScene.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.ExecuteScene;
    return proto.com.keus.hub.ExecuteScene.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.ExecuteScene} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.ExecuteScene}
 */
proto.com.keus.hub.ExecuteScene.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.ExecuteScene.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.ExecuteScene.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.ExecuteScene} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.ExecuteScene.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
};
/**
 * optional int32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.ExecuteScene.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.ExecuteScene} returns this
 */
proto.com.keus.hub.ExecuteScene.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 2;
 * @return {string}
 */
proto.com.keus.hub.ExecuteScene.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.ExecuteScene} returns this
 */
proto.com.keus.hub.ExecuteScene.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.ExecuteSceneResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.ExecuteSceneResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.ExecuteSceneResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.ExecuteSceneResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.ExecuteSceneResponse}
 */
proto.com.keus.hub.ExecuteSceneResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.ExecuteSceneResponse;
    return proto.com.keus.hub.ExecuteSceneResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.ExecuteSceneResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.ExecuteSceneResponse}
 */
proto.com.keus.hub.ExecuteSceneResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.ExecuteSceneResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.ExecuteSceneResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.ExecuteSceneResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.ExecuteSceneResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.ExecuteSceneResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.ExecuteSceneResponse} returns this
 */
proto.com.keus.hub.ExecuteSceneResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.ExecuteSceneResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.ExecuteSceneResponse} returns this
 */
proto.com.keus.hub.ExecuteSceneResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.ExecuteSceneResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.ExecuteSceneResponse} returns this
 */
proto.com.keus.hub.ExecuteSceneResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.MoveSceneToRoom.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.MoveSceneToRoom.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.MoveSceneToRoom} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.MoveSceneToRoom.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 2, ""),
            newSceneRoom: jspb.Message.getFieldWithDefault(msg, 3, ""),
            newSceneSection: jspb.Message.getFieldWithDefault(msg, 4, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.MoveSceneToRoom}
 */
proto.com.keus.hub.MoveSceneToRoom.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.MoveSceneToRoom;
    return proto.com.keus.hub.MoveSceneToRoom.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.MoveSceneToRoom} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.MoveSceneToRoom}
 */
proto.com.keus.hub.MoveSceneToRoom.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setNewSceneRoom(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setNewSceneSection(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.MoveSceneToRoom.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.MoveSceneToRoom.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.MoveSceneToRoom} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.MoveSceneToRoom.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeInt32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getNewSceneRoom();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getNewSceneSection();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
};
/**
 * optional int32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.MoveSceneToRoom.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.MoveSceneToRoom} returns this
 */
proto.com.keus.hub.MoveSceneToRoom.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 2;
 * @return {string}
 */
proto.com.keus.hub.MoveSceneToRoom.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.MoveSceneToRoom} returns this
 */
proto.com.keus.hub.MoveSceneToRoom.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional string new_scene_room = 3;
 * @return {string}
 */
proto.com.keus.hub.MoveSceneToRoom.prototype.getNewSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.MoveSceneToRoom} returns this
 */
proto.com.keus.hub.MoveSceneToRoom.prototype.setNewSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional string new_scene_section = 4;
 * @return {string}
 */
proto.com.keus.hub.MoveSceneToRoom.prototype.getNewSceneSection = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.MoveSceneToRoom} returns this
 */
proto.com.keus.hub.MoveSceneToRoom.prototype.setNewSceneSection = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.MoveSceneToRoomResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.MoveSceneToRoomResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.MoveSceneToRoomResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.MoveSceneToRoomResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.MoveSceneToRoomResponse}
 */
proto.com.keus.hub.MoveSceneToRoomResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.MoveSceneToRoomResponse;
    return proto.com.keus.hub.MoveSceneToRoomResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.MoveSceneToRoomResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.MoveSceneToRoomResponse}
 */
proto.com.keus.hub.MoveSceneToRoomResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.MoveSceneToRoomResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.MoveSceneToRoomResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.MoveSceneToRoomResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.MoveSceneToRoomResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.MoveSceneToRoomResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.MoveSceneToRoomResponse} returns this
 */
proto.com.keus.hub.MoveSceneToRoomResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.MoveSceneToRoomResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.MoveSceneToRoomResponse} returns this
 */
proto.com.keus.hub.MoveSceneToRoomResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.MoveSceneToRoomResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.MoveSceneToRoomResponse} returns this
 */
proto.com.keus.hub.MoveSceneToRoomResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.DeleteScene.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.DeleteScene.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.DeleteScene} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.DeleteScene.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 2, ""),
            forceDelete: jspb.Message.getBooleanFieldWithDefault(msg, 3, false)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.DeleteScene}
 */
proto.com.keus.hub.DeleteScene.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.DeleteScene;
    return proto.com.keus.hub.DeleteScene.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.DeleteScene} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.DeleteScene}
 */
proto.com.keus.hub.DeleteScene.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 3:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setForceDelete(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.DeleteScene.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.DeleteScene.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.DeleteScene} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.DeleteScene.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeUint32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getForceDelete();
    if (f) {
        writer.writeBool(3, f);
    }
};
/**
 * optional uint32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.DeleteScene.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.DeleteScene} returns this
 */
proto.com.keus.hub.DeleteScene.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 2;
 * @return {string}
 */
proto.com.keus.hub.DeleteScene.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeleteScene} returns this
 */
proto.com.keus.hub.DeleteScene.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional bool force_delete = 3;
 * @return {boolean}
 */
proto.com.keus.hub.DeleteScene.prototype.getForceDelete = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 3, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.DeleteScene} returns this
 */
proto.com.keus.hub.DeleteScene.prototype.setForceDelete = function (value) {
    return jspb.Message.setProto3BooleanField(this, 3, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.DeleteSceneResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.DeleteSceneResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.DeleteSceneResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.DeleteSceneResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, ""),
            requestId: jspb.Message.getFieldWithDefault(msg, 4, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.DeleteSceneResponse}
 */
proto.com.keus.hub.DeleteSceneResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.DeleteSceneResponse;
    return proto.com.keus.hub.DeleteSceneResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.DeleteSceneResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.DeleteSceneResponse}
 */
proto.com.keus.hub.DeleteSceneResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setRequestId(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.DeleteSceneResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.DeleteSceneResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.DeleteSceneResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.DeleteSceneResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeUint32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getRequestId();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.DeleteSceneResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.DeleteSceneResponse} returns this
 */
proto.com.keus.hub.DeleteSceneResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional uint32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.DeleteSceneResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.DeleteSceneResponse} returns this
 */
proto.com.keus.hub.DeleteSceneResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.DeleteSceneResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeleteSceneResponse} returns this
 */
proto.com.keus.hub.DeleteSceneResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional string request_id = 4;
 * @return {string}
 */
proto.com.keus.hub.DeleteSceneResponse.prototype.getRequestId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.DeleteSceneResponse} returns this
 */
proto.com.keus.hub.DeleteSceneResponse.prototype.setRequestId = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.SyncAreaSceneUIData.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.SyncAreaSceneUIData.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.SyncAreaSceneUIData} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.SyncAreaSceneUIData.toObject = function (includeInstance, msg) {
        var f, obj = {
            areaId: jspb.Message.getFieldWithDefault(msg, 1, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.SyncAreaSceneUIData}
 */
proto.com.keus.hub.SyncAreaSceneUIData.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.SyncAreaSceneUIData;
    return proto.com.keus.hub.SyncAreaSceneUIData.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.SyncAreaSceneUIData} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.SyncAreaSceneUIData}
 */
proto.com.keus.hub.SyncAreaSceneUIData.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setAreaId(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.SyncAreaSceneUIData.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.SyncAreaSceneUIData.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.SyncAreaSceneUIData} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.SyncAreaSceneUIData.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getAreaId();
    if (f !== 0) {
        writer.writeUint32(1, f);
    }
};
/**
 * optional uint32 area_id = 1;
 * @return {number}
 */
proto.com.keus.hub.SyncAreaSceneUIData.prototype.getAreaId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SyncAreaSceneUIData} returns this
 */
proto.com.keus.hub.SyncAreaSceneUIData.prototype.setAreaId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.SyncAreaSceneUIDataResponse.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.SyncAreaSceneUIDataResponse} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.SyncAreaSceneUIDataResponse.toObject = function (includeInstance, msg) {
        var f, obj = {
            success: jspb.Message.getBooleanFieldWithDefault(msg, 1, false),
            code: jspb.Message.getFieldWithDefault(msg, 2, 0),
            message: jspb.Message.getFieldWithDefault(msg, 3, ""),
            requestId: jspb.Message.getFieldWithDefault(msg, 4, "")
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.SyncAreaSceneUIDataResponse}
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.SyncAreaSceneUIDataResponse;
    return proto.com.keus.hub.SyncAreaSceneUIDataResponse.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.SyncAreaSceneUIDataResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.SyncAreaSceneUIDataResponse}
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {boolean} */ (reader.readBool());
                msg.setSuccess(value);
                break;
            case 2:
                var value = /** @type {number} */ (reader.readInt32());
                msg.setCode(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setMessage(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setRequestId(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.SyncAreaSceneUIDataResponse.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.SyncAreaSceneUIDataResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSuccess();
    if (f) {
        writer.writeBool(1, f);
    }
    f = message.getCode();
    if (f !== 0) {
        writer.writeInt32(2, f);
    }
    f = message.getMessage();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getRequestId();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
};
/**
 * optional bool success = 1;
 * @return {boolean}
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.getSuccess = function () {
    return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 1, false));
};
/**
 * @param {boolean} value
 * @return {!proto.com.keus.hub.SyncAreaSceneUIDataResponse} returns this
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.setSuccess = function (value) {
    return jspb.Message.setProto3BooleanField(this, 1, value);
};
/**
 * optional int32 code = 2;
 * @return {number}
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.getCode = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SyncAreaSceneUIDataResponse} returns this
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.setCode = function (value) {
    return jspb.Message.setProto3IntField(this, 2, value);
};
/**
 * optional string message = 3;
 * @return {string}
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.getMessage = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SyncAreaSceneUIDataResponse} returns this
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.setMessage = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional string request_id = 4;
 * @return {string}
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.getRequestId = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SyncAreaSceneUIDataResponse} returns this
 */
proto.com.keus.hub.SyncAreaSceneUIDataResponse.prototype.setRequestId = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.ReportSceneExecutionActivity.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.ReportSceneExecutionActivity.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.ReportSceneExecutionActivity} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.ReportSceneExecutionActivity.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneIdentifier: (f = msg.getSceneIdentifier()) && proto.com.keus.hub.SceneIdentifier.toObject(includeInstance, f),
            activityTime: jspb.Message.getFieldWithDefault(msg, 4, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.ReportSceneExecutionActivity}
 */
proto.com.keus.hub.ReportSceneExecutionActivity.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.ReportSceneExecutionActivity;
    return proto.com.keus.hub.ReportSceneExecutionActivity.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.ReportSceneExecutionActivity} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.ReportSceneExecutionActivity}
 */
proto.com.keus.hub.ReportSceneExecutionActivity.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = new proto.com.keus.hub.SceneIdentifier;
                reader.readMessage(value, proto.com.keus.hub.SceneIdentifier.deserializeBinaryFromReader);
                msg.setSceneIdentifier(value);
                break;
            case 4:
                var value = /** @type {number} */ (reader.readUint64());
                msg.setActivityTime(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.ReportSceneExecutionActivity.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.ReportSceneExecutionActivity.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.ReportSceneExecutionActivity} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.ReportSceneExecutionActivity.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneIdentifier();
    if (f != null) {
        writer.writeMessage(1, f, proto.com.keus.hub.SceneIdentifier.serializeBinaryToWriter);
    }
    f = message.getActivityTime();
    if (f !== 0) {
        writer.writeUint64(4, f);
    }
};
/**
 * optional SceneIdentifier scene_identifier = 1;
 * @return {?proto.com.keus.hub.SceneIdentifier}
 */
proto.com.keus.hub.ReportSceneExecutionActivity.prototype.getSceneIdentifier = function () {
    return /** @type{?proto.com.keus.hub.SceneIdentifier} */ (jspb.Message.getWrapperField(this, proto.com.keus.hub.SceneIdentifier, 1));
};
/**
 * @param {?proto.com.keus.hub.SceneIdentifier|undefined} value
 * @return {!proto.com.keus.hub.ReportSceneExecutionActivity} returns this
*/
proto.com.keus.hub.ReportSceneExecutionActivity.prototype.setSceneIdentifier = function (value) {
    return jspb.Message.setWrapperField(this, 1, value);
};
/**
 * Clears the message field making it undefined.
 * @return {!proto.com.keus.hub.ReportSceneExecutionActivity} returns this
 */
proto.com.keus.hub.ReportSceneExecutionActivity.prototype.clearSceneIdentifier = function () {
    return this.setSceneIdentifier(undefined);
};
/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.com.keus.hub.ReportSceneExecutionActivity.prototype.hasSceneIdentifier = function () {
    return jspb.Message.getField(this, 1) != null;
};
/**
 * optional uint64 activity_time = 4;
 * @return {number}
 */
proto.com.keus.hub.ReportSceneExecutionActivity.prototype.getActivityTime = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 4, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.ReportSceneExecutionActivity} returns this
 */
proto.com.keus.hub.ReportSceneExecutionActivity.prototype.setActivityTime = function (value) {
    return jspb.Message.setProto3IntField(this, 4, value);
};
if (jspb.Message.GENERATE_TO_OBJECT) {
    /**
     * Creates an object representation of this proto.
     * Field names that are reserved in JavaScript and will be renamed to pb_name.
     * Optional fields that are not set will be set to undefined.
     * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
     * For the list of reserved names please see:
     *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
     * @param {boolean=} opt_includeInstance Deprecated. whether to include the
     *     JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @return {!Object}
     */
    proto.com.keus.hub.SceneExecutionEvent.prototype.toObject = function (opt_includeInstance) {
        return proto.com.keus.hub.SceneExecutionEvent.toObject(opt_includeInstance, this);
    };
    /**
     * Static version of the {@see toObject} method.
     * @param {boolean|undefined} includeInstance Deprecated. Whether to include
     *     the JSPB instance for transitional soy proto support:
     *     http://goto/soy-param-migration
     * @param {!proto.com.keus.hub.SceneExecutionEvent} msg The msg instance to transform.
     * @return {!Object}
     * @suppress {unusedLocalVariables} f is only used for nested messages
     */
    proto.com.keus.hub.SceneExecutionEvent.toObject = function (includeInstance, msg) {
        var f, obj = {
            sceneId: jspb.Message.getFieldWithDefault(msg, 1, 0),
            sceneRoom: jspb.Message.getFieldWithDefault(msg, 2, ""),
            activitySource: jspb.Message.getFieldWithDefault(msg, 3, ""),
            activityUser: jspb.Message.getFieldWithDefault(msg, 4, ""),
            activityTime: jspb.Message.getFieldWithDefault(msg, 5, 0)
        };
        if (includeInstance) {
            obj.$jspbMessageInstance = msg;
        }
        return obj;
    };
}
/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.com.keus.hub.SceneExecutionEvent}
 */
proto.com.keus.hub.SceneExecutionEvent.deserializeBinary = function (bytes) {
    var reader = new jspb.BinaryReader(bytes);
    var msg = new proto.com.keus.hub.SceneExecutionEvent;
    return proto.com.keus.hub.SceneExecutionEvent.deserializeBinaryFromReader(msg, reader);
};
/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.com.keus.hub.SceneExecutionEvent} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.com.keus.hub.SceneExecutionEvent}
 */
proto.com.keus.hub.SceneExecutionEvent.deserializeBinaryFromReader = function (msg, reader) {
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        var field = reader.getFieldNumber();
        switch (field) {
            case 1:
                var value = /** @type {number} */ (reader.readUint32());
                msg.setSceneId(value);
                break;
            case 2:
                var value = /** @type {string} */ (reader.readString());
                msg.setSceneRoom(value);
                break;
            case 3:
                var value = /** @type {string} */ (reader.readString());
                msg.setActivitySource(value);
                break;
            case 4:
                var value = /** @type {string} */ (reader.readString());
                msg.setActivityUser(value);
                break;
            case 5:
                var value = /** @type {number} */ (reader.readUint64());
                msg.setActivityTime(value);
                break;
            default:
                reader.skipField();
                break;
        }
    }
    return msg;
};
/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.serializeBinary = function () {
    var writer = new jspb.BinaryWriter();
    proto.com.keus.hub.SceneExecutionEvent.serializeBinaryToWriter(this, writer);
    return writer.getResultBuffer();
};
/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.com.keus.hub.SceneExecutionEvent} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.com.keus.hub.SceneExecutionEvent.serializeBinaryToWriter = function (message, writer) {
    var f = undefined;
    f = message.getSceneId();
    if (f !== 0) {
        writer.writeUint32(1, f);
    }
    f = message.getSceneRoom();
    if (f.length > 0) {
        writer.writeString(2, f);
    }
    f = message.getActivitySource();
    if (f.length > 0) {
        writer.writeString(3, f);
    }
    f = message.getActivityUser();
    if (f.length > 0) {
        writer.writeString(4, f);
    }
    f = message.getActivityTime();
    if (f !== 0) {
        writer.writeUint64(5, f);
    }
};
/**
 * optional uint32 scene_id = 1;
 * @return {number}
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.getSceneId = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SceneExecutionEvent} returns this
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.setSceneId = function (value) {
    return jspb.Message.setProto3IntField(this, 1, value);
};
/**
 * optional string scene_room = 2;
 * @return {string}
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.getSceneRoom = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneExecutionEvent} returns this
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.setSceneRoom = function (value) {
    return jspb.Message.setProto3StringField(this, 2, value);
};
/**
 * optional string activity_source = 3;
 * @return {string}
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.getActivitySource = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneExecutionEvent} returns this
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.setActivitySource = function (value) {
    return jspb.Message.setProto3StringField(this, 3, value);
};
/**
 * optional string activity_user = 4;
 * @return {string}
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.getActivityUser = function () {
    return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};
/**
 * @param {string} value
 * @return {!proto.com.keus.hub.SceneExecutionEvent} returns this
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.setActivityUser = function (value) {
    return jspb.Message.setProto3StringField(this, 4, value);
};
/**
 * optional uint64 activity_time = 5;
 * @return {number}
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.getActivityTime = function () {
    return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 5, 0));
};
/**
 * @param {number} value
 * @return {!proto.com.keus.hub.SceneExecutionEvent} returns this
 */
proto.com.keus.hub.SceneExecutionEvent.prototype.setActivityTime = function (value) {
    return jspb.Message.setProto3IntField(this, 5, value);
};
goog.object.extend(exports, proto.com.keus.hub);
//# sourceMappingURL=scene_structures_pb.js.map