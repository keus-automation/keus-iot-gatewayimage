// GENERATED CODE -- NO SERVICES IN PROTO
//# sourceMappingURL=schedule_structure_grpc_pb.js.map