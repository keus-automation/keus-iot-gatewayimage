"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const protoRpcRegistry = __importStar(require("./proto-rpc-registry"));
const system_constants_1 = require("../../../constants/gateway/system-constants");
const TypeRegistry = [
    //Voice Handlers - Google
    {
        msgName: 'GoogleHomeSyncDevices',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.googleVoiceTypes.GoogleHomeSyncDevices.deserializeBinary
    },
    {
        msgName: 'GoogleHomeSyncDevicesResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.googleVoiceTypes.GoogleHomeSyncDevicesResponse.deserializeBinary
    },
    {
        msgName: 'GoogleHomeExecuteCommand',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.googleVoiceTypes.GoogleHomeExecuteCommand.deserializeBinary
    },
    {
        msgName: 'GoogleHomeExecuteCommandResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.googleVoiceTypes.GoogleHomeExecuteCommandResponse.deserializeBinary
    },
    {
        msgName: 'GoogleHomeDisconnectDevices',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.googleVoiceTypes.GoogleHomeDisconnectDevices.deserializeBinary
    },
    {
        msgName: 'GoogleHomeDisconnectDevicesResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.googleVoiceTypes.GoogleHomeDisconnectDevicesResponse.deserializeBinary
    },
    {
        msgName: 'GoogleHomeQueryState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.googleVoiceTypes.GoogleHomeQueryState.deserializeBinary
    },
    {
        msgName: 'GoogleHomeQueryStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.googleVoiceTypes.GoogleHomeQueryStateResponse.deserializeBinary
    },
    //voice handlers alexa
    {
        msgName: 'AlexaDiscoverDevices',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.alexaRpcTypes.AlexaDiscoverDevices.deserializeBinary
    },
    {
        msgName: 'AlexaDiscoverDevicesResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.alexaRpcTypes.AlexaDiscoverDevicesResponse.deserializeBinary
    },
    {
        msgName: 'AlexaExecuteCommand',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.alexaRpcTypes.AlexaExecuteCommand.deserializeBinary
    },
    {
        msgName: 'AlexaExecuteCommandResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.alexaRpcTypes.AlexaExecuteCommandResponse.deserializeBinary
    },
    //Activity Handlers
    {
        msgName: 'GetActivityLog',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.activityRpcTypes.GetActivityLog.deserializeBinary
    },
    {
        msgName: 'GetActivityLogResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.activityRpcTypes.GetActivityLogResponse.deserializeBinary
    },
    {
        msgName: 'ReportJobCompletion',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.jobCompletionRpcTypes.ReportJobCompletion.deserializeBinary
    },
    {
        msgName: 'ReportJobCompletionResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.jobCompletionRpcTypes.ReportJobCompletionResponse.deserializeBinary
    },
    {
        msgName: 'ReportSystemActivity',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.activityRpcTypes.ReportSystemActivity.deserializeBinary
    },
    {
        msgName: 'ReportSystemActivityResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.activityRpcTypes.ReportSystemActivityResponse.deserializeBinary
    },
    //Device Common
    {
        msgName: 'EnterPairMode',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.deviceRpcTypes.EnterPairMode.deserializeBinary
    },
    {
        msgName: 'EnterPairModeResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.deviceRpcTypes.EnterPairModeResponse.deserializeBinary
    },
    {
        msgName: 'RegisterDevice',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.deviceRpcTypes.RegisterDevice.deserializeBinary
    },
    {
        msgName: 'RegisterDeviceResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.deviceRpcTypes.RegisterDeviceResponse.deserializeBinary
    },
    //Dimmable Drivers
    {
        msgName: 'ConfigureZigbeeDimmableDriver',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.ConfigureZigbeeDimmableDriver.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeDimmableDriverResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.ConfigureZigbeeDimmableDriverResponse.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeDimmableDriverRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.MoveZigbeeDimmableDriverRoom.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeDimmableDriverRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.MoveZigbeeDimmableDriverRoomResponse.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeDimmableDriverState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.UpdateZigbeeDimmableDriverState.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeDimmableDriverStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.UpdateZigbeeDimmableDriverStateResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureDaliDimmableDriver',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliDimmableDriverTypes.ConfigureDaliDimmableDriver.deserializeBinary
    },
    {
        msgName: 'ConfigureDaliDimmableDriverResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliDimmableDriverTypes.ConfigureDaliDimmableDriverResponse.deserializeBinary
    },
    {
        msgName: 'MoveDaliDimmableDriverRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliDimmableDriverTypes.MoveDaliDimmableDriverRoom.deserializeBinary
    },
    {
        msgName: 'MoveDaliDimmableDriverRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliDimmableDriverTypes.MoveDaliDimmableDriverRoomResponse.deserializeBinary
    },
    {
        msgName: 'UpdateDaliDimmableDriverState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliDimmableDriverTypes.UpdateDaliDimmableDriverState.deserializeBinary
    },
    {
        msgName: 'UpdateDaliDimmableDriverStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliDimmableDriverTypes.UpdateDaliDimmableDriverStateResponse.deserializeBinary
    },
    //Dali color tunable
    {
        msgName: 'CheckDaliDriverType',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.CheckDaliDriverType.deserializeBinary
    },
    {
        msgName: 'CheckDaliDriverTypeResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.CheckDaliDriverTypeResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureDaliColorTunableProperties',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.ConfigureDaliColorTunableProperties.deserializeBinary
    },
    {
        msgName: 'ConfigureDaliColorTunablePropertiesResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.ConfigureDaliColorTunablePropertiesResponse.deserializeBinary
    },
    {
        msgName: 'MoveDaliColorTunableDriverRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.MoveDaliColorTunableDriverRoom.deserializeBinary
    },
    {
        msgName: 'MoveDaliColorTunableRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.MoveDaliColorTunableRoomResponse.deserializeBinary
    },
    {
        msgName: 'SetDaliColorTunableDriverNameLocation',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.SetDaliColorTunableDriverNameLocation.deserializeBinary
    },
    {
        msgName: 'SetDaliColorTunableDriverNameLocationResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.SetDaliColorTunableDriverNameLocationResponse.deserializeBinary
    },
    {
        msgName: 'UpdateDaliDriverType',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.UpdateDaliDriverType.deserializeBinary
    },
    {
        msgName: 'UpdateDaliDriverTypeResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.UpdateDaliDriverTypeResponse.deserializeBinary
    },
    {
        msgName: 'UpdateDaliColorTunableDriverState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.UpdateDaliColorTunableDriverState.deserializeBinary
    },
    {
        msgName: 'UpdateDaliColorTunableDriverStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.daliColorTunableDriverTypes.UpdateDaliColorTunableDriverStateResponse.deserializeBinary
    },
    //Scene Wizard
    {
        msgName: 'MoveSceneWizardRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneWizardTypes.MoveSceneWizardRoom.deserializeBinary
    },
    {
        msgName: 'MoveSceneWizardRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneWizardTypes.MoveSceneWizardRoomResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureSceneWizardButtons',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneWizardTypes.ConfigureSceneWizardButtons.deserializeBinary
    },
    {
        msgName: 'ConfigureSceneWizardButtonsResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneWizardTypes.ConfigureSceneWizardButtonsResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureSceneWizard',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneWizardTypes.ConfigureSceneWizard.deserializeBinary
    },
    {
        msgName: 'ConfigureSceneWizardResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneWizardTypes.ConfigureSceneWizardResponse.deserializeBinary
    },
    //Smart Consoles
    {
        msgName: 'ClearConsoleData',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.ClearConsoleData.deserializeBinary
    },
    {
        msgName: 'ClearConsoleDataResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.ClearConsoleDataResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureConsoleButtons',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.ConfigureConsoleButtons.deserializeBinary
    },
    {
        msgName: 'ConfigureConsoleButtonsResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.ConfigureConsoleButtonsResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureSmartConsole',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.ConfigureSmartConsole.deserializeBinary
    },
    {
        msgName: 'ConfigureSmartConsoleResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.ConfigureSmartConsoleResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureSmartConsoleRelay',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.ConfigureSmartConsoleRelay.deserializeBinary
    },
    {
        msgName: 'ConfigureSmartConsoleRelayResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.ConfigureSmartConsoleRelayResponse.deserializeBinary
    },
    {
        msgName: 'DaliSetRestoreLastLevel',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.DaliSetRestoreLastLevel.deserializeBinary
    },
    {
        msgName: 'DaliSetRestoreLastLevelResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.DaliSetRestoreLastLevelResponse.deserializeBinary
    },
    {
        msgName: 'DiscoverDaliDevices',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.DiscoverDaliDevices.deserializeBinary
    },
    {
        msgName: 'DiscoverDaliDevicesResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.DiscoverDaliDevicesResponse.deserializeBinary
    },
    {
        msgName: 'FlashConsoleButtons',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.FlashConsoleButtons.deserializeBinary
    },
    {
        msgName: 'FlashConsoleButtonsResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.FlashConsoleButtonsResponse.deserializeBinary
    },
    {
        msgName: 'MoveSmartConsoleRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.MoveSmartConsoleRoom.deserializeBinary
    },
    {
        msgName: 'MoveSmartConsoleRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.MoveSmartConsoleRoomResponse.deserializeBinary
    },
    {
        msgName: 'SetAreaMaster',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.SetAreaMaster.deserializeBinary
    },
    {
        msgName: 'SetAreaMasterResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.SetAreaMasterResponse.deserializeBinary
    },
    {
        msgName: 'SetConsoleRelayState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.SetConsoleRelayState.deserializeBinary
    },
    {
        msgName: 'SetConsoleRelayStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.SetConsoleRelayStateResponse.deserializeBinary
    },
    {
        msgName: 'SetDaliMaster',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.SetDaliMaster.deserializeBinary
    },
    {
        msgName: 'SetDaliMasterResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.SetDaliMasterResponse.deserializeBinary
    },
    {
        msgName: 'SyncSceneUIData',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.SyncSceneUIData.deserializeBinary
    },
    {
        msgName: 'SyncSceneUIDataResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.smartConsoleTypes.SyncSceneUIDataResponse.deserializeBinary
    },
    //Zigbee Curtain Controller
    {
        msgName: 'ConfigureZigbeeCurtainController',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeCurtainControllerTypes.ConfigureZigbeeCurtainController.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeCurtainControllerResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeCurtainControllerTypes.ConfigureZigbeeCurtainControllerResponse.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeCurtainControllerRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeCurtainControllerTypes.MoveZigbeeCurtainControllerRoom.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeCurtainControllerRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeCurtainControllerTypes.MoveZigbeeCurtainControllerRoomResponse.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeCurtainControllerState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeCurtainControllerTypes.UpdateZigbeeCurtainControllerState.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeCurtainControllerStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeCurtainControllerTypes.UpdateZigbeeCurtainControllerStateResponse.deserializeBinary
    },
    //Fan Controllers
    {
        msgName: 'ConfigureZigbeeACFanController',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeAcFanControlerTypes.ConfigureZigbeeACFanController.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeACFanControllerResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeAcFanControlerTypes.ConfigureZigbeeACFanControllerResponse.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeACFanControllerRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeAcFanControlerTypes.MoveZigbeeACFanControllerRoom.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeACFanControllerRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeAcFanControlerTypes.MoveZigbeeACFanControllerRoomResponse.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeACFanControllerState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeAcFanControlerTypes.UpdateZigbeeACFanControllerState.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeACFanControllerStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeAcFanControlerTypes.UpdateZigbeeACFanControllerStateResponse.deserializeBinary
    },
    //IR Blaster
    {
        msgName: 'GetIRRemoteList',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.GetIRRemoteList.deserializeBinary
    },
    {
        msgName: 'GetIRRemoteListResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.GetIRRemoteListResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeIRBlaster',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.ConfigureZigbeeIRBlaster.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeIRBlasterResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.ConfigureZigbeeIRBlasterResponse.deserializeBinary
    },
    {
        msgName: 'AddRemoteToZigbeeIRBlaster',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.AddRemoteToZigbeeIRBlaster.deserializeBinary
    },
    {
        msgName: 'AddRemoteToZigbeeIRBlasterResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.AddRemoteToZigbeeIRBlasterResponse.deserializeBinary
    },
    {
        msgName: 'BlastIRCommand',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.BlastIRCommand.deserializeBinary
    },
    {
        msgName: 'BlastIRCommandResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.BlastIRCommandResponse.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeIRBlasterRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.MoveZigbeeIRBlasterRoom.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeIRBlasterRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.MoveZigbeeIRBlasterRoomResponse.deserializeBinary
    },
    {
        msgName: 'RemoveRemoteFromZigbeeIRBlaster',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.RemoveRemoteFromZigbeeIRBlaster.deserializeBinary
    },
    {
        msgName: 'RemoveRemoteFromZigbeeIRBlasterResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeIRBlasterTypes.RemoveRemoteFromZigbeeIRBlasterResponse.deserializeBinary
    },
    //Groups
    {
        msgName: 'AddDeviceToGroup',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.AddDeviceToGroup.deserializeBinary
    },
    {
        msgName: 'AddDeviceToGroupResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.AddDeviceToGroupResponse.deserializeBinary
    },
    {
        msgName: 'ChangeGroupName',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.ChangeGroupName.deserializeBinary
    },
    {
        msgName: 'ChangeGroupNameResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.ChangeGroupNameResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureGroupProperties',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.ConfigureGroupProperties.deserializeBinary
    },
    {
        msgName: 'ConfigureGroupPropertiesResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.ConfigureGroupPropertiesResponse.deserializeBinary
    },
    {
        msgName: 'CreateGroup',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.CreateGroup.deserializeBinary
    },
    {
        msgName: 'CreateGroupResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.CreateGroupResponse.deserializeBinary
    },
    {
        msgName: 'DeleteGroup',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.DeleteGroup.deserializeBinary
    },
    {
        msgName: 'DeleteGroupResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.DeleteGroupResponse.deserializeBinary
    },
    {
        msgName: 'RemoveDeviceFromGroup',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.RemoveDeviceFromGroup.deserializeBinary
    },
    {
        msgName: 'RemoveDeviceFromGroupResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.RemoveDeviceFromGroupResponse.deserializeBinary
    },
    {
        msgName: 'UpdateGroupState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.UpdateGroupState.deserializeBinary
    },
    {
        msgName: 'UpdateGroupStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.groupRpcTypes.UpdateGroupStateResponse.deserializeBinary
    },
    {
        msgName: 'AssignSuperUser',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.AssignSuperUser.deserializeBinary
    },
    {
        msgName: 'AssignSuperUserResponse',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.AssignSuperUserResponse.deserializeBinary
    },
    {
        msgName: 'GetUserDetails',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GetUserDetails.deserializeBinary
    },
    {
        msgName: 'GetUserDetailsResponse',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GetUserDetailsResponse.deserializeBinary
    },
    {
        msgName: 'GetUsersDetails',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GetUsersDetails.deserializeBinary
    },
    {
        msgName: 'GetUsersDetailsResponse',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GetUsersDetailsResponse.deserializeBinary
    },
    {
        msgName: 'GrantUserPermission',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GrantUserPermission.deserializeBinary
    },
    {
        msgName: 'RequestOtpFromGateway',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.RequestOtpFromGateway.deserializeBinary
    },
    {
        msgName: 'RequestOtpFromGatewayResponse',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.RequestOtpFromGatewayResponse.deserializeBinary
    },
    {
        msgName: 'RemoveHomeFromUser',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.RemoveHomeFromUser.deserializeBinary
    },
    {
        msgName: 'RemoveHomeFromUserResponse',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.RemoveHomeFromUserResponse.deserializeBinary
    },
    {
        msgName: 'GrantUserPermissionResponse',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GrantUserPermissionResponse.deserializeBinary
    },
    {
        msgName: 'GetRemoteList',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GetRemoteList.deserializeBinary
    },
    {
        msgName: 'GetRemoteListResponse',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GetRemoteListResponse.deserializeBinary
    },
    {
        msgName: 'GetRemoteFileLink',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GetRemoteFileLink.deserializeBinary
    },
    {
        msgName: 'GetRemoteFileLinkResponse',
        packageName: system_constants_1.ProtoCloudPackageName,
        deserializeFunc: protoRpcRegistry.gatewayToCloudRpcTypes.GetRemoteFileLinkResponse.deserializeBinary
    },
    // gateway setup protos
    {
        msgName: 'ConfigureGateway',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.GatewaySetupRpcTypes.ConfigureGateway.deserializeBinary
    },
    {
        msgName: 'ConfigureGatewayResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.GatewaySetupRpcTypes.ConfigureGatewayResponse.deserializeBinary
    },
    {
        msgName: 'GetGatewayStatus',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.GatewaySetupRpcTypes.GetGatewayStatus.deserializeBinary
    },
    {
        msgName: 'GetGatewayStatusResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.GatewaySetupRpcTypes.GetGatewayStatusResponse.deserializeBinary
    },
    {
        msgName: 'RegisterGatewayToCloud',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.GatewaySetupRpcTypes.RegisterGatewayToCloud.deserializeBinary
    },
    {
        msgName: 'RegisterGatewayToCloudResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.GatewaySetupRpcTypes.RegisterGatewayToCloudResponse.deserializeBinary
    },
    {
        msgName: 'ServiceLogin',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.GatewaySetupRpcTypes.ServiceLogin.deserializeBinary
    },
    {
        msgName: 'ServiceLoginResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.GatewaySetupRpcTypes.ServiceLoginResponse.deserializeBinary
    },
    //Home Protos
    {
        msgName: 'GetHubData',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.GetHubData.deserializeBinary
    },
    {
        msgName: 'GetHubDataResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.GetHubDataResponse.deserializeBinary
    },
    {
        msgName: 'GetAreas',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.GetAreas.deserializeBinary
    },
    {
        msgName: 'GetAreasResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.GetAreasResponse.deserializeBinary
    },
    {
        msgName: 'CreateArea',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.CreateArea.deserializeBinary
    },
    {
        msgName: 'CreateAreaResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.CreateAreaResponse.deserializeBinary
    },
    {
        msgName: 'EditArea',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.EditArea.deserializeBinary
    },
    {
        msgName: 'EditAreaResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.EditAreaResponse.deserializeBinary
    },
    {
        msgName: 'DeleteArea',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.DeleteArea.deserializeBinary
    },
    {
        msgName: 'DeleteAreaResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.DeleteAreaResponse.deserializeBinary
    },
    {
        msgName: 'GetFloors',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.GetFloors.deserializeBinary
    },
    {
        msgName: 'GetFloorsResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.GetFloorsResponse.deserializeBinary
    },
    {
        msgName: 'CreateFloor',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.CreateFloor.deserializeBinary
    },
    {
        msgName: 'CreateFloorResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.CreateFloorResponse.deserializeBinary
    },
    {
        msgName: 'DeleteFloor',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.DeleteFloor.deserializeBinary
    },
    {
        msgName: 'DeleteFloorResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.DeleteFloorResponse.deserializeBinary
    },
    {
        msgName: 'EditFloor',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.EditFloor.deserializeBinary
    },
    {
        msgName: 'EditFloorResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.EditFloorResponse.deserializeBinary
    },
    {
        msgName: 'UpdateGatewayColor',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.UpdateGatewayColor.deserializeBinary
    },
    {
        msgName: 'UpdateGatewayColorResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.UpdateGatewayColorResponse.deserializeBinary
    },
    //permission
    {
        msgName: 'AssignSuperUser',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.permissionRpcTypes.AssignSuperUser.deserializeBinary
    },
    {
        msgName: 'AssignSuperUserResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.permissionRpcTypes.AssignSuperUserResponse.deserializeBinary
    },
    {
        msgName: 'GetUserPermissionList',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.permissionRpcTypes.GetUserPermissionList.deserializeBinary
    },
    {
        msgName: 'GetUserPermissionListResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.permissionRpcTypes.GetUserPermissionListResponse.deserializeBinary
    },
    {
        msgName: 'GrantUserPermission',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.permissionRpcTypes.GrantUserPermission.deserializeBinary
    },
    {
        msgName: 'GrantUserPermissionResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.permissionRpcTypes.GrantUserPermissionResponse.deserializeBinary
    },
    {
        msgName: 'RemoveUserPermission',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.permissionRpcTypes.RemoveUserPermission.deserializeBinary
    },
    {
        msgName: 'RemoveUserPermissionResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.permissionRpcTypes.RemoveUserPermissionResponse.deserializeBinary
    },
    //users
    {
        msgName: 'RequestOtp',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.userRpcTypes.RequestOtp.deserializeBinary
    },
    {
        msgName: 'RequestOtpResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.userRpcTypes.RequestOtpResponse.deserializeBinary
    },
    {
        msgName: 'GetUserInfo',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.userRpcTypes.GetUserInfo.deserializeBinary
    },
    {
        msgName: 'GetUserInfoResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.userRpcTypes.GetUserInfoResponse.deserializeBinary
    },
    {
        msgName: 'TotpLogin',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.userRpcTypes.TotpLogin.deserializeBinary
    },
    {
        msgName: 'TotpLoginResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.userRpcTypes.TotpLoginResponse.deserializeBinary
    },
    //Rooms
    {
        msgName: 'GetRooms',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.GetRooms.deserializeBinary
    },
    {
        msgName: 'GetRoomsResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.GetRoomsResponse.deserializeBinary
    },
    {
        msgName: 'CreateRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.CreateRoom.deserializeBinary
    },
    {
        msgName: 'CreateRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.CreateRoomResponse.deserializeBinary
    },
    {
        msgName: 'EditRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.EditRoom.deserializeBinary
    },
    {
        msgName: 'EditRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.EditRoomResponse.deserializeBinary
    },
    {
        msgName: 'DeleteRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.DeleteRoom.deserializeBinary
    },
    {
        msgName: 'DeleteRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.DeleteRoomResponse.deserializeBinary
    },
    //Sections
    {
        msgName: 'AddSection',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.AddSection.deserializeBinary
    },
    {
        msgName: 'AddSectionResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.AddSectionResponse.deserializeBinary
    },
    {
        msgName: 'DeleteSection',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.DeleteSection.deserializeBinary
    },
    {
        msgName: 'DeleteSectionResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.DeleteSectionResponse.deserializeBinary
    },
    {
        msgName: 'EditSection',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.EditSection.deserializeBinary
    },
    {
        msgName: 'EditSectionResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.homeRpcTypes.EditSectionResponse.deserializeBinary
    },
    // Scenes
    {
        msgName: 'CreateScene',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.CreateScene.deserializeBinary
    },
    {
        msgName: 'CreateSceneResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.CreateSceneResponse.deserializeBinary
    },
    {
        msgName: 'DeleteScene',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.DeleteScene.deserializeBinary
    },
    {
        msgName: 'DeleteSceneResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.DeleteSceneResponse.deserializeBinary
    },
    {
        msgName: 'AddActionToScene',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.AddActionToScene.deserializeBinary
    },
    {
        msgName: 'AddActionToSceneResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.AddActionToSceneResponse.deserializeBinary
    },
    {
        msgName: 'RemoveActionFromScene',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.RemoveActionFromScene.deserializeBinary
    },
    {
        msgName: 'RemoveActionFromSceneResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.RemoveActionFromSceneResponse.deserializeBinary
    },
    {
        msgName: 'ExecuteScene',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.ExecuteScene.deserializeBinary
    },
    {
        msgName: 'ExecuteSceneResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.ExecuteSceneResponse.deserializeBinary
    },
    {
        msgName: 'EditSceneName',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.EditSceneName.deserializeBinary
    },
    {
        msgName: 'EditSceneNameResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.EditSceneNameResponse.deserializeBinary
    },
    {
        msgName: 'MoveSceneToRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.MoveSceneToRoom.deserializeBinary
    },
    {
        msgName: 'MoveSceneToRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.MoveSceneToRoomResponse.deserializeBinary
    },
    {
        msgName: 'AddTimeslotToScene',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.AddTimeslotToScene.deserializeBinary
    },
    {
        msgName: 'AddTimeslotToSceneResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.AddActionToSceneResponse.deserializeBinary
    },
    {
        msgName: 'RemoveTimeslotFromScene',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.RemoveTimeslotFromScene.deserializeBinary
    },
    {
        msgName: 'RemoveTimeslotFromSceneResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.RemoveTimeslotFromSceneResponse.deserializeBinary
    },
    {
        msgName: 'AdjustTimeslotDelay',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.AdjustTimeslotDelay.deserializeBinary
    },
    {
        msgName: 'AdjustTimeslotDelayResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.AdjustTimeslotDelayResponse.deserializeBinary
    },
    {
        msgName: 'SyncAreaSceneUIData',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.SyncAreaSceneUIData.deserializeBinary
    },
    {
        msgName: 'SyncAreaSceneUIDataResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.sceneRpcTypes.SyncAreaSceneUIDataResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeRgbwwaResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.ConfigureZigbeeDimmableDriver.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeDimmableDriverState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.UpdateZigbeeDimmableDriverState.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeDimmableDriverStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.UpdateZigbeeDimmableDriverStateResponse.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeDimmableDriverRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.MoveZigbeeDimmableDriverRoom.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeDimmableDriverRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDimmableDriverTypes.MoveZigbeeDimmableDriverRoomResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeRgbwwa',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeRgbwwaTypes.ConfigureZigbeeRgbwwa.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeRgbwwaResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeRgbwwaTypes.ConfigureZigbeeRgbwwaResponse.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeRgbwwaState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeRgbwwaTypes.UpdateZigbeeRgbwwaState.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeRgbwwaStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeRgbwwaTypes.UpdateZigbeeRgbwwaStateResponse.deserializeBinary
    },
    {
        msgName: 'SetZigbeeRgbwwaDefaultAction',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeRgbwwaTypes.SetZigbeeRgbwwaDefaultAction.deserializeBinary
    },
    {
        msgName: 'SetZigbeeRgbwwaDefaultActionResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeRgbwwaTypes.SetZigbeeRgbwwaDefaultActionResponse.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeRgbwwaRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeRgbwwaTypes.MoveZigbeeRgbwwaRoom.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeRgbwwaRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeRgbwwaTypes.MoveZigbeeRgbwwaRoomResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureEmbeddedSwitches',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.ConfigureEmbeddedSwitches.deserializeBinary
    },
    {
        msgName: 'ConfigureEmbeddedSwitchesResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.ConfigureEmbeddedSwitchesResponse.deserializeBinary
    },
    {
        msgName: 'AddEditAppliance',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.AddEditAppliance.deserializeBinary
    },
    {
        msgName: 'AddEditApplianceResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.AddEditApplianceResponse.deserializeBinary
    },
    {
        msgName: 'DeleteAppliance',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.DeleteAppliance.deserializeBinary
    },
    {
        msgName: 'DeleteApplianceResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.DeleteApplianceResponse.deserializeBinary
    },
    {
        msgName: 'EditEmbeddedSwitchDetails',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.EditEmbeddedSwitchDetails.deserializeBinary
    },
    {
        msgName: 'EditEmbeddedSwitchDetailsResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.EditEmbeddedSwitchDetailsResponse.deserializeBinary
    },
    {
        msgName: 'UpdateApplianceState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.UpdateApplianceState.deserializeBinary
    },
    {
        msgName: 'UpdateApplianceStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.UpdateApplianceStateResponse.deserializeBinary
    },
    {
        msgName: 'UpdatePortState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.UpdatePortState.deserializeBinary
    },
    {
        msgName: 'UpdatePortStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.UpdatePortStateResponse.deserializeBinary
    },
    {
        msgName: 'MoveEmbeddedSwitchRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.MoveEmbeddedSwitchRoom.deserializeBinary
    },
    {
        msgName: 'MoveEmbeddedSwitchRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSwitchTypes.MoveEmbeddedSwitchRoomResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeEmbeddedSceneSwitch',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.ConfigureZigbeeEmbeddedSceneSwitch.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeEmbeddedSceneSwitchResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.ConfigureZigbeeEmbeddedSceneSwitchResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeEmbeddedSceneSwitchButtons',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.ConfigureZigbeeEmbeddedSceneSwitchButtons.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeEmbeddedSceneSwitchButtonsResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.ConfigureZigbeeEmbeddedSceneSwitchButtonsResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeEmbeddedGlobalSceneSwitchButtons',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.ConfigureZigbeeEmbeddedGlobalSceneSwitchButtons.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeEmbeddedGlobalSceneSwitchButtonsResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.ConfigureZigbeeEmbeddedGlobalSceneSwitchButtonsResponse.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeEmbeddedSceneSwitchRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.MoveZigbeeEmbeddedSceneSwitchRoom.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeEmbeddedSceneSwitchRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeEmbeddedSceneSwitchTypes.MoveZigbeeEmbeddedSceneSwitchRoomResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeDCFanController',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDcFanControlerTypes.ConfigureZigbeeDCFanController.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeDCFanControllerResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDcFanControlerTypes.ConfigureZigbeeDCFanControllerResponse.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeDCFanControllerRoom',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDcFanControlerTypes.MoveZigbeeDCFanControllerRoom.deserializeBinary
    },
    {
        msgName: 'MoveZigbeeDCFanControllerRoomResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDcFanControlerTypes.MoveZigbeeDCFanControllerRoomResponse.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeDCFanControllerState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDcFanControlerTypes.UpdateZigbeeDCFanControllerState.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeDCFanControllerStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeDcFanControlerTypes.UpdateZigbeeDCFanControllerStateResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeContactSensor',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeContactSensorTypes.ConfigureZigbeeContactSensor.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeContactSensorResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeContactSensorTypes.ConfigureZigbeeContactSensorResponse.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeContactSensorState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeContactSensorTypes.UpdateZigbeeContactSensorState.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeContactSensorStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeContactSensorTypes.UpdateZigbeeContactSensorStateResponse.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeInlineDimmer',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeInlineDimmerTypes.ConfigureZigbeeInlineDimmer.deserializeBinary
    },
    {
        msgName: 'ConfigureZigbeeInlineDimmerResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeInlineDimmerTypes.ConfigureZigbeeInlineDimmerResponse.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeInlineDimmerState',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeInlineDimmerTypes.UpdateZigbeeInlineDimmerState.deserializeBinary
    },
    {
        msgName: 'UpdateZigbeeInlineDimmerStateResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.zigbeeInlineDimmerTypes.UpdateZigbeeInlineDimmerStateResponse.deserializeBinary
    },
    //scheudle rpc type
    {
        msgName: 'CreateSchedule',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.CreateSchedule.deserializeBinary
    },
    {
        msgName: 'CreateScheduleResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.CreateScheduleResponse.deserializeBinary
    },
    {
        msgName: 'EditSchedule',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.EditSchedule.deserializeBinary
    },
    {
        msgName: 'EditScheduleResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.EditScheduleResponse.deserializeBinary
    },
    {
        msgName: 'EditScheduleProperties',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.EditScheduleProperties.deserializeBinary
    },
    {
        msgName: 'EditSchedulePropertiesResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.EditSchedulePropertiesResponse.deserializeBinary
    },
    {
        msgName: 'EditScheduleAction',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.EditScheduleAction.deserializeBinary
    },
    {
        msgName: 'EditScheduleActionResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.EditScheduleActionResponse.deserializeBinary
    },
    {
        msgName: 'DeleteSchedule',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.DeleteSchedule.deserializeBinary
    },
    {
        msgName: 'DeleteScheduleResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.DeleteScheduleResponse.deserializeBinary
    },
    {
        msgName: 'EnableDisableSchedule',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.EnableDisableSchedule.deserializeBinary
    },
    {
        msgName: 'EnableDisableScheduleResponse',
        packageName: system_constants_1.ProtoPackageName,
        deserializeFunc: protoRpcRegistry.scheduleRpcTypes.EnableDisableScheduleResponse.deserializeBinary
    }
    // {
    //     msgName: 'GetSchedules',
    //     packageName: ProtoPackageName,
    //     deserializeFunc: protoRpcRegistry.scheduleRpcTypes.GetSchedules.deserializeBinary
    // },
    // {
    //     msgName: 'GetSchedulesResponse',
    //     packageName: ProtoPackageName,
    //     deserializeFunc:
    //         protoRpcRegistry.scheduleRpcTypes.GetSchedulesResponse.deserializeBinary
    // },
];
exports.default = TypeRegistry;
//# sourceMappingURL=type-registry.js.map