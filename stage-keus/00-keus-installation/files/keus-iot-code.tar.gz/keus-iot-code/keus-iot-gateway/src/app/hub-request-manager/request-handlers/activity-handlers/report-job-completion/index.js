"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const job_completion_pb_1 = require("../../../protos/generated/hub/activity/job_completion_pb");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const group_constants_1 = require("../../../../../constants/group/group-constants");
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const keus_schedule_1 = __importDefault(require("../../../../../models/database-models/keus-schedule"));
const scene_types_1 = require("../../../../../constants/scene/scene-types");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Report Job Completion' });
exports.default = async (reportJobCompReq) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                //Check user permissions & check if zigbee is ready
                logInst.log('Report Job Completion Called');
                const reqType = reportJobCompReq.getJobType();
                switch (reqType) {
                    case job_completion_pb_1.JOB_TYPES.GROUP_CONF:
                        if (!reportJobCompReq.hasGroupConfigureUpdate()) {
                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                        }
                        const grpConfigReq = reportJobCompReq.getGroupConfigureUpdate();
                        const configGroup = await getGroupFromArea(grpConfigReq.getGroupId(), grpConfigReq.getAreaId());
                        if (!configGroup) {
                            throw new errors_1.GroupErrors.InvalidGroupId();
                        }
                        else {
                            let configGrpSyncState;
                            if (grpConfigReq.getRequestId() != configGroup.groupSyncState.lastRequestId) {
                                throw new errors_1.GeneralErrors.InvalidRequestId();
                            }
                            else {
                                if (grpConfigReq.getSuccess()) {
                                    configGrpSyncState = {
                                        lastRequestId: configGroup.groupSyncState.lastRequestId,
                                        lastRequestParameters: configGroup.groupSyncState.lastRequestParameters,
                                        lastRequestTime: configGroup.groupSyncState.lastRequestTime,
                                        lastRequestType: configGroup.groupSyncState.lastRequestType,
                                        syncState: group_structures_pb_1.GROUP_SYNC_STATES.GROUPINSYNC,
                                        syncedDevices: []
                                    };
                                    //Update driver configs
                                    await keus_device_1.default.updateGroupDeviceProperties(configGroup.deviceList, configGroup.groupSyncState.lastRequestParameters);
                                    //Update group config
                                    await keus_group_1.default.configureGroupProperties(configGroup.groupId, configGroup.groupRoom, configGroup.groupSyncState.lastRequestParameters, configGroup.isHidden);
                                }
                                else {
                                    configGrpSyncState = {
                                        lastRequestId: configGroup.groupSyncState.lastRequestId,
                                        lastRequestParameters: configGroup.groupSyncState.lastRequestParameters,
                                        lastRequestTime: configGroup.groupSyncState.lastRequestTime,
                                        lastRequestType: configGroup.groupSyncState.lastRequestType,
                                        syncState: group_structures_pb_1.GROUP_SYNC_STATES.GROUPSYNCFAILED,
                                        syncedDevices: grpConfigReq.getConfiguredDevicesList()
                                    };
                                    await keus_device_1.default.updateGroupDeviceProperties(grpConfigReq.getConfiguredDevicesList(), configGroup.groupSyncState.lastRequestParameters);
                                }
                                await keus_group_1.default.updateGroupSyncState(configGroup.groupId, configGroup.groupRoom, configGrpSyncState);
                                resolve(response_1.default.getReportSuccessful());
                            }
                        }
                        break;
                    case job_completion_pb_1.JOB_TYPES.GROUP_DEL:
                        if (!reportJobCompReq.hasGroupDeleteUpdate()) {
                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                        }
                        const grpDelReq = reportJobCompReq.getGroupDeleteUpdate();
                        const deleteGroup = await getGroupFromArea(grpDelReq.getGroupId(), grpDelReq.getAreaId());
                        if (!deleteGroup) {
                            throw new errors_1.GroupErrors.InvalidGroupId();
                        }
                        else {
                            let delGrpSyncState;
                            if (grpDelReq.getRequestId() != deleteGroup.groupSyncState.lastRequestId) {
                                throw new errors_1.GeneralErrors.InvalidRequestId();
                            }
                            else {
                                if (grpDelReq.getSuccess()) {
                                    //Delete all smartconsole buttons
                                    await keus_device_1.default.cleanSmartConsoleGroupButtons(deleteGroup.groupId, deleteGroup.groupRoom);
                                    //Delete All scene Actions
                                    await keus_scene_1.default.cleanGroupActionsFromScene(deleteGroup.groupId, deleteGroup.groupRoom);
                                    //Delete All schedule group actions
                                    await keus_schedule_1.default.cleanGroupSchedules(deleteGroup.groupId, deleteGroup.groupRoom);
                                    //Update Device Groups
                                    await updateGroupDeviceInfo(deleteGroup, grpDelReq.getDeletedDevicesList(), true);
                                    //Delete the group
                                    await keus_group_1.default.deleteGroupById(deleteGroup.groupId, deleteGroup.groupRoom);
                                }
                                else {
                                    delGrpSyncState = {
                                        lastRequestId: deleteGroup.groupSyncState.lastRequestId,
                                        lastRequestParameters: deleteGroup.groupSyncState.lastRequestParameters,
                                        lastRequestTime: deleteGroup.groupSyncState.lastRequestTime,
                                        lastRequestType: deleteGroup.groupSyncState.lastRequestType,
                                        syncState: group_structures_pb_1.GROUP_SYNC_STATES.GROUPSYNCFAILED,
                                        syncedDevices: grpDelReq.getDeletedDevicesList()
                                    };
                                    //Update Driver Groups
                                    await updateGroupDeviceInfo(deleteGroup, grpDelReq.getDeletedDevicesList(), false);
                                    //Update Group Sync state
                                    await keus_group_1.default.updateGroupSyncState(deleteGroup.groupId, deleteGroup.groupRoom, delGrpSyncState);
                                }
                                resolve(response_1.default.getReportSuccessful());
                            }
                        }
                        break;
                    case job_completion_pb_1.JOB_TYPES.SCENE_ADGRP_ACTION:
                        if (!reportJobCompReq.getAddGroupToSceneUpdate()) {
                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                        }
                        else {
                            const addGrpToSceneReq = reportJobCompReq.getAddGroupToSceneUpdate();
                            const configScene = await getSceneFromArea(addGrpToSceneReq.getSceneId(), addGrpToSceneReq.getAreaId());
                            if (!configScene) {
                                throw new errors_1.SceneErrors.InvalidSceneId();
                            }
                            else {
                                const grpAction = configScene.actionList.find(function (act) {
                                    return act.syncRequestId == addGrpToSceneReq.getRequestId();
                                });
                                if (!grpAction) {
                                    throw new errors_1.GeneralErrors.InvalidRequestId();
                                }
                                else {
                                    if (addGrpToSceneReq.getSuccess()) {
                                        grpAction.syncStatus = scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC;
                                        grpAction.syncRequestId = '-';
                                    }
                                    else {
                                        grpAction.syncStatus = scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCFAILED;
                                        grpAction.syncRequestId = '-';
                                    }
                                    console.log('THIS IS HTE ACTION LIST', configScene.actionList);
                                    await keus_scene_1.default.updateSceneActionList(configScene.sceneId, configScene.sceneRoom, configScene.actionList);
                                    resolve(response_1.default.getReportSuccessful());
                                }
                            }
                        }
                        break;
                    case job_completion_pb_1.JOB_TYPES.SCENE_DLGRP_ACTION:
                        if (!reportJobCompReq.getRemoveGroupFromSceneUpdate()) {
                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                        }
                        else {
                            const removeGrpFromSceneReq = reportJobCompReq.getRemoveGroupFromSceneUpdate();
                            const configScene = await getSceneFromArea(removeGrpFromSceneReq.getSceneId(), removeGrpFromSceneReq.getAreaId());
                            if (!configScene) {
                                throw new errors_1.SceneErrors.InvalidSceneId();
                            }
                            else {
                                const grpAction = configScene.actionList.find(function (act) {
                                    return act.syncRequestId == removeGrpFromSceneReq.getRequestId();
                                });
                                if (!grpAction) {
                                    throw new errors_1.GeneralErrors.InvalidRequestId();
                                }
                                else {
                                    if (removeGrpFromSceneReq.getSuccess()) {
                                        const filteredActionList = configScene.actionList.filter(function (action) {
                                            return action.actionId != grpAction.actionId;
                                        });
                                        await keus_scene_1.default.updateSceneActionList(configScene.sceneId, configScene.sceneRoom, filteredActionList);
                                    }
                                    else {
                                        grpAction.syncStatus = scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCFAILED;
                                        grpAction.syncRequestId = '-';
                                        await keus_scene_1.default.updateSceneActionList(configScene.sceneId, configScene.sceneRoom, configScene.actionList);
                                    }
                                    resolve(response_1.default.getReportSuccessful());
                                }
                            }
                        }
                        break;
                    case job_completion_pb_1.JOB_TYPES.SCENE_ADTS:
                        if (!reportJobCompReq.getAdjustTimeslotDelayUpdate()) {
                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                        }
                        else {
                            const adjTsReq = reportJobCompReq.getAdjustTimeslotDelayUpdate();
                            const configScene = await getSceneFromArea(adjTsReq.getSceneId(), adjTsReq.getAreaId());
                            if (!configScene) {
                                throw new errors_1.SceneErrors.InvalidSceneId();
                            }
                            else {
                                if (configScene.sceneSyncInfo.syncRequestId != adjTsReq.getRequestId()) {
                                    throw new errors_1.GeneralErrors.InvalidRequestId();
                                }
                                else {
                                    if (adjTsReq.getSuccess()) {
                                        configScene.sceneSyncInfo.syncRequestId = '-';
                                        configScene.sceneSyncInfo.syncStatus = scene_constants_pb_1.SCENE_SYNC_STATES.SCENEINSYNC;
                                        const adjTimeSlotParams = (configScene.sceneSyncInfo.syncRequestParams);
                                        const timeslot = configScene.timeslotList.find(tslot => tslot.timeslotId == adjTimeSlotParams.timeslotId);
                                        timeslot.timeslotDelay = adjTimeSlotParams.timeslotDelay;
                                        await keus_scene_1.default.updateSceneTimeslotList(configScene.sceneId, configScene.sceneRoom, configScene.timeslotList, configScene.sceneSyncInfo);
                                    }
                                    else {
                                        configScene.sceneSyncInfo.syncRequestId = '-';
                                        configScene.sceneSyncInfo.syncStatus = scene_constants_pb_1.SCENE_SYNC_STATES.SCENESYNCFAILED;
                                        await keus_scene_1.default.updateSceneSyncState(configScene.sceneId, configScene.sceneRoom, configScene.sceneSyncInfo);
                                    }
                                    resolve(response_1.default.getReportSuccessful());
                                }
                            }
                        }
                        break;
                    case job_completion_pb_1.JOB_TYPES.SCENE_DLTS:
                        if (!reportJobCompReq.getDeleteTimeslotUpdate()) {
                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                        }
                        else {
                            const delTsReq = reportJobCompReq.getDeleteTimeslotUpdate();
                            const configScene = await getSceneFromArea(delTsReq.getSceneId(), delTsReq.getAreaId());
                            if (!configScene) {
                                throw new errors_1.SceneErrors.InvalidSceneId();
                            }
                            else {
                                if (configScene.sceneSyncInfo.syncRequestId != delTsReq.getRequestId()) {
                                    throw new errors_1.GeneralErrors.InvalidRequestId();
                                }
                                else {
                                    if (delTsReq.getSuccess()) {
                                        configScene.sceneSyncInfo.syncRequestId = '-';
                                        configScene.sceneSyncInfo.syncStatus = scene_constants_pb_1.SCENE_SYNC_STATES.SCENEINSYNC;
                                        const delTimeSlotParams = (configScene.sceneSyncInfo.syncRequestParams);
                                        configScene.actionList = configScene.actionList.filter(function (action) {
                                            return action.timeslotId != delTimeSlotParams.timeslotId;
                                        });
                                        configScene.timeslotList = configScene.timeslotList.filter(function (ts) {
                                            return ts.timeslotId != delTimeSlotParams.timeslotId;
                                        });
                                        //Update Action List
                                        await keus_scene_1.default.updateSceneActionList(configScene.sceneId, configScene.sceneRoom, configScene.actionList);
                                        //Update Timelost List and sync info
                                        await keus_scene_1.default.updateSceneTimeslotList(configScene.sceneId, configScene.sceneRoom, configScene.timeslotList, configScene.sceneSyncInfo);
                                    }
                                    else {
                                        configScene.sceneSyncInfo.syncRequestId = '-';
                                        configScene.sceneSyncInfo.syncStatus = scene_constants_pb_1.SCENE_SYNC_STATES.SCENESYNCFAILED;
                                        await keus_scene_1.default.updateSceneSyncState(configScene.sceneId, configScene.sceneRoom, configScene.sceneSyncInfo);
                                    }
                                    resolve(response_1.default.getReportSuccessful());
                                }
                            }
                        }
                        break;
                    case job_completion_pb_1.JOB_TYPES.SCENE_DEL:
                        if (!reportJobCompReq.getDeleteSceneUpdate()) {
                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                        }
                        else {
                            const delSceneReq = reportJobCompReq.getDeleteSceneUpdate();
                            const deleteScene = await getSceneFromArea(delSceneReq.getSceneId(), delSceneReq.getAreaId());
                            if (!deleteScene) {
                                throw new errors_1.SceneErrors.InvalidSceneId();
                            }
                            else {
                                if (deleteScene.sceneSyncInfo.syncRequestId != delSceneReq.getRequestId()) {
                                    throw new errors_1.GeneralErrors.InvalidRequestId();
                                }
                                else {
                                    if (delSceneReq.getSuccess()) {
                                        //Remove scene from smart consoles & scene wizards
                                        //Delete all smartconsole buttons
                                        await keus_device_1.default.cleanSmartConsoleSceneButtons(deleteScene.sceneId, deleteScene.sceneRoom);
                                        //Delete all scenewizard buttons
                                        await keus_device_1.default.cleanSceneWizardSceneButtons(deleteScene.sceneId, deleteScene.sceneRoom);
                                        //Delete all scene switch buttons
                                        await keus_device_1.default.cleanSceneSwitchButtons(deleteScene.sceneId, deleteScene.sceneRoom);
                                        //Clean Scene Schedules
                                        await keus_schedule_1.default.cleanSceneSchedules(deleteScene.sceneId, deleteScene.sceneRoom);
                                        //Delete scene
                                        await keus_scene_1.default.deleteSceneById(deleteScene.sceneId, deleteScene.sceneRoom);
                                    }
                                    else {
                                        deleteScene.sceneSyncInfo.syncRequestId = '-';
                                        deleteScene.sceneSyncInfo.syncStatus = scene_constants_pb_1.SCENE_SYNC_STATES.SCENESYNCFAILED;
                                        await updateSceneActionInfo(deleteScene, delSceneReq.getDeletedDevicesList(), delSceneReq.getDeletedGroupsList());
                                        await keus_scene_1.default.updateSceneSyncState(deleteScene.sceneId, deleteScene.sceneRoom, deleteScene.sceneSyncInfo);
                                    }
                                    resolve(response_1.default.getReportSuccessful());
                                }
                            }
                        }
                        break;
                    case job_completion_pb_1.JOB_TYPES.SYNC_DEVICE_SCENE_UI:
                        if (!reportJobCompReq.getSyncSceneUidataUpdate()) {
                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                        }
                        else {
                            const syncDeviceSceneUIReq = reportJobCompReq.getSyncSceneUidataUpdate();
                            const syncSceneUIDevice = await keus_device_1.default.getDeviceById(syncDeviceSceneUIReq.getDeviceId());
                            if (!syncSceneUIDevice) {
                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                            }
                            else {
                                if (!syncSceneUIDevice.deviceSyncInfo ||
                                    syncSceneUIDevice.deviceSyncInfo.syncRequestId !=
                                        syncDeviceSceneUIReq.getRequestId()) {
                                    throw new errors_1.GeneralErrors.InvalidRequestId();
                                }
                                else {
                                    if (syncDeviceSceneUIReq.getSuccess()) {
                                        syncSceneUIDevice.deviceSyncInfo.syncRequestId = '-';
                                        syncSceneUIDevice.deviceSyncInfo.syncStatus = device_constants_pb_1.DEVICE_SYNC_STATES.DEVICEINSYNC;
                                    }
                                    else {
                                        syncSceneUIDevice.deviceSyncInfo.syncRequestId = '-';
                                        syncSceneUIDevice.deviceSyncInfo.syncStatus =
                                            device_constants_pb_1.DEVICE_SYNC_STATES.DEVICESYNCFAILED;
                                    }
                                    await keus_device_1.default.updateDeviceSyncInfo(syncSceneUIDevice.deviceId, syncSceneUIDevice.deviceSyncInfo);
                                    resolve(response_1.default.getReportSuccessful());
                                }
                            }
                        }
                        break;
                    case job_completion_pb_1.JOB_TYPES.SYNC_AREA_SCENE_UI:
                        if (!reportJobCompReq.getSyncAreaSceneUidataUpdate()) {
                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                        }
                        else {
                            const syncAreaSceneUIReq = reportJobCompReq.getSyncAreaSceneUidataUpdate();
                            const syncArea = await keus_home_1.default.getAreaById(syncAreaSceneUIReq.getAreaId());
                            if (!syncArea) {
                                throw new errors_1.HomeErrors.InvalidAreaId();
                            }
                            else {
                                if (!syncArea.areaSyncInfo ||
                                    syncArea.areaSyncInfo.syncRequestId != syncAreaSceneUIReq.getRequestId()) {
                                    throw new errors_1.GeneralErrors.InvalidRequestId();
                                }
                                else {
                                    if (syncAreaSceneUIReq.getSuccess()) {
                                        syncArea.areaSyncInfo.syncRequestId = '-';
                                        syncArea.areaSyncInfo.syncStatus = home_structures_pb_1.AREA_SYNC_STATES.AREAINSYNC;
                                    }
                                    else {
                                        syncArea.areaSyncInfo.syncRequestId = '-';
                                        syncArea.areaSyncInfo.syncStatus = home_structures_pb_1.AREA_SYNC_STATES.AREASYNCFAILED;
                                    }
                                    await keus_home_1.default.updateAreaSyncState(syncArea.areaId, syncArea.areaSyncInfo);
                                    resolve(response_1.default.getReportSuccessful());
                                }
                            }
                        }
                        break;
                    default:
                }
            }
            catch (e) {
                console.log(e);
                switch (e) {
                    case errors_1.GeneralErrors.InvalidParameterSet:
                        resolve(response_1.default.getInvalidParameterSet());
                        break;
                    case errors_1.GeneralErrors.InvalidRequestId:
                        resolve(response_1.default.getInvalidRequestId());
                        break;
                    case errors_1.GroupErrors.InvalidGroupId:
                        resolve(response_1.default.getInvalidGroupId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.HomeErrors.InvalidAreaId:
                        resolve(response_1.default.getInvalidAreaId());
                        break;
                    case errors_1.SceneErrors.InvalidSceneId:
                        resolve(response_1.default.getInvalidSceneId());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
async function getGroupFromArea(groupId, areaId) {
    const grpRooms = home_utils_1.getRoomIdsFromRoomList(await keus_home_1.default.getRoomsByArea(areaId));
    const roomGrpList = await keus_group_1.default.getGroupsByRooms(grpRooms);
    const group = roomGrpList.find(function (grp) {
        return grp.groupId == groupId;
    });
    return group;
}
async function getSceneFromArea(sceneId, areaId) {
    const scnRooms = home_utils_1.getRoomIdsFromRoomList(await keus_home_1.default.getRoomsByArea(areaId));
    const roomScnList = await keus_scene_1.default.getScenesByRooms(scnRooms);
    const scene = roomScnList.find(function (scn) {
        return scn.sceneId == sceneId;
    });
    return scene;
}
async function updateGroupDeviceInfo(group, deletedDeviceList, deleteSuccess) {
    try {
        const currentGroupInfo = {
            groupId: group.groupId,
            groupRoom: group.groupRoom
        };
        switch (group.groupType) {
            case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
            case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
            case group_structures_pb_1.GROUP_TYPES.RGBWWA:
            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
                if (deleteSuccess) {
                    await keus_device_1.default.updateDriversGroup(group.deviceList, group_constants_1.NoGroupId, '');
                }
                else {
                    await keus_device_1.default.updateDriversGroup(deletedDeviceList, group_constants_1.NoGroupId, '');
                    //Update Group Device list
                    const newDriverList = group.deviceList.filter(function (driverId) {
                        return deletedDeviceList.indexOf(driverId) < 0;
                    });
                    await keus_group_1.default.updateGroupDeviceList(group.groupId, group.groupRoom, newDriverList);
                }
                break;
            case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                const applCTGroupProperties = group.groupProperties;
                const deleteCTApplianceList = applCTGroupProperties.deviceList.filter(function (appliance) {
                    return deletedDeviceList.indexOf(appliance.deviceId) > -1;
                });
                const ctEmbeddedDeviceIdList = [];
                const ctEmbeddedApplianceIdList = [];
                deleteCTApplianceList.forEach(function (deletedAppl) {
                    ctEmbeddedApplianceIdList.push(deletedAppl.applianceId);
                    ctEmbeddedDeviceIdList.push(deletedAppl.deviceId);
                });
                if (deleteSuccess) {
                    await keus_device_1.default.updateEmbeddedApplianceGroups(ctEmbeddedDeviceIdList, ctEmbeddedApplianceIdList, group_constants_1.NoGroupId, '', currentGroupInfo);
                }
                else {
                    await keus_device_1.default.updateEmbeddedApplianceGroups(ctEmbeddedDeviceIdList, ctEmbeddedApplianceIdList, group_constants_1.NoGroupId, '', currentGroupInfo);
                    applCTGroupProperties.deviceList = applCTGroupProperties.deviceList.filter(function (appliance) {
                        return deletedDeviceList.indexOf(appliance.deviceId) < 0;
                    });
                    await keus_group_1.default.configureGroupProperties(group.groupId, group.groupRoom, applCTGroupProperties, false);
                }
                break;
            case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                const applFanGroupProperties = group.groupProperties;
                const deleteFanApplianceList = applFanGroupProperties.deviceList.filter(function (appliance) {
                    return deletedDeviceList.indexOf(appliance.deviceId) > -1;
                });
                const fanEmbeddedDeviceIdList = [];
                const fanEmbeddedApplianceIdList = [];
                deleteFanApplianceList.forEach(function (deletedAppl) {
                    fanEmbeddedApplianceIdList.push(deletedAppl.applianceId);
                    fanEmbeddedDeviceIdList.push(deletedAppl.deviceId);
                });
                if (deleteSuccess) {
                    await keus_device_1.default.updateEmbeddedApplianceGroups(fanEmbeddedDeviceIdList, fanEmbeddedApplianceIdList, group_constants_1.NoGroupId, '', currentGroupInfo);
                }
                else {
                    await keus_device_1.default.updateEmbeddedApplianceGroups(fanEmbeddedDeviceIdList, fanEmbeddedApplianceIdList, group_constants_1.NoGroupId, '', currentGroupInfo);
                    applFanGroupProperties.deviceList = applFanGroupProperties.deviceList.filter(function (appliance) {
                        return deletedDeviceList.indexOf(appliance.deviceId) < 0;
                    });
                    await keus_group_1.default.configureGroupProperties(group.groupId, group.groupRoom, applFanGroupProperties, false);
                }
                break;
            case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                const applDimmerGroupProperties = group.groupProperties;
                const deleteDimmerApplianceList = applDimmerGroupProperties.deviceList.filter(function (appliance) {
                    return deletedDeviceList.indexOf(appliance.deviceId) > -1;
                });
                const dimmerEmbeddedDeviceIdList = [];
                const dimmerEmbeddedApplianceIdList = [];
                deleteDimmerApplianceList.forEach(function (deletedAppl) {
                    dimmerEmbeddedApplianceIdList.push(deletedAppl.applianceId);
                    dimmerEmbeddedDeviceIdList.push(deletedAppl.deviceId);
                });
                if (deleteSuccess) {
                    await keus_device_1.default.updateEmbeddedApplianceGroups(dimmerEmbeddedDeviceIdList, dimmerEmbeddedApplianceIdList, group_constants_1.NoGroupId, '', currentGroupInfo);
                }
                else {
                    await keus_device_1.default.updateEmbeddedApplianceGroups(dimmerEmbeddedDeviceIdList, dimmerEmbeddedApplianceIdList, group_constants_1.NoGroupId, '', currentGroupInfo);
                    applDimmerGroupProperties.deviceList = applDimmerGroupProperties.deviceList.filter(function (appliance) {
                        return deletedDeviceList.indexOf(appliance.deviceId) < 0;
                    });
                    await keus_group_1.default.configureGroupProperties(group.groupId, group.groupRoom, applDimmerGroupProperties, false);
                }
                break;
            case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
                const applOnOffGroupProperties = group.groupProperties;
                const deleteOnOffApplianceList = applOnOffGroupProperties.deviceList.filter(function (appliance) {
                    return deletedDeviceList.indexOf(appliance.deviceId) > -1;
                });
                const onOffEmbeddedDeviceIdList = [];
                const onOffEmbeddedApplianceIdList = [];
                deleteOnOffApplianceList.forEach(function (deletedAppl) {
                    onOffEmbeddedApplianceIdList.push(deletedAppl.applianceId);
                    onOffEmbeddedDeviceIdList.push(deletedAppl.deviceId);
                });
                if (deleteSuccess) {
                    await keus_device_1.default.updateEmbeddedApplianceGroups(onOffEmbeddedDeviceIdList, onOffEmbeddedApplianceIdList, group_constants_1.NoGroupId, '', currentGroupInfo);
                }
                else {
                    await keus_device_1.default.updateEmbeddedApplianceGroups(onOffEmbeddedDeviceIdList, onOffEmbeddedApplianceIdList, group_constants_1.NoGroupId, '', currentGroupInfo);
                    applOnOffGroupProperties.deviceList = applOnOffGroupProperties.deviceList.filter(function (appliance) {
                        return deletedDeviceList.indexOf(appliance.deviceId) < 0;
                    });
                    await keus_group_1.default.configureGroupProperties(group.groupId, group.groupRoom, applOnOffGroupProperties, false);
                }
                break;
            default:
        }
    }
    catch (e) {
        throw e;
    }
}
async function updateSceneActionInfo(scene, deletedDeviceList, deletedGroupList) {
    try {
        const newActionList = scene.actionList.filter(function (action) {
            switch (action.actionType) {
                case scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER:
                    const ddAction = action.actionItem;
                    return deletedGroupList.indexOf(ddAction.groupId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.DALINONDIMMABLEDRIVER:
                    const dndAction = action.actionItem;
                    return deletedGroupList.indexOf(dndAction.groupId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER:
                    const zdAction = action.actionItem;
                    return deletedGroupList.indexOf(zdAction.groupId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.ZIGBEENONDIMMABLEDRIVER:
                    const zndAction = action.actionItem;
                    return deletedGroupList.indexOf(zndAction.groupId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.GROUPAPPLIANCECOLORTUNABLE:
                    const ctGrpApplAction = action.actionItem;
                    return deletedGroupList.indexOf(ctGrpApplAction.groupId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.GROUPAPPLIANCEFAN:
                    const fanGrpApplAction = action.actionItem;
                    return deletedGroupList.indexOf(fanGrpApplAction.groupId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.GROUPAPPLIANCEONOFF:
                    const onOffApplGrpAction = action.actionItem;
                    return deletedGroupList.indexOf(onOffApplGrpAction.groupId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.GROUPAPPLIANCESINGLEDIMMER:
                    const sDimmerApplGrpAction = action.actionItem;
                    return deletedGroupList.indexOf(sDimmerApplGrpAction.groupId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.GROUPRGBWWADRIVER:
                    const zrgbwwaGrpAction = action.actionItem;
                    return deletedGroupList.indexOf(zrgbwwaGrpAction.groupId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE:
                    const scRelayAction = action.actionItem;
                    return deletedDeviceList.indexOf(scRelayAction.deviceId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH:
                    const esAction = action.actionItem;
                    return deletedDeviceList.indexOf(esAction.deviceId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER:
                    const zccAction = action.actionItem;
                    return deletedDeviceList.indexOf(zccAction.deviceId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER:
                    const zacfcAction = action.actionItem;
                    return deletedDeviceList.indexOf(zacfcAction.deviceId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.ZIGBEEDCFANCONTROLLER:
                    const zdcfcAction = action.actionItem;
                    return deletedDeviceList.indexOf(zdcfcAction.deviceId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.ZIGBEERGBWWADRIVER:
                    const zrgbwwaAction = action.actionItem;
                    return deletedDeviceList.indexOf(zrgbwwaAction.deviceId) < 0;
                    break;
                case scene_types_1.SceneActionTypes.ZIGBEEIRBLASTER:
                    const zirbAction = action.actionItem;
                    return deletedDeviceList.indexOf(zirbAction.irDevice) < 0;
                    break;
                default:
                    return true;
            }
        });
        await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, newActionList);
    }
    catch (e) {
        throw e;
    }
}
//# sourceMappingURL=index.js.map