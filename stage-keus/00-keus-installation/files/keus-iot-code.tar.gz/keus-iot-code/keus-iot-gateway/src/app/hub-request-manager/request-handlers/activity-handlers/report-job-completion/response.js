"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const job_completion_pb_1 = require("../../../protos/generated/hub/activity/job_completion_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class ReportJobCompletion {
    static getReportSuccessful() {
        const resp = new job_completion_pb_1.ReportJobCompletionResponse();
        resp.setCode(800);
        resp.setMessage('Reported Successfully');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
    static getInvalidParameterSet() {
        const resp = new job_completion_pb_1.ReportJobCompletionResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Parameter Set');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
    static getInvalidRequestId() {
        const resp = new job_completion_pb_1.ReportJobCompletionResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Request Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
    static getInvalidGroupId() {
        const resp = new job_completion_pb_1.ReportJobCompletionResponse();
        resp.setCode(803);
        resp.setMessage('Invalid Group Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new job_completion_pb_1.ReportJobCompletionResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
    static getInvalidAreaId() {
        const resp = new job_completion_pb_1.ReportJobCompletionResponse();
        resp.setCode(805);
        resp.setMessage('Invalid Area Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
    static getInvalidSceneId() {
        const resp = new job_completion_pb_1.ReportJobCompletionResponse();
        resp.setCode(806);
        resp.setMessage('Invalid Scene Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
    static getInternalServerError() {
        const resp = new job_completion_pb_1.ReportJobCompletionResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
}
exports.default = ReportJobCompletion;
ReportJobCompletion.responseType = system_constants_1.ProtoPackageName + '.ReportJobCompletionResponse';
//# sourceMappingURL=response.js.map