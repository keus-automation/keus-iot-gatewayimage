"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const activity_constants_pb_1 = require("../../../protos/generated/hub/activity/activity_constants_pb");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const SystemConstants = __importStar(require("../../../../../constants/gateway/system-constants"));
const zigbee_curtain_controller_1 = require("../../device-handlers/zigbee-curtain-controller");
const zigbee_fan_controllers_1 = require("../../device-handlers/zigbee-fan-controllers");
const scene_handlers_1 = require("../../scene-handlers");
const smart_consoles_1 = require("../../device-handlers/smart-consoles");
const zigbee_embedded_switches_1 = require("../../device-handlers/zigbee-embedded-switches");
const group_handlers_1 = require("../../group-handlers");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Report Job Completion' });
exports.default = async (reportSystemActivityReq) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                const sourceInfo = {
                    phone: SystemConstants.SystemNumber
                };
                logInst.log('Report system Activity Called');
                reportSystemActivityReq.getSystemActivityList().forEach(async function (sysActivity) {
                    switch (sysActivity.getActivityType()) {
                        case activity_constants_pb_1.REPORT_ACTIVITY_TYPES.CURTAIN_DEVICE:
                            await zigbee_curtain_controller_1.ReportZigbeeCurtainControllerActivity(sysActivity.getCurtainActivity(), sourceInfo.phone);
                            break;
                        case activity_constants_pb_1.REPORT_ACTIVITY_TYPES.ACFAN_DEVICE:
                            await zigbee_fan_controllers_1.ReportZigbeeACFanActivity(sysActivity.getAcFanActivity(), sourceInfo.phone);
                            break;
                        case activity_constants_pb_1.REPORT_ACTIVITY_TYPES.DCFAN_DEVICE:
                            await zigbee_fan_controllers_1.ReportZigbeeDCFanActivity(sysActivity.getDcFanActivity(), sourceInfo.phone);
                            break;
                        case activity_constants_pb_1.REPORT_ACTIVITY_TYPES.SCRELAY_DEVICE:
                            await smart_consoles_1.ReportConsoleRelayActivity(sysActivity.getRelayActivity(), sourceInfo.phone);
                            break;
                        case activity_constants_pb_1.REPORT_ACTIVITY_TYPES.ESAPPL_DEVICE:
                            await zigbee_embedded_switches_1.ReportApplianceActivity(sysActivity.getEsApplianceActivity(), sourceInfo.phone);
                            break;
                        case activity_constants_pb_1.REPORT_ACTIVITY_TYPES.UPDATE_GROUP:
                            await group_handlers_1.ReportGroupActivity(sysActivity.getGroupActivity(), sourceInfo.phone);
                            break;
                        case activity_constants_pb_1.REPORT_ACTIVITY_TYPES.EXECUTE_SCENE:
                            await scene_handlers_1.ReportSceneActivity(sysActivity.getSceneActivity(), sourceInfo.phone);
                            break;
                        default:
                    }
                });
                resolve(response_1.default.getReportSuccessful());
            }
            catch (e) {
                switch (e) {
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map