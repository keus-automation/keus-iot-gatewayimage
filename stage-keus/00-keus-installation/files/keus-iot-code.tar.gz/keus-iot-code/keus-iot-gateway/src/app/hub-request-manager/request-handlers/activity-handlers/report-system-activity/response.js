"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const activity_structures_pb_1 = require("../../../protos/generated/hub/activity/activity_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class ReportJobCompletion {
    static getReportSuccessful() {
        const resp = new activity_structures_pb_1.ReportSystemActivityResponse();
        resp.setCode(800);
        resp.setMessage('Reported Successfully');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
    static getInternalServerError() {
        const resp = new activity_structures_pb_1.ReportSystemActivityResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ReportJobCompletion.responseType);
    }
}
exports.default = ReportJobCompletion;
ReportJobCompletion.responseType = system_constants_1.ProtoPackageName + '.ReportSystemActivityResponse';
//# sourceMappingURL=response.js.map