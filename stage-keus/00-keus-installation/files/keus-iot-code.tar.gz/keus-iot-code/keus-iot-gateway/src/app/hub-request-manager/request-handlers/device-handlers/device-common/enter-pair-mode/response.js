"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const device_pb_1 = require("../../../../protos/generated/hub/devices/device_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class EnterPairMode {
    static getEnterPairModeSuccessful() {
        const resp = new device_pb_1.EnterPairModeResponse();
        resp.setCode(800);
        resp.setMessage('Entered Pairing Mode');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), EnterPairMode.responseType);
    }
    static getUserNotAdmin() {
        const resp = new device_pb_1.EnterPairModeResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EnterPairMode.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new device_pb_1.EnterPairModeResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EnterPairMode.responseType);
    }
    static getZigbeeControllerNotReady() {
        const resp = new device_pb_1.EnterPairModeResponse();
        resp.setCode(801);
        resp.setMessage('Zigbee Controller Not Ready');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EnterPairMode.responseType);
    }
    static getInternalServerError() {
        const resp = new device_pb_1.EnterPairModeResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), EnterPairMode.responseType);
    }
}
exports.default = EnterPairMode;
EnterPairMode.responseType = system_constants_1.ProtoPackageName + '.EnterPairModeResponse';
//# sourceMappingURL=response.js.map