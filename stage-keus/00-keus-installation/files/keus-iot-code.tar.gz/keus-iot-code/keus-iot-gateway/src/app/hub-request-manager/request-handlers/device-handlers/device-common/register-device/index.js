"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const keus_device_models_1 = __importDefault(require("../../../../../../models/device-models/device-categories/keus-device-models"));
const local_client_1 = require("../../../../local-client");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Register Device' });
const responseType = system_constants_1.ProtoPackageName + '.RegisterDeviceResponse';
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const cloud_client_1 = require("../../../../cloud-client");
const proto_utils_1 = require("../../../../../../utilities/gateway/proto-utils");
exports.default = async (regDeviceReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Register Device: ', regDeviceReq.getDeviceId());
                if (!regDeviceReq.getDeviceId()) {
                    resolve(response_1.default.getInvalidDeviceId());
                }
                else {
                    let user = await keus_user_1.default.getUserByPhone(phone);
                    // await checkUserIsAdmin(user);
                    const device = await keus_device_1.default.getDeviceById(regDeviceReq.getDeviceId());
                    // if (device) {
                    //     throw new DeviceErrors.DeviceAlreadyRegistered();
                    // } else {
                    const deviceObj = await keus_device_models_1.default.getDeviceInstance(regDeviceReq.getDeviceId(), regDeviceReq.getMasterId(), regDeviceReq.getDeviceType(), regDeviceReq.getFirmwareVersion(), regDeviceReq.getDeviceParent());
                    console.log('Registering Device', deviceObj);
                    if (!device) {
                        await keus_device_1.default.insertDevice(deviceObj);
                    }
                    //-----------------------Device Registration Event--------------------------------
                    const eventArg = response_1.default.getRegisterSuccessful(proto_utils_1.DeviceProtoUtils.getDeviceProto(deviceObj));
                    local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                    cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                    resolve(eventArg);
                    // }
                }
            }
            catch (e) {
                console.log('Register Device error', e);
                switch (e.constructor) {
                    case errors_1.DeviceErrors.DeviceAlreadyRegistered:
                        resolve(response_1.default.getDeviceAlreadyRegistered());
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map