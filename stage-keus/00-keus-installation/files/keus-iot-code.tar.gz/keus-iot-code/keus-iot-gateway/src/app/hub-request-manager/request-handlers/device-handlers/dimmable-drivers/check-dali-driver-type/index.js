"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../../errors/errors");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Set Dali Color Tunable Driver' });
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const general_1 = require("../../../../../../utilities/general");
const local_client_1 = require("../../../../local-client");
const dali_dimmable_driver_pb_1 = require("../../../../../device-manager/providers/generated/devices/dali_dimmable_driver_pb");
const device_constants_pb_1 = require("../../../../../device-manager/providers/generated/devices/device_constants_pb");
exports.default = async (setdctdReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Configuring Dali Dimmable Driver: ', setdctdReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(setdctdReq.getDeviceId());
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    let checkObj = new dali_dimmable_driver_pb_1.DMGetDaliDriverProperties();
                    checkObj.setDeviceId(setdctdReq.getDeviceId());
                    checkObj.setReqType(device_constants_pb_1.DMDALI_READPROPS_REQ_TYPE.DALI_PROPS_CHECK);
                    let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(checkObj.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMGetDaliDriverProperties'));
                    // make zigbee call to get the dali driver type
                    //will return drvice category code dali dimmable driver (KDDD) or dali color tunable driver(KDCTD)
                    resolve(response_1.default.getCheckDriverTypeSuccessful(res.getIsColourTunable() ? 'KDCTD' : 'KDDD'));
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map