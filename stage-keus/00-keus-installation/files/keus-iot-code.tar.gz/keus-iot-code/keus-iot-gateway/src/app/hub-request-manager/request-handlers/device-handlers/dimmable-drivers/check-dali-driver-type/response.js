"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const dali_color_tunable_driver_pb_1 = require("../../../../protos/generated/hub/devices/dali_color_tunable_driver_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class CheckDaliDriverTypeResp {
    static getCheckDriverTypeSuccessful(driverType) {
        const resp = new dali_color_tunable_driver_pb_1.CheckDaliDriverTypeResponse();
        resp.setCode(800);
        resp.setMessage('Check Dali Driver Type successful');
        resp.setSuccess(true);
        resp.setDriverType(driverType);
        return general_1.PackIntoAny(resp.serializeBinary(), CheckDaliDriverTypeResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new dali_color_tunable_driver_pb_1.CheckDaliDriverTypeResponse();
        resp.setCode(801);
        resp.setMessage('Invalid DeviceId');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CheckDaliDriverTypeResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new dali_color_tunable_driver_pb_1.CheckDaliDriverTypeResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CheckDaliDriverTypeResp.responseType);
    }
    static getInternalServerError() {
        const resp = new dali_color_tunable_driver_pb_1.CheckDaliDriverTypeResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), CheckDaliDriverTypeResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new dali_color_tunable_driver_pb_1.CheckDaliDriverTypeResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CheckDaliDriverTypeResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new dali_color_tunable_driver_pb_1.CheckDaliDriverTypeResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CheckDaliDriverTypeResp.responseType);
    }
}
exports.default = CheckDaliDriverTypeResp;
CheckDaliDriverTypeResp.responseType = system_constants_1.ProtoPackageName + '.CheckDaliDriverTypeResponse';
//# sourceMappingURL=response.js.map