"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../../errors/errors");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Configure Dali Color Tunable Driver' });
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const general_1 = require("../../../../../../utilities/general");
const local_client_1 = require("../../../../local-client");
const dali_colour_tunable_driver_pb_1 = require("../../../../../device-manager/providers/generated/devices/dali_colour_tunable_driver_pb");
exports.default = async (confdctdReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Configuring Dali Color Tunable Driver: ', confdctdReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(confdctdReq.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_DALI_COLOR_TUNABLE_DRIVER').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        device.isHidden = confdctdReq.getIsHidden();
                        device.isConfigured = true;
                        let deviceProperties = device.deviceProperties;
                        // deviceProperties.defaultState = confdctdReq.getDeviceProperties().getDefaultState();
                        deviceProperties.minValue = confdctdReq.getMinValue();
                        deviceProperties.maxValue = confdctdReq.getMaxValue();
                        deviceProperties.fadeTime = confdctdReq.getFadeTime();
                        deviceProperties.maxTemperature = confdctdReq.getMaxTemperature();
                        deviceProperties.minTemperature = confdctdReq.getMinTemperature();
                        deviceProperties.defaultState.driverState = confdctdReq.getDriverState();
                        deviceProperties.defaultState.colorTemperature = confdctdReq.getColorTemperature();
                        device.deviceProperties = deviceProperties;
                        // add DM CALL 
                        let DmConfigObj = new dali_colour_tunable_driver_pb_1.DMConfigureDaliColourTunableDriver();
                        DmConfigObj.setDeviceId(confdctdReq.getDeviceId());
                        DmConfigObj.setDefaultState(confdctdReq.getDriverState());
                        DmConfigObj.setDefaultTemp(confdctdReq.getColorTemperature());
                        DmConfigObj.setMinValue(confdctdReq.getMinValue());
                        DmConfigObj.setMaxValue(confdctdReq.getMaxValue());
                        let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(DmConfigObj.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMConfigureDaliColourTunableDriver'));
                        await keus_device_1.default.updateDevice(device.deviceId, device);
                        resolve(response_1.default.getConfigureSuccessful());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map