"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const zigbee_dimmable_driver_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_dimmable_driver_pb");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const errors_1 = require("../../../../../../errors/errors");
const local_client_1 = require("../../../../local-client");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Configure Zigbee Dimmable Driver' });
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
exports.default = async (confzddReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Configuring Zigbee Dimmable Driver: ', confzddReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(confzddReq.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_DIMMABLE_DRIVER').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        device.deviceName = confzddReq.getDeviceName();
                        device.deviceLocation = confzddReq.getDeviceLocation();
                        device.isHidden = confzddReq.getIsHidden();
                        device.isConfigured = true;
                        let deviceProperties = device.deviceProperties;
                        deviceProperties.defaultState = confzddReq.getDeviceProperties().getDefaultState();
                        deviceProperties.minValue = confzddReq.getDeviceProperties().getMinValue();
                        deviceProperties.maxValue = confzddReq.getDeviceProperties().getMaxValue();
                        deviceProperties.fadeTime = confzddReq.getDeviceProperties().getFadeTime();
                        device.deviceProperties = deviceProperties;
                        let configureObj = new zigbee_dimmable_driver_pb_1.DMConfigureZigbeeDimmableDriver();
                        configureObj.setDefaultState(deviceProperties.defaultState);
                        configureObj.setDeviceId(device.deviceId);
                        configureObj.setFadeTime(deviceProperties.fadeTime);
                        configureObj.setMinValue(deviceProperties.minValue);
                        configureObj.setMaxValue(deviceProperties.maxValue);
                        let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(configureObj.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMConfigureZigbeeDimmableDriver'));
                        await keus_device_1.default.updateDevice(device.deviceId, device);
                        resolve(response_1.default.getConfigureSuccessful());
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map