"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const dali_color_tunable_driver_pb_1 = require("../../../../protos/generated/hub/devices/dali_color_tunable_driver_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class MoveDaliColorTunableRoomResp {
    static getMoveRoomSuccessful() {
        const resp = new dali_color_tunable_driver_pb_1.MoveDaliColorTunableRoomResponse();
        resp.setCode(800);
        resp.setMessage('Move Room Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveDaliColorTunableRoomResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new dali_color_tunable_driver_pb_1.MoveDaliColorTunableRoomResponse();
        resp.setCode(801);
        resp.setMessage('Invalid DeviceId');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveDaliColorTunableRoomResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new dali_color_tunable_driver_pb_1.MoveDaliColorTunableRoomResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveDaliColorTunableRoomResp.responseType);
    }
    static getTargetRoomDoesntExist() {
        const resp = new dali_color_tunable_driver_pb_1.MoveDaliColorTunableRoomResponse();
        resp.setCode(803);
        resp.setMessage('Target Room Doesnt Exist');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveDaliColorTunableRoomResp.responseType);
    }
    static getTargetSectionDoesntExist() {
        const resp = new dali_color_tunable_driver_pb_1.MoveDaliColorTunableRoomResponse();
        resp.setCode(803);
        resp.setMessage('Target Section Doesnt Exist');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveDaliColorTunableRoomResp.responseType);
    }
    static getParentNotInTargetArea() {
        const resp = new dali_color_tunable_driver_pb_1.MoveDaliColorTunableRoomResponse();
        resp.setCode(804);
        resp.setMessage('Parent Not In Target Area');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveDaliColorTunableRoomResp.responseType);
    }
    static getInternalServerError() {
        const resp = new dali_color_tunable_driver_pb_1.MoveDaliColorTunableRoomResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveDaliColorTunableRoomResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new dali_color_tunable_driver_pb_1.MoveDaliColorTunableRoomResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveDaliColorTunableRoomResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new dali_color_tunable_driver_pb_1.MoveDaliColorTunableRoomResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveDaliColorTunableRoomResp.responseType);
    }
}
exports.default = MoveDaliColorTunableRoomResp;
MoveDaliColorTunableRoomResp.responseType = system_constants_1.ProtoPackageName + '.MoveDaliColorTunableRoomResponse';
//# sourceMappingURL=response.js.map