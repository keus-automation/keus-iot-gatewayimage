"use strict";
/* eslint-disable */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const errors_1 = require("../../../../../../errors/errors");
const home_constants_1 = require("../../../../../../constants/gateway/home-constants");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const HomeUtils = __importStar(require("../../../../../../utilities/gateway/home-utils"));
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Move Dali Dimmable Driver' });
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
exports.default = async (mvDddReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Moving Dali Dimmable Driver: ', mvDddReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(mvDddReq.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_DALI_DIMMABLE_DRIVER').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const targetRoom = await keus_home_1.default.getRoomById(mvDddReq.getDeviceRoom());
                    const daliParent = await keus_device_1.default.getDeviceById(device.deviceParent);
                    const parentRoom = await keus_home_1.default.getRoomById(daliParent.deviceRoom);
                    const targetSection = targetRoom
                        ? targetRoom.sectionList.find(function (sec) {
                            return sec.sectionId == mvDddReq.getDeviceSection();
                        })
                        : null;
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else if (!targetRoom) {
                        throw new errors_1.HomeErrors.InvalidRoomId();
                    }
                    else if (!targetSection) {
                        throw new errors_1.HomeErrors.InvalidSectionId();
                    }
                    else if (parentRoom.areaId != targetRoom.areaId) {
                        throw new errors_1.HomeErrors.ParentNotInTargetArea();
                    }
                    else if (device.deviceRoom == home_constants_1.DefaultRoomId) {
                        // await zigbee add to area
                        throw new errors_1.HomeErrors.ParentNotInTargetArea();
                    }
                    else {
                        const currentRoom = await keus_home_1.default.getRoomById(device.deviceRoom);
                        const areSameArea = HomeUtils.checkRoomsInSameArea([currentRoom, targetRoom]);
                        if (areSameArea) {
                            await keus_device_1.default.updateDeviceRoomAndSection(device.deviceId, mvDddReq.getDeviceRoom(), mvDddReq.getDeviceSection());
                            resolve(response_1.default.getMoveRoomSuccessful());
                        }
                        else {
                            throw new errors_1.HomeErrors.ParentNotInTargetArea();
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.HomeErrors.InvalidRoomId:
                        resolve(response_1.default.getTargetRoomDoesntExist());
                        break;
                    case errors_1.HomeErrors.InvalidSectionId:
                        resolve(response_1.default.getTargetSectionDoesntExist());
                        break;
                    case errors_1.HomeErrors.ParentNotInTargetArea:
                        resolve(response_1.default.getParentNotInTargetArea());
                        break;
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map