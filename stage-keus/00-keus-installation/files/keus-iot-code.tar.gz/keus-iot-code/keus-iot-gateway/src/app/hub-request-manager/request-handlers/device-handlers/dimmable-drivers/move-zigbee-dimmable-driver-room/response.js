"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const zigbee_dimmable_driver_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_dimmable_driver_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class MoveZigbeeDimmableDriverRoomResp {
    static getMoveRoomSuccessful() {
        const resp = new zigbee_dimmable_driver_pb_1.MoveZigbeeDimmableDriverRoomResponse();
        resp.setCode(800);
        resp.setMessage('Move Room Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveZigbeeDimmableDriverRoomResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new zigbee_dimmable_driver_pb_1.MoveZigbeeDimmableDriverRoomResponse();
        resp.setCode(801);
        resp.setMessage('Invalid DeviceId');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveZigbeeDimmableDriverRoomResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_dimmable_driver_pb_1.MoveZigbeeDimmableDriverRoomResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveZigbeeDimmableDriverRoomResp.responseType);
    }
    static getTargetRoomDoesntExist() {
        const resp = new zigbee_dimmable_driver_pb_1.MoveZigbeeDimmableDriverRoomResponse();
        resp.setCode(803);
        resp.setMessage('Target Room Doesnt Exist');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveZigbeeDimmableDriverRoomResp.responseType);
    }
    static getTargetSectionDoesntExist() {
        const resp = new zigbee_dimmable_driver_pb_1.MoveZigbeeDimmableDriverRoomResponse();
        resp.setCode(803);
        resp.setMessage('Target Section Doesnt Exist');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveZigbeeDimmableDriverRoomResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_dimmable_driver_pb_1.MoveZigbeeDimmableDriverRoomResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveZigbeeDimmableDriverRoomResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_dimmable_driver_pb_1.MoveZigbeeDimmableDriverRoomResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveZigbeeDimmableDriverRoomResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_dimmable_driver_pb_1.MoveZigbeeDimmableDriverRoomResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveZigbeeDimmableDriverRoomResp.responseType);
    }
}
exports.default = MoveZigbeeDimmableDriverRoomResp;
MoveZigbeeDimmableDriverRoomResp.responseType = system_constants_1.ProtoPackageName + '.MoveZigbeeDimmableDriverRoomResponse';
//# sourceMappingURL=response.js.map