"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../../errors/errors");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const activity_utils_1 = require("../../../../../../utilities/gateway/activity-utils");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const keus_activity_1 = __importDefault(require("../../../../../../models/database-models/keus-activity"));
const general_1 = require("../../../../../../utilities/general");
const local_client_1 = require("../../../../local-client");
const dali_colour_tunable_driver_pb_1 = require("../../../../../device-manager/providers/generated/devices/dali_colour_tunable_driver_pb");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Update Dali Color Tunable Driver' });
exports.default = async (updatedctdStateReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Updating Dali Color Tunable Driver State: ', updatedctdStateReq.getDeviceId());
                const device = await keus_device_1.default.getDeviceById(updatedctdStateReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                // await checkAccessForUser(user, device.deviceRoom);
                const arrayList = device_categories_1.default.get('KEUS_DALI_COLOR_TUNABLE_DRIVER').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        let deviceProperties = device.deviceProperties;
                        let deviceState = device.deviceState;
                        let driverState = updatedctdStateReq.getDriverState().getDriverState();
                        let driverTemperature = updatedctdStateReq.getDriverState().getColorTemperature();
                        console.log('This is driver state:', updatedctdStateReq.getDriverState());
                        if (updatedctdStateReq.getDriverState().getDriverState() != 0 &&
                            updatedctdStateReq.getDriverState().getDriverState() < deviceProperties.minValue) {
                            driverState = deviceProperties.minValue;
                        }
                        else if (updatedctdStateReq.getDriverState().getDriverState() > deviceProperties.maxValue) {
                            driverState = deviceProperties.maxValue;
                        }
                        if (updatedctdStateReq.getDriverState().getColorTemperature() < deviceProperties.minTemperature) {
                            driverTemperature = deviceProperties.minTemperature;
                        }
                        else if (updatedctdStateReq.getDriverState().getColorTemperature() > deviceProperties.maxTemperature) {
                            driverTemperature = deviceProperties.maxTemperature;
                        }
                        let DmUpdateObj = new dali_colour_tunable_driver_pb_1.DMUpdateDaliColourTunableDriverState();
                        DmUpdateObj.setDeviceId(updatedctdStateReq.getDeviceId());
                        DmUpdateObj.setDriverState(driverState);
                        DmUpdateObj.setDriverTemp(driverTemperature);
                        let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(DmUpdateObj.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMUpdateDaliColourTunableDriverState'));
                        device.lastUpdateBy = phone;
                        device.lastUpdateSource = system_constants_1.UpdateSourceMapping.ANDROID;
                        device.lastUpdateTime = Date.now();
                        device.lastUpdateUser = user.userName;
                        deviceState.driverState = driverState;
                        deviceState.colorTemperature = driverTemperature;
                        deviceState.lastUpdateBy = phone;
                        deviceState.lastUpdateSource = system_constants_1.UpdateSourceMapping.ANDROID;
                        deviceState.lastUpdateTime = Date.now();
                        deviceState.lastUpdateUser = user.userName;
                        device.deviceState = deviceState;
                        await keus_device_1.default.updateDevice(device.deviceId, device);
                        let roomDetails = await keus_home_1.default.getRoomById(device.deviceRoom);
                        let activityObj = await activity_utils_1.getDeviceActivityObj(user, device, roomDetails, updatedctdStateReq, {
                            activitySource: system_constants_1.UpdateSourceMapping.SYSTEM
                        });
                        await keus_activity_1.default.insertActivity(activityObj);
                        resolve(response_1.default.getUpdateStateSuccessful());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_2.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map