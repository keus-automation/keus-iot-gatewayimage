"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dali_color_tunable_driver_pb_1 = require("../../../../protos/generated/hub/devices/dali_color_tunable_driver_pb");
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../../errors/errors");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const DeviceConfigurationConstants = __importStar(require("../../../../../../constants/device/default-configuration-constants"));
const system_constants_2 = require("../../../../../../constants/gateway/system-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Set Dali Color Tunable Driver' });
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const device_types_1 = require("../../../../../../constants/device/device-types");
const dali_dimmable_driver_pb_1 = require("../../../../protos/generated/hub/devices/dali_dimmable_driver_pb");
const general_1 = require("../../../../../../utilities/general");
const local_client_1 = require("../../../../local-client");
const dali_dimmable_driver_pb_2 = require("../../../../../device-manager/providers/generated/devices/dali_dimmable_driver_pb");
const device_constants_pb_1 = require("../../../../../device-manager/providers/generated/devices/device_constants_pb");
exports.default = async (upddTypeReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Updating  Dali Driver Type: ', upddTypeReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(upddTypeReq.getDeviceId());
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    console.log('this is new driver type', upddTypeReq.getDriverType());
                    if (upddTypeReq.getDriverType() == device.deviceCategory) {
                        resolve(response_1.default.getSameUpdateType());
                    }
                    else {
                        let dctProps, dddProps;
                        if (upddTypeReq.getDriverType() != device_categories_1.default.get('KEUS_DALI_COLOR_TUNABLE_DRIVER').deviceCategoryCode && upddTypeReq.getDriverType() != device_categories_1.default.get('KEUS_DALI_DIMMABLE_DRIVER').deviceCategoryCode) {
                            console.log('-----------not dali type');
                            resolve(response_1.default.getInvalidDeviceType());
                        }
                        let checkObj = new dali_dimmable_driver_pb_2.DMGetDaliDriverProperties();
                        checkObj.setDeviceId(upddTypeReq.getDeviceId());
                        checkObj.setReqType(device_constants_pb_1.DMDALI_READPROPS_REQ_TYPE.DALI_PROPS_READ);
                        let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(checkObj.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMGetDaliDriverProperties'));
                        if (upddTypeReq.getDriverType() == device_categories_1.default.get('KEUS_DALI_COLOR_TUNABLE_DRIVER').deviceCategoryCode) {
                            device.deviceType = device_types_1.TypeMap.KDCTD01;
                            device.deviceCategory = device_categories_1.default.get('KEUS_DALI_COLOR_TUNABLE_DRIVER').deviceCategoryCode;
                            device.deviceName = 'Keus DCT Driver';
                            device.deviceTypeName = 'Keus_Color_Tunable_Driver';
                            device.deviceTypeDisplayName = 'Keus DCT Driver';
                            device.deviceProperties = {
                                fadeTime: DeviceConfigurationConstants.DaliColorTunableFadeTime,
                                minValue: res.getProps().getMinValue(),
                                maxValue: res.getProps().getMaxValue(),
                                minTemperature: res.getProps().getMinTemp(),
                                maxTemperature: res.getProps().getMaxTemp(),
                                isDriverPropertyUpdated: true,
                                defaultState: {
                                    driverState: 0,
                                    colorTemperature: DeviceConfigurationConstants.DaliColorTunableMinTemperature,
                                    lastUpdateBy: system_constants_2.SystemNumber,
                                    lastUpdateSource: system_constants_2.UpdateSourceMapping.SYSTEM,
                                    lastUpdateUser: system_constants_2.SystemUser,
                                    lastUpdateTime: Date.now()
                                }
                            };
                            device.deviceState = {
                                driverState: 0,
                                colorTemperature: DeviceConfigurationConstants.DaliColorTunableMinTemperature,
                                lastUpdateBy: system_constants_2.SystemNumber,
                                lastUpdateSource: system_constants_2.UpdateSourceMapping.SYSTEM,
                                lastUpdateUser: system_constants_2.SystemUser,
                                lastUpdateTime: Date.now()
                            };
                            dctProps = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverProperties();
                            dctProps.setFadeTime(DeviceConfigurationConstants.DaliColorTunableFadeTime);
                            dctProps.setMinValue(res.getProps().getMinValue());
                            dctProps.setMaxValue(res.getProps().getMaxValue());
                            dctProps.setMinTemperature(res.getProps().getMinTemp());
                            dctProps.setMaxTemperature(res.getProps().getMaxTemp());
                            dctProps.setIsDriverPropertyUpdated(true);
                            let defCtState = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverState();
                            defCtState.setDriverState(0);
                            defCtState.setColorTemperature(DeviceConfigurationConstants.DaliColorTunableMinTemperature);
                            defCtState.setLastUpdateBy(system_constants_2.SystemNumber);
                            defCtState.setLastUpdateSource(system_constants_2.UpdateSourceMapping.SYSTEM);
                            defCtState.setLastUpdateUser(system_constants_2.SystemUser);
                            defCtState.setLastUpdateTime(Date.now());
                            dctProps.setDefaultState(defCtState);
                            //make zigbee call
                        }
                        if (upddTypeReq.getDriverType() == device_categories_1.default.get('KEUS_DALI_DIMMABLE_DRIVER').deviceCategoryCode) {
                            device.deviceType = device_types_1.TypeMap.KDDD01;
                            device.deviceCategory = device_categories_1.default.get('KEUS_DALI_DIMMABLE_DRIVER').deviceCategoryCode;
                            device.deviceName = 'Keus DSD Driver';
                            device.deviceTypeName = 'Keus_Dali_Dimmable_Single_Channel';
                            device.deviceTypeDisplayName = 'Keus DSD Driver';
                            device.deviceProperties = {
                                fadeTime: DeviceConfigurationConstants.DimmableDriverFadeTime,
                                minValue: res.getProps().getMinValue(),
                                maxValue: res.getProps().getMaxValue(),
                                defaultState: DeviceConfigurationConstants.DimmableDriverDefaultState,
                                isDriverPropertyUpdated: true
                            };
                            device.deviceState = {
                                driverState: 0
                            };
                            dddProps = new dali_dimmable_driver_pb_1.DaliDimmableDriverProperties();
                            dddProps.setFadeTime(DeviceConfigurationConstants.DimmableDriverFadeTime);
                            dddProps.setMinValue(res.getProps().getMinValue());
                            dddProps.setMaxValue(res.getProps().getMaxValue());
                            dddProps.setDefaultState(DeviceConfigurationConstants.DimmableDriverDefaultState);
                            dddProps.setIsDriverPropertyUpdated(true);
                            //make zigbe call
                        }
                        await keus_device_1.default.updateDevice(device.deviceId, device);
                        resolve(response_1.default.getUpdateDriverTypeSuccessful(upddTypeReq.getDriverType(), dctProps, dddProps));
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map