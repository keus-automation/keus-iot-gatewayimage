"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const dali_color_tunable_driver_pb_1 = require("../../../../protos/generated/hub/devices/dali_color_tunable_driver_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class UpdateDaliDriverTypeResp {
    static getUpdateDriverTypeSuccessful(driverType, ctProps, ddprops) {
        const resp = new dali_color_tunable_driver_pb_1.UpdateDaliDriverTypeResponse();
        resp.setCode(800);
        resp.setMessage('Update DriverType successful');
        resp.setSuccess(true);
        if (ctProps) {
            resp.setCtProps(ctProps);
        }
        if (ddprops) {
            resp.setDdProps(ddprops);
        }
        resp.setDriverType(driverType);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateDaliDriverTypeResp.responseType);
    }
    static getSameUpdateType() {
        const resp = new dali_color_tunable_driver_pb_1.UpdateDaliDriverTypeResponse();
        resp.setCode(800);
        resp.setMessage('same driver update type');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateDaliDriverTypeResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new dali_color_tunable_driver_pb_1.UpdateDaliDriverTypeResponse();
        resp.setCode(801);
        resp.setMessage('Invalid DeviceId');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateDaliDriverTypeResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new dali_color_tunable_driver_pb_1.UpdateDaliDriverTypeResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateDaliDriverTypeResp.responseType);
    }
    static getInternalServerError() {
        const resp = new dali_color_tunable_driver_pb_1.UpdateDaliDriverTypeResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateDaliDriverTypeResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new dali_color_tunable_driver_pb_1.UpdateDaliDriverTypeResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateDaliDriverTypeResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new dali_color_tunable_driver_pb_1.UpdateDaliDriverTypeResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateDaliDriverTypeResp.responseType);
    }
}
exports.default = UpdateDaliDriverTypeResp;
UpdateDaliDriverTypeResp.responseType = system_constants_1.ProtoPackageName + '.UpdateDaliDriverTypeResponse';
//# sourceMappingURL=response.js.map