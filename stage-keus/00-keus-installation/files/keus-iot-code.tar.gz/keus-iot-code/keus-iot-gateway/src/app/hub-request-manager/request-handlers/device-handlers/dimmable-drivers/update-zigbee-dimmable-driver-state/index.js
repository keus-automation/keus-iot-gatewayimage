"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const zigbee_dimmable_driver_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_dimmable_driver_pb");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const errors_1 = require("../../../../../../errors/errors");
const local_client_1 = require("../../../../local-client");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Update Zigbee Dimmable Driver' });
exports.default = async (updatezddStateReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Updating Zigbee Dimmable Driver State: ', updatezddStateReq.getDeviceId());
                const device = await keus_device_1.default.getDeviceById(updatezddStateReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkAccessForUser(user, device.deviceRoom);
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_DIMMABLE_DRIVER').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        let deviceProperties = device.deviceProperties;
                        let deviceState = device.deviceState;
                        let driverState = updatezddStateReq.getDriverState();
                        if (updatezddStateReq.getDriverState() != 0 &&
                            updatezddStateReq.getDriverState() < deviceProperties.minValue) {
                            driverState = deviceProperties.minValue;
                        }
                        else if (updatezddStateReq.getDriverState() > deviceProperties.maxValue) {
                            driverState = deviceProperties.maxValue;
                        }
                        let updateObj = new zigbee_dimmable_driver_pb_1.DMUpdateZigbeeDimmableDriverState();
                        updateObj.setDeviceId(device.deviceId);
                        updateObj.setDriverState(driverState);
                        let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(updateObj.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMUpdateZigbeeDimmableDriverState'));
                        device.lastUpdateSource = '';
                        device.lastUpdateTime = Date.now();
                        device.lastUpdateBy = '';
                        deviceState.driverState = driverState;
                        device.deviceState = deviceState;
                        await keus_device_1.default.updateDevice(device.deviceId, device);
                        // let roomDetails = await KeusHomeModel.getRoomById(device.deviceRoom);
                        // let activityObj = await getDeviceActivityObj(user, device, roomDetails, updatezddStateReq, {
                        //     activitySource: UpdateSourceMapping.SYSTEM
                        // });
                        // await KeusActivityModel.insertActivity(activityObj);
                        resolve(response_1.default.getUpdateStateSuccessful());
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_2.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map