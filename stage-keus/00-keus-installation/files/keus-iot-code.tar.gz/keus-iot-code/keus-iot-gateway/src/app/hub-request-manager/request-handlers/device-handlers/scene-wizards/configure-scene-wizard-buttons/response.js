"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const scene_wizard_pb_1 = require("../../../../protos/generated/hub/devices/scene_wizard_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class ConfigureSceneWizardButtons {
    static getConfigureSuccessful() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(800);
        resp.setMessage('Configure Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(801);
        resp.setMessage('Invalid device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getInvalidButtonId() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(803);
        resp.setMessage('Invalid button id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getInvalidButtonType() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(804);
        resp.setMessage('Invalid button type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getInvalidPropertySet() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(805);
        resp.setMessage('Invalid property set');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getCurtainCountExceeded() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(806);
        resp.setMessage('Curtain count exceeded');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getInvalidGroup() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(807);
        resp.setMessage('Invalid group');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getInvalidScene() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(808);
        resp.setMessage('Invalid scene');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getInvalidDevice() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        resp.setCode(809);
        resp.setMessage('Invalid device');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
    static getInternalServerError() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardButtonsResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizardButtons.responseType);
    }
}
exports.default = ConfigureSceneWizardButtons;
ConfigureSceneWizardButtons.responseType = system_constants_1.ProtoPackageName + '.ConfigureSceneWizardButtonsResponse';
//# sourceMappingURL=response.js.map