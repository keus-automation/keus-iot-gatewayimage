"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const errors_1 = require("../../../../../../errors/errors");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Configure Scene Wizard' });
exports.default = async (configSceneWizardReq) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Configuring Scene Wizard: ', configSceneWizardReq.getDeviceId());
                if (!configSceneWizardReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(configSceneWizardReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SCENE_WIZARD').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        device.deviceName = configSceneWizardReq.getDeviceName()
                            ? configSceneWizardReq.getDeviceName()
                            : device.deviceName;
                        device.deviceLocation = configSceneWizardReq.getDeviceLocation()
                            ? configSceneWizardReq.getDeviceLocation()
                            : device.deviceLocation;
                        var deviceProps = device.deviceProperties;
                        deviceProps.sceneStepSize = configSceneWizardReq.getSceneStepSize();
                        //Zigbee call for defaults
                        device.deviceProperties = deviceProps;
                        keus_device_1.default.updateDevice(device.deviceId, device);
                        resolve(response_1.default.getConfigureSceneWizardSuccessful());
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                    case errors_1.DeviceErrors.DeviceNotInSameArea:
                        resolve(response_1.default.getDeviceNotInSameArea());
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map