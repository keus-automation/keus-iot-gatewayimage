"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const scene_wizard_pb_1 = require("../../../../protos/generated/hub/devices/scene_wizard_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class ConfigureSceneWizard {
    static getConfigureSceneWizardSuccessful() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardResponse();
        resp.setCode(800);
        resp.setMessage('Configure Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizard.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardResponse();
        resp.setCode(801);
        resp.setMessage('Invalid device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizard.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizard.responseType);
    }
    static getDeviceNotInSameArea() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardResponse();
        resp.setCode(803);
        resp.setMessage('Device not in same area');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizard.responseType);
    }
    static getInternalServerError() {
        const resp = new scene_wizard_pb_1.ConfigureSceneWizardResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureSceneWizard.responseType);
    }
}
exports.default = ConfigureSceneWizard;
ConfigureSceneWizard.responseType = system_constants_1.ProtoPackageName + '.ConfigureSceneWizardResponse';
//# sourceMappingURL=response.js.map