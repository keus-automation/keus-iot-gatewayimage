"use strict";
/* eslint-disable */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../../errors/errors");
const home_constants_1 = require("../../../../../../constants/gateway/home-constants");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const HomeUtils = __importStar(require("../../../../../../utilities/gateway/home-utils"));
const device_types_1 = require("../../../../../../constants/device/device-types");
const KZSW01_1 = require("../../../../../../models/device-models/device-types/KZSW01");
const local_client_1 = require("../../../../local-client");
const general_1 = require("../../../../../../utilities/general");
const home_structures_pb_1 = require("../../../../../device-manager/providers/generated/home/home_structures_pb");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Move Scene Wizard Room' });
exports.default = async (mvSceneWizardReq) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Moving Scene Wizard Room: ', mvSceneWizardReq.getDeviceId());
                const device = await keus_device_1.default.getDeviceById(mvSceneWizardReq.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_SCENE_WIZARD').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const targetRoom = await keus_home_1.default.getRoomById(mvSceneWizardReq.getDeviceRoom());
                    const targetSection = targetRoom
                        ? targetRoom.sectionList.find(function (sec) {
                            return sec.sectionId == mvSceneWizardReq.getDeviceSection();
                        })
                        : null;
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else if (!targetRoom) {
                        throw new errors_1.HomeErrors.InvalidRoomId();
                    }
                    else if (!targetSection) {
                        throw new errors_1.HomeErrors.InvalidSectionId();
                    }
                    else if (device.deviceRoom == home_constants_1.DefaultRoomId) {
                        // await zigbee add to area
                        let dmAddDevicetoAreaReq = new home_structures_pb_1.DMAddDeviceToArea();
                        dmAddDevicetoAreaReq.setAreaId(targetRoom.areaId);
                        dmAddDevicetoAreaReq.setDeviceId(device.deviceId);
                        dmAddDevicetoAreaReq.setForceAdd(true);
                        let dmAddDeviceToAreaRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddDevicetoAreaReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddDeviceToArea'));
                        if (!dmAddDeviceToAreaRsp.getSuccess()) {
                            throw new Error(dmAddDeviceToAreaRsp.getMessage());
                        }
                        await keus_device_1.default.updateDeviceRoomAndSection(device.deviceId, mvSceneWizardReq.getDeviceRoom(), mvSceneWizardReq.getDeviceSection());
                        resolve(response_1.default.getMoveRoomSuccessful());
                    }
                    else {
                        const currentRoom = await keus_home_1.default.getRoomById(device.deviceRoom);
                        const areSameArea = HomeUtils.checkRoomsInSameArea([currentRoom, targetRoom]);
                        // if (areSameArea) {
                        //     await KeusDeviceModel.updateDeviceRoomAndSection(
                        //         device.deviceId,
                        //         mvSceneWizardReq.getDeviceRoom(),
                        //         mvSceneWizardReq.getDeviceSection()
                        //     );
                        //     resolve(MoveSceneWizardRoomResponse.getMoveRoomSuccessful());
                        // } else {
                        // await zigbee add to area
                        let dmAddDevicetoAreaReq = new home_structures_pb_1.DMAddDeviceToArea();
                        dmAddDevicetoAreaReq.setAreaId(targetRoom.areaId);
                        dmAddDevicetoAreaReq.setDeviceId(device.deviceId);
                        dmAddDevicetoAreaReq.setForceAdd(true);
                        let dmAddDeviceToAreaRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddDevicetoAreaReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddDeviceToArea'));
                        if (!dmAddDeviceToAreaRsp.getSuccess()) {
                            throw new Error(dmAddDeviceToAreaRsp.getMessage());
                        }
                        switch (device.deviceType) {
                            case device_types_1.TypeMap.KZSW01:
                                const sceneWizardProps = {
                                    buttons: KZSW01_1.sceneWizardButtonList,
                                    sceneStepSize: 25
                                };
                                await keus_device_1.default.updateDeviceProperties(device.deviceId, sceneWizardProps, false);
                                break;
                        }
                        await keus_device_1.default.updateDeviceRoomAndSection(device.deviceId, targetRoom.roomId, targetSection.sectionId);
                        resolve(response_1.default.getMoveRoomSuccessful());
                        // }
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.HomeErrors.InvalidRoomId:
                        resolve(response_1.default.getTargetRoomDoesntExist());
                        break;
                    case errors_1.HomeErrors.InvalidSectionId:
                        resolve(response_1.default.getTargetSectionDoesntExist());
                        break;
                    default:
                        logInst.log('Error ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map