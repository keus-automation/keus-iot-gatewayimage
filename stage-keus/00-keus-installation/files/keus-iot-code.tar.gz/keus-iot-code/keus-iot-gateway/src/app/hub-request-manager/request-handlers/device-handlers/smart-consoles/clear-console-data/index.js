"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const errors_1 = require("../../../../../../errors/errors");
const scene_constants_1 = require("../../../../../../constants/scene/scene-constants");
const device_types_1 = require("../../../../../../constants/device/device-types");
const KZSC7C_1 = require("../../../../../../models/device-models/device-types/KZSC7C");
const KZSC4C_1 = require("../../../../../../models/device-models/device-types/KZSC4C");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Clear Console Data' });
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
exports.default = async (clearConsoleDataReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Clearing Console Data: ', clearConsoleDataReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                var clearFlag = true;
                if (!clearConsoleDataReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(clearConsoleDataReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        try {
                            //-----------------------Zigbee Call to Clear console Data--------------------------------
                            // Try zigbee call and catch for force delete
                        }
                        catch (e) {
                            if (!clearConsoleDataReq.getForceClear()) {
                                clearFlag = false;
                            }
                            else {
                                throw e;
                            }
                        }
                        if (clearFlag) {
                            var buttonProps = {};
                            var deviceProps = device.deviceProperties;
                            deviceProps.defaultFan = null;
                            deviceProps.defaultSceneId = scene_constants_1.NoSceneId;
                            deviceProps.defaultSceneRoom = null;
                            switch (device.deviceType) {
                                case device_types_1.TypeMap.KZSC7C:
                                    deviceProps.buttons = KZSC7C_1.smartConsoleSevenChannelButtonList;
                                    break;
                                case device_types_1.TypeMap.KZSC4C:
                                    deviceProps.buttons = KZSC4C_1.smartConsoleFourChannelButtonList;
                                default:
                                    deviceProps.buttons.forEach(function (button) {
                                        button.buttonType = device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_UNCONFIGURED;
                                        button.buttonProperties = buttonProps;
                                    });
                            }
                            keus_device_1.default.updateDeviceProperties(device.deviceId, deviceProps, false);
                            resolve(response_1.default.getClearDataSuccessful());
                        }
                    }
                }
            }
            catch (e) {
                switch (e) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                    case errors_1.DeviceErrors.DeviceZigbeeError:
                    //Handle Device Zigbee Error
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map