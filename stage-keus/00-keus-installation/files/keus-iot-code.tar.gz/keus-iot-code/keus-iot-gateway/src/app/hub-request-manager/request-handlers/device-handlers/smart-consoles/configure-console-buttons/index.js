"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const device_types_1 = require("../../../../../../constants/device/device-types");
const default_configuration_constants_1 = require("../../../../../../constants/device/default-configuration-constants");
const keus_group_1 = __importDefault(require("../../../../../../models/database-models/keus-group"));
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const keus_scene_1 = __importDefault(require("../../../../../../models/database-models/keus-scene"));
const HomeUtils = __importStar(require("../../../../../../utilities/gateway/home-utils"));
const errors_1 = require("../../../../../../errors/errors");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const general_1 = require("../../../../../../utilities/general");
const smart_console_pb_1 = require("../../../../../device-manager/providers/generated/devices/smart_console_pb");
const local_client_1 = require("../../../../local-client");
const device_constants_pb_2 = require("../../../../../device-manager/providers/generated/devices/device_constants_pb");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Configure Console Buttons' });
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
exports.default = async (configureConsoleButtonsReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                //------------------------Permission Check-----------------------------------
                logInst.log('Configuring Console Buttons: ', configureConsoleButtonsReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                console.log('this is user ', user);
                await home_utils_1.checkUserIsAdmin(user);
                if (!configureConsoleButtonsReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(configureConsoleButtonsReq.getDeviceId());
                    const dmConfigureConsoleButtonsReq = new smart_console_pb_1.DMConfigureConsoleButtons();
                    dmConfigureConsoleButtonsReq.setDeviceId(device.deviceId);
                    let dmButtonsList = new Array(configureConsoleButtonsReq.getButtonList().length);
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        var invalidButtonType = false;
                        var invalidButtonId = false;
                        var curtainCountExceeded = false;
                        var invalidConsoleType = false;
                        var invalidPropertySet = false;
                        var invalidDevice = false;
                        var invalidGroup = false;
                        var invalidScene = false;
                        var invalidRelayId = false;
                        const roomList = await keus_home_1.default.getRoomsInSameArea(device.deviceRoom);
                        const roomIdList = HomeUtils.getRoomIdsFromRoomList(roomList);
                        const areaGroupList = await keus_group_1.default.getGroupsByRooms(roomIdList);
                        var areaSceneList = await keus_scene_1.default.getScenesByRooms(roomIdList);
                        var areaDeviceList = await keus_device_1.default.getDevicesByRooms(roomIdList);
                        var devProps = device.deviceProperties;
                        var numButtons = devProps.buttons.length;
                        var curtainCount;
                        if (device.deviceType == device_types_1.TypeMap.KZSC4C) {
                            curtainCount = default_configuration_constants_1.SmartConsoleFourChannelCurtainCount;
                        }
                        else if (device.deviceType == device_types_1.TypeMap.KZSC7C) {
                            curtainCount = default_configuration_constants_1.SmartConsoleSevenChannelCurtainCount;
                        }
                        else {
                            invalidConsoleType = true;
                        }
                        if (invalidConsoleType) {
                            throw new errors_1.DeviceErrors.InvalidDeviceType();
                        }
                        else {
                            for (var k = 0; k < configureConsoleButtonsReq.getButtonList().length; k++) {
                                dmButtonsList[k] = new smart_console_pb_1.DMSmartConsoleButton();
                                var buttonConfig = configureConsoleButtonsReq.getButtonList()[k];
                                console.log('this is button type', buttonConfig.getButtonType());
                                if (buttonConfig.getButtonId() > numButtons) {
                                    throw new errors_1.DeviceErrors.InvalidButtonId();
                                }
                                else {
                                    switch (buttonConfig.getButtonType()) {
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_GROUP:
                                            if (buttonConfig.hasGroupButtonProperties()) {
                                                var filteredGroups = areaGroupList.filter(function (group) {
                                                    return (group.groupId ==
                                                        buttonConfig.getGroupButtonProperties().getGroupId() &&
                                                        group.groupRoom ==
                                                            buttonConfig.getGroupButtonProperties().getRoomId());
                                                });
                                                //If group exists in area
                                                if (filteredGroups.length) {
                                                    var gbuttonProperties = {
                                                        groupId: buttonConfig.getGroupButtonProperties().getGroupId(),
                                                        roomId: buttonConfig.getGroupButtonProperties().getRoomId()
                                                    };
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonType =
                                                        device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_GROUP;
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonProperties = gbuttonProperties;
                                                    //Make zigbee call for group here. Send if group is high power as well
                                                    dmButtonsList[k].setButtonId(buttonConfig.getButtonId());
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_GROUP);
                                                    let dmGroupBtnProps = new smart_console_pb_1.DMSmartConsoleGroupButtonProperties();
                                                    dmGroupBtnProps.setGroupId(gbuttonProperties.groupId);
                                                    dmGroupBtnProps.setIsHighPower(filteredGroups[0].isHighPower);
                                                    dmButtonsList[k].setGroupButtonProperties(dmGroupBtnProps);
                                                }
                                                else {
                                                    throw new errors_1.GroupErrors.InvalidGroupId();
                                                }
                                            }
                                            else {
                                                throw new errors_1.GeneralErrors.InvalidParameterSet();
                                            }
                                            break;
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_SCENE:
                                            if (buttonConfig.hasSceneButtonProperties()) {
                                                var filteredScenes = areaSceneList.filter(function (scene) {
                                                    return (scene.sceneId ==
                                                        buttonConfig.getSceneButtonProperties().getSceneId() &&
                                                        scene.sceneRoom ==
                                                            buttonConfig.getSceneButtonProperties().getRoomId());
                                                });
                                                //If scene exists in area
                                                if (filteredScenes.length) {
                                                    var sbuttonProperties = {
                                                        sceneId: buttonConfig.getSceneButtonProperties().getSceneId(),
                                                        roomId: buttonConfig.getSceneButtonProperties().getRoomId()
                                                    };
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonType =
                                                        device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_SCENE;
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonProperties = sbuttonProperties;
                                                    //Zigbee call to add scene to smart console
                                                    dmButtonsList[k].setButtonId(buttonConfig.getButtonId());
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_SCENE);
                                                    let dmSceneBtnProps = new smart_console_pb_1.DMSmartConsoleSceneButtonProperties();
                                                    dmSceneBtnProps.setSceneId(sbuttonProperties.sceneId);
                                                    dmButtonsList[k].setSceneButtonProperties(dmSceneBtnProps);
                                                }
                                                else {
                                                    throw new errors_1.SceneErrors.InvalidSceneId();
                                                }
                                            }
                                            else {
                                                throw new errors_1.GeneralErrors.InvalidParameterSet();
                                            }
                                            break;
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_FANCONTROLLER:
                                            if (buttonConfig.hasFanButtonProperties()) {
                                                var filteredFanList = areaDeviceList.filter(function (device) {
                                                    return (device.deviceId ==
                                                        buttonConfig.getFanButtonProperties().getDeviceId() &&
                                                        (device.deviceCategory ==
                                                            device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER')
                                                                .deviceCategoryCode ||
                                                            device.deviceCategory ==
                                                                device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER')
                                                                    .deviceCategoryCode));
                                                });
                                                //If fan exists
                                                if (filteredFanList.length) {
                                                    var fbuttonProperties = {
                                                        deviceId: buttonConfig.getFanButtonProperties().getDeviceId()
                                                    };
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonType =
                                                        device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_FANCONTROLLER;
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonProperties = fbuttonProperties;
                                                    devProps.defaultFan = buttonConfig
                                                        .getFanButtonProperties()
                                                        .getDeviceId();
                                                    //Zigbee call to add fan here
                                                    dmButtonsList[k].setButtonId(buttonConfig.getButtonId());
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_FANCONTROLLER);
                                                    let dmFanBtnProps = new smart_console_pb_1.DMSmartConsoleFanButtonProperties();
                                                    dmFanBtnProps.setDeviceId(fbuttonProperties.deviceId);
                                                    dmButtonsList[k].setFanButtonProperties(dmFanBtnProps);
                                                }
                                                else {
                                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                                }
                                            }
                                            else {
                                                throw new errors_1.GeneralErrors.InvalidParameterSet();
                                            }
                                            break;
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_CURTAINCONTROLLER:
                                            if (buttonConfig.hasCurtainButtonProperties()) {
                                                if (buttonConfig.getCurtainButtonProperties().getDeviceIdList().length >
                                                    curtainCount) {
                                                    throw new errors_1.DeviceErrors.CurtainCountExceeded();
                                                }
                                                else {
                                                    //Check if each curtain exists
                                                    buttonConfig
                                                        .getCurtainButtonProperties()
                                                        .getDeviceIdList()
                                                        .forEach(function (deviceId) {
                                                        var filteredCurtainList = areaDeviceList.filter(function (device) {
                                                            return (device.deviceId == deviceId &&
                                                                device.deviceCategory ==
                                                                    device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode);
                                                        });
                                                        if (!filteredCurtainList.length) {
                                                            throw new errors_1.DeviceErrors.InvalidDeviceId();
                                                        }
                                                    });
                                                    var cbuttonProperties = {
                                                        deviceIds: buttonConfig
                                                            .getCurtainButtonProperties()
                                                            .getDeviceIdList()
                                                    };
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonType =
                                                        device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_CURTAINCONTROLLER;
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonProperties = cbuttonProperties;
                                                    //Zigbee call to add curtain here
                                                    dmButtonsList[k].setButtonId(buttonConfig.getButtonId());
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_CURTAINCONTROLLER);
                                                    let dmCurtainBtnProps = new smart_console_pb_1.DMSmartConsoleCurtainButtonProperties();
                                                    dmCurtainBtnProps.setDeviceIdList(cbuttonProperties.deviceIds);
                                                    dmButtonsList[k].setCurtainButtonProperties(dmCurtainBtnProps);
                                                }
                                            }
                                            else {
                                                throw new errors_1.GeneralErrors.InvalidParameterSet();
                                            }
                                            break;
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_RELAYCONTROLLER:
                                            if (buttonConfig.hasRelayButtonProperties()) {
                                                if (buttonConfig.getRelayButtonProperties().getRelayId() >
                                                    devProps.relays.length - 1) {
                                                    throw new errors_1.DeviceErrors.InvalidRelayId();
                                                }
                                                else {
                                                    var rbuttonProperties = {
                                                        relayId: buttonConfig.getRelayButtonProperties().getRelayId()
                                                    };
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonType =
                                                        device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_RELAYCONTROLLER;
                                                    devProps.buttons[buttonConfig.getButtonId()].buttonProperties = rbuttonProperties;
                                                    //Zigbee call to add relay here
                                                    dmButtonsList[k].setButtonId(buttonConfig.getButtonId());
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_RELAYCONTROLLER);
                                                    let dmRelayBtnProps = new smart_console_pb_1.DMSmartConsoleRelayButtonProperties();
                                                    dmRelayBtnProps.setRelayId(rbuttonProperties.relayId);
                                                    dmRelayBtnProps.setIsHighPower(devProps.relays[rbuttonProperties.relayId].isHighPower);
                                                    dmButtonsList[k].setRelayButtonProperties(dmRelayBtnProps);
                                                }
                                            }
                                            else {
                                                throw new errors_1.GeneralErrors.InvalidParameterSet();
                                            }
                                            break;
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_REMOTERELAY:
                                            if (buttonConfig.hasRemoteRelayButtonProperties()) {
                                                const remoteDevice = await keus_device_1.default.getDeviceById(buttonConfig.getRemoteRelayButtonProperties().getDeviceId());
                                                if (!remoteDevice) {
                                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                                }
                                                else if (remoteDevice.deviceCategory !=
                                                    device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE')
                                                        .deviceCategoryCode) {
                                                    throw new errors_1.DeviceErrors.InvalidDeviceType();
                                                }
                                                else {
                                                    const remoteDevProps = (remoteDevice.deviceProperties);
                                                    console.log('this is relay id ', buttonConfig.getRemoteRelayButtonProperties().getRelayId());
                                                    if (buttonConfig.getRemoteRelayButtonProperties().getRelayId() >
                                                        remoteDevProps.relays.length - 1) {
                                                        throw new errors_1.DeviceErrors.InvalidRelayId();
                                                    }
                                                    else {
                                                        const remoteRelayButtons = remoteDevProps.buttons.filter(function (button) {
                                                            if (button.buttonType ==
                                                                device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_RELAYCONTROLLER) {
                                                                const remoteRelayBtnProps = button.buttonProperties;
                                                                return (remoteRelayBtnProps.relayId ==
                                                                    buttonConfig
                                                                        .getRemoteRelayButtonProperties()
                                                                        .getRelayId());
                                                            }
                                                            return false;
                                                        });
                                                        if (!remoteRelayButtons.length) {
                                                            throw new errors_1.DeviceErrors.RelayNotBound();
                                                        }
                                                        else {
                                                            var rrbuttonProperties = {
                                                                deviceId: remoteDevice.deviceId,
                                                                relayId: buttonConfig
                                                                    .getRemoteRelayButtonProperties()
                                                                    .getRelayId()
                                                            };
                                                            devProps.buttons[buttonConfig.getButtonId()].buttonType =
                                                                device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_REMOTERELAY;
                                                            devProps.buttons[buttonConfig.getButtonId()].buttonProperties = rrbuttonProperties;
                                                            //Zigbee call to add remote relay here
                                                            dmButtonsList[k].setButtonId(buttonConfig.getButtonId());
                                                            dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_REMOTERELAY);
                                                            let dmRemoteRelayBtnProps = new smart_console_pb_1.DMSmartConsoleRemoteRelayButtonProperties();
                                                            dmRemoteRelayBtnProps.setDeviceId(remoteDevice.deviceId);
                                                            dmRemoteRelayBtnProps.setRelayId(rrbuttonProperties.relayId);
                                                            dmRemoteRelayBtnProps.setIsHighPower(remoteDevProps.relays[rrbuttonProperties.relayId]
                                                                .isHighPower);
                                                            dmButtonsList[k].setRemRelayButtonProperties(dmRemoteRelayBtnProps);
                                                        }
                                                    }
                                                }
                                            }
                                            else {
                                                throw new errors_1.GeneralErrors.InvalidParameterSet();
                                            }
                                            break;
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_INC:
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_DEC:
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_LIGHTINC:
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_LIGHTDEC:
                                        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_UNCONFIGURED:
                                            devProps.buttons[buttonConfig.getButtonId()].buttonType = buttonConfig.getButtonType();
                                            var nButtonProperties = {};
                                            devProps.buttons[buttonConfig.getButtonId()].buttonProperties = nButtonProperties;
                                            dmButtonsList[k].setButtonId(buttonConfig.getButtonId());
                                            switch (buttonConfig.getButtonType()) {
                                                case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_INC:
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_INC);
                                                    break;
                                                case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_DEC:
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_DEC);
                                                    break;
                                                case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_LIGHTINC:
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_LIGHTINC);
                                                    break;
                                                case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_LIGHTDEC:
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_LIGHTDEC);
                                                    break;
                                                case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_UNCONFIGURED:
                                                    dmButtonsList[k].setButtonType(device_constants_pb_2.DMSMART_CONSOLE_BUTTON_TYPES.SC_UNCONFIGURED);
                                                    break;
                                            }
                                            break;
                                        default:
                                            throw new errors_1.DeviceErrors.InvalidButtonType();
                                    }
                                }
                            }
                            dmConfigureConsoleButtonsReq.setButtonList(dmButtonsList);
                            const anyObj = general_1.PackIntoAny(dmConfigureConsoleButtonsReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMConfigureConsoleButtons');
                            console.log("--------------this is before zigbee call");
                            let dmConfigureConsoleButtonsRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, anyObj);
                            console.log("--------------this is after zigbee call");
                            if (!dmConfigureConsoleButtonsRsp.getSuccess()) {
                                throw new Error('Failed to configure buttons');
                            }
                            await keus_device_1.default.updateDeviceProperties(device.deviceId, devProps, true);
                            resolve(response_1.default.getConfigureSuccessful());
                        }
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidButtonId:
                        resolve(response_1.default.getInvalidButtonId());
                        break;
                    case errors_1.DeviceErrors.InvalidRelayId:
                        resolve(response_1.default.getInvalidRelayId());
                        break;
                    case errors_1.DeviceErrors.RelayNotBound:
                        resolve(response_1.default.getRelayNotBound());
                        break;
                    case errors_1.DeviceErrors.InvalidButtonType:
                        resolve(response_1.default.getInvalidButtonType());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDevice());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.DeviceErrors.CurtainCountExceeded:
                        resolve(response_1.default.getCurtainCountExceeded());
                        break;
                    case errors_1.GeneralErrors.InvalidParameterSet:
                        resolve(response_1.default.getInvalidPropertySet());
                        break;
                    case errors_1.GroupErrors.InvalidGroupId:
                        resolve(response_1.default.getInvalidGroup());
                        break;
                    case errors_1.SceneErrors.InvalidSceneId:
                        resolve(response_1.default.getInvalidScene());
                        break;
                    case errors_1.DeviceErrors.DeviceZigbeeError:
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map