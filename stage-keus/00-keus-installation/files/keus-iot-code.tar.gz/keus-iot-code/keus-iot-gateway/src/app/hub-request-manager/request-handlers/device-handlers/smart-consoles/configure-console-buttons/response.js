"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const smart_console_pb_1 = require("../../../../protos/generated/hub/devices/smart_console_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class ConfigureConsoleButtons {
    static getConfigureSuccessful() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(800);
        resp.setMessage('Configure Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(801);
        resp.setMessage('Invalid device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInvalidButtonId() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(803);
        resp.setMessage('Invalid button id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInvalidButtonType() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(804);
        resp.setMessage('Invalid button type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInvalidPropertySet() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(805);
        resp.setMessage('Invalid property set');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getCurtainCountExceeded() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(806);
        resp.setMessage('Curtain count exceeded');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInvalidGroup() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(807);
        resp.setMessage('Invalid group');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInvalidScene() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(808);
        resp.setMessage('Invalid scene');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInvalidDevice() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(809);
        resp.setMessage('Invalid device');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInvalidRelayId() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(810);
        resp.setMessage('Invalid relay id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getRelayNotBound() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(811);
        resp.setMessage('Relay Not Bound to Button');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInternalServerError() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getUserNotAdmin() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(812);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new smart_console_pb_1.ConfigureConsoleButtonsResponse();
        resp.setCode(813);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureConsoleButtons.responseType);
    }
}
exports.default = ConfigureConsoleButtons;
ConfigureConsoleButtons.responseType = system_constants_1.ProtoPackageName + '.ConfigureConsoleButtonsResponse';
//# sourceMappingURL=response.js.map