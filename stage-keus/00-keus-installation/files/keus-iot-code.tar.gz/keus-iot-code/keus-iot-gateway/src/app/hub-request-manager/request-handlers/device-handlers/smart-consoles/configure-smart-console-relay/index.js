"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const errors_1 = require("../../../../../../errors/errors");
const device_types_1 = require("../../../../../../constants/device/device-types");
const default_configuration_constants_1 = require("../../../../../../constants/device/default-configuration-constants");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Configure Smart Console Relay' });
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
exports.default = async (configSmartConsoleRelayReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Configuring Smart Console Relay: ', configSmartConsoleRelayReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!configSmartConsoleRelayReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(configSmartConsoleRelayReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        const deviceProperties = device.deviceProperties;
                        if (configSmartConsoleRelayReq.getRelayId() > deviceProperties.relays.length - 1) {
                            throw new errors_1.DeviceErrors.InvalidRelayId();
                        }
                        else {
                            var relayId = configSmartConsoleRelayReq.getRelayId();
                            deviceProperties.relays[relayId].applianceType = configSmartConsoleRelayReq.getApplianceType();
                            deviceProperties.relays[relayId].relayName = configSmartConsoleRelayReq.getRelayName();
                            if (configSmartConsoleRelayReq.getIsHighPower()) {
                                if ((device.deviceType == device_types_1.TypeMap.KZSC7C &&
                                    default_configuration_constants_1.SmartConsoleSevenChannelHighPowerRelays.indexOf(relayId) < 0) ||
                                    (device.deviceType == device_types_1.TypeMap.KZSC4C &&
                                        default_configuration_constants_1.SmartConsoleFourChannelHighPowerRelays.indexOf(relayId) < 0)) {
                                    throw new errors_1.DeviceErrors.RelayCannotBeHighLoad();
                                }
                            }
                            deviceProperties.relays[relayId].isHighPower = configSmartConsoleRelayReq.getIsHighPower();
                            //Scene part skipped for now
                            device.deviceProperties = deviceProperties;
                            keus_device_1.default.updateDeviceProperties(device.deviceId, deviceProperties, true);
                            resolve(response_1.default.getConfigureSmartConsoleRelaySuccessful());
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.DeviceErrors.InvalidRelayId:
                        resolve(response_1.default.getInvalidRelayId());
                        break;
                    case errors_1.DeviceErrors.RelayCannotBeHighLoad:
                        resolve(response_1.default.getRelayCannotBeHighLoad());
                        break;
                    default:
                        logInst.log('Error ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map