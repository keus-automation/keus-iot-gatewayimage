"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const errors_1 = require("../../../../../../errors/errors");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const HomeUtils = __importStar(require("../../../../../../utilities/gateway/home-utils"));
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Configure Smart Console' });
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const smart_console_pb_1 = require("../../../../../device-manager/providers/generated/devices/smart_console_pb");
const local_client_1 = require("../../../../local-client");
const general_1 = require("../../../../../../utilities/general");
exports.default = async (configSmartConsoleReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Configuring Smart Console: ', configSmartConsoleReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!configSmartConsoleReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(configSmartConsoleReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        device.deviceName = configSmartConsoleReq.getDeviceName()
                            ? configSmartConsoleReq.getDeviceName()
                            : device.deviceName;
                        device.deviceLocation = configSmartConsoleReq.getDeviceLocation()
                            ? configSmartConsoleReq.getDeviceLocation()
                            : device.deviceLocation;
                        var deviceProps = device.deviceProperties;
                        const fanDevice = await keus_device_1.default.getDeviceById(configSmartConsoleReq.getDefaultFan());
                        if (fanDevice) {
                            if (fanDevice.deviceCategory !=
                                device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceCategoryCode &&
                                fanDevice.deviceCategory !=
                                    device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER').deviceCategoryCode) {
                                throw new errors_1.DeviceErrors.InvalidDeviceType();
                            }
                            else {
                                var deviceRooms = await keus_home_1.default.getAllRooms();
                                deviceRooms = deviceRooms.filter(function (room) {
                                    return room.roomId == device.deviceRoom || room.roomId == fanDevice.deviceRoom;
                                });
                                const sameAreaCheck = HomeUtils.checkRoomsInSameArea(deviceRooms);
                                if (!sameAreaCheck) {
                                    throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                }
                            }
                        }
                        deviceProps.defaultFan = configSmartConsoleReq.getDefaultFan();
                        deviceProps.sceneStepSize = configSmartConsoleReq.getSceneStepSize();
                        if (deviceProps.defaultFan) {
                            // zigbee call to configure
                            let dmConfigureSmartConsoleReq = new smart_console_pb_1.DMConfigureSmartConsole();
                            dmConfigureSmartConsoleReq.setDeviceId(device.deviceId);
                            dmConfigureSmartConsoleReq.setDefaultFan(deviceProps.defaultFan);
                            dmConfigureSmartConsoleReq.setSceneStepSize(25);
                            let dmConfigureSmartConsoleRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmConfigureSmartConsoleReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMConfigureSmartConsole'));
                            console.log("This is rsp", dmConfigureSmartConsoleRsp);
                            if (!dmConfigureSmartConsoleRsp.getSuccess()) {
                                throw new Error(dmConfigureSmartConsoleRsp.getMessage());
                            }
                        }
                        //Scene part skipped for now
                        device.deviceProperties = deviceProps;
                        keus_device_1.default.updateDevice(device.deviceId, device);
                        resolve(response_1.default.getConfigureSmartConsoleSuccessful());
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.DeviceErrors.DeviceNotInSameArea:
                        resolve(response_1.default.getDeviceNotInSameArea());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map