"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const smart_console_pb_1 = require("../../../../protos/generated/hub/devices/smart_console_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class DaliSetRestoreLastLevel {
    static getDaliSetRestoreLastLevelSuccessful() {
        const resp = new smart_console_pb_1.DaliSetRestoreLastLevelResponse();
        resp.setCode(800);
        resp.setMessage('Dali Set Restore Level Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), DaliSetRestoreLastLevel.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new smart_console_pb_1.DaliSetRestoreLastLevelResponse();
        resp.setCode(801);
        resp.setMessage('Invalid device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DaliSetRestoreLastLevel.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new smart_console_pb_1.DaliSetRestoreLastLevelResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DaliSetRestoreLastLevel.responseType);
    }
    static getInternalServerError() {
        const resp = new smart_console_pb_1.DaliSetRestoreLastLevelResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), DaliSetRestoreLastLevel.responseType);
    }
    static getUserNotAdmin() {
        const resp = new smart_console_pb_1.DaliSetRestoreLastLevelResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DaliSetRestoreLastLevel.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new smart_console_pb_1.DaliSetRestoreLastLevelResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DaliSetRestoreLastLevel.responseType);
    }
}
exports.default = DaliSetRestoreLastLevel;
DaliSetRestoreLastLevel.responseType = system_constants_1.ProtoPackageName + '.DaliSetRestoreLastLevelResponse';
//# sourceMappingURL=response.js.map