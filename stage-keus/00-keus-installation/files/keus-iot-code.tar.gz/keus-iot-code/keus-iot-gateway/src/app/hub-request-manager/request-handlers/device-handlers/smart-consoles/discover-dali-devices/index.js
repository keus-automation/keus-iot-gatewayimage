"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const smart_console_pb_1 = require("../../../../../device-manager/providers/generated/devices/smart_console_pb");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const errors_1 = require("../../../../../../errors/errors");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const local_client_1 = require("../../../../local-client");
const general_1 = require("../../../../../../utilities/general");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Discover Dali Devices' });
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_group_1 = __importDefault(require("../../../../../../models/database-models/keus-group"));
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
exports.default = async (discoverDaliDevicesReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Discovering Dali Devices: ', discoverDaliDevicesReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!discoverDaliDevicesReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(discoverDaliDevicesReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        //If additive install
                        const discoverReq = new smart_console_pb_1.DMDiscoverDaliDevices();
                        discoverReq.setDeviceId(device.deviceId);
                        console.log('daliDiscoveryType', discoverDaliDevicesReq.getDiscoveryType());
                        discoverReq.setDiscoveryType(discoverDaliDevicesReq.getDiscoveryType());
                        const anyObj = general_1.PackIntoAny(discoverReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMDiscoverDaliDevices');
                        if (discoverDaliDevicesReq.getDiscoveryType() !== device_constants_pb_1.SMART_CONSOLE_DALI_DISCOVERY_TYPES.SC_FRESH_DISCOVERY) {
                            console.log('Hitting discovery');
                            await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, anyObj);
                            resolve(response_1.default.getDiscoverDaliDevicesSuccessful());
                        }
                        //If removing as dali master -> Handle Case
                        else {
                            console.log('Hitting fresh discovery');
                            const currentDriverList = await keus_device_1.default.getDevicesByParent(device.deviceId);
                            const driverIdList = home_utils_1.getDeviceIdsFromDeviceList(currentDriverList);
                            await keus_device_1.default.cleanDrivers(driverIdList);
                            await keus_group_1.default.cleanDriverGroups(driverIdList);
                            await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, anyObj);
                            resolve(response_1.default.getDiscoverDaliDevicesSuccessful());
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        logInst.log('Error ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map