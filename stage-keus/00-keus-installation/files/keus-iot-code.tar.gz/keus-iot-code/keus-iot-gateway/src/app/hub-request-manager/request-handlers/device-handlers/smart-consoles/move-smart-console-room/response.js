"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const smart_console_pb_1 = require("../../../../protos/generated/hub/devices/smart_console_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class MoveSmartConsoleRoomResp {
    static getMoveRoomSuccessful() {
        const resp = new smart_console_pb_1.MoveSmartConsoleRoomResponse();
        resp.setCode(800);
        resp.setMessage('Move Room Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveSmartConsoleRoomResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new smart_console_pb_1.MoveSmartConsoleRoomResponse();
        resp.setCode(801);
        resp.setMessage('Invalid DeviceId');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveSmartConsoleRoomResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new smart_console_pb_1.MoveSmartConsoleRoomResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveSmartConsoleRoomResp.responseType);
    }
    static getTargetRoomDoesntExist() {
        const resp = new smart_console_pb_1.MoveSmartConsoleRoomResponse();
        resp.setCode(803);
        resp.setMessage('Target Room Doesnt Exist');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveSmartConsoleRoomResp.responseType);
    }
    static getTargetSectionDoesntExist() {
        const resp = new smart_console_pb_1.MoveSmartConsoleRoomResponse();
        resp.setCode(803);
        resp.setMessage('Target Section Doesnt Exist');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveSmartConsoleRoomResp.responseType);
    }
    static getInternalServerError() {
        const resp = new smart_console_pb_1.MoveSmartConsoleRoomResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveSmartConsoleRoomResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new smart_console_pb_1.MoveSmartConsoleRoomResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveSmartConsoleRoomResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new smart_console_pb_1.MoveSmartConsoleRoomResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), MoveSmartConsoleRoomResp.responseType);
    }
}
exports.default = MoveSmartConsoleRoomResp;
MoveSmartConsoleRoomResp.responseType = system_constants_1.ProtoPackageName + '.MoveSmartConsoleRoomResponse';
//# sourceMappingURL=response.js.map