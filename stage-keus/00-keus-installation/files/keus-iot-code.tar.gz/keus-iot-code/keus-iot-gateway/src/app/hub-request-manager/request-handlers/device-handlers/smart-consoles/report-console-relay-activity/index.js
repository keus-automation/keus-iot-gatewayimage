"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const smart_console_pb_1 = require("../../../../protos/generated/hub/devices/smart_console_pb");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const errors_1 = require("../../../../../../errors/errors");
const local_client_1 = require("../../../../local-client");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const cloud_client_1 = require("../../../../cloud-client");
const eventType = system_constants_1.ProtoPackageName + '.ConsoleRelayEvent';
exports.default = async (reportConsoleRelayStateReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                if (!reportConsoleRelayStateReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(reportConsoleRelayStateReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        var deviceProps = device.deviceProperties;
                        if (reportConsoleRelayStateReq.getRelayId() < deviceProps.relays.length) {
                            //Add activity
                            deviceProps.relays[reportConsoleRelayStateReq.getRelayId()].relayState = reportConsoleRelayStateReq.getRelayState();
                            deviceProps.relays[reportConsoleRelayStateReq.getRelayId()].lastUpdateBy = phone;
                            deviceProps.relays[reportConsoleRelayStateReq.getRelayId()].lastUpdateSource = system_constants_1.UpdateSourceMapping.MANUAL;
                            deviceProps.relays[reportConsoleRelayStateReq.getRelayId()].lastUpdateUser = system_constants_1.SystemUser;
                            deviceProps.relays[reportConsoleRelayStateReq.getRelayId()].lastUpdateTime = reportConsoleRelayStateReq.getActivityTime();
                            await keus_device_1.default.updateDeviceProperties(device.deviceId, deviceProps, device.isConfigured);
                            //Events
                            console.log('Throwing Relay Event');
                            const scRelayEvent = new smart_console_pb_1.ConsoleRelayEvent();
                            const consoleRelayState = new smart_console_pb_1.SetConsoleRelayState();
                            consoleRelayState.setDeviceId(reportConsoleRelayStateReq.getDeviceId());
                            consoleRelayState.setRelayId(reportConsoleRelayStateReq.getRelayId());
                            consoleRelayState.setRelayState(reportConsoleRelayStateReq.getRelayState());
                            scRelayEvent.setUpdateState(consoleRelayState);
                            scRelayEvent.setActivitySource(system_constants_1.UpdateSourceMapping.MANUAL);
                            scRelayEvent.setActivityUser(phone);
                            scRelayEvent.setActivityTime(deviceProps.relays[reportConsoleRelayStateReq.getRelayId()].lastUpdateTime);
                            const eventArg = general_1.PackIntoAny(scRelayEvent.serializeBinary(), eventType);
                            local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                            cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                            resolve(response_1.default.getSetStateSuccessful());
                        }
                        else {
                            throw new errors_1.DeviceErrors.InvalidRelayId();
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.DeviceErrors.InvalidRelayId:
                        resolve(response_1.default.getInvalidRelayId());
                        break;
                    case errors_1.DeviceErrors.DeviceZigbeeError:
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map