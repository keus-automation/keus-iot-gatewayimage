"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const errors_1 = require("../../../../../../errors/errors");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_2 = require("../../../../../../utilities/gateway/home-utils");
const home_structures_pb_1 = require("../../../../../device-manager/providers/generated/home/home_structures_pb");
const local_client_1 = require("../../../../local-client");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
exports.default = async (setAreaMasterReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_2.checkUserIsAdmin(user);
                if (!setAreaMasterReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(setAreaMasterReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        //If setting as master
                        if (setAreaMasterReq.getIsAreaMaster()) {
                            var masterExists = false;
                            const roomList = await keus_home_1.default.getRoomsInSameArea(device.deviceRoom);
                            const roomIdsList = await home_utils_1.getRoomIdsFromRoomList(roomList);
                            var deviceList = await keus_device_1.default.getAllDevices();
                            let areaServerDeviceId = null;
                            deviceList = deviceList.filter(function (altDevice) {
                                return (altDevice.deviceCategory ==
                                    device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode &&
                                    altDevice.deviceId != device.deviceId &&
                                    roomIdsList.indexOf(altDevice.deviceRoom) >= 0);
                            });
                            deviceList.forEach(function (scDevice) {
                                var devProps = scDevice.deviceProperties;
                                if (devProps.isAreaMaster) {
                                    masterExists = true;
                                    areaServerDeviceId = scDevice.deviceId;
                                }
                            });
                            if (masterExists && (areaServerDeviceId !== device.deviceId)) {
                                throw new errors_1.HomeErrors.MasterExistsInArea();
                            }
                            else {
                                const targetRoom = await keus_home_1.default.getRoomById(device.deviceRoom);
                                let dmSetAreaServerReq = new home_structures_pb_1.DMSetAreaServer();
                                dmSetAreaServerReq.setDeviceId(device.deviceId);
                                dmSetAreaServerReq.setIsAreaServer(setAreaMasterReq.getIsAreaMaster());
                                dmSetAreaServerReq.setAreaId(targetRoom.areaId);
                                let dmSetAreaServerRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmSetAreaServerReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMSetAreaServer'));
                                console.log('This is rsp', dmSetAreaServerRsp);
                                if (!dmSetAreaServerRsp.getSuccess()) {
                                    throw new Error(dmSetAreaServerRsp.getMessage());
                                }
                                var deviceProperties = device.deviceProperties;
                                deviceProperties.isAreaMaster = true;
                                device.deviceProperties = deviceProperties;
                                await keus_device_1.default.updateDeviceProperties(device.deviceId, device.deviceProperties, device.isConfigured);
                                resolve(response_1.default.getSetAreaMasterSuccessful());
                            }
                        }
                        //If removing as area master -> Handle Case
                        else {
                            const targetRoom = await keus_home_1.default.getRoomById(device.deviceRoom);
                            let dmSetAreaServerReq = new home_structures_pb_1.DMSetAreaServer();
                            dmSetAreaServerReq.setDeviceId(device.deviceId);
                            dmSetAreaServerReq.setIsAreaServer(false);
                            dmSetAreaServerReq.setAreaId(targetRoom.areaId);
                            let dmSetAreaServerRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmSetAreaServerReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMSetAreaServer'));
                            console.log('This is rsp', dmSetAreaServerRsp);
                            if (!dmSetAreaServerRsp.getSuccess()) {
                                throw new Error(dmSetAreaServerRsp.getMessage());
                            }
                            var deviceProperties = device.deviceProperties;
                            deviceProperties.isAreaMaster = false;
                            device.deviceProperties = deviceProperties;
                            await keus_device_1.default.updateDeviceProperties(device.deviceId, device.deviceProperties, device.isConfigured);
                            resolve(response_1.default.getSetAreaMasterSuccessful());
                        }
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.HomeErrors.MasterExistsInArea:
                        resolve(response_1.default.getMasterExistsInArea());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map