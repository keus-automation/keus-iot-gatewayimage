"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const smart_console_pb_1 = require("../../../../protos/generated/hub/devices/smart_console_pb");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const errors_1 = require("../../../../../../errors/errors");
const smart_console_pb_2 = require("../../../../../device-manager/providers/generated/devices/smart_console_pb");
const local_client_1 = require("../../../../local-client");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const cloud_client_1 = require("../../../../cloud-client");
const eventType = system_constants_1.ProtoPackageName + '.ConsoleRelayEvent';
exports.default = async (setConsoleRelayStateReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                if (!setConsoleRelayStateReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(setConsoleRelayStateReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        await home_utils_1.checkAccessForUser(user, device.deviceRoom);
                        var deviceProps = device.deviceProperties;
                        if (setConsoleRelayStateReq.getRelayId() < deviceProps.relays.length) {
                            //----------------------------------------Zigbee call to turn on relay-----------------------------------
                            let dmSetConsoleRelayStateReq = new smart_console_pb_2.DMSetConsoleRelayState();
                            dmSetConsoleRelayStateReq.setDeviceId(device.deviceId);
                            dmSetConsoleRelayStateReq.setRelayId(setConsoleRelayStateReq.getRelayId());
                            dmSetConsoleRelayStateReq.setRelayState(setConsoleRelayStateReq.getRelayState());
                            let dmSetConsoleRelayStateRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmSetConsoleRelayStateReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMSetConsoleRelayState'));
                            console.log('This is rsp', dmSetConsoleRelayStateRsp);
                            if (!dmSetConsoleRelayStateRsp.getSuccess()) {
                                throw new Error(dmSetConsoleRelayStateRsp.getMessage());
                            }
                            //Add activity
                            deviceProps.relays[setConsoleRelayStateReq.getRelayId()].relayState = setConsoleRelayStateReq.getRelayState();
                            deviceProps.relays[setConsoleRelayStateReq.getRelayId()].lastUpdateBy = phone;
                            deviceProps.relays[setConsoleRelayStateReq.getRelayId()].lastUpdateSource = system_constants_1.UpdateSourceMapping.ANDROID;
                            deviceProps.relays[setConsoleRelayStateReq.getRelayId()].lastUpdateUser = user.userName;
                            deviceProps.relays[setConsoleRelayStateReq.getRelayId()].lastUpdateTime = Date.now();
                            await keus_device_1.default.updateDeviceProperties(device.deviceId, deviceProps, device.isConfigured);
                            //Events
                            const scRelayEvent = new smart_console_pb_1.ConsoleRelayEvent();
                            scRelayEvent.setUpdateState(setConsoleRelayStateReq);
                            scRelayEvent.setActivitySource(system_constants_1.UpdateSourceMapping.ANDROID);
                            scRelayEvent.setActivityUser(phone);
                            scRelayEvent.setActivityTime(deviceProps.relays[setConsoleRelayStateReq.getRelayId()].lastUpdateTime);
                            const eventArg = general_1.PackIntoAny(scRelayEvent.serializeBinary(), eventType);
                            local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                            cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                            resolve(response_1.default.getSetStateSuccessful());
                        }
                        else {
                            throw new errors_1.DeviceErrors.InvalidRelayId();
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.DeviceErrors.InvalidRelayId:
                        resolve(response_1.default.getInvalidRelayId());
                        break;
                    case errors_1.DeviceErrors.DeviceZigbeeError:
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map