"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const errors_1 = require("../../../../../../errors/errors");
const logger_service_1 = __importDefault(require("../../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Sync Scene UI Data' });
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const device_constants_pb_2 = require("../../../../../device-manager/providers/generated/devices/device_constants_pb");
const smart_console_pb_1 = require("../../../../../device-manager/providers/generated/devices/smart_console_pb");
const local_client_1 = require("../../../../local-client");
const general_1 = require("../../../../../../utilities/general");
const keus_gateway_1 = __importDefault(require("../../../../../../models/database-models/keus-gateway"));
exports.default = async (syncSceneUIDataReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Syncing Scene UI Data: ', syncSceneUIDataReq.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!syncSceneUIDataReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(syncSceneUIDataReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        //-----------------------Zigbee Call to Sync Scene UI Data--------------------------------
                        const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                        let dmUpdateSmartConsoleSceneUIReq = new smart_console_pb_1.DMUpdateSmartConsoleSceneUI();
                        dmUpdateSmartConsoleSceneUIReq.setUpdatetype(device_constants_pb_2.DMSMART_CONSOLE_SCENE_UI_UPDATE_TYPE.ALL_SCENES);
                        dmUpdateSmartConsoleSceneUIReq.setDeviceId(device.deviceId);
                        dmUpdateSmartConsoleSceneUIReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                        let dmUpdateSmartConsoleSceneUIRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmUpdateSmartConsoleSceneUIReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMUpdateSmartConsoleSceneUI'));
                        console.log("This is rsp", dmUpdateSmartConsoleSceneUIRsp);
                        if (!dmUpdateSmartConsoleSceneUIRsp.getSuccess()) {
                            throw new Error(dmUpdateSmartConsoleSceneUIRsp.getMessage());
                        }
                        const reqId = dmUpdateSmartConsoleSceneUIRsp.getRequestId();
                        const devSyncInfo = {
                            syncRequestId: reqId,
                            syncRequestParams: {},
                            syncRequestTime: Date.now(),
                            syncRequestType: device_constants_pb_1.DEVICE_JOB_TYPES.DEVICE_SYNCSCENEUI,
                            syncStatus: device_constants_pb_1.DEVICE_SYNC_STATES.DEVICESYNCPENDING
                        };
                        await keus_device_1.default.updateDeviceSyncInfo(device.deviceId, devSyncInfo);
                        resolve(response_1.default.getSyncSceneUIDataQueued(reqId));
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        logInst.log('Error ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map