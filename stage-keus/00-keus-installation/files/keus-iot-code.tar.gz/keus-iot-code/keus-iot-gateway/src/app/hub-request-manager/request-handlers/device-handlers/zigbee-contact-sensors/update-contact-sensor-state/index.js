"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const keus_activity_1 = __importDefault(require("../../../../../../models/database-models/keus-activity"));
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const activity_utils_1 = require("../../../../../../utilities/gateway/activity-utils");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
exports.default = async (updateStateData) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                const deviceObj = await keus_device_1.default.getDeviceById(updateStateData.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(system_constants_1.SystemNumber);
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_INWALL_FAN_CONTROLLER').deviceTypesList;
                if (!deviceObj) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                if (arrayList.indexOf(deviceObj.deviceType) < 0) {
                    throw new errors_1.DeviceErrors.InvalidDeviceType();
                }
                else {
                    let deviceState = deviceObj.deviceState;
                    deviceState.deviceState = updateStateData.getDeviceState();
                    deviceObj.lastUpdateBy = 'manual'; //need to be done
                    deviceObj.lastUpdateSource = 'manual'; //need to be done
                    deviceObj.lastUpdateTime = Date.now();
                    deviceObj.deviceState = deviceState;
                    await keus_device_1.default.updateDevice(deviceObj.deviceId, deviceObj);
                    let roomDetails = await keus_home_1.default.getRoomById(deviceObj.deviceRoom);
                    let activityObj = await activity_utils_1.getDeviceActivityObj(user, deviceObj, roomDetails, updateStateData, {
                        activitySource: system_constants_1.UpdateSourceMapping.SYSTEM
                    });
                    await keus_activity_1.default.insertActivity(activityObj);
                    resolve(response_1.default.getUpdateSuccessful());
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getDeviceNotFound());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map