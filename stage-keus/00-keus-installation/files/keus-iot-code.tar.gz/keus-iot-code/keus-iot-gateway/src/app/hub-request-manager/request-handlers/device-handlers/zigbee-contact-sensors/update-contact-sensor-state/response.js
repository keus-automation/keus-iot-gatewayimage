"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_contact_sensor_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_contact_sensor_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class UpdateZigbeeContactSensorStateResp {
    static getUpdateSuccessful() {
        const resp = new zigbee_contact_sensor_pb_1.UpdateZigbeeContactSensorStateResponse();
        resp.setCode(800);
        resp.setMessage('update fan state success');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeContactSensorStateResp.responseType);
    }
    static getDeviceNotFound() {
        const resp = new zigbee_contact_sensor_pb_1.UpdateZigbeeContactSensorStateResponse();
        resp.setCode(801);
        resp.setMessage('Device not found');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeContactSensorStateResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_contact_sensor_pb_1.UpdateZigbeeContactSensorStateResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeContactSensorStateResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_contact_sensor_pb_1.UpdateZigbeeContactSensorStateResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeContactSensorStateResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_contact_sensor_pb_1.UpdateZigbeeContactSensorStateResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeContactSensorStateResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_contact_sensor_pb_1.UpdateZigbeeContactSensorStateResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeContactSensorStateResp.responseType);
    }
}
exports.default = UpdateZigbeeContactSensorStateResp;
UpdateZigbeeContactSensorStateResp.responseType = system_constants_1.ProtoPackageName + '.UpdateZigbeeContactSensorStateResponse';
//# sourceMappingURL=response.js.map