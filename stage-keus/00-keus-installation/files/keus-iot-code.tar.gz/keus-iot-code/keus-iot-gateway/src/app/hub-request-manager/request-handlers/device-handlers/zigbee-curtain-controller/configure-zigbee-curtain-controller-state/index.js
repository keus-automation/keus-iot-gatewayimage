"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const zigbee_curtain_controller_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_curtain_controller_pb");
const local_client_1 = require("../../../../local-client");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
exports.default = async (configureZCCReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!configureZCCReq.getDeviceId()) {
                    resolve(response_1.default.getInvalidDeviceId());
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(configureZCCReq.getDeviceId());
                    if (!device) {
                        resolve(response_1.default.getInvalidDeviceId());
                    }
                    else if (device.deviceCategory !=
                        device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode) {
                        resolve(response_1.default.getInvalidDeviceType());
                    }
                    else {
                        //-----------------------Zigbee Call to Configure Curtain--------------------------------
                        let curtainConfigUpdate = new zigbee_curtain_controller_pb_1.DMConfigureZigbeeCurtainController();
                        curtainConfigUpdate.setDeviceId(device.deviceId);
                        curtainConfigUpdate.setInvertAction(configureZCCReq.getInvertSignal());
                        curtainConfigUpdate.setMotorCalibrationTime(configureZCCReq.getMotorCalibrationTime());
                        curtainConfigUpdate.setRfremoteEnabled(true);
                        curtainConfigUpdate.setActionTriggerTime(20);
                        let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(curtainConfigUpdate.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMConfigureZigbeeCurtainController'));
                        if (!res.getSuccess()) {
                            throw new Error('Error configuring curtain ');
                        }
                        let deviceProperties = device.deviceProperties;
                        deviceProperties.actionTriggerTime = configureZCCReq.getActionTriggerTime();
                        deviceProperties.curtainType = configureZCCReq.getCurtainType();
                        deviceProperties.invertSignal = configureZCCReq.getInvertSignal();
                        deviceProperties.motorCalibrationTime = configureZCCReq.getMotorCalibrationTime();
                        deviceProperties.rfremoteEnabled = configureZCCReq.getRfremoteEnabled();
                        device.isHidden = configureZCCReq.getIsHidden();
                        device.isConfigured = true;
                        device.deviceName = configureZCCReq.getDeviceName()
                            ? configureZCCReq.getDeviceName()
                            : device.deviceName;
                        device.deviceLocation = configureZCCReq.getDeviceLocation()
                            ? configureZCCReq.getDeviceLocation()
                            : device.deviceLocation;
                        device.deviceProperties = deviceProperties;
                        await keus_device_1.default.updateDevice(device.deviceId, device);
                        resolve(response_1.default.getConfigureSuccessful());
                    }
                }
            }
            catch (e) {
                switch (e) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map