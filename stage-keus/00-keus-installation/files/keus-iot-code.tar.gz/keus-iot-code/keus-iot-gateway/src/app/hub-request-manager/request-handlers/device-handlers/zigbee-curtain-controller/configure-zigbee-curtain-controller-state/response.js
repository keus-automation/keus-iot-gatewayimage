"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_curtain_controller_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_curtain_controller_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class ConfigureZigbeeCurtainControllerResp {
    static getConfigureSuccessful() {
        const resp = new zigbee_curtain_controller_pb_1.ConfigureZigbeeCurtainControllerResponse();
        resp.setCode(800);
        resp.setMessage('Configure Curtain Controller Success');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeCurtainControllerResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new zigbee_curtain_controller_pb_1.ConfigureZigbeeCurtainControllerResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeCurtainControllerResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_curtain_controller_pb_1.ConfigureZigbeeCurtainControllerResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeCurtainControllerResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_curtain_controller_pb_1.ConfigureZigbeeCurtainControllerResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeCurtainControllerResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_curtain_controller_pb_1.ConfigureZigbeeCurtainControllerResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeCurtainControllerResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_curtain_controller_pb_1.ConfigureZigbeeCurtainControllerResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeCurtainControllerResp.responseType);
    }
}
exports.default = ConfigureZigbeeCurtainControllerResp;
ConfigureZigbeeCurtainControllerResp.responseType = system_constants_1.ProtoPackageName + '.ConfigureZigbeeCurtainControllerResponse';
//# sourceMappingURL=response.js.map