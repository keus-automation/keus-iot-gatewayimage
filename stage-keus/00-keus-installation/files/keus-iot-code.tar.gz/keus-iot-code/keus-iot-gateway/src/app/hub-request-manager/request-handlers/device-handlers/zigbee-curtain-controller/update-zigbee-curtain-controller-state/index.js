"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const zigbee_curtain_controller_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_curtain_controller_pb");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const keus_activity_1 = __importDefault(require("../../../../../../models/database-models/keus-activity"));
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const activity_utils_1 = require("../../../../../../utilities/gateway/activity-utils");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const zigbee_curtain_controller_pb_2 = require("../../../../../device-manager/providers/generated/devices/zigbee_curtain_controller_pb");
const local_client_1 = require("../../../../local-client");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const cloud_client_1 = require("../../../../cloud-client");
const reqType = system_constants_1.ProtoPackageName + '.UpdateZigbeeCurtainControllerState';
const eventType = system_constants_1.ProtoPackageName + '.ZigbeeCurtainControllerEvent';
exports.default = async (updateZCCStateReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                if (!updateZCCStateReq.getDeviceId()) {
                    resolve(response_1.default.getInvalidDeviceId());
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(updateZCCStateReq.getDeviceId());
                    let user = await keus_user_1.default.getUserByPhone(phone);
                    await home_utils_1.checkAccessForUser(user, device.deviceRoom);
                    if (!device) {
                        resolve(response_1.default.getInvalidDeviceId());
                    }
                    else if (device.deviceCategory !=
                        device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode) {
                        resolve(response_1.default.getInvalidDeviceType());
                    }
                    else {
                        const curtainProps = device.deviceProperties;
                        let curtainState;
                        curtainState = updateZCCStateReq.getCurtainState();
                        let curtainStateUpdate = new zigbee_curtain_controller_pb_2.DMUpdateZigbeeCurtainControllerState();
                        curtainStateUpdate.setDeviceId(device.deviceId);
                        curtainStateUpdate.setCurtainState(curtainState);
                        let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(curtainStateUpdate.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMUpdateZigbeeCurtainControllerState'));
                        if (!res.getSuccess()) {
                            throw new Error('Error setting curtain state');
                        }
                        let deviceState = device.deviceState;
                        deviceState.curtainState = updateZCCStateReq.getCurtainState();
                        device.deviceState = deviceState;
                        device.lastUpdateBy = phone;
                        device.lastUpdateSource = system_constants_1.UpdateSourceMapping.ANDROID;
                        device.lastUpdateTime = Date.now();
                        device.lastUpdateUser = user.userName;
                        let roomDetails = await keus_home_1.default.getRoomById(device.deviceRoom);
                        let activityObj = await activity_utils_1.getDeviceActivityObj(user, device, roomDetails, updateZCCStateReq, {
                            activitySource: system_constants_1.UpdateSourceMapping.ANDROID
                        });
                        await keus_activity_1.default.insertActivity(activityObj);
                        await keus_device_1.default.updateDevice(device.deviceId, device);
                        //-----------------------Update Curtain Controller State Event--------------------------------
                        const curtainControllerEvent = new zigbee_curtain_controller_pb_1.ZigbeeCurtainControllerEvent();
                        curtainControllerEvent.setUpdateState(updateZCCStateReq);
                        curtainControllerEvent.setActivitySource(system_constants_1.UpdateSourceMapping.ANDROID);
                        curtainControllerEvent.setActivityUser(phone);
                        curtainControllerEvent.setActivityTime(device.lastUpdateTime);
                        const eventArg = general_1.PackIntoAny(curtainControllerEvent.serializeBinary(), eventType);
                        local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                        cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                        resolve(response_1.default.getUpdateSuccessful());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map