"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_curtain_controller_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_curtain_controller_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class UpdateZigbeeCurtainControllerStateResp {
    static getUpdateSuccessful() {
        const resp = new zigbee_curtain_controller_pb_1.UpdateZigbeeCurtainControllerStateResponse();
        resp.setCode(800);
        resp.setMessage('Update Curtain State Success');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeCurtainControllerStateResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new zigbee_curtain_controller_pb_1.UpdateZigbeeCurtainControllerStateResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeCurtainControllerStateResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_curtain_controller_pb_1.UpdateZigbeeCurtainControllerStateResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeCurtainControllerStateResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_curtain_controller_pb_1.UpdateZigbeeCurtainControllerStateResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeCurtainControllerStateResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_curtain_controller_pb_1.UpdateZigbeeCurtainControllerStateResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeCurtainControllerStateResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_curtain_controller_pb_1.UpdateZigbeeCurtainControllerStateResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeCurtainControllerStateResp.responseType);
    }
}
exports.default = UpdateZigbeeCurtainControllerStateResp;
UpdateZigbeeCurtainControllerStateResp.responseType = system_constants_1.ProtoPackageName + '.UpdateZigbeeCurtainControllerStateResponse';
//# sourceMappingURL=response.js.map