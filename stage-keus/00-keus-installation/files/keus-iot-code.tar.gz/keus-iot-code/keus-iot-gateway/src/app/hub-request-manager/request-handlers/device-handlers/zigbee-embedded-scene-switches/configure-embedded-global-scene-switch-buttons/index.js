"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const zigbee_embedded_scene_switch_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_embedded_scene_switch_pb");
const local_client_1 = require("../../../../local-client");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const device_types_1 = require("../../../../../../constants/device/device-types");
const home_constants_1 = require("../../../../../../constants/gateway/home-constants");
exports.default = async (configureData, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const deviceObj = await keus_device_1.default.getDeviceById(configureData.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SCENE_SWITCH').deviceTypesList;
                if (!deviceObj) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    console.log(configureData.toObject());
                    const deviceRoom = await keus_home_1.default.getRoomById(deviceObj.deviceRoom);
                    if (deviceObj.deviceType != device_types_1.TypeMap.KZESS10) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    const device = deviceObj;
                    let switches = configureData.getSwitchesList();
                    let deviceProperties = device.deviceProperties;
                    const dmSceneSwitchButtonList = [];
                    switches.forEach(sw => {
                        for (let i = 0; i < deviceProperties.switches.length; i++) {
                            if (sw.getSwitchId() == deviceProperties.switches[i].switchId) {
                                deviceProperties.switches[i].sceneId = sw.getSceneId();
                                deviceProperties.switches[i].sceneRoom = sw.getSceneRoom();
                                if (sw.getSceneRoom() != home_constants_1.DefaultRoomId) {
                                    throw new errors_1.HomeErrors.InvalidRoomId();
                                }
                                const dmSceneSwitchButton = new zigbee_embedded_scene_switch_pb_1.SceneSwitchButton();
                                sw.getSceneId() == -1 ? dmSceneSwitchButton.setSceneId(0xFF) : dmSceneSwitchButton.setSceneId(sw.getSceneId());
                                dmSceneSwitchButton.setAreaId(home_constants_1.DefaultAreaId);
                                dmSceneSwitchButton.setSwitchId(sw.getSwitchId());
                                dmSceneSwitchButtonList.push(dmSceneSwitchButton);
                            }
                        }
                    });
                    device.deviceProperties = deviceProperties;
                    //Make Zigbee Call to configure switches
                    let dmConfigureEmbeddedSceneSwitchButtons = new zigbee_embedded_scene_switch_pb_1.DMConfigureZigbeeEmbeddedSceneSwitch();
                    dmConfigureEmbeddedSceneSwitchButtons.setDeviceId(device.deviceId);
                    dmConfigureEmbeddedSceneSwitchButtons.setSwitchesList(dmSceneSwitchButtonList);
                    let dmConfigureEmbeddedSceneSwitchButtonsRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmConfigureEmbeddedSceneSwitchButtons.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMConfigureZigbeeEmbeddedSceneSwitch'));
                    console.log("-------------this is before zigbee call");
                    if (!dmConfigureEmbeddedSceneSwitchButtonsRsp.getSuccess()) {
                        throw new Error(dmConfigureEmbeddedSceneSwitchButtonsRsp.getMessage());
                    }
                    let updateObj = await keus_device_1.default.updateDevice(device.deviceId, device);
                    if (!updateObj) {
                        resolve(response_1.default.getDeviceNotFound());
                    }
                    else {
                        resolve(response_1.default.getConfigureSuccessful());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getDeviceNotFound());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        console.log("this is internalserver error", e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map