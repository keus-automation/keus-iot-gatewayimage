"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
exports.default = async (configureData, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const deviceObj = await keus_device_1.default.getDeviceById(configureData.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SCENE_SWITCH').deviceTypesList;
                if (!deviceObj) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    if (arrayList.indexOf(deviceObj.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    const device = deviceObj;
                    device.deviceName = configureData.getDeviceName();
                    device.deviceLocation = configureData.getDeviceLocation();
                    device.isHidden = configureData.getIsHidden();
                    device.isConfigured = true;
                    let deviceProperties = device.deviceProperties;
                    device.deviceProperties = deviceProperties;
                    let updateObj = await keus_device_1.default.updateDevice(device.deviceId, device);
                    if (!updateObj) {
                        resolve(response_1.default.getDeviceNotFound());
                    }
                    else {
                        resolve(response_1.default.getConfigureSuccessful());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getDeviceNotFound());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map