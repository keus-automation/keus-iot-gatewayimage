"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const configure_zigbee_embedded_scene_switch_1 = __importDefault(require("./configure-zigbee-embedded-scene-switch"));
exports.ConfigureZigbeeEmbeddedSceneSwitch = configure_zigbee_embedded_scene_switch_1.default;
const configure_embedded_scene_switch_buttons_1 = __importDefault(require("./configure-embedded-scene-switch-buttons"));
exports.ConfigureZigbeeEmbeddedSceneSwitchButtons = configure_embedded_scene_switch_buttons_1.default;
const configure_embedded_global_scene_switch_buttons_1 = __importDefault(require("./configure-embedded-global-scene-switch-buttons"));
exports.ConfigureZigbeeEmbeddedGlobalSceneSwitchButtons = configure_embedded_global_scene_switch_buttons_1.default;
const move_zigbee_embedded_scene_switches_1 = __importDefault(require("./move-zigbee-embedded-scene-switches"));
exports.MoveZigbeeEmbeddedSceneSwitchRoom = move_zigbee_embedded_scene_switches_1.default;
//# sourceMappingURL=index.js.map