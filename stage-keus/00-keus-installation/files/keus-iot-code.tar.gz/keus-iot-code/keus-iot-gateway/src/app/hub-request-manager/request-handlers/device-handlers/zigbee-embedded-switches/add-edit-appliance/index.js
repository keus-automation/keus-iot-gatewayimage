"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const zigbee_embedded_switch_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_embedded_switch_pb");
const device_constants_pb_2 = require("../../../../../device-manager/providers/generated/devices/device_constants_pb");
const local_client_1 = require("../../../../local-client");
const general_1 = require("../../../../../../utilities/general");
const rs = __importStar(require("randomstring"));
exports.default = async (incomingRequest, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(incomingRequest.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        let deviceProperties = device.deviceProperties;
                        let applianceList = deviceProperties.appliance;
                        let portList = deviceProperties.outputPorts;
                        let appliance = applianceList.find(function (app) {
                            return app.applianceId == incomingRequest.getAppliance().getApplianceId();
                        });
                        let newAppliance = {};
                        console.log('before new appliance', appliance);
                        newAppliance.applianceId = appliance ? appliance.applianceId : rs.generate(6);
                        let portsAvailable = await checkPortAvailability(portList, incomingRequest.getAppliance());
                        if (!portsAvailable) {
                            throw new errors_1.DeviceErrors.PortsNotAvailable();
                        }
                        newAppliance.iconType = incomingRequest.getAppliance().getIconType();
                        newAppliance.inGroup = incomingRequest.getAppliance().getInGroup();
                        newAppliance.groupId = incomingRequest.getAppliance().getGroupId();
                        newAppliance.applianceName = incomingRequest.getAppliance().getApplianceName();
                        newAppliance.applianceType = incomingRequest.getAppliance().getApplianceType();
                        newAppliance.lastUpdatedTime = Date.now();
                        newAppliance.lastUpdatedUser = user.userName;
                        newAppliance.lastUpdatedSource = system_constants_1.UpdateSourceMapping.SYSTEM;
                        newAppliance.lastUpdatedBy = user.phone;
                        let dmAddEditApplianceReq = new zigbee_embedded_switch_pb_1.DMAddEditAppliance();
                        dmAddEditApplianceReq.setDeviceId(device.deviceId);
                        let dmApplianceInfo = new zigbee_embedded_switch_pb_1.DMEmbeddedAppliance();
                        dmAddEditApplianceReq.setAppliance(dmApplianceInfo);
                        dmApplianceInfo.setApplianceId(newAppliance.applianceId);
                        dmApplianceInfo.setInGroup(newAppliance.inGroup);
                        dmApplianceInfo.setGroupId(newAppliance.groupId);
                        switch (incomingRequest.getAppliance().getApplianceType()) {
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                                let onoffState = {
                                    switchState: incomingRequest
                                        .getAppliance()
                                        .getOnOffState()
                                        .getSwitchState()
                                };
                                let onoffProperties = {
                                    portId: incomingRequest
                                        .getAppliance()
                                        .getOnOffProperties()
                                        .getPortId()
                                };
                                let onoffDefault = {
                                    switchState: incomingRequest
                                        .getAppliance()
                                        .getOnOffDefaultState()
                                        .getSwitchState()
                                };
                                newAppliance.applianceProperties = onoffProperties;
                                newAppliance.applianceState = onoffState;
                                newAppliance.defaultState = onoffDefault;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getOnOffProperties()
                                    .getPortId()].isInAppliance = true;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getOnOffProperties()
                                    .getPortId()].applianceId = newAppliance.applianceId;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getOnOffProperties()
                                    .getPortId()].portState = incomingRequest
                                    .getAppliance()
                                    .getOnOffState()
                                    .getSwitchState();
                                let oldApplianceProperties = appliance ? appliance.applianceProperties : {};
                                if (appliance &&
                                    oldApplianceProperties.portId !=
                                        incomingRequest
                                            .getAppliance()
                                            .getOnOffProperties()
                                            .getPortId()) {
                                    portList[oldApplianceProperties.portId].applianceId = '';
                                    portList[oldApplianceProperties.portId].isInAppliance = false;
                                }
                                //zigbee data    
                                dmApplianceInfo.setApplianceType(device_constants_pb_2.DMEMBEDDED_APPLIANCE_TYPES.ON_OFF);
                                let dmOnOffState = new zigbee_embedded_switch_pb_1.DMOnOffApplianceState();
                                dmOnOffState.setSwitchState(onoffState.switchState);
                                dmApplianceInfo.setOnOffState(dmOnOffState);
                                let dmOnOffProperties = new zigbee_embedded_switch_pb_1.DMOnOffApplianceProperties();
                                dmOnOffProperties.setPortId(onoffProperties.portId);
                                dmApplianceInfo.setOnOffProperties(dmOnOffProperties);
                                let dmOnOffDefState = new zigbee_embedded_switch_pb_1.DMOnOffApplianceState();
                                dmOnOffDefState.setSwitchState(onoffDefault.switchState);
                                dmApplianceInfo.setOnOffDefaultState(dmOnOffDefState);
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                                let sdState = {
                                    switchState: incomingRequest
                                        .getAppliance()
                                        .getSingleDimmerState()
                                        .getSwitchState()
                                };
                                console.log('came sdState');
                                let sdProperties = {
                                    portId: incomingRequest
                                        .getAppliance()
                                        .getSingleDimmerProperties()
                                        .getPortId()
                                };
                                console.log('came sdState2');
                                let sdDefault = {
                                    switchState: incomingRequest
                                        .getAppliance()
                                        .getSingleDimmerDefaultState()
                                        .getSwitchState()
                                };
                                console.log('came sdState3');
                                newAppliance.applianceProperties = sdProperties;
                                newAppliance.applianceState = sdState;
                                newAppliance.defaultState = sdDefault;
                                console.log('came to single dimmer', newAppliance);
                                portList[incomingRequest
                                    .getAppliance()
                                    .getSingleDimmerProperties()
                                    .getPortId()].isInAppliance = true;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getSingleDimmerProperties()
                                    .getPortId()].applianceId = newAppliance.applianceId;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getSingleDimmerProperties()
                                    .getPortId()].portState = incomingRequest
                                    .getAppliance()
                                    .getSingleDimmerState()
                                    .getSwitchState();
                                console.log('port update completed');
                                let oldAppliancesdProperties = appliance ? appliance.applianceProperties : {};
                                if (appliance &&
                                    oldAppliancesdProperties.portId !=
                                        incomingRequest
                                            .getAppliance()
                                            .getSingleDimmerProperties()
                                            .getPortId()) {
                                    portList[oldAppliancesdProperties.portId].applianceId = '';
                                    portList[oldAppliancesdProperties.portId].isInAppliance = false;
                                }
                                //zigbee data    
                                dmApplianceInfo.setApplianceType(device_constants_pb_2.DMEMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER);
                                let dmSingleDimmerState = new zigbee_embedded_switch_pb_1.DMSingleDimmerApplianceState();
                                dmSingleDimmerState.setSwitchState(sdState.switchState);
                                dmApplianceInfo.setSingleDimmerState(dmSingleDimmerState);
                                let dmSingleDimmerProperties = new zigbee_embedded_switch_pb_1.DMSingleDimmerApplianceProperties();
                                dmSingleDimmerProperties.setPortId(sdProperties.portId);
                                dmApplianceInfo.setSingleDimmerProperties(dmSingleDimmerProperties);
                                let dmSingleDimmerDefState = new zigbee_embedded_switch_pb_1.DMSingleDimmerApplianceState();
                                dmSingleDimmerDefState.setSwitchState(sdDefault.switchState);
                                dmApplianceInfo.setSingleDimmerDefaultState(dmSingleDimmerDefState);
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                                let fanState = {
                                    fanState: incomingRequest
                                        .getAppliance()
                                        .getFanState()
                                        .getFanState()
                                };
                                let fanProperties = {
                                    portId: incomingRequest
                                        .getAppliance()
                                        .getFanProperties()
                                        .getPortId()
                                };
                                let fanDefault = {
                                    fanState: incomingRequest
                                        .getAppliance()
                                        .getFanDefaultState()
                                        .getFanState()
                                };
                                newAppliance.applianceProperties = fanProperties;
                                newAppliance.applianceState = fanState;
                                newAppliance.defaultState = fanDefault;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getFanProperties()
                                    .getPortId()].isInAppliance = true;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getFanProperties()
                                    .getPortId()].applianceId = newAppliance.applianceId;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getFanProperties()
                                    .getPortId()].portState = incomingRequest
                                    .getAppliance()
                                    .getFanState()
                                    .getFanState();
                                let oldApplianceFanProperties = appliance ? appliance.applianceProperties : {};
                                if (appliance &&
                                    oldApplianceFanProperties.portId !=
                                        incomingRequest
                                            .getAppliance()
                                            .getFanProperties()
                                            .getPortId()) {
                                    portList[oldApplianceFanProperties.portId].applianceId = '';
                                    portList[oldApplianceFanProperties.portId].isInAppliance = false;
                                }
                                //zigbee data    
                                dmApplianceInfo.setApplianceType(device_constants_pb_2.DMEMBEDDED_APPLIANCE_TYPES.FAN);
                                let dmFanState = new zigbee_embedded_switch_pb_1.DMFanApplianceState();
                                dmFanState.setFanState(fanState.fanState);
                                dmApplianceInfo.setFanState(dmFanState);
                                let dmFanProperties = new zigbee_embedded_switch_pb_1.DMFanApplianceProperties();
                                dmFanProperties.setPortId(fanProperties.portId);
                                dmApplianceInfo.setFanProperties(dmFanProperties);
                                let dmFanDefState = new zigbee_embedded_switch_pb_1.DMFanApplianceState();
                                dmFanDefState.setFanState(fanDefault.fanState);
                                dmApplianceInfo.setFanDefaultState(dmFanDefState);
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                                let ctState = {
                                    lightState: incomingRequest
                                        .getAppliance()
                                        .getColorTunableState()
                                        .getLightState(),
                                    warmWhiteState: incomingRequest
                                        .getAppliance()
                                        .getColorTunableState()
                                        .getWarmWhiteState(),
                                    coolWhiteState: incomingRequest
                                        .getAppliance()
                                        .getColorTunableState()
                                        .getCoolWhiteState()
                                };
                                let ctProperties = {
                                    warmWhitePort: incomingRequest
                                        .getAppliance()
                                        .getColorTunableProperties()
                                        .getWarmWhitePort(),
                                    coolWhitePort: incomingRequest
                                        .getAppliance()
                                        .getColorTunableProperties()
                                        .getCoolWhitePort()
                                };
                                let ctDefault = {
                                    lightState: incomingRequest
                                        .getAppliance()
                                        .getColorTunableDefaultState()
                                        .getLightState(),
                                    warmWhiteState: incomingRequest
                                        .getAppliance()
                                        .getColorTunableDefaultState()
                                        .getWarmWhiteState(),
                                    coolWhiteState: incomingRequest
                                        .getAppliance()
                                        .getColorTunableDefaultState()
                                        .getCoolWhiteState()
                                };
                                newAppliance.applianceProperties = ctProperties;
                                newAppliance.applianceState = ctState;
                                newAppliance.defaultState = ctDefault;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getColorTunableProperties()
                                    .getWarmWhitePort()].isInAppliance = true;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getColorTunableProperties()
                                    .getWarmWhitePort()].applianceId = newAppliance.applianceId;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getColorTunableProperties()
                                    .getCoolWhitePort()].isInAppliance = true;
                                portList[incomingRequest
                                    .getAppliance()
                                    .getColorTunableProperties()
                                    .getCoolWhitePort()].applianceId = newAppliance.applianceId;
                                let oldApplianceCtProps = appliance ? appliance.applianceProperties : {};
                                if (appliance) {
                                    if (oldApplianceCtProps.coolWhitePort !=
                                        incomingRequest
                                            .getAppliance()
                                            .getColorTunableProperties()
                                            .getCoolWhitePort()) {
                                        portList[oldApplianceCtProps.coolWhitePort].applianceId = '';
                                        portList[oldApplianceCtProps.coolWhitePort].isInAppliance = false;
                                    }
                                    if (oldApplianceCtProps.warmWhitePort !=
                                        incomingRequest
                                            .getAppliance()
                                            .getColorTunableProperties()
                                            .getWarmWhitePort()) {
                                        portList[oldApplianceCtProps.warmWhitePort].applianceId = '';
                                        portList[oldApplianceCtProps.warmWhitePort].isInAppliance = false;
                                    }
                                }
                                //zigbee data    
                                dmApplianceInfo.setApplianceType(device_constants_pb_2.DMEMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE);
                                let dmColorTunableState = new zigbee_embedded_switch_pb_1.DMColorTunableApplianceState();
                                dmColorTunableState.setCoolWhiteState(ctState.coolWhiteState);
                                dmColorTunableState.setWarmWhiteState(ctState.warmWhiteState);
                                dmColorTunableState.setLightState(ctState.lightState);
                                dmApplianceInfo.setColorTunableState(dmColorTunableState);
                                let dmColorTunableProperties = new zigbee_embedded_switch_pb_1.DMColorTunableApplianceProperties();
                                dmColorTunableProperties.setCoolWhitePort(ctProperties.coolWhitePort);
                                dmColorTunableProperties.setWarmWhitePort(ctProperties.warmWhitePort);
                                dmApplianceInfo.setColorTunableProperties(dmColorTunableProperties);
                                let dmColorTunableDefState = new zigbee_embedded_switch_pb_1.DMColorTunableApplianceState();
                                dmColorTunableDefState.setCoolWhiteState(ctState.coolWhiteState);
                                dmColorTunableDefState.setWarmWhiteState(ctState.warmWhiteState);
                                dmColorTunableDefState.setLightState(ctState.lightState);
                                dmApplianceInfo.setColorTunableDefaultState(dmColorTunableDefState);
                                break;
                            default:
                                break;
                        }
                        console.log('switch case completed', newAppliance);
                        applianceList = applianceList.filter(function (app) {
                            return app.applianceId != newAppliance.applianceId;
                        });
                        applianceList.push(newAppliance);
                        console.log('new appliace success pushed', applianceList);
                        let dmAddEditApplianceRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddEditApplianceReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddEditAppliance'));
                        console.log("This is rsp", dmAddEditApplianceRsp);
                        if (!dmAddEditApplianceRsp.getSuccess()) {
                            throw new Error(dmAddEditApplianceRsp.getMessage());
                        }
                        let updateddeviceProps = {
                            outputPorts: portList,
                            appliance: applianceList,
                            switch: deviceProperties.switch
                        };
                        await keus_device_1.default.updateDeviceProperties(device.deviceId, updateddeviceProps, true);
                        resolve(response_1.default.getAddEditApplianceSuccessful(newAppliance.applianceId));
                    }
                }
            }
            catch (e) {
                console.log('there is error', e);
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.PortsNotAvailable:
                        resolve(response_1.default.getInvalidPort());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
async function checkPortAvailability(portsList, appliance) {
    switch (appliance.getApplianceType()) {
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
            let onofPort = portsList[appliance.getOnOffProperties().getPortId()];
            if (!onofPort.isInAppliance) {
                return true;
            }
            else if (onofPort.isInAppliance && onofPort.applianceId == appliance.getApplianceId()) {
                return true;
            }
            else {
                return false;
            }
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
            let sdPort = portsList[appliance.getSingleDimmerProperties().getPortId()];
            if (!sdPort.isInAppliance) {
                return true;
            }
            else if (sdPort.isInAppliance && sdPort.applianceId == appliance.getApplianceId()) {
                return true;
            }
            else {
                return false;
            }
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
            let fPort = portsList[appliance.getFanProperties().getPortId()];
            if (!fPort.isInAppliance) {
                return true;
            }
            else if (fPort.isInAppliance && fPort.applianceId == appliance.getApplianceId()) {
                return true;
            }
            else {
                return false;
            }
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
            let cwport = portsList[appliance.getColorTunableProperties().getCoolWhitePort()];
            let wwport = portsList[appliance.getColorTunableProperties().getWarmWhitePort()];
            if (!cwport.isInAppliance && !wwport.isInAppliance) {
                return true;
            }
            if (cwport.isInAppliance &&
                wwport.isInAppliance &&
                cwport.applianceId == appliance.getApplianceId() &&
                wwport.applianceId == appliance.getApplianceId()) {
                return true;
            }
            else {
                return false;
            }
            break;
    }
}
exports.checkPortAvailability = checkPortAvailability;
//# sourceMappingURL=index.js.map