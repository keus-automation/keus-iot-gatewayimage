"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const zigbee_embedded_switch_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_embedded_switch_pb");
const general_1 = require("../../../../../../utilities/general");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
class AddEditApplianceResp {
    static getAddEditApplianceSuccessful(applianceId) {
        const resp = new zigbee_embedded_switch_pb_1.AddEditApplianceResponse();
        resp.setCode(800);
        resp.setMessage('Add Edit Appliance Successful');
        resp.setSuccess(true);
        resp.setApplianceId(applianceId);
        return general_1.PackIntoAny(resp.serializeBinary(), AddEditApplianceResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new zigbee_embedded_switch_pb_1.AddEditApplianceResponse();
        resp.setCode(801);
        resp.setMessage('Invalid DeviceId');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddEditApplianceResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_embedded_switch_pb_1.AddEditApplianceResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddEditApplianceResp.responseType);
    }
    static getInvalidPort() {
        const resp = new zigbee_embedded_switch_pb_1.AddEditApplianceResponse();
        resp.setCode(803);
        resp.setMessage('Ports Not Available');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddEditApplianceResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_embedded_switch_pb_1.AddEditApplianceResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), AddEditApplianceResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_embedded_switch_pb_1.AddEditApplianceResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddEditApplianceResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_embedded_switch_pb_1.AddEditApplianceResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddEditApplianceResp.responseType);
    }
}
exports.default = AddEditApplianceResp;
AddEditApplianceResp.responseType = system_constants_1.ProtoPackageName + '.AddEditApplianceResponse';
//# sourceMappingURL=response.js.map