"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const zigbee_embedded_switch_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_embedded_switch_pb");
const device_constants_pb_2 = require("../../../../../device-manager/providers/generated/devices/device_constants_pb");
const local_client_1 = require("../../../../local-client");
const general_1 = require("../../../../../../utilities/general");
exports.default = async (configureData, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(configureData.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    let deviceProperties = device.deviceProperties;
                    let switchList = deviceProperties.switch;
                    let finalSwitch = switchList.find(function (swi) {
                        return swi.switchId == configureData.getSwitch().getSwitchId();
                    });
                    finalSwitch.switchName = configureData.getSwitch().getSwitchName();
                    finalSwitch.switchType = configureData.getSwitch().getSwitchType();
                    let dmConfigureSwitchReq = new zigbee_embedded_switch_pb_1.DMConfigureEmbeddedSwitches();
                    dmConfigureSwitchReq.setDeviceId(device.deviceId);
                    let dmESInfo = new zigbee_embedded_switch_pb_1.DMEmbeddedSwitch();
                    dmConfigureSwitchReq.setSwitch(dmESInfo);
                    dmESInfo.setSwitchId(finalSwitch.switchId);
                    switch (configureData.getSwitch().getSwitchType()) {
                        case device_constants_pb_1.EMBEDDED_SWITCH_TYPES.APPLIANCE:
                            let appProps = {
                                applianceId: configureData.getSwitch().getApplianceProperties().getApplianceId()
                            };
                            finalSwitch.switchProperties = appProps;
                            dmESInfo.setSwitchType(device_constants_pb_2.DMEMBEDDED_SWITCH_TYPES.APPLIANCE);
                            let dmAppProps = new zigbee_embedded_switch_pb_1.DMSwitchApplianceProperties();
                            dmAppProps.setApplianceId(appProps.applianceId);
                            dmESInfo.setApplianceProperties(dmAppProps);
                            break;
                        case device_constants_pb_1.EMBEDDED_SWITCH_TYPES.GROUP_EXECUTION:
                            let groupProps = {
                                groupId: configureData.getSwitch().getGroupProperties().getGroupId(),
                                roomId: configureData.getSwitch().getGroupProperties().getRoomId()
                            };
                            finalSwitch.switchProperties = groupProps;
                            dmESInfo.setSwitchType(device_constants_pb_2.DMEMBEDDED_SWITCH_TYPES.GROUP_EXECUTION);
                            let dmGroupProps = new zigbee_embedded_switch_pb_1.DMSwitchGroupProperties();
                            dmGroupProps.setGroupId(groupProps.groupId);
                            dmESInfo.setGroupProperties(dmGroupProps);
                            break;
                        case device_constants_pb_1.EMBEDDED_SWITCH_TYPES.AC_FAN:
                            let acProps = {
                                deviceId: configureData.getSwitch().getAcFanProperties().getDeviceId()
                            };
                            finalSwitch.switchProperties = acProps;
                            dmESInfo.setSwitchType(device_constants_pb_2.DMEMBEDDED_SWITCH_TYPES.AC_FAN);
                            let dmAcFanProps = new zigbee_embedded_switch_pb_1.DMSwitchAcFanProperties();
                            dmAcFanProps.setDeviceId(device.deviceId);
                            dmESInfo.setAcFanProperties(dmAcFanProps);
                            break;
                        case device_constants_pb_1.EMBEDDED_SWITCH_TYPES.DC_FAN:
                            let dcProps = {
                                deviceId: configureData.getSwitch().getDcFanProperties().getDeviceId()
                            };
                            finalSwitch.switchProperties = dcProps;
                            dmESInfo.setSwitchType(device_constants_pb_2.DMEMBEDDED_SWITCH_TYPES.DC_FAN);
                            let dmDcFanProps = new zigbee_embedded_switch_pb_1.DMSwitchDcFanProperties();
                            dmDcFanProps.setDeviceId(device.deviceId);
                            dmESInfo.setDcFanProperties(dmDcFanProps);
                            break;
                        default:
                            break;
                    }
                    let dmConfigureSwitchRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmConfigureSwitchReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMConfigureEmbeddedSwitches'));
                    console.log("This is rsp", dmConfigureSwitchRsp);
                    if (!dmConfigureSwitchRsp.getSuccess()) {
                        throw new Error(dmConfigureSwitchRsp.getMessage());
                    }
                    deviceProperties.switch = switchList;
                    await keus_device_1.default.updateDeviceProperties(device.deviceId, deviceProperties, true);
                    resolve(response_1.default.getConfigureSuccessful());
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getDeviceNotFound());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map