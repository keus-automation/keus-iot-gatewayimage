"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_embedded_switch_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_embedded_switch_pb");
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const zigbee_embedded_switch_pb_2 = require("../../../../../device-manager/providers/generated/devices/zigbee_embedded_switch_pb");
const local_client_1 = require("../../../../local-client");
const general_1 = require("../../../../../../utilities/general");
const cloud_client_1 = require("../../../../cloud-client");
const eventType = system_constants_1.ProtoPackageName + '.ZigbeeEmbeddedApplianceEvent';
//activty log and zigbee calls are pending
exports.default = async (incomingRequest, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(incomingRequest.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        let deviceProperties = device.deviceProperties;
                        let applianceList = deviceProperties.appliance;
                        let portList = deviceProperties.outputPorts;
                        let appliance = applianceList.find(function (app) {
                            return app.applianceId == incomingRequest.getApplianceId();
                        });
                        if (!appliance) {
                            throw new errors_1.DeviceErrors.InvalidApplianceId();
                        }
                        appliance.lastUpdatedTime = Date.now();
                        appliance.lastUpdatedUser = user.userName;
                        appliance.lastUpdatedSource = system_constants_1.UpdateSourceMapping.ANDROID;
                        appliance.lastUpdatedBy = user.phone;
                        let dmUpdateApplianceStateReq = new zigbee_embedded_switch_pb_2.DMUpdateApplianceState();
                        dmUpdateApplianceStateReq.setDeviceId(device.deviceId);
                        dmUpdateApplianceStateReq.setApplianceId(appliance.applianceId);
                        switch (appliance.applianceType) {
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                                let onffState = {
                                    switchState: incomingRequest.getOnOffState().getSwitchState()
                                };
                                //made zigbee call
                                appliance.applianceState = onffState;
                                let dmOnOffApplState = new zigbee_embedded_switch_pb_2.DMOnOffApplianceState();
                                dmOnOffApplState.setSwitchState(onffState.switchState);
                                dmUpdateApplianceStateReq.setOnOffState(dmOnOffApplState);
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                                let sdState = {
                                    switchState: incomingRequest.getSingleDimmerState().getSwitchState()
                                };
                                //made zigbee call
                                appliance.applianceState = sdState;
                                let dmSDApplState = new zigbee_embedded_switch_pb_2.DMSingleDimmerApplianceState();
                                dmSDApplState.setSwitchState(sdState.switchState);
                                dmUpdateApplianceStateReq.setSingleDimmerState(dmSDApplState);
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                                let fanState = {
                                    fanState: incomingRequest.getFanState().getFanState()
                                };
                                appliance.applianceState = fanState;
                                let dmFanApplState = new zigbee_embedded_switch_pb_2.DMFanApplianceState();
                                dmFanApplState.setFanState(fanState.fanState);
                                dmUpdateApplianceStateReq.setFanState(dmFanApplState);
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                                let ctState = {
                                    lightState: incomingRequest.getColorTunableState().getLightState(),
                                    warmWhiteState: incomingRequest.getColorTunableState().getWarmWhiteState(),
                                    coolWhiteState: incomingRequest.getColorTunableState().getCoolWhiteState()
                                };
                                //made zigbee call
                                appliance.applianceState = ctState;
                                let dmCTApplState = new zigbee_embedded_switch_pb_2.DMColorTunableApplianceState();
                                dmCTApplState.setCoolWhiteState(ctState.coolWhiteState);
                                dmCTApplState.setWarmWhiteState(ctState.warmWhiteState);
                                dmCTApplState.setLightState(ctState.lightState);
                                dmUpdateApplianceStateReq.setColorTunableState(dmCTApplState);
                                break;
                            default:
                                break;
                        }
                        let dmUpdateApplianceStateRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmUpdateApplianceStateReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMUpdateApplianceState'));
                        console.log("This is rsp", dmUpdateApplianceStateRsp);
                        if (!dmUpdateApplianceStateRsp.getSuccess()) {
                            throw new Error(dmUpdateApplianceStateRsp.getMessage());
                        }
                        let updateddeviceProps = {
                            outputPorts: deviceProperties.outputPorts,
                            appliance: applianceList,
                            switch: deviceProperties.switch
                        };
                        await keus_device_1.default.updateDeviceProperties(device.deviceId, updateddeviceProps, device.isConfigured);
                        //Events
                        const ESApplianceEvent = new zigbee_embedded_switch_pb_1.ZigbeeEmbeddedApplianceEvent();
                        ESApplianceEvent.setUpdateState(incomingRequest);
                        ESApplianceEvent.setActivitySource(system_constants_1.UpdateSourceMapping.ANDROID);
                        ESApplianceEvent.setActivityUser(phone);
                        ESApplianceEvent.setActivityTime(appliance.lastUpdatedTime);
                        const eventArg = general_1.PackIntoAny(ESApplianceEvent.serializeBinary(), eventType);
                        local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                        cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                        resolve(response_1.default.getUpdateApplianceStateSuccessful());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidApplianceId:
                        resolve(response_1.default.getInvalidApplianceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map