"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_ac_fan_controller_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const keus_activity_1 = __importDefault(require("../../../../../../models/database-models/keus-activity"));
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const activity_utils_1 = require("../../../../../../utilities/gateway/activity-utils");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const local_client_1 = require("../../../../local-client");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const cloud_client_1 = require("../../../../cloud-client");
const reqType = system_constants_1.ProtoPackageName + '.UpdateZigbeeACFanControllerState';
const eventType = system_constants_1.ProtoPackageName + '.ZigbeeACFanControllerEvent';
exports.default = async (reportStateData, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                const deviceObj = await keus_device_1.default.getDeviceById(reportStateData.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceTypesList;
                var commandId;
                if (!deviceObj) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                if (arrayList.indexOf(deviceObj.deviceType) < 0) {
                    throw new errors_1.DeviceErrors.InvalidDeviceType();
                }
                else {
                    let deviceState = deviceObj.deviceState;
                    if (reportStateData.getUpdateType() == device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_FAN_UPDATE ||
                        reportStateData.getUpdateType() == device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_BOTH_UPDATE) {
                        deviceState.fanState = reportStateData.getFanState();
                    }
                    if (reportStateData.getUpdateType() == device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_LIGHT_UPDATE ||
                        reportStateData.getUpdateType() == device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_BOTH_UPDATE) {
                        deviceState.lightState = reportStateData.getLightState();
                    }
                    deviceObj.deviceState = deviceState;
                    deviceObj.lastUpdateBy = phone;
                    deviceObj.lastUpdateSource = system_constants_1.UpdateSourceMapping.MANUAL;
                    deviceObj.lastUpdateTime = reportStateData.getActivityTime();
                    deviceObj.lastUpdateUser = system_constants_1.SystemUser;
                    let roomDetails = await keus_home_1.default.getRoomById(deviceObj.deviceRoom);
                    let activityObj = await activity_utils_1.getDeviceActivityObj(user, deviceObj, roomDetails, reportStateData, {
                        activitySource: system_constants_1.UpdateSourceMapping.MANUAL
                    });
                    await keus_activity_1.default.insertActivity(activityObj);
                    await keus_device_1.default.updateDevice(deviceObj.deviceId, deviceObj);
                    //-----------------------Update AC Fan Controller State Event--------------------------------
                    console.log('Throwing AC Fan Event');
                    const AcFanControllerEvent = new zigbee_ac_fan_controller_pb_1.ZigbeeACFanControllerEvent();
                    const acFanState = new zigbee_ac_fan_controller_pb_1.UpdateZigbeeACFanControllerState();
                    acFanState.setDeviceId(reportStateData.getDeviceId());
                    acFanState.setUpdateType(reportStateData.getUpdateType());
                    acFanState.setFanState(reportStateData.getFanState());
                    acFanState.setLightState(reportStateData.getLightState());
                    AcFanControllerEvent.setUpdateState(acFanState);
                    AcFanControllerEvent.setActivitySource(system_constants_1.UpdateSourceMapping.MANUAL);
                    AcFanControllerEvent.setActivityUser(phone);
                    AcFanControllerEvent.setActivityTime(deviceObj.lastUpdateTime);
                    const eventArg = general_1.PackIntoAny(AcFanControllerEvent.serializeBinary(), eventType);
                    local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                    cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                    resolve(response_1.default.getUpdateSuccessful());
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_2.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getDeviceNotFound());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map