"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_dc_fan_controller_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const keus_activity_1 = __importDefault(require("../../../../../../models/database-models/keus-activity"));
const activity_structures_pb_1 = require("../../../../protos/generated/hub/activity/activity_structures_pb");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const activity_utils_1 = require("../../../../../../utilities/gateway/activity-utils");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_home_2 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const local_client_1 = require("../../../../local-client");
const cloud_client_1 = require("../../../../cloud-client");
const reqType = system_constants_1.ProtoPackageName + '.UpdateZigbeeDCFanControllerState';
const eventType = system_constants_1.ProtoPackageName + '.ZigbeeDCFanControllerEvent';
exports.default = async (reportStateData, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                const deviceObj = await keus_device_1.default.getDeviceById(reportStateData.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkAccessForUser(user, deviceObj.deviceRoom);
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER').deviceTypesList;
                if (!deviceObj) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                if (arrayList.indexOf(deviceObj.deviceType) < 0) {
                    throw new errors_1.DeviceErrors.InvalidDeviceType();
                }
                else {
                    let deviceProperties = deviceObj.deviceProperties;
                    let deviceState = deviceObj.deviceState;
                    if (reportStateData.getUpdateType() == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_FAN_UPDATE ||
                        reportStateData.getUpdateType() == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_BOTH_UPDATE) {
                        deviceState.fanState = reportStateData.getFanState();
                    }
                    if (reportStateData.getUpdateType() == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_LIGHT_UPDATE ||
                        reportStateData.getUpdateType() == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_BOTH_UPDATE) {
                        let lightState = reportStateData.getLightState();
                        deviceState.lightState = lightState.getLightState();
                        deviceState.lightTemperature = lightState.getLightTemperature();
                    }
                    deviceObj.deviceState = deviceState;
                    deviceObj.lastUpdateBy = phone;
                    deviceObj.lastUpdateSource = system_constants_1.UpdateSourceMapping.MANUAL;
                    deviceObj.lastUpdateTime = reportStateData.getActivityTime();
                    deviceObj.lastUpdateUser = system_constants_1.SystemUser;
                    await keus_device_1.default.updateDevice(deviceObj.deviceId, deviceObj);
                    let roomDetails = await keus_home_2.default.getRoomById(deviceObj.deviceRoom);
                    let activityObj = await activity_utils_1.getDeviceActivityObj(user, deviceObj, roomDetails, reportStateData, {
                        activitySource: system_constants_1.UpdateSourceMapping.SYSTEM
                    });
                    await keus_activity_1.default.insertActivity(activityObj);
                    //-----------------------Update DC Fan Controller State Event--------------------------------
                    console.log('Throwing DC Fan Event');
                    const DcFanControllerEvent = new zigbee_dc_fan_controller_pb_1.ZigbeeDCFanControllerEvent();
                    const dcFanState = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerState();
                    dcFanState.setDeviceId(reportStateData.getDeviceId());
                    dcFanState.setUpdateType(reportStateData.getUpdateType());
                    dcFanState.setFanState(reportStateData.getFanState());
                    dcFanState.setLightState(reportStateData.getLightState());
                    DcFanControllerEvent.setUpdateState(dcFanState);
                    DcFanControllerEvent.setActivitySource(system_constants_1.UpdateSourceMapping.MANUAL);
                    DcFanControllerEvent.setActivityUser(phone);
                    DcFanControllerEvent.setActivityTime(deviceObj.lastUpdateTime);
                    const eventArg = general_1.PackIntoAny(DcFanControllerEvent.serializeBinary(), eventType);
                    local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                    cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                    resolve(response_1.default.getUpdateSuccessful());
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getDeviceNotFound());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
async function getActivityObj(deviceObj, updateStateData) {
    let roomDetails = await keus_home_1.default.getRoomById(deviceObj.deviceRoom);
    let sectionDetails = roomDetails.sectionList.find(section => section.sectionId == deviceObj.deviceSection);
    let dcFanActivityAction = {
        fanState: 0,
        lightState: 0,
        lightTemperature: 0
    };
    switch (updateStateData.getUpdateType()) {
        case device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_FAN_UPDATE:
            dcFanActivityAction.fanState = updateStateData.getFanState();
            delete dcFanActivityAction.lightState;
            delete dcFanActivityAction.lightTemperature;
            break;
        case device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_LIGHT_UPDATE:
            let lightState = updateStateData.getLightState();
            dcFanActivityAction.lightState = lightState.getLightState();
            dcFanActivityAction.lightTemperature = lightState.getLightTemperature();
            delete dcFanActivityAction.fanState;
            break;
    }
    let activityAction = {
        deviceId: deviceObj.deviceId,
        deviceName: deviceObj.deviceName,
        deviceRoom: roomDetails.roomId,
        deviceRoomName: roomDetails.roomName,
        deviceArea: roomDetails.areaId,
        deviceSectionName: sectionDetails.sectionName,
        deviceSection: sectionDetails.sectionId,
        deviceCategory: deviceObj.deviceObj,
        deviceAction: dcFanActivityAction
    };
    let activityObject = {
        activityId: activity_utils_1.generateActivityId(),
        activityBy: 'from permissions',
        activityAction: activityAction,
        activitySource: 'from permissions source',
        activityTime: Date.now(),
        activityUsername: 'from permissions username',
        activityType: activity_structures_pb_1.ACTIVITY_TYPES.DEVICE
    };
    console.log('Ended switch case', activityObject);
    return activityObject;
}
//# sourceMappingURL=index.js.map