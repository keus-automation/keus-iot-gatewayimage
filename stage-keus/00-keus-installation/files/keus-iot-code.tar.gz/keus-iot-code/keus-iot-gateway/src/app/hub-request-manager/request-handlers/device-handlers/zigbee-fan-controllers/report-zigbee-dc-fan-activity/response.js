"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_dc_fan_controller_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class UpdateZigbeeDcFanControllerstateResp {
    static getUpdateSuccessful() {
        const resp = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerStateResponse();
        resp.setCode(800);
        resp.setMessage('update fan state success');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeDcFanControllerstateResp.responseType);
    }
    static getDeviceNotFound() {
        const resp = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerStateResponse();
        resp.setCode(801);
        resp.setMessage('Device not found');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeDcFanControllerstateResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerStateResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeDcFanControllerstateResp.responseType);
    }
    static getSwitchNotFound() {
        const resp = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerStateResponse();
        resp.setCode(802);
        resp.setMessage('switch not found');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeDcFanControllerstateResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerStateResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeDcFanControllerstateResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerStateResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeDcFanControllerstateResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerStateResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateZigbeeDcFanControllerstateResp.responseType);
    }
}
exports.default = UpdateZigbeeDcFanControllerstateResp;
UpdateZigbeeDcFanControllerstateResp.responseType = system_constants_1.ProtoPackageName + '.UpdateZigbeeDCFanControllerStateResponse';
//# sourceMappingURL=response.js.map