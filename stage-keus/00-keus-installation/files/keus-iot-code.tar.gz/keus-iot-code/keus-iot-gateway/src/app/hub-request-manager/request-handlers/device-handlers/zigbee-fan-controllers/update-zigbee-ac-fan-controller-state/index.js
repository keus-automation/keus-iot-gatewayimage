"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_ac_fan_controller_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const keus_activity_1 = __importDefault(require("../../../../../../models/database-models/keus-activity"));
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const activity_utils_1 = require("../../../../../../utilities/gateway/activity-utils");
const metadata_1 = require("../../../../../device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-fans/metadata");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const zigbee_ac_fan_controller_pb_2 = require("../../../../../device-manager/providers/generated/devices/zigbee_ac_fan_controller_pb");
const local_client_1 = require("../../../../local-client");
const device_constants_pb_2 = require("../../../../../device-manager/providers/generated/devices/device_constants_pb");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const cloud_client_1 = require("../../../../cloud-client");
const reqType = system_constants_1.ProtoPackageName + '.UpdateZigbeeACFanControllerState';
const eventType = system_constants_1.ProtoPackageName + '.ZigbeeACFanControllerEvent';
exports.default = async (updateStateData, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                const deviceObj = await keus_device_1.default.getDeviceById(updateStateData.getDeviceId());
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkAccessForUser(user, deviceObj.deviceRoom);
                console.log('THIS SI THE FAN STATE BEING SET', updateStateData.getFanState());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceTypesList;
                var commandId;
                let data = {};
                if (!deviceObj) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                if (arrayList.indexOf(deviceObj.deviceType) < 0) {
                    throw new errors_1.DeviceErrors.InvalidDeviceType();
                }
                else {
                    let deviceState = deviceObj.deviceState;
                    let acFanStateUpdate = new zigbee_ac_fan_controller_pb_2.DMUpdateZigbeeACFanControllerState();
                    let res;
                    acFanStateUpdate.setDeviceId(deviceObj.deviceId);
                    if (updateStateData.getUpdateType() == device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_FAN_UPDATE ||
                        updateStateData.getUpdateType() == device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_BOTH_UPDATE) {
                        commandId = metadata_1.SetLevel.CommandId;
                        console.log('SETTIGN FAN STATE', updateStateData.getFanState());
                        deviceState.fanState = updateStateData.getFanState();
                        data.level = updateStateData.getFanState();
                        acFanStateUpdate.setUpdateType(device_constants_pb_2.DMAC_FAN_CONTROLLER_UPDATE_TYPE.AC_FAN_UPDATE);
                        acFanStateUpdate.setFanState(data.level);
                        ///call zigbee
                        res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(acFanStateUpdate.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMUpdateZigbeeACFanControllerState'));
                        if (!res.getSuccess()) {
                            throw new Error('Error setting fan state');
                        }
                    }
                    if (updateStateData.getUpdateType() == device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_LIGHT_UPDATE ||
                        updateStateData.getUpdateType() == device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_BOTH_UPDATE) {
                        commandId = metadata_1.SetLight.CommandId;
                        deviceState.lightState = updateStateData.getLightState();
                        data.lightState = updateStateData.getLightState();
                        acFanStateUpdate.setUpdateType(device_constants_pb_2.DMAC_FAN_CONTROLLER_UPDATE_TYPE.AC_LIGHT_UPDATE);
                        acFanStateUpdate.setLightState(data.lightState);
                        res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(acFanStateUpdate.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMUpdateZigbeeACFanControllerState'));
                        if (!res.getSuccess()) {
                            throw new Error('Error setting fan state');
                        }
                    }
                    deviceObj.deviceState = deviceState;
                    deviceObj.lastUpdateBy = phone;
                    deviceObj.lastUpdateSource = system_constants_1.UpdateSourceMapping.ANDROID;
                    deviceObj.lastUpdateTime = Date.now();
                    deviceObj.lastUpdateUser = user.userName;
                    let roomDetails = await keus_home_1.default.getRoomById(deviceObj.deviceRoom);
                    let activityObj = await activity_utils_1.getDeviceActivityObj(user, deviceObj, roomDetails, updateStateData, {
                        activitySource: system_constants_1.UpdateSourceMapping.ANDROID
                    });
                    await keus_activity_1.default.insertActivity(activityObj);
                    await keus_device_1.default.updateDevice(deviceObj.deviceId, deviceObj);
                    //-----------------------Update AC Fan Controller State Event--------------------------------
                    const AcFanControllerEvent = new zigbee_ac_fan_controller_pb_1.ZigbeeACFanControllerEvent();
                    AcFanControllerEvent.setUpdateState(updateStateData);
                    AcFanControllerEvent.setActivitySource(system_constants_1.UpdateSourceMapping.ANDROID);
                    AcFanControllerEvent.setActivityUser(phone);
                    AcFanControllerEvent.setActivityTime(deviceObj.lastUpdateTime);
                    const eventArg = general_1.PackIntoAny(AcFanControllerEvent.serializeBinary(), eventType);
                    local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                    cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                    resolve(response_1.default.getUpdateSuccessful());
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_2.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getDeviceNotFound());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map