"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_inline_dimmer_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_inline_dimmer_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class ConfigureZigbeeInlineDimmerResp {
    static getConfigureSuccessful() {
        const resp = new zigbee_inline_dimmer_pb_1.ConfigureZigbeeInlineDimmerResponse();
        resp.setCode(800);
        resp.setMessage('configure successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeInlineDimmerResp.responseType);
    }
    static getDeviceNotFound() {
        const resp = new zigbee_inline_dimmer_pb_1.ConfigureZigbeeInlineDimmerResponse();
        resp.setCode(801);
        resp.setMessage('Device not found');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeInlineDimmerResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_inline_dimmer_pb_1.ConfigureZigbeeInlineDimmerResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeInlineDimmerResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_inline_dimmer_pb_1.ConfigureZigbeeInlineDimmerResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeInlineDimmerResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_inline_dimmer_pb_1.ConfigureZigbeeInlineDimmerResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeInlineDimmerResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_inline_dimmer_pb_1.ConfigureZigbeeInlineDimmerResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeInlineDimmerResp.responseType);
    }
}
exports.default = ConfigureZigbeeInlineDimmerResp;
ConfigureZigbeeInlineDimmerResp.responseType = system_constants_1.ProtoPackageName + '.ConfigureZigbeeInlineDimmerResponse';
//# sourceMappingURL=response.js.map