"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const zigbee_ir_blaster_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_ir_blaster_pb");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const DeviceUtils = __importStar(require("../../../../../../utilities/gateway/device-utils"));
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../../errors/errors");
const fs = __importStar(require("fs"));
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const gateway_to_cloud_pb_1 = require("../../../../protos/generated/cloud/gateway_to_cloud_pb");
const rpc_maker_util_1 = require("../../../../../../utilities/gateway/rpc-maker-util");
const general_errors_1 = require("../../../../../../errors/general-errors");
const node_fetch_1 = __importDefault(require("node-fetch"));
const keus_ir_remote_1 = __importDefault(require("../../../../../../models/database-models/keus-ir-remote"));
const proto_utils_1 = require("../../../../../../utilities/gateway/proto-utils");
const multigateway_1 = __importDefault(require("../../../../../../configs/multigateway"));
const local_client_1 = require("../../../../local-client");
exports.default = async (addRemoteToZIRBReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                // await checkUserIsAdmin(user);
                if (!addRemoteToZIRBReq.getIrDevice()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(addRemoteToZIRBReq.getIrDevice());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_IR_BLASTER').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        const remoteId = DeviceUtils.generateIRRemoteId();
                        const fileName = addRemoteToZIRBReq.getCompanyId() + '_' + addRemoteToZIRBReq.getModelId() + '.' + multigateway_1.default.irFilesExt;
                        console.log("\n\n------------------------------------------");
                        console.log(multigateway_1.default);
                        console.log(fileName);
                        const fileId = addRemoteToZIRBReq.getModelId() + '_' + addRemoteToZIRBReq.getCompanyId();
                        var filePath = '';
                        switch (addRemoteToZIRBReq.getRemoteType()) {
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                                filePath = multigateway_1.default.irFilesPath + 'ac/' + fileName;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                                filePath = multigateway_1.default.irFilesPath + 'tv/' + fileName;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                                filePath = multigateway_1.default.irFilesPath + 'amp/' + fileName;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                                filePath = multigateway_1.default.irFilesPath + 'pr/' + fileName;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                                filePath = multigateway_1.default.irFilesPath + 'fan/' + fileName;
                                break;
                        }
                        const fileExists = fs.existsSync(filePath);
                        //File download required
                        if (addRemoteToZIRBReq.getForceDownload() || !fileExists) {
                            const getRemoteFileLinkReq = new gateway_to_cloud_pb_1.GetRemoteFileLink();
                            console.log(fileId, addRemoteToZIRBReq.getCompanyId(), addRemoteToZIRBReq.getModelId());
                            getRemoteFileLinkReq.setRemoteType(addRemoteToZIRBReq.getRemoteType());
                            getRemoteFileLinkReq.setId(fileId);
                            const remoteFileLinkResp = await rpc_maker_util_1.MakeAuthCloudRpc(general_1.PackIntoAny(getRemoteFileLinkReq.serializeBinary(), system_constants_1.ProtoCloudPackageName + '.GetRemoteFileLink'));
                            if (!remoteFileLinkResp.getSuccess()) {
                                console.log(remoteFileLinkResp);
                                throw new general_errors_1.RpcResponseFalseError(remoteFileLinkResp.getMessage());
                            }
                            else {
                                try {
                                    const remoteFileLink = remoteFileLinkResp.getRemoteLink();
                                    console.log('THIS IS REMOTE LINK', remoteFileLink);
                                    if (fileExists) {
                                        fs.unlinkSync(filePath);
                                    }
                                    await downloadFile(remoteFileLink, filePath);
                                }
                                catch (err) {
                                    console.log(err);
                                }
                            }
                        }
                        //File exists/downloaded
                        //DO the zigbee stuff here
                        const zigbeeRequest = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlaster();
                        zigbeeRequest.setCompanyId(addRemoteToZIRBReq.getCompanyId());
                        zigbeeRequest.setModelId(addRemoteToZIRBReq.getModelId());
                        zigbeeRequest.setRemoteType(addRemoteToZIRBReq.getRemoteType());
                        zigbeeRequest.setRemoteName(addRemoteToZIRBReq.getRemoteName());
                        zigbeeRequest.setIrDevice(addRemoteToZIRBReq.getIrDevice());
                        zigbeeRequest.setForceDownload(addRemoteToZIRBReq.getForceDownload());
                        let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(zigbeeRequest.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.AddRemoteToZigbeeIRBlaster'));
                        if (!res.hasRemote()) {
                            throw new errors_1.DeviceErrors.RemoteCreationFailed();
                        }
                        const remoteProto = res.getRemote();
                        var remoteState, remoteProperties;
                        switch (addRemoteToZIRBReq.getRemoteType()) {
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                                const acPropsProto = remoteProto.getAcProperties();
                                const acProps = {
                                    temperatureRange: acPropsProto.getTemperatureRangeList(),
                                    swingHEnabled: acPropsProto.getSwingHEnabled(),
                                    swingHSelectType: acPropsProto.getSwingHSelectType(),
                                    swingHOptions: acPropsProto.getSwingHOptionsList(),
                                    swingVEnabled: acPropsProto.getSwingVEnabled(),
                                    swingVSelectType: acPropsProto.getSwingVSelectType(),
                                    swingVOptions: acPropsProto.getSwingVOptionsList(),
                                    modeEnabled: acPropsProto.getModeEnabled(),
                                    modeSelectType: acPropsProto.getModeSelectType(),
                                    modeOptions: acPropsProto.getModeOptionsList(),
                                    fanEnabled: acPropsProto.getFanEnabled(),
                                    fanSelectType: acPropsProto.getFanSelectType(),
                                    fanOptions: acPropsProto.getFanOptionsList()
                                };
                                const acState = {
                                    powerOn: false,
                                    temperature: acProps.temperatureRange[0],
                                    swingHLevel: acProps.swingHEnabled ? acProps.swingHOptions[0] : null,
                                    swingVLevel: acProps.swingVEnabled ? acProps.swingVOptions[0] : null,
                                    mode: acProps.modeEnabled ? acProps.modeOptions[0] : null,
                                    fanLevel: acProps.fanEnabled ? acProps.fanOptions[0] : null
                                };
                                remoteProperties = acProps;
                                remoteState = acState;
                                console.log(acProps, acState, remoteProperties, remoteState);
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                                const tvPropsProto = remoteProto.getTvProperties();
                                const tvProps = {
                                    sourceEnabled: tvPropsProto.getSourceEnabled(),
                                    sourceSelectType: tvPropsProto.getSourceSelectType(),
                                    sourceOptions: tvPropsProto.getSourceOptionsList(),
                                    modeEnabled: tvPropsProto.getModeEnabled(),
                                    modeSelectType: tvPropsProto.getModeSelectType(),
                                    modeOptions: tvPropsProto.getModeOptionsList()
                                };
                                const tvState = {};
                                remoteProperties = tvProps;
                                remoteState = tvState;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                                const ampPropsProto = remoteProto.getAmpProperties();
                                const ampProps = {
                                    sourceEnabled: ampPropsProto.getSourceEnabled(),
                                    sourceSelectType: ampPropsProto.getSourceSelectType(),
                                    sourceOptions: ampPropsProto.getSourceOptionsList(),
                                    modeEnabled: ampPropsProto.getModeEnabled(),
                                    modeSelectType: ampPropsProto.getModeSelectType(),
                                    modeOptions: ampPropsProto.getModeOptionsList()
                                };
                                const ampState = {};
                                remoteProperties = ampProps;
                                remoteState = ampState;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                                const prPropsProto = remoteProto.getPrProperties();
                                const prProps = {
                                    sourceEnabled: prPropsProto.getSourceEnabled(),
                                    sourceSelectType: prPropsProto.getSourceSelectType(),
                                    sourceOptions: prPropsProto.getSourceOptionsList(),
                                    modeEnabled: prPropsProto.getModeEnabled(),
                                    modeSelectType: prPropsProto.getModeSelectType(),
                                    modeOptions: prPropsProto.getModeOptionsList()
                                };
                                const prState = {};
                                remoteProperties = prProps;
                                remoteState = prState;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                                const fanPropsProto = remoteProto.getFanProperties();
                                const fanProps = {
                                    speedSelectType: fanPropsProto.getSpeedSelectType(),
                                    speedOptions: fanPropsProto.getSpeedOptionsList(),
                                    modeEnabled: fanPropsProto.getModeEnabled(),
                                    modeSelectType: fanPropsProto.getModeSelectType(),
                                    modeOptions: fanPropsProto.getModeOptionsList(),
                                    ledEnabled: fanPropsProto.getLedEnabled()
                                };
                                const fanState = {
                                    powerOn: false,
                                    speedLevel: fanProps.speedOptions[0],
                                    mode: fanProps.modeEnabled ? fanProps.modeOptions[0] : null,
                                    ledState: fanProps.ledEnabled ? 0 : null
                                };
                                remoteProperties = fanProps;
                                remoteState = fanState;
                                break;
                        }
                        const irRemote = {
                            remoteId: remoteId,
                            remoteType: addRemoteToZIRBReq.getRemoteType(),
                            companyId: addRemoteToZIRBReq.getCompanyId(),
                            modelId: addRemoteToZIRBReq.getModelId(),
                            remoteName: addRemoteToZIRBReq.getRemoteName(),
                            irDevice: addRemoteToZIRBReq.getIrDevice(),
                            lastUpdateTime: Date.now(),
                            lastUpdateBy: system_constants_1.SystemNumber,
                            lastUpdateSource: system_constants_1.UpdateSourceMapping.SYSTEM,
                            lastUpdateUser: system_constants_1.SystemNumber,
                            remoteProperties: remoteProperties,
                            remoteState: remoteState
                        };
                        await keus_ir_remote_1.default.insertIRRemote(irRemote);
                        resolve(response_1.default.getAddIRRemoteSuccessful(proto_utils_1.DeviceProtoUtils.getIRRemoteProto(irRemote)));
                    }
                }
            }
            catch (e) {
                console.log('THIS SI ERROR', e);
                switch (e) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.DeviceErrors.RemoteCreationFailed:
                        resolve(response_1.default.getRemoteCreationFailed());
                        break;
                    case errors_1.GeneralErrors.RpcMakerError:
                        resolve(response_1.default.getConnectionError());
                        break;
                    case errors_1.GeneralErrors.RpcResponseFalseError:
                        resolve(response_1.default.getCloudRpcError(e.message));
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
async function downloadFile(url, downloadPath) {
    const res = await node_fetch_1.default(url);
    await new Promise((resolve, reject) => {
        const fileStream = fs.createWriteStream(downloadPath);
        res.body.pipe(fileStream);
        res.body.on('error', err => {
            reject(err);
        });
        fileStream.on('finish', function () {
            resolve();
        });
    });
}
//# sourceMappingURL=index.js.map