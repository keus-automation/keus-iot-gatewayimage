"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_ir_blaster_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_ir_blaster_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class AddRemoteToZigbeeIRBlasterResp {
    static getAddIRRemoteSuccessful(IRRemote) {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        resp.setCode(800);
        resp.setMessage('Create Area Successful');
        resp.setSuccess(true);
        resp.setRemote(IRRemote);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
    static getRemoteCreationFailed() {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        resp.setCode(803);
        resp.setMessage('Remote Creation Failed');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
    static getGatewayNotRegisteredToCloud() {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        resp.setCode(804);
        resp.setMessage('Get Gateway Not Registered To Cloud');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
    static getCloudRpcError(cloudmsg) {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        resp.setCode(805);
        resp.setMessage(cloudmsg);
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
    static getConnectionError() {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        resp.setCode(806);
        resp.setMessage('Connection Error');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_ir_blaster_pb_1.AddRemoteToZigbeeIRBlasterResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddRemoteToZigbeeIRBlasterResp.responseType);
    }
}
exports.default = AddRemoteToZigbeeIRBlasterResp;
AddRemoteToZigbeeIRBlasterResp.responseType = system_constants_1.ProtoPackageName + '.AddRemoteToZigbeeIRBlasterResponse';
//# sourceMappingURL=response.js.map