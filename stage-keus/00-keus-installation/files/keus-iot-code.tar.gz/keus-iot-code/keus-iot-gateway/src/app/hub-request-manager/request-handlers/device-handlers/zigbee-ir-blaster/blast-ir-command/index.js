"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const zigbee_ir_blaster_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_ir_blaster_pb");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../../errors/errors");
const keus_ir_remote_1 = __importDefault(require("../../../../../../models/database-models/keus-ir-remote"));
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const local_client_1 = require("../../../../local-client");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
exports.default = async (blastIRCommandReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                // await checkUserIsAdmin(user);
                if (!blastIRCommandReq.getRemoteId()) {
                    throw new errors_1.DeviceErrors.InvalidRemoteId();
                }
                else {
                    const irRemote = await keus_ir_remote_1.default.getIRRemoteById(blastIRCommandReq.getRemoteId());
                    if (!irRemote) {
                        throw new errors_1.DeviceErrors.InvalidRemoteId();
                    }
                    else {
                        const device = await keus_device_1.default.getDeviceById(irRemote.irDevice);
                        if (!device) {
                            throw new errors_1.DeviceErrors.InvalidDeviceId();
                        }
                        else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_IR_BLASTER').deviceCategoryCode) {
                            throw new errors_1.DeviceErrors.InvalidDeviceType();
                        }
                        else {
                            // Send the zigbee blast command here
                            const zigbeeRequest = new zigbee_ir_blaster_pb_1.DMBlastIRCommand();
                            zigbeeRequest.setCompanyId(irRemote.companyId);
                            zigbeeRequest.setModelId(irRemote.modelId);
                            zigbeeRequest.setIrDevice(irRemote.irDevice);
                            zigbeeRequest.setRemoteType(blastIRCommandReq.getRemoteType());
                            var deviceState;
                            let res;
                            switch (irRemote.remoteType) {
                                case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                                    const acDeviceState = irRemote.remoteState;
                                    const acDeviceProperties = irRemote.remoteProperties;
                                    const zigbeeAcBlast = new zigbee_ir_blaster_pb_1.IRACBlast();
                                    zigbeeAcBlast.setUpdateType(blastIRCommandReq.getAcBlastInfo().getUpdateType());
                                    zigbeeAcBlast.setPowerOn(blastIRCommandReq.getAcBlastInfo().getPowerOn());
                                    zigbeeAcBlast.setTemperature(blastIRCommandReq.getAcBlastInfo().getTemperature());
                                    zigbeeAcBlast.setSwingHLevel(blastIRCommandReq.getAcBlastInfo().getSwingHLevel());
                                    zigbeeAcBlast.setSwingVLevel(blastIRCommandReq.getAcBlastInfo().getSwingVLevel());
                                    zigbeeAcBlast.setMode(blastIRCommandReq.getAcBlastInfo().getMode());
                                    zigbeeAcBlast.setFanLevel(blastIRCommandReq.getAcBlastInfo().getFanLevel());
                                    zigbeeRequest.setAcBlastInfo(zigbeeAcBlast);
                                    res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(zigbeeRequest.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMBlastIRCommand'));
                                    console.log('Zigbee call completed');
                                    acDeviceState.powerOn = blastIRCommandReq.getAcBlastInfo().getPowerOn();
                                    acDeviceState.temperature = blastIRCommandReq.getAcBlastInfo().getTemperature();
                                    acDeviceState.swingHLevel = acDeviceProperties.swingHEnabled
                                        ? blastIRCommandReq.getAcBlastInfo().getSwingHLevel()
                                        : null;
                                    acDeviceState.swingVLevel = acDeviceProperties.swingVEnabled
                                        ? blastIRCommandReq.getAcBlastInfo().getSwingVLevel()
                                        : null;
                                    acDeviceState.mode = acDeviceProperties.modeEnabled
                                        ? blastIRCommandReq.getAcBlastInfo().getMode()
                                        : null;
                                    acDeviceState.fanLevel = acDeviceProperties.fanEnabled
                                        ? blastIRCommandReq.getAcBlastInfo().getFanLevel()
                                        : null;
                                    deviceState = acDeviceState;
                                    break;
                                case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                                    const zigbeeTvBlast = new zigbee_ir_blaster_pb_1.IRTVBlast();
                                    zigbeeTvBlast.setUpdateType(blastIRCommandReq.getTvBlastInfo().getUpdateType());
                                    zigbeeTvBlast.setPowerOn(blastIRCommandReq.getTvBlastInfo().getPowerOn());
                                    zigbeeTvBlast.setChannelNumber(blastIRCommandReq.getTvBlastInfo().getChannelNumber());
                                    zigbeeTvBlast.setMode(blastIRCommandReq.getTvBlastInfo().getMode());
                                    zigbeeTvBlast.setSource(blastIRCommandReq.getTvBlastInfo().getSource());
                                    zigbeeRequest.setTvBlastInfo(zigbeeTvBlast);
                                    res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(zigbeeRequest.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMBlastIRCommand'));
                                    const tvDeviceState = irRemote.remoteState;
                                    deviceState = tvDeviceState;
                                    break;
                                case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                                    const zigbeePrBlast = new zigbee_ir_blaster_pb_1.IRPRBlast();
                                    zigbeePrBlast.setUpdateType(blastIRCommandReq.getPrBlastInfo().getUpdateType());
                                    zigbeePrBlast.setPowerOn(blastIRCommandReq.getPrBlastInfo().getPowerOn());
                                    zigbeePrBlast.setMode(blastIRCommandReq.getPrBlastInfo().getMode());
                                    zigbeePrBlast.setSource(blastIRCommandReq.getPrBlastInfo().getSource());
                                    zigbeeRequest.setPrBlastInfo(zigbeePrBlast);
                                    res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(zigbeeRequest.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMBlastIRCommand'));
                                    const prDeviceState = irRemote.remoteState;
                                    deviceState = prDeviceState;
                                    break;
                                case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                                    const zigbeeAmpBlast = new zigbee_ir_blaster_pb_1.IRAMPBlast();
                                    zigbeeAmpBlast.setUpdateType(blastIRCommandReq.getAmpBlastInfo().getUpdateType());
                                    zigbeeAmpBlast.setPowerOn(blastIRCommandReq.getAmpBlastInfo().getPowerOn());
                                    zigbeeAmpBlast.setMode(blastIRCommandReq.getAmpBlastInfo().getMode());
                                    zigbeeAmpBlast.setSource(blastIRCommandReq.getAmpBlastInfo().getSource());
                                    zigbeeRequest.setAmpBlastInfo(zigbeeAmpBlast);
                                    res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(zigbeeRequest.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMBlastIRCommand'));
                                    const ampDeviceState = irRemote.remoteState;
                                    deviceState = ampDeviceState;
                                    break;
                                case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                                    const zigbeeFanBlast = new zigbee_ir_blaster_pb_1.IRFANBlast();
                                    zigbeeFanBlast.setUpdateType(blastIRCommandReq.getFanBlastInfo().getUpdateType());
                                    zigbeeFanBlast.setPowerOn(blastIRCommandReq.getFanBlastInfo().getPowerOn());
                                    zigbeeFanBlast.setMode(blastIRCommandReq.getFanBlastInfo().getMode());
                                    zigbeeFanBlast.setSpeedLevel(blastIRCommandReq.getFanBlastInfo().getSpeedLevel());
                                    zigbeeFanBlast.setLedState(blastIRCommandReq.getFanBlastInfo().getLedState());
                                    zigbeeRequest.setFanBlastInfo(zigbeeFanBlast);
                                    res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(zigbeeRequest.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMBlastIRCommand'));
                                    const fanDeviceState = irRemote.remoteState;
                                    const fanDeviceProperties = irRemote.remoteProperties;
                                    fanDeviceState.powerOn = blastIRCommandReq.getFanBlastInfo().getPowerOn();
                                    fanDeviceState.speedLevel = blastIRCommandReq.getFanBlastInfo().getSpeedLevel();
                                    fanDeviceState.mode = fanDeviceProperties.modeEnabled
                                        ? blastIRCommandReq.getFanBlastInfo().getMode()
                                        : null;
                                    fanDeviceState.ledState = fanDeviceProperties.ledEnabled
                                        ? blastIRCommandReq.getFanBlastInfo().getLedState()
                                        : null;
                                    deviceState = fanDeviceState;
                                    break;
                                default:
                                    throw new errors_1.DeviceErrors.InvalidRemoteType();
                            }
                            await keus_ir_remote_1.default.updateIRRemoteState(irRemote.remoteId, deviceState);
                            resolve(response_1.default.getBlastCommandSuccessful());
                            //Add activity log here
                            //Add events here
                        }
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.DeviceErrors.InvalidRemoteId:
                        resolve(response_1.default.getInvalidRemoteId());
                        break;
                    case errors_1.DeviceErrors.InvalidRemoteType:
                        resolve(response_1.default.getInvalidRemoteType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map