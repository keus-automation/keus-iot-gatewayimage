"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_ir_blaster_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_ir_blaster_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class BlastIRCommandResp {
    static getBlastCommandSuccessful() {
        const resp = new zigbee_ir_blaster_pb_1.BlastIRCommandResponse();
        resp.setCode(800);
        resp.setMessage('Blast Command Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), BlastIRCommandResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new zigbee_ir_blaster_pb_1.BlastIRCommandResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), BlastIRCommandResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_ir_blaster_pb_1.BlastIRCommandResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), BlastIRCommandResp.responseType);
    }
    static getInvalidRemoteId() {
        const resp = new zigbee_ir_blaster_pb_1.BlastIRCommandResponse();
        resp.setCode(803);
        resp.setMessage('Invalid Remote Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), BlastIRCommandResp.responseType);
    }
    static getInvalidRemoteType() {
        const resp = new zigbee_ir_blaster_pb_1.BlastIRCommandResponse();
        resp.setCode(802);
        resp.setMessage('Invalid remote type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), BlastIRCommandResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_ir_blaster_pb_1.BlastIRCommandResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), BlastIRCommandResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_ir_blaster_pb_1.BlastIRCommandResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), BlastIRCommandResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_ir_blaster_pb_1.BlastIRCommandResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), BlastIRCommandResp.responseType);
    }
}
exports.default = BlastIRCommandResp;
BlastIRCommandResp.responseType = system_constants_1.ProtoPackageName + '.BlastIRCommandResponse';
//# sourceMappingURL=response.js.map