"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
exports.default = async (configureZIRBReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!configureZIRBReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const device = await keus_device_1.default.getDeviceById(configureZIRBReq.getDeviceId());
                    if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else if (device.deviceCategory != device_categories_1.default.get('KEUS_ZIGBEE_IR_BLASTER').deviceCategoryCode) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else {
                        //-----------------------Zigbee Call to Configure IRBlaster--------------------------------
                        // let irbConfigUpdate = new DMConfigureZigbeeIRBlaster();
                        // irbConfigUpdate.setDeviceId(device.deviceId);
                        // irbConfigUpdate.setBlastSignalDelay(configureZIRBReq.getBlastSignalDelay());
                        // let res: DMConfigureZigbeeIRBlasterResponse = await GatewayProvidersManager.makeRPC(
                        //     DeviceManager.DeviceManagerGatewayServicePrefix,
                        //     PackIntoAny(
                        //         irbConfigUpdate.serializeBinary(),
                        //         DeviceManager.ProtoPackageName + '.DMConfigureZigbeeIRBlaster'
                        //     )
                        // );
                        // if (!res.getSuccess()) {
                        //     throw new Error('Error configuring IRBlaster ');
                        // }
                        let deviceProperties = device.deviceProperties;
                        deviceProperties.blastSignalDelay = configureZIRBReq.getBlastSignalDelay();
                        device.isHidden = configureZIRBReq.getIsHidden();
                        device.isConfigured = true;
                        device.deviceName = configureZIRBReq.getDeviceName()
                            ? configureZIRBReq.getDeviceName()
                            : device.deviceName;
                        device.deviceLocation = configureZIRBReq.getDeviceLocation()
                            ? configureZIRBReq.getDeviceLocation()
                            : device.deviceLocation;
                        device.deviceProperties = deviceProperties;
                        await keus_device_1.default.updateDevice(device.deviceId, device);
                        resolve(response_1.default.getConfigureSuccessful());
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map