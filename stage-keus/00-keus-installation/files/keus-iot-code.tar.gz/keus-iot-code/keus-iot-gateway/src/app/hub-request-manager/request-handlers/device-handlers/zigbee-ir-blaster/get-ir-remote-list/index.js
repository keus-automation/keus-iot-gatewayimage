"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_ir_blaster_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_ir_blaster_pb");
const gateway_to_cloud_pb_1 = require("../../../../protos/generated/cloud/gateway_to_cloud_pb");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const rpc_maker_util_1 = require("../../../../../../utilities/gateway/rpc-maker-util");
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_errors_1 = require("../../../../../../errors/general-errors");
exports.default = async (getRemoteListReq, userPhone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                // await checkUserIsAdmin(userPhone);
                const getRemoteList = new gateway_to_cloud_pb_1.GetRemoteList();
                getRemoteList.setRemoteType(getRemoteListReq.getRemoteType());
                const getRemoteListResp = await rpc_maker_util_1.MakeAuthCloudRpc(general_1.PackIntoAny(getRemoteList.serializeBinary(), system_constants_1.ProtoCloudPackageName + '.GetRemoteList'));
                console.log('THIS IS REMOTE LSIT RESP', getRemoteListResp.getSuccess(), getRemoteListResp.getMessage());
                if (!getRemoteListResp.getSuccess()) {
                    throw new general_errors_1.RpcResponseFalseError(getRemoteListResp.getMessage());
                }
                else {
                    const IRRemList = new Array();
                    getRemoteListResp.getRemotesList().forEach(function (irRemote) {
                        const clIRRem = new zigbee_ir_blaster_pb_1.CloudIRRemote();
                        clIRRem.setCompanyId(irRemote.getCompanyId());
                        clIRRem.setCompanyName(irRemote.getCompanyName());
                        clIRRem.setModelId(irRemote.getModelId());
                        clIRRem.setModelName(irRemote.getModelName());
                        clIRRem.setId(irRemote.getId());
                        IRRemList.push(clIRRem);
                    });
                    final_resp = response_1.default.getGetIRRemoteListSuccessful(IRRemList);
                }
            }
            catch (e) {
                console.log('THIS IS ERROR', e);
                switch (e.constructor) {
                    case errors_1.GeneralErrors.RpcMakerError:
                        final_resp = response_1.default.getConnectionError();
                        break;
                    case errors_1.GeneralErrors.RpcResponseFalseError:
                        final_resp = response_1.default.getCloudRpcError(e.message);
                        break;
                    default:
                        final_resp = response_1.default.getInternalServerError();
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map