"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const zigbee_ir_blaster_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_ir_blaster_pb");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const keus_ir_remote_1 = __importDefault(require("../../../../../../models/database-models/keus-ir-remote"));
const keus_scene_1 = __importDefault(require("../../../../../../models/database-models/keus-scene"));
const local_client_1 = require("../../../../local-client");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
exports.default = async (deleteRemoteFromZIRBReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!deleteRemoteFromZIRBReq.getRemoteId()) {
                    throw new errors_1.DeviceErrors.InvalidRemoteId();
                }
                else {
                    const irRemote = await keus_ir_remote_1.default.getIRRemoteById(deleteRemoteFromZIRBReq.getRemoteId());
                    if (!irRemote) {
                        throw new errors_1.DeviceErrors.InvalidRemoteId();
                    }
                    else {
                        //Make Zigbee call here - try catch and check for force delete
                        const zRemoveRemoteFromIRBlasterReq = new zigbee_ir_blaster_pb_1.DMRemoveRemoteFromZigbeeIRBlaster();
                        zRemoveRemoteFromIRBlasterReq.setCompanyId(irRemote.companyId);
                        zRemoveRemoteFromIRBlasterReq.setIrDevice(irRemote.irDevice);
                        zRemoveRemoteFromIRBlasterReq.setModelId(irRemote.modelId);
                        zRemoveRemoteFromIRBlasterReq.setRemoteType(irRemote.remoteType);
                        zRemoveRemoteFromIRBlasterReq.setForceDelete(deleteRemoteFromZIRBReq.getForceDelete());
                        let zRemoveRemoteFromIRBlasterRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(zRemoveRemoteFromIRBlasterReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveRemoteFromZigbeeIRBlaster'));
                        console.log(zRemoveRemoteFromIRBlasterRsp.getSuccess(), zRemoveRemoteFromIRBlasterRsp.getMessage(), zRemoveRemoteFromIRBlasterRsp.getCode());
                        if (!zRemoveRemoteFromIRBlasterRsp.getSuccess()) {
                            throw new Error('Failed to remove remote from zigbee');
                        }
                        await keus_scene_1.default.cleanRemoteActionsFromScene(irRemote.remoteId);
                        await keus_ir_remote_1.default.deleteRemoteById(irRemote.remoteId);
                        resolve(response_1.default.getRemoveIRRemoteSuccessful());
                    }
                }
            }
            catch (e) {
                console.log('Error ', e);
                switch (e) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidRemoteId:
                        resolve(response_1.default.getInvalidRemoteId());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map