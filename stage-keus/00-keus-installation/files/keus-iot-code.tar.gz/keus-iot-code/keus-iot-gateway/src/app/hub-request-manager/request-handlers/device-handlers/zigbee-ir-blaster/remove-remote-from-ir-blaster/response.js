"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_ir_blaster_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_ir_blaster_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class RemoveRemoteFromZigbeeIRBlasterResp {
    static getRemoveIRRemoteSuccessful() {
        const resp = new zigbee_ir_blaster_pb_1.RemoveRemoteFromZigbeeIRBlasterResponse();
        resp.setCode(800);
        resp.setMessage('Remove Remote Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), RemoveRemoteFromZigbeeIRBlasterResp.responseType);
    }
    static getInvalidRemoteId() {
        const resp = new zigbee_ir_blaster_pb_1.RemoveRemoteFromZigbeeIRBlasterResponse();
        resp.setCode(803);
        resp.setMessage('Invalid Remote Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RemoveRemoteFromZigbeeIRBlasterResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_ir_blaster_pb_1.RemoveRemoteFromZigbeeIRBlasterResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), RemoveRemoteFromZigbeeIRBlasterResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_ir_blaster_pb_1.RemoveRemoteFromZigbeeIRBlasterResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RemoveRemoteFromZigbeeIRBlasterResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_ir_blaster_pb_1.RemoveRemoteFromZigbeeIRBlasterResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RemoveRemoteFromZigbeeIRBlasterResp.responseType);
    }
}
exports.default = RemoveRemoteFromZigbeeIRBlasterResp;
RemoveRemoteFromZigbeeIRBlasterResp.responseType = system_constants_1.ProtoPackageName + '.RemoveRemoteFromZigbeeIRBlasterResponse';
//# sourceMappingURL=response.js.map