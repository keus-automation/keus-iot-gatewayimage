"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_rgbwwa_driver_pb_1 = require("../../../../protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const response_helper_1 = __importDefault(require("../../../../../../utilities/response-helper"));
const general_1 = require("../../../../../../utilities/general");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
class ConfigureZigbeeRgbwwaResp {
    static getConfigureSuccessful() {
        const resp = new zigbee_rgbwwa_driver_pb_1.ConfigureZigbeeRgbwwaResponse();
        resp.setCode(800);
        resp.setMessage('configure successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeRgbwwaResp.responseType);
    }
    static getDeviceNotFound() {
        const resp = new zigbee_rgbwwa_driver_pb_1.ConfigureZigbeeRgbwwaResponse();
        resp.setCode(801);
        resp.setMessage('Device not found');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeRgbwwaResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new zigbee_rgbwwa_driver_pb_1.ConfigureZigbeeRgbwwaResponse();
        resp.setCode(802);
        resp.setMessage('Invalid device type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeRgbwwaResp.responseType);
    }
    static getInternalServerError() {
        const resp = new zigbee_rgbwwa_driver_pb_1.ConfigureZigbeeRgbwwaResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeRgbwwaResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new zigbee_rgbwwa_driver_pb_1.ConfigureZigbeeRgbwwaResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeRgbwwaResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new zigbee_rgbwwa_driver_pb_1.ConfigureZigbeeRgbwwaResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureZigbeeRgbwwaResp.responseType);
    }
}
exports.default = ConfigureZigbeeRgbwwaResp;
ConfigureZigbeeRgbwwaResp.responseType = system_constants_1.ProtoPackageName + '.ConfigureZigbeeRgbwwaResponse';
//# sourceMappingURL=response.js.map