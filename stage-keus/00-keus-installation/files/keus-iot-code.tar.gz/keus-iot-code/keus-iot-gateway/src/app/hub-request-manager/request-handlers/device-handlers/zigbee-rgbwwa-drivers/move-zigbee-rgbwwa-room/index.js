"use strict";
/* eslint-disable */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const response_1 = __importDefault(require("./response"));
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const local_client_1 = require("../../../../local-client");
const errors_1 = require("../../../../../../errors/errors");
const home_constants_1 = require("../../../../../../constants/gateway/home-constants");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const HomeUtils = __importStar(require("../../../../../../utilities/gateway/home-utils"));
const keus_group_1 = __importDefault(require("../../../../../../models/database-models/keus-group"));
const group_constants_1 = require("../../../../../../constants/group/group-constants");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const home_structures_pb_1 = require("../../../../../device-manager/providers/generated/home/home_structures_pb");
exports.default = async (mvZRgbwwaReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(mvZRgbwwaReq.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceTypesList;
                console.log("\n\n=====================\nRGB Move to room :" + device);
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const targetRoom = await keus_home_1.default.getRoomById(mvZRgbwwaReq.getDeviceRoom());
                    const targetSection = targetRoom
                        ? targetRoom.sectionList.find(function (sec) {
                            return sec.sectionId == mvZRgbwwaReq.getDeviceSection();
                        })
                        : null;
                    if (arrayList.indexOf(device.deviceType) < 0) {
                        throw new errors_1.DeviceErrors.InvalidDeviceType();
                    }
                    else if (!targetRoom) {
                        throw new errors_1.HomeErrors.InvalidRoomId();
                    }
                    else if (!targetSection) {
                        throw new errors_1.HomeErrors.InvalidSectionId();
                    }
                    else if (device.deviceRoom == home_constants_1.DefaultRoomId) {
                        // await zigbee add to area
                        await keus_device_1.default.updateDeviceRoomAndSection(device.deviceId, mvZRgbwwaReq.getDeviceRoom(), mvZRgbwwaReq.getDeviceSection());
                        resolve(response_1.default.getMoveRoomSuccessful());
                    }
                    else {
                        const currentRoom = await keus_home_1.default.getRoomById(device.deviceRoom);
                        const areSameArea = HomeUtils.checkRoomsInSameArea([currentRoom, targetRoom]);
                        if (areSameArea) {
                            await keus_device_1.default.updateDeviceRoomAndSection(device.deviceId, mvZRgbwwaReq.getDeviceRoom(), mvZRgbwwaReq.getDeviceSection());
                            // await zigbee add to area => force adding to zigbee
                            let dmAddDevicetoAreaReq = new home_structures_pb_1.DMAddDeviceToArea();
                            dmAddDevicetoAreaReq.setAreaId(targetRoom.areaId);
                            dmAddDevicetoAreaReq.setDeviceId(device.deviceId);
                            dmAddDevicetoAreaReq.setForceAdd(true);
                            let dmAddDeviceToAreaRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddDevicetoAreaReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddDeviceToArea'));
                            console.log('This is reesp', dmAddDeviceToAreaRsp);
                            if (!dmAddDeviceToAreaRsp.getSuccess()) {
                                throw new Error(dmAddDeviceToAreaRsp.getMessage());
                            }
                            resolve(response_1.default.getMoveRoomSuccessful());
                        }
                        else {
                            // await zigbee add to area
                            let dmAddDevicetoAreaReq = new home_structures_pb_1.DMAddDeviceToArea();
                            dmAddDevicetoAreaReq.setAreaId(targetRoom.areaId);
                            dmAddDevicetoAreaReq.setDeviceId(device.deviceId);
                            dmAddDevicetoAreaReq.setForceAdd(true);
                            let dmAddDeviceToAreaRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddDevicetoAreaReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddDeviceToArea'));
                            console.log('This is reesp', dmAddDeviceToAreaRsp);
                            if (!dmAddDeviceToAreaRsp.getSuccess()) {
                                throw new Error(dmAddDeviceToAreaRsp.getMessage());
                            }
                            if (device.inGroup) {
                                const deviceGroup = await keus_group_1.default.getGroupById(device.deviceGroup, device.groupRoom);
                                if (deviceGroup) {
                                    await keus_group_1.default.updateGroupDeviceList(deviceGroup.groupId, deviceGroup.groupRoom, deviceGroup.deviceList.filter(function (devId) {
                                        return devId != device.deviceId;
                                    }));
                                }
                                await keus_device_1.default.updateDeviceGroup(device.deviceId, group_constants_1.NoGroupId, home_constants_1.DefaultRoomId);
                            }
                            resolve(response_1.default.getMoveRoomSuccessful());
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.HomeErrors.InvalidRoomId:
                        resolve(response_1.default.getTargetRoomDoesntExist());
                        break;
                    case errors_1.HomeErrors.InvalidSectionId:
                        resolve(response_1.default.getTargetSectionDoesntExist());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map