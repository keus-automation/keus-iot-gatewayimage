"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
exports.default = async (defaultStateData, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const device = await keus_device_1.default.getDeviceById(defaultStateData.getDeviceId());
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceTypesList;
                if (!device) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                if (arrayList.indexOf(device.deviceType) < 0) {
                    throw new errors_1.DeviceErrors.InvalidDeviceType();
                }
                else {
                    let deviceState = device.deviceState;
                    deviceState.defaultUpdateType = defaultStateData.getUpdateType();
                    if (defaultStateData.getUpdateType() == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                        deviceState.defaultRgbAction = {
                            red: defaultStateData.getDefaultRgb().getRed(),
                            green: defaultStateData.getDefaultRgb().getGreen(),
                            blue: defaultStateData.getDefaultRgb().getBlue(),
                            pattern: defaultStateData.getDefaultRgb().getPattern(),
                            deviceState: defaultStateData.getDefaultRgb().getDeviceState()
                        };
                    }
                    else if (defaultStateData.getUpdateType() == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                        deviceState.defaultWwaAction = {
                            warmWhite: defaultStateData.getDefaultWwa().getWarmWhite(),
                            coolWhite: defaultStateData.getDefaultWwa().getCoolWhite(),
                            amber: defaultStateData.getDefaultWwa().getAmber(),
                            deviceState: defaultStateData.getDefaultWwa().getDeviceState()
                        };
                    }
                    device.deviceState = deviceState;
                    await keus_device_1.default.updateDevice(device.deviceId, device);
                    resolve(response_1.default.getSavedSuccessfully());
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getDeviceNotFound());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map