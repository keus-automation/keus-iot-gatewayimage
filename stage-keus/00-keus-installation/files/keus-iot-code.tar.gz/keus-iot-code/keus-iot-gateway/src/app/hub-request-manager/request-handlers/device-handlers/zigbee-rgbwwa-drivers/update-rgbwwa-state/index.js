"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../../errors/errors");
const device_categories_1 = __importDefault(require("../../../../../../constants/device/device-categories"));
const activity_utils_1 = require("../../../../../../utilities/gateway/activity-utils");
const keus_activity_1 = __importDefault(require("../../../../../../models/database-models/keus-activity"));
const device_constants_pb_1 = require("../../../../protos/generated/hub/devices/device_constants_pb");
const keus_user_1 = __importDefault(require("../../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../../errors/errors");
const home_utils_1 = require("../../../../../../utilities/gateway/home-utils");
const system_constants_1 = require("../../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../../utilities/general");
const keus_home_1 = __importDefault(require("../../../../../../models/database-models/keus-home"));
const local_client_1 = require("../../../../local-client");
const cloud_client_1 = require("../../../../cloud-client");
const zigbee_rgbwwa_driver_pb_1 = require("../../../../../device-manager/providers/generated/devices/zigbee_rgbwwa_driver_pb");
const device_constants_pb_2 = require("../../../../../device-manager/providers/generated/devices/device_constants_pb");
const reqType = system_constants_1.ProtoPackageName + '.UpdateZigbeeRgbwwaState';
exports.default = async (updateStateData, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                const deviceObj = await keus_device_1.default.getDeviceById(updateStateData.getDeviceId());
                await home_utils_1.checkAccessForUser(user, deviceObj.deviceRoom);
                console.log('This is Update ZIgbee RGBWWA State');
                let deviceState = deviceObj.deviceState;
                const arrayList = device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceTypesList;
                if (!deviceObj) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else if (arrayList.indexOf(deviceObj.deviceType) < 0) {
                    throw new errors_1.DeviceErrors.InvalidDeviceType();
                }
                else {
                    deviceState.lastUpdateType = updateStateData.getUpdateType();
                    var rgbwwwaUdpates;
                    let dmUpdateRGBWWAStateReq = new zigbee_rgbwwa_driver_pb_1.DMUpdateZigbeeRgbwwaState();
                    dmUpdateRGBWWAStateReq.setDeviceId(deviceObj.deviceId);
                    if (updateStateData.getDeviceState() == 0) {
                        dmUpdateRGBWWAStateReq.setDeviceState(0);
                        rgbwwwaUdpates = [
                            {
                                id: 0,
                                state: 0
                            },
                            {
                                id: 1,
                                state: 0
                            },
                            {
                                id: 2,
                                state: 0
                            },
                            {
                                id: 3,
                                state: 0
                            },
                            {
                                id: 4,
                                state: 0
                            },
                            {
                                id: 5,
                                state: 0
                            }
                        ];
                        //send zigbee all zero values;
                    }
                    else {
                        dmUpdateRGBWWAStateReq.setDeviceState(255);
                        deviceState.lastUpdateType = updateStateData.getUpdateType();
                        if (updateStateData.getUpdateType() == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                            //send zigbee call
                            rgbwwwaUdpates = [
                                {
                                    id: 0,
                                    state: updateStateData.getRgbState().getRed()
                                },
                                {
                                    id: 1,
                                    state: updateStateData.getRgbState().getGreen()
                                },
                                {
                                    id: 2,
                                    state: updateStateData.getRgbState().getBlue()
                                },
                                {
                                    id: 3,
                                    state: 0
                                },
                                {
                                    id: 4,
                                    state: 0
                                },
                                {
                                    id: 5,
                                    state: 0
                                }
                            ];
                            console.log('this is rgb update ', updateStateData.getRgbState().getRed(), "gree:-", updateStateData.getRgbState().getGreen(), "this is blue", updateStateData.getRgbState().getBlue());
                            dmUpdateRGBWWAStateReq.setUpdateType(device_constants_pb_2.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE);
                            let DMRGBState = new zigbee_rgbwwa_driver_pb_1.DMRGB();
                            DMRGBState.setRed(rgbwwwaUdpates[0].state);
                            DMRGBState.setGreen(rgbwwwaUdpates[1].state);
                            DMRGBState.setBlue(rgbwwwaUdpates[2].state);
                            dmUpdateRGBWWAStateReq.setRgbState(DMRGBState);
                            deviceState.lastUpdatedRGBAction = {
                                red: updateStateData.getRgbState().getRed(),
                                green: updateStateData.getRgbState().getGreen(),
                                blue: updateStateData.getRgbState().getBlue(),
                                pattern: updateStateData.getRgbState().getPattern(),
                                deviceState: updateStateData.getRgbState().getDeviceState()
                            };
                        }
                        else if (updateStateData.getUpdateType() == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                            //send zigbee call
                            rgbwwwaUdpates = [
                                {
                                    id: 0,
                                    state: 0
                                },
                                {
                                    id: 1,
                                    state: 0
                                },
                                {
                                    id: 2,
                                    state: 0
                                },
                                {
                                    id: 3,
                                    state: updateStateData.getWwaState().getCoolWhite()
                                },
                                {
                                    id: 4,
                                    state: updateStateData.getWwaState().getWarmWhite()
                                },
                                {
                                    id: 5,
                                    state: updateStateData.getWwaState().getAmber()
                                }
                            ];
                            console.log('------------------------------------THIS IS WWA UPDATE', updateStateData.getWwaState().getWarmWhite(), updateStateData.getWwaState().getCoolWhite());
                            dmUpdateRGBWWAStateReq.setUpdateType(device_constants_pb_2.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE);
                            let DMWWAState = new zigbee_rgbwwa_driver_pb_1.DMWWA();
                            DMWWAState.setWarmWhite(rgbwwwaUdpates[3].state);
                            DMWWAState.setCoolWhite(rgbwwwaUdpates[4].state);
                            DMWWAState.setAmber(rgbwwwaUdpates[5].state);
                            dmUpdateRGBWWAStateReq.setWwaState(DMWWAState);
                            deviceState.lastUpdatedWWAAction = {
                                warmWhite: updateStateData.getWwaState().getWarmWhite(),
                                coolWhite: updateStateData.getWwaState().getCoolWhite(),
                                amber: updateStateData.getWwaState().getAmber(),
                                deviceState: updateStateData.getWwaState().getDeviceState()
                            };
                        }
                    }
                    let dmUpdateRGBWWAStateRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmUpdateRGBWWAStateReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMUpdateZigbeeRgbwwaState'));
                    console.log('This is reesp', dmUpdateRGBWWAStateRsp);
                    if (!dmUpdateRGBWWAStateRsp.getSuccess()) {
                        throw new Error(dmUpdateRGBWWAStateRsp.getMessage());
                    }
                    console.log('THIS IS THE DEVICE STATE', deviceState);
                    deviceObj.lastUpdateSource = '';
                    deviceObj.lastUpdateTime = Date.now();
                    deviceObj.lastUpdateBy = '';
                    deviceObj.deviceState = deviceState;
                    await keus_device_1.default.updateDevice(deviceObj.deviceId, deviceObj);
                    let roomDetails = await keus_home_1.default.getRoomById(deviceObj.deviceRoom);
                    let activityObj = await activity_utils_1.getDeviceActivityObj(user, deviceObj, roomDetails, updateStateData, {
                        activitySource: system_constants_1.UpdateSourceMapping.SYSTEM
                    });
                    await keus_activity_1.default.insertActivity(activityObj);
                    //-----------------------Update RGBWWA Controller State Event--------------------------------
                    const eventArg = general_1.PackIntoAny(updateStateData.serializeBinary(), reqType);
                    local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                    cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                    resolve(response_1.default.getUpdateSuccessful());
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    case errors_2.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getDeviceNotFound());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map