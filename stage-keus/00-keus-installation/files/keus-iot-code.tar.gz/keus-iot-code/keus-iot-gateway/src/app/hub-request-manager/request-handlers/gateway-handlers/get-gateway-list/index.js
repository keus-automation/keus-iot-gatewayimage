"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const errors = __importStar(require("../../../../../errors/errors"));
const response_1 = __importDefault(require("./response"));
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const logInst = new logger_service_1.default({ enable: true, namespace: 'UPDATE_MINIGATEWAY_INFO' });
exports.default = async (GetMiniGatewayListReq) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Get Minigateway List');
                const gatewayInfo = await keus_gateway_1.default.getGateway();
                if (!gatewayInfo.length) {
                    throw new errors.GatewayErrors.MainGatewayNotConfigured();
                }
                else {
                    const miniGatewayProtoList = ProtoUtils.GatewayProtoUtils.getMiniGatewayProtoList(gatewayInfo[0].miniGateways);
                    resolve(response_1.default.getGetMiniGatewayListSuccessful(miniGatewayProtoList));
                }
            }
            catch (e) {
                console.log('Get Minigateway List Error', e);
                switch (e.constructor) {
                    case errors.GatewayErrors.MainGatewayNotConfigured:
                        resolve(response_1.default.getMainGatewayNotConfigured());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map