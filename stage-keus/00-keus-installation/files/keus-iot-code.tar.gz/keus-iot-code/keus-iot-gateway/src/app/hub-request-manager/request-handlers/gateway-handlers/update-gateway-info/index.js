"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const errors = __importStar(require("../../../../../errors/errors"));
const response_1 = __importDefault(require("./response"));
const logInst = new logger_service_1.default({ enable: true, namespace: 'UPDATE_MINIGATEWAY_INFO' });
exports.default = async (UpdateMiniGatewayInfoReq) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Update Minigateway Id: ', UpdateMiniGatewayInfoReq.getGatewayId());
                const gatewayInfo = await keus_gateway_1.default.getGateway();
                if (!gatewayInfo.length) {
                    throw new errors.GatewayErrors.MainGatewayNotConfigured();
                }
                else {
                    const miniGateway = gatewayInfo[0].miniGateways.find(function (mg) {
                        return mg.gatewayId == UpdateMiniGatewayInfoReq.getGatewayId();
                    });
                    if (!miniGateway) {
                        throw new errors.GatewayErrors.InvalidMiniGatewayId();
                    }
                    else {
                        const miniGatewayInfo = {
                            gatewayId: UpdateMiniGatewayInfoReq.getGatewayId(),
                            floor: UpdateMiniGatewayInfoReq.getGatewayFloor(),
                            name: UpdateMiniGatewayInfoReq.getGatewayName(),
                            location: UpdateMiniGatewayInfoReq.getGatewayLocation(),
                            ip: miniGateway.ip
                        };
                        await keus_gateway_1.default.updateMiniGatewayInfo(gatewayInfo[0].gatewayId, miniGatewayInfo);
                    }
                    resolve(response_1.default.getUpdateMiniGatewayInfoSuccessful());
                }
            }
            catch (e) {
                console.log('Delete Minigateway Error', e);
                switch (e.constructor) {
                    case errors.GatewayErrors.MainGatewayNotConfigured:
                        resolve(response_1.default.getMainGatewayNotConfigured());
                        break;
                    case errors.GatewayErrors.InvalidMiniGatewayId:
                        resolve(response_1.default.getInvalidMiniGatewayId());
                        break;
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map