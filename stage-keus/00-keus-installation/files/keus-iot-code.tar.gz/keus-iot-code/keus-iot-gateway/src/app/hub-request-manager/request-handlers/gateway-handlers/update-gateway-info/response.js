"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mini_gateway_setup_pb_1 = require("../../../protos/generated/hub/gatewaysetup/mini-gateway_setup_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class UpdateMiniGatewayInfoResp {
    static getUpdateMiniGatewayInfoSuccessful() {
        const resp = new mini_gateway_setup_pb_1.UpdateMiniGatewayInfoResponse();
        resp.setCode(800);
        resp.setMessage('Update MiniGateway Info Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateMiniGatewayInfoResp.responseType);
    }
    static getMainGatewayNotConfigured() {
        const resp = new mini_gateway_setup_pb_1.UpdateMiniGatewayInfoResponse();
        resp.setCode(801);
        resp.setMessage('Get MainGateway Not Configured');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateMiniGatewayInfoResp.responseType);
    }
    static getInvalidMiniGatewayId() {
        const resp = new mini_gateway_setup_pb_1.UpdateMiniGatewayInfoResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Minigateway Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateMiniGatewayInfoResp.responseType);
    }
    static getInternalServerError() {
        const resp = new mini_gateway_setup_pb_1.UpdateMiniGatewayInfoResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateMiniGatewayInfoResp.responseType);
    }
}
exports.default = UpdateMiniGatewayInfoResp;
UpdateMiniGatewayInfoResp.responseType = system_constants_1.ProtoPackageName + '.UpdateMiniGatewayInfoResponse';
//# sourceMappingURL=response.js.map