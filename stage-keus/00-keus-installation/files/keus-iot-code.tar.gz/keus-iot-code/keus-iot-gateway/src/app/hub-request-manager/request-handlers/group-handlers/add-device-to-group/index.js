"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const general_1 = require("../../../../../utilities/general");
const group_constants_1 = require("../../../../../constants/group/group-constants");
const errors_1 = require("../../../../../errors/errors");
const group_structures_pb_2 = require("../../../../device-manager/providers/generated/groups/group_structures_pb");
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const local_client_1 = require("../../../local-client");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const device_categories_1 = __importDefault(require("../../../../../constants/device/device-categories"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (addDeviceToGroupReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!addDeviceToGroupReq.getGroupId() || !addDeviceToGroupReq.getGroupRoom()) {
                    throw new errors_1.GroupErrors.InvalidGroupId();
                }
                else if (!addDeviceToGroupReq.getDeviceId()) {
                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                }
                else {
                    const group = await keus_group_1.default.getGroupById(addDeviceToGroupReq.getGroupId(), addDeviceToGroupReq.getGroupRoom());
                    const device = await keus_device_1.default.getDeviceById(addDeviceToGroupReq.getDeviceId());
                    console.log("------------------this is device category", device.deviceCategory);
                    console.log("------------------this is group details", group);
                    if (!group) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    else if (!device) {
                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                    }
                    else {
                        if (device.deviceCategory != group_constants_1.getGroupType(group.groupType)) {
                            throw new errors_1.GroupErrors.DeviceIncompatibleWithGroup();
                        }
                        else if (device.inGroup && device.deviceGroup != group.groupId) {
                            throw new errors_1.GroupErrors.DeviceInAnotherGroup();
                        }
                        else {
                            if (device.deviceCategory ==
                                device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode) {
                                let deviceProps = device.deviceProperties;
                                let applianceList = deviceProps.appliance;
                                let appliance = applianceList.find(function (app) {
                                    return app.applianceId == addDeviceToGroupReq.getApplianceId();
                                });
                                if (appliance.inGroup && appliance.groupId != group.groupId) {
                                    throw new errors_1.GroupErrors.DeviceInAnotherGroup();
                                }
                            }
                            const room = await keus_home_1.default.getRoomById(addDeviceToGroupReq.getGroupRoom());
                            //INCLUDE EMBEDDED APPLIANCE ZIGBEE CALL
                            const dmAddDeviceToGroupReq = new group_structures_pb_2.DMAddDeviceToGroup();
                            dmAddDeviceToGroupReq.setDeviceId(addDeviceToGroupReq.getDeviceId());
                            dmAddDeviceToGroupReq.setGroupArea(room.areaId);
                            dmAddDeviceToGroupReq.setGroupId(addDeviceToGroupReq.getGroupId());
                            if (device.deviceCategory ==
                                device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode) {
                                let deviceProps = device.deviceProperties;
                                let applianceList = deviceProps.appliance;
                                let appliance = applianceList.find(function (app) {
                                    return app.applianceId == addDeviceToGroupReq.getApplianceId();
                                });
                                dmAddDeviceToGroupReq.setApplianceId(appliance.applianceId);
                            }
                            const dmAddDeviceToGroupRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddDeviceToGroupReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddDeviceToGroup'));
                            if (!dmAddDeviceToGroupRsp.getSuccess()) {
                                throw new Error(dmAddDeviceToGroupRsp.getMessage());
                            }
                            let updatedGroup;
                            if (device.deviceCategory ==
                                device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode) {
                                let deviceProps = device.deviceProperties;
                                let applianceList = deviceProps.appliance;
                                let appliance = applianceList.find(function (app) {
                                    return app.applianceId == addDeviceToGroupReq.getApplianceId();
                                });
                                appliance.inGroup = true;
                                appliance.groupId = group.groupId;
                                appliance.groupRoom = group.groupRoom;
                                let final_device_properties = {
                                    outputPorts: deviceProps.outputPorts,
                                    appliance: applianceList,
                                    switch: deviceProps.switch
                                };
                                await keus_device_1.default.updateDeviceProperties(device.deviceId, final_device_properties, true);
                                let grp;
                                switch (group.groupType) {
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
                                        grp = group.groupProperties;
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                                        grp = group.groupProperties;
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                                        grp = group.groupProperties;
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                                        grp = group.groupProperties;
                                        break;
                                }
                                let alreadyPresent = false;
                                for (let i = 0; i < grp.deviceList.length; i++) {
                                    if (grp.deviceList[i].deviceId == device.deviceId &&
                                        grp.deviceList[i].applianceId == addDeviceToGroupReq.getApplianceId()) {
                                        alreadyPresent = true;
                                    }
                                }
                                if (!alreadyPresent) {
                                    let newAppliance = {
                                        deviceId: device.deviceId,
                                        applianceId: addDeviceToGroupReq.getApplianceId()
                                    };
                                    grp.deviceList.push(newAppliance);
                                }
                                updatedGroup = await keus_group_1.default.configureGroupProperties(group.groupId, group.groupRoom, grp, false);
                            }
                            else {
                                await keus_device_1.default.updateDeviceGroup(device.deviceId, group.groupId, group.groupRoom);
                                if (group.deviceList.indexOf(device.deviceId) < 0) {
                                    group.deviceList.push(device.deviceId);
                                }
                                updatedGroup = await keus_group_1.default.updateGroupDeviceList(group.groupId, group.groupRoom, group.deviceList);
                            }
                            resolve(response_1.default.getAddDeviceToGroupSuccessful(ProtoUtils.GroupProtoUtils.getGroupProto(updatedGroup)));
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.GroupErrors.InvalidGroupId:
                        resolve(response_1.default.getInvalidGroupId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.GroupErrors.DeviceIncompatibleWithGroup:
                        resolve(response_1.default.getDeviceIncompatibleWithGroup());
                        break;
                    case errors_1.GroupErrors.DeviceInAnotherGroup:
                        resolve(response_1.default.getDeviceInAnotherGroup());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map