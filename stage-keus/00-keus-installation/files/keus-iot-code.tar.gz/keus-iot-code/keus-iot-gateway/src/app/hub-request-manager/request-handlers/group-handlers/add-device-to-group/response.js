"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class AddDeviceToGroupResp {
    static getAddDeviceToGroupSuccessful(group) {
        const resp = new group_structures_pb_1.AddDeviceToGroupResponse();
        resp.setCode(800);
        resp.setMessage('Add Device to Group Successful');
        resp.setSuccess(true);
        resp.setGroup(group);
        return general_1.PackIntoAny(resp.serializeBinary(), AddDeviceToGroupResp.responseType);
    }
    static getDeviceInAnotherGroup() {
        const resp = new group_structures_pb_1.AddDeviceToGroupResponse();
        resp.setCode(801);
        resp.setMessage('Device In Another Group');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddDeviceToGroupResp.responseType);
    }
    static getDeviceIncompatibleWithGroup() {
        const resp = new group_structures_pb_1.AddDeviceToGroupResponse();
        resp.setCode(802);
        resp.setMessage('Device Incompatible With Group');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddDeviceToGroupResp.responseType);
    }
    static getInvalidGroupId() {
        const resp = new group_structures_pb_1.AddDeviceToGroupResponse();
        resp.setCode(803);
        resp.setMessage('Invalid Group Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddDeviceToGroupResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new group_structures_pb_1.AddDeviceToGroupResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddDeviceToGroupResp.responseType);
    }
    static getInternalServerError() {
        const resp = new group_structures_pb_1.AddDeviceToGroupResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), AddDeviceToGroupResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new group_structures_pb_1.AddDeviceToGroupResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddDeviceToGroupResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new group_structures_pb_1.AddDeviceToGroupResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddDeviceToGroupResp.responseType);
    }
}
exports.default = AddDeviceToGroupResp;
AddDeviceToGroupResp.responseType = system_constants_1.ProtoPackageName + '.AddDeviceToGroupResponse';
//# sourceMappingURL=response.js.map