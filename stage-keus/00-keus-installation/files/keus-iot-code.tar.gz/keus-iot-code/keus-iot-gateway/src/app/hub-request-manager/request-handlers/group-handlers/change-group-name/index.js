"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const proto_utils_1 = require("../../../../../utilities/gateway/proto-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (changeGroupNameReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!changeGroupNameReq.getGroupId() || !changeGroupNameReq.getGroupRoom()) {
                    throw new errors_1.GroupErrors.InvalidGroupId();
                }
                else {
                    const group = await keus_group_1.default.getGroupById(changeGroupNameReq.getGroupId(), changeGroupNameReq.getGroupRoom());
                    if (!group) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    else if (!changeGroupNameReq.getGroupName() || !changeGroupNameReq.getGroupName().length) {
                        throw new errors_1.GroupErrors.InvalidGroupName();
                    }
                    else {
                        const groupList = await keus_group_1.default.getGroupsByRooms([group.groupRoom]);
                        const filteredGroupList = groupList.filter(function (groupItem) {
                            return (groupItem.groupName == changeGroupNameReq.getGroupName() &&
                                groupItem.groupSection == group.groupSection &&
                                groupItem.groupId != group.groupId);
                        });
                        if (filteredGroupList.length) {
                            throw new errors_1.GroupErrors.DuplicateGroupName();
                        }
                        else {
                            const groupVoiceName = changeGroupNameReq.getGroupVoiceName() && changeGroupNameReq.getGroupVoiceName.length
                                ? changeGroupNameReq.getGroupVoiceName()
                                : group.groupVoiceName;
                            const updatedGroup = await keus_group_1.default.changeGroupName(group.groupId, group.groupRoom, changeGroupNameReq.getGroupName(), groupVoiceName);
                            resolve(response_1.default.getChangeGroupNameSuccessful(proto_utils_1.GroupProtoUtils.getGroupProto(group)));
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.GroupErrors.InvalidGroupId:
                        resolve(response_1.default.getInvalidGroupId());
                        break;
                    case errors_1.GroupErrors.InvalidGroupName:
                        resolve(response_1.default.getInvalidGroupName());
                        break;
                    case errors_1.GroupErrors.DuplicateGroupName:
                        resolve(response_1.default.getDuplicateGroupName());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map