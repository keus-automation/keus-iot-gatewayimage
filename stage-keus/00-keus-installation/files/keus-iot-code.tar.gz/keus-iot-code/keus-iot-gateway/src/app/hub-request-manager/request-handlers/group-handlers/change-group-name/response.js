"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class ChangeGroupNameResp {
    static getChangeGroupNameSuccessful(group) {
        const resp = new group_structures_pb_1.ChangeGroupNameResponse();
        resp.setCode(800);
        resp.setMessage('Delete Group Successful');
        resp.setSuccess(true);
        resp.setGroup(group);
        return general_1.PackIntoAny(resp.serializeBinary(), ChangeGroupNameResp.responseType);
    }
    static getInvalidGroupId() {
        const resp = new group_structures_pb_1.ChangeGroupNameResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Group Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ChangeGroupNameResp.responseType);
    }
    static getInvalidGroupName() {
        const resp = new group_structures_pb_1.ChangeGroupNameResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Group Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ChangeGroupNameResp.responseType);
    }
    static getDuplicateGroupName() {
        const resp = new group_structures_pb_1.ChangeGroupNameResponse();
        resp.setCode(801);
        resp.setMessage('Duplicate Group Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ChangeGroupNameResp.responseType);
    }
    static getInternalServerError() {
        const resp = new group_structures_pb_1.ChangeGroupNameResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ChangeGroupNameResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new group_structures_pb_1.ChangeGroupNameResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ChangeGroupNameResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new group_structures_pb_1.ChangeGroupNameResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ChangeGroupNameResp.responseType);
    }
}
exports.default = ChangeGroupNameResp;
ChangeGroupNameResp.responseType = system_constants_1.ProtoPackageName + '.ChangeGroupNameResponse';
//# sourceMappingURL=response.js.map