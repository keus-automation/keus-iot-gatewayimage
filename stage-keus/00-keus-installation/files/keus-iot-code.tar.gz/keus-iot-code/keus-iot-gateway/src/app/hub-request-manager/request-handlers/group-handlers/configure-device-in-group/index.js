// import {
//     ConfigureDeviceInGroup,
//     GROUP_TYPES
// } from '../../../protos/generated/hub/groups/group_structures_pb';
// import ConfigureDeviceInGroupResponse from './response';
// import { TPromise } from '../../../../../utilities/timed-promise';
// import { Any } from 'google-protobuf/google/protobuf/any_pb';
// import { GroupTypeMapping } from '../../../../../constants/group/group-constants';
// import Logger from '../../../../../services/logger-service';
// import { GatewayLogNamespace } from '../../../../../constants/gateway/system-constants';
// import KeusDeviceModel from '../../../../../models/database-models/keus-device';
// import * as DeviceInterfaces from '../../../../../models/device-models/device-categories/keus-device-interfaces';
// import { DeviceErrors, GroupErrors } from '../../../../../errors/errors';
// import { getGroupType } from '../../../../../constants/group/group-constants';
// import KeusUserModel from '../../../../../models/database-models/keus-user';
// import { GeneralErrors } from '../../../../../errors/errors';
// import {checkAccessForUser,checkUserIsAdmin} from '../../../../../utilities/gateway/home-utils'
// const logInst = new Logger({ enable: true, namespace: GatewayLogNamespace });
// export default async (configureDeviceInGroupReq: ConfigureDeviceInGroup,phone:string): Promise<Any> => {
//     return TPromise(function() {
//         return new Promise(async function(resolve, reject) {
//             try {
//                 let user = await KeusUserModel.getUserByPhone(phone);
//                 await checkUserIsAdmin(user);
//                 if (!configureDeviceInGroupReq.getDeviceId()) {
//                     throw new DeviceErrors.InvalidDeviceId();
//                     resolve(ConfigureDeviceInGroupResponse.getInvalidDeviceId());
//                 } else {
//                     const device = await KeusDeviceModel.getDeviceById(configureDeviceInGroupReq.getDeviceId());
//                     if (!device) {
//                         throw new DeviceErrors.InvalidDeviceId();
//                         resolve(ConfigureDeviceInGroupResponse.getInvalidDeviceId());
//                     } else {
//                         var configureProperties: object;
//                         var invalidPropertySet = false;
//                         switch (device.deviceType) {
//                             case getGroupType(GROUP_TYPES.ZIGBEE_DIMMABLE):
//                                 if (!configureDeviceInGroupReq.hasZdimmableDriverProperties()) {
//                                     throw new GroupErrors.InvalidPropertySet();
//                                     invalidPropertySet = true;
//                                 } else {
//                                     var zddProps: DeviceInterfaces.IZigbeeDimmableDriverProperties = {
//                                         fadeTime: configureDeviceInGroupReq
//                                             .getZdimmableDriverProperties()
//                                             .getFadeTime(),
//                                         minValue: configureDeviceInGroupReq
//                                             .getZdimmableDriverProperties()
//                                             .getMinValue(),
//                                         maxValue: configureDeviceInGroupReq
//                                             .getZdimmableDriverProperties()
//                                             .getMinValue(),
//                                         defaultState: configureDeviceInGroupReq
//                                             .getZdimmableDriverProperties()
//                                             .getDefaultState()
//                                     };
//                                     configureProperties = zddProps as object;
//                                 }
//                                 break;
//                             case getGroupType(GROUP_TYPES.ZIGBEE_NON_DIMMABLE):
//                                 if (!configureDeviceInGroupReq.hasZnondimmableDriverProperties()) {
//                                     throw new GroupErrors.InvalidPropertySet();
//                                     invalidPropertySet = true;
//                                 } else {
//                                     var zndProps: DeviceInterfaces.IZigbeeNonDimmableDriverProperties = {
//                                         fadeTime: configureDeviceInGroupReq
//                                             .getZnondimmableDriverProperties()
//                                             .getFadeTime()
//                                     };
//                                     configureProperties = zndProps as object;
//                                 }
//                                 break;
//                             case getGroupType(GROUP_TYPES.DALI_DIMMABLE):
//                                 if (!configureDeviceInGroupReq.hasDdimmableDriverProperties()) {
//                                     throw new GroupErrors.InvalidPropertySet();
//                                     invalidPropertySet = true;
//                                 } else {
//                                     var dddProps: DeviceInterfaces.IDaliDimmableDriverProperties = {
//                                         fadeTime: configureDeviceInGroupReq
//                                             .getDdimmableDriverProperties()
//                                             .getFadeTime(),
//                                         minValue: configureDeviceInGroupReq
//                                             .getDdimmableDriverProperties()
//                                             .getMinValue(),
//                                         maxValue: configureDeviceInGroupReq
//                                             .getDdimmableDriverProperties()
//                                             .getMinValue(),
//                                         defaultState: configureDeviceInGroupReq
//                                             .getZdimmableDriverProperties()
//                                             .getDefaultState()
//                                     };
//                                     configureProperties = dddProps as object;
//                                 }
//                                 break;
//                             case getGroupType(GROUP_TYPES.DALI_NON_DIMMABLE):
//                                 if (!configureDeviceInGroupReq.hasDnondimmableDriverProperties()) {
//                                     throw new GroupErrors.InvalidPropertySet();
//                                     invalidPropertySet = true;
//                                 } else {
//                                     var dndProps: DeviceInterfaces.IDaliNonDimmableDriverProperties = {
//                                         fadeTime: configureDeviceInGroupReq
//                                             .getDnondimmableDriverProperties()
//                                             .getFadeTime()
//                                     };
//                                     configureProperties = dndProps as object;
//                                 }
//                                 break;
//                             case getGroupType(GROUP_TYPES.ZIGBEE_INLINE):
//                                 if (!configureDeviceInGroupReq.hasZinlineDimmerProperties()) {
//                                     throw new GroupErrors.InvalidPropertySet();
//                                     invalidPropertySet = true;
//                                 } else {
//                                     var zidProps: DeviceInterfaces.IZigbeeDimmableDriverProperties = {
//                                         fadeTime: configureDeviceInGroupReq.getZinlineDimmerProperties().getFadeTime(),
//                                         maxValue: configureDeviceInGroupReq.getZinlineDimmerProperties().getMaxValue(),
//                                         minValue: configureDeviceInGroupReq.getZinlineDimmerProperties().getMinValue(),
//                                         defaultState: configureDeviceInGroupReq
//                                             .getZinlineDimmerProperties()
//                                             .getDefaultState()
//                                     };
//                                     configureProperties = zidProps as object;
//                                 }
//                                 break;
//                             case getGroupType(GROUP_TYPES.RGBWWA):
//                                 if (!configureDeviceInGroupReq.hasZrgbwwaProperties()) {
//                                     throw new GroupErrors.InvalidPropertySet();
//                                     invalidPropertySet = true;
//                                 } else {
//                                     var zrgbwwaProps: DeviceInterfaces.IZigbeeRgbwwaDriverProperties = {
//                                         outputChannels: configureDeviceInGroupReq
//                                             .getZrgbwwaProperties()
//                                             .getOutputChannels(),
//                                         amberEnabled: configureDeviceInGroupReq
//                                             .getZrgbwwaProperties()
//                                             .getAmberEnabled(),
//                                         coolWhiteEnabled: configureDeviceInGroupReq
//                                             .getZrgbwwaProperties()
//                                             .getCoolWhiteEnabled(),
//                                         warmWhiteEnabled: configureDeviceInGroupReq
//                                             .getZrgbwwaProperties()
//                                             .getWarmWhiteEnabled(),
//                                         rgbEnabled: configureDeviceInGroupReq.getZrgbwwaProperties().getRgbEnabled(),
//                                         fadeTime: configureDeviceInGroupReq.getZrgbwwaProperties().getFadeTime()
//                                     };
//                                     configureProperties = zrgbwwaProps as object;
//                                 }
//                             default:
//                                 throw new GroupErrors.InvalidPropertySet();
//                                 invalidPropertySet = true;
//                         }
//                         await KeusDeviceModel.updateGroupDeviceProperties([device.deviceId], configureProperties);
//                         resolve(ConfigureDeviceInGroupResponse.getConfigureDeviceInGroupSuccessful());
//                     }
//                 }
//             } catch (e) {
//                 switch (e.constructor) {
//                     case GeneralErrors.UserNotAdminError:
//                         resolve(ConfigureDeviceInGroupResponse.getUserNotAdmin());
//                         break;
//                     case DeviceErrors.InvalidDeviceId:
//                         resolve(ConfigureDeviceInGroupResponse.getInvalidDeviceId());
//                         break;
//                     case GroupErrors.InvalidPropertySet:
//                         resolve(ConfigureDeviceInGroupResponse.getInvalidPropertySet());
//                         break;
//                     default:
//                         logInst.log(e);
//                         resolve(ConfigureDeviceInGroupResponse.getInternalServerError());
//                 }
//             }
//         });
//     });
// };
//# sourceMappingURL=index.js.map