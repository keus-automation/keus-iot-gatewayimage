"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../utilities/general");
const group_structures_pb_2 = require("../../../../device-manager/providers/generated/groups/group_structures_pb");
const local_client_1 = require("../../../local-client");
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const zigbee_dimmable_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_dimmable_driver_pb");
const dali_dimmable_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/dali_dimmable_driver_pb");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const zigbee_rgbwwa_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_rgbwwa_driver_pb");
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const device_constants_pb_2 = require("../../../../device-manager/providers/generated/devices/device_constants_pb");
const dali_colour_tunable_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/dali_colour_tunable_driver_pb");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Configure Group Properties' });
exports.default = async (configureGroupPropertiesReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                var updatedDeviceList = [];
                var isHidden;
                if (!configureGroupPropertiesReq.getGroupId() || !configureGroupPropertiesReq.getGroupRoom()) {
                    resolve(response_1.default.getInvalidGroupId());
                }
                else {
                    const group = await keus_group_1.default.getGroupById(configureGroupPropertiesReq.getGroupId(), configureGroupPropertiesReq.getGroupRoom());
                    if (!group) {
                        resolve(response_1.default.getInvalidGroupId());
                    }
                    else {
                        var configureProperties;
                        var invalidPropertySet = false;
                        let zParams = {};
                        isHidden = configureGroupPropertiesReq.getIsHidden();
                        isHidden = isHidden == true || isHidden == false ? isHidden : group.isHidden;
                        const room = await keus_home_1.default.getRoomById(group.groupRoom);
                        const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                        const dmConfigureGroupProperties = new group_structures_pb_2.DMConfigureGroupProperties();
                        dmConfigureGroupProperties.setGroupId(group.groupId);
                        dmConfigureGroupProperties.setGroupArea(room.areaId);
                        dmConfigureGroupProperties.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                        switch (group.groupType) {
                            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
                                if (!configureGroupPropertiesReq.hasZdimmableDriverProperties()) {
                                    invalidPropertySet = true;
                                }
                                else {
                                    var zddProps = {
                                        fadeTime: configureGroupPropertiesReq
                                            .getZdimmableDriverProperties()
                                            .getFadeTime(),
                                        minValue: configureGroupPropertiesReq
                                            .getZdimmableDriverProperties()
                                            .getMinValue(),
                                        maxValue: configureGroupPropertiesReq
                                            .getZdimmableDriverProperties()
                                            .getMaxValue(),
                                        defaultState: configureGroupPropertiesReq
                                            .getZdimmableDriverProperties()
                                            .getDefaultState()
                                    };
                                    configureProperties = zddProps;
                                    dmConfigureGroupProperties.setGroupType(group_structures_pb_2.DMGROUP_TYPES.ZIGBEE_DIMMABLE);
                                    let dmZDimmableDriverGroupProps = new zigbee_dimmable_driver_pb_1.DMZigbeeDimmableDriverProperties();
                                    dmZDimmableDriverGroupProps.setDefaultState(zddProps.defaultState);
                                    dmZDimmableDriverGroupProps.setFadeTime(zddProps.fadeTime);
                                    dmZDimmableDriverGroupProps.setMaxValue(zddProps.maxValue);
                                    dmZDimmableDriverGroupProps.setMinValue(zddProps.minValue);
                                    dmConfigureGroupProperties.setDmzdimmableDriverProperties(dmZDimmableDriverGroupProps);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
                                if (!configureGroupPropertiesReq.hasZnondimmableDriverProperties()) {
                                    invalidPropertySet = true;
                                }
                                else {
                                    var zndProps = {
                                        fadeTime: configureGroupPropertiesReq
                                            .getZnondimmableDriverProperties()
                                            .getFadeTime()
                                    };
                                    configureProperties = zndProps;
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
                                if (!configureGroupPropertiesReq.hasDdimmableDriverProperties()) {
                                    invalidPropertySet = true;
                                }
                                else {
                                    var dddProps = {
                                        fadeTime: configureGroupPropertiesReq
                                            .getDdimmableDriverProperties()
                                            .getFadeTime(),
                                        minValue: configureGroupPropertiesReq
                                            .getDdimmableDriverProperties()
                                            .getMinValue(),
                                        maxValue: configureGroupPropertiesReq
                                            .getDdimmableDriverProperties()
                                            .getMaxValue(),
                                        defaultState: configureGroupPropertiesReq
                                            .getDdimmableDriverProperties()
                                            .getDefaultState(),
                                        isDriverPropertyUpdated: true
                                    };
                                    configureProperties = dddProps;
                                    dmConfigureGroupProperties.setGroupType(group_structures_pb_2.DMGROUP_TYPES.DALI_DIMMABLE);
                                    let dmDDimmableDriverGroupProps = new dali_dimmable_driver_pb_1.DMDaliDimmableDriverProperties();
                                    dmDDimmableDriverGroupProps.setDefaultState(dddProps.defaultState);
                                    dmDDimmableDriverGroupProps.setFadeTime(dddProps.fadeTime);
                                    dmDDimmableDriverGroupProps.setMaxValue(dddProps.maxValue);
                                    dmDDimmableDriverGroupProps.setMinValue(dddProps.minValue);
                                    dmConfigureGroupProperties.setDmddimmableDriverProperties(dmDDimmableDriverGroupProps);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
                                if (!configureGroupPropertiesReq.hasDcolortunableDriverProperties()) {
                                    invalidPropertySet = true;
                                }
                                else {
                                    let ctGrpProps = group.groupProperties;
                                    var dctdProps = {
                                        fadeTime: configureGroupPropertiesReq
                                            .getDcolortunableDriverProperties()
                                            .getFadeTime(),
                                        minValue: configureGroupPropertiesReq
                                            .getDcolortunableDriverProperties()
                                            .getMinValue(),
                                        maxValue: configureGroupPropertiesReq
                                            .getDcolortunableDriverProperties()
                                            .getMaxValue(),
                                        minTemperature: configureGroupPropertiesReq
                                            .getDcolortunableDriverProperties()
                                            .getMinTemperature(),
                                        maxTemperature: configureGroupPropertiesReq
                                            .getDcolortunableDriverProperties()
                                            .getMaxTemperature(),
                                        defaultState: ctGrpProps.defaultState,
                                        deviceVoiceName: ctGrpProps.deviceVoiceName,
                                    };
                                    dctdProps.defaultState.driverState = configureGroupPropertiesReq.getDcolortunableDriverProperties().getDefaultState().getDriverState();
                                    dctdProps.defaultState.colorTemperature = configureGroupPropertiesReq.getDcolortunableDriverProperties().getDefaultState().getColorTemperature();
                                    configureProperties = dctdProps;
                                    dmConfigureGroupProperties.setGroupType(group_structures_pb_2.DMGROUP_TYPES.DALI_COLOR_TUNABLE);
                                    let dmDDColorTunableDriverGroupProps = new dali_colour_tunable_driver_pb_1.DMDaliColourTunableDriverProperties();
                                    dmDDColorTunableDriverGroupProps.setDefaultState(configureGroupPropertiesReq.getDcolortunableDriverProperties().getDefaultState().getDriverState());
                                    dmDDColorTunableDriverGroupProps.setDefaultTemp(configureGroupPropertiesReq.getDcolortunableDriverProperties().getDefaultState().getColorTemperature());
                                    dmDDColorTunableDriverGroupProps.setFadeTime(configureGroupPropertiesReq
                                        .getDcolortunableDriverProperties()
                                        .getFadeTime());
                                    dmDDColorTunableDriverGroupProps.setMaxValue(configureGroupPropertiesReq
                                        .getDcolortunableDriverProperties()
                                        .getMaxValue());
                                    dmDDColorTunableDriverGroupProps.setMinValue(configureGroupPropertiesReq
                                        .getDcolortunableDriverProperties()
                                        .getMinValue());
                                    dmDDColorTunableDriverGroupProps.setMinTemp(configureGroupPropertiesReq
                                        .getDcolortunableDriverProperties()
                                        .getMinTemperature());
                                    dmDDColorTunableDriverGroupProps.setMaxTemp(configureGroupPropertiesReq
                                        .getDcolortunableDriverProperties()
                                        .getMaxTemperature());
                                    dmConfigureGroupProperties.setDmdcolourTunableDriverProperties(dmDDColorTunableDriverGroupProps);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
                                if (!configureGroupPropertiesReq.hasDnondimmableDriverProperties()) {
                                    invalidPropertySet = true;
                                }
                                else {
                                    var dndProps = {
                                        fadeTime: configureGroupPropertiesReq
                                            .getDnondimmableDriverProperties()
                                            .getFadeTime(),
                                        isDriverPropertyUpdated: true
                                    };
                                    configureProperties = dndProps;
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
                                if (!configureGroupPropertiesReq.hasZinlineDimmerProperties()) {
                                    invalidPropertySet = true;
                                }
                                else {
                                    var zidProps = {
                                        fadeTime: configureGroupPropertiesReq
                                            .getZinlineDimmerProperties()
                                            .getFadeTime(),
                                        maxValue: configureGroupPropertiesReq
                                            .getZinlineDimmerProperties()
                                            .getMaxValue(),
                                        minValue: configureGroupPropertiesReq
                                            .getZinlineDimmerProperties()
                                            .getMinValue(),
                                        defaultState: configureGroupPropertiesReq
                                            .getZinlineDimmerProperties()
                                            .getDefaultState()
                                    };
                                    configureProperties = zidProps;
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.RGBWWA:
                                if (!configureGroupPropertiesReq.hasZrgbwwaProperties()) {
                                    invalidPropertySet = true;
                                }
                                else {
                                    dmConfigureGroupProperties.setGroupType(group_structures_pb_2.DMGROUP_TYPES.RGBWWA);
                                    var zrgbProps = {
                                        fadeTime: configureGroupPropertiesReq
                                            .getZrgbwwaProperties()
                                            .getFadeTime(),
                                        rgbEnabled: configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getRgbEnabled(),
                                        warmWhiteEnabled: configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getWarmWhiteEnabled(),
                                        coolWhiteEnabled: configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getCoolWhiteEnabled(),
                                        amberEnabled: configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getAmberEnabled(),
                                        defaultUpdateType: configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultUpdateType(),
                                        defaultRgbAction: {
                                            red: configureGroupPropertiesReq
                                                .getZrgbwwaProperties().getDefaultRgbAction().getRed(),
                                            green: configureGroupPropertiesReq
                                                .getZrgbwwaProperties().getDefaultRgbAction().getGreen(),
                                            blue: configureGroupPropertiesReq
                                                .getZrgbwwaProperties().getDefaultRgbAction().getBlue(),
                                            pattern: configureGroupPropertiesReq
                                                .getZrgbwwaProperties().getDefaultRgbAction().getPattern(),
                                            deviceState: configureGroupPropertiesReq
                                                .getZrgbwwaProperties().getDefaultRgbAction().getDeviceState()
                                        },
                                        defaultWwaAction: {
                                            warmWhite: configureGroupPropertiesReq
                                                .getZrgbwwaProperties().getDefaultWwaAction().getWarmWhite(),
                                            coolWhite: configureGroupPropertiesReq
                                                .getZrgbwwaProperties().getDefaultWwaAction().getCoolWhite(),
                                            amber: configureGroupPropertiesReq
                                                .getZrgbwwaProperties().getDefaultWwaAction().getAmber(),
                                            deviceState: configureGroupPropertiesReq
                                                .getZrgbwwaProperties().getDefaultWwaAction().getDeviceState()
                                        },
                                        outputChannels: configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getOutputChannels()
                                    };
                                    configureProperties = zrgbProps;
                                    console.log("------------this is rgb default values", zrgbProps);
                                    let dmRgbwwaConfig = new zigbee_rgbwwa_driver_pb_1.DMZigbeeRgbwwaProperties();
                                    dmRgbwwaConfig.setFadeTime(configureGroupPropertiesReq.getZrgbwwaProperties().getFadeTime());
                                    if (configureGroupPropertiesReq.getZrgbwwaProperties().getDefaultUpdateType() == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                                        dmRgbwwaConfig.setUpdateType(device_constants_pb_2.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE);
                                        let dmRgb = new zigbee_rgbwwa_driver_pb_1.DMRGB();
                                        dmRgb.setDeviceState(configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultRgbAction().getDeviceState());
                                        dmRgb.setBlue(configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultRgbAction().getBlue());
                                        dmRgb.setGreen(configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultRgbAction().getGreen());
                                        dmRgb.setRed(configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultRgbAction().getRed());
                                        dmRgb.setPattern(configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultRgbAction().getPattern());
                                        dmRgbwwaConfig.setRgbState(dmRgb);
                                    }
                                    if (configureGroupPropertiesReq.getZrgbwwaProperties().getDefaultUpdateType() == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                                        dmRgbwwaConfig.setUpdateType(device_constants_pb_2.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE);
                                        let dmWwa = new zigbee_rgbwwa_driver_pb_1.DMWWA();
                                        dmWwa.setDeviceState(configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultWwaAction().getDeviceState());
                                        dmWwa.setAmber(configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultWwaAction().getAmber());
                                        dmWwa.setCoolWhite(configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultWwaAction().getCoolWhite());
                                        dmWwa.setWarmWhite(configureGroupPropertiesReq
                                            .getZrgbwwaProperties().getDefaultWwaAction().getWarmWhite());
                                        dmRgbwwaConfig.setWwaState(dmWwa);
                                    }
                                    dmConfigureGroupProperties.setDmzrgbwwaProperties(dmRgbwwaConfig);
                                }
                                break;
                            // case GROUP_TYPES.APPLIANCE_ON_OFF:
                            //     configureProperties = group.groupProperties;
                            //     break;
                            // case GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                            //     configureProperties = group.groupProperties;
                            //     break;
                            // case GROUP_TYPES.APPLIANCE_FAN:
                            //     configureProperties = group.groupProperties;
                            //     break;
                            // case GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                            //     configureProperties = group.groupProperties;
                            //     break;
                            default:
                                invalidPropertySet = true;
                        }
                        if (invalidPropertySet) {
                            resolve(response_1.default.getInvalidPropertySet());
                        }
                        else {
                            //Await zigbee call here - Get Request Id from zigbee call
                            //make changes for embedded appliance
                            const dmConfigureGroupPropertiesRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmConfigureGroupProperties.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMConfigureGroupProperties'));
                            if (!dmConfigureGroupPropertiesRsp.getSuccess()) {
                                throw new Error(dmConfigureGroupPropertiesRsp.getMessage());
                            }
                            const reqId = dmConfigureGroupPropertiesRsp.getRequestId();
                            const syncState = {
                                syncState: group_structures_pb_1.GROUP_SYNC_STATES.GROUPSYNCPENDING,
                                lastRequestId: reqId,
                                lastRequestParameters: configureProperties,
                                lastRequestTime: Date.now(),
                                lastRequestType: group_structures_pb_1.GROUP_JOB_TYPES.GROUP_CONFIGURE,
                                syncedDevices: []
                            };
                            const updatedGroup = await keus_group_1.default.updateGroupSyncState(group.groupId, group.groupRoom, syncState);
                            resolve(response_1.default.getConfigureGroupPropertiesQueued(reqId));
                            // updatedDeviceList = group.deviceList;
                            // if (updatedDeviceList.length) {
                            //     await KeusDeviceModel.updateGroupDeviceProperties(
                            //         updatedDeviceList,
                            //         configureProperties
                            //     );
                            //     const updatedGroup = await KeusGroupModel.configureGroupProperties(
                            //         group.groupId,
                            //         group.groupRoom,
                            //         configureProperties,
                            //         isHidden
                            //     );
                            //     //Check if device properties need to be updated
                            //     if (updatedDeviceList.length == group.deviceList.length) {
                            //         resolve(
                            //             ConfigureGroupPropertiesResponse.getConfigureGroupPropertiesSuccessful(
                            //                 ProtoUtils.GroupProtoUtils.getGroupProto(updatedGroup)
                            //             )
                            //         );
                            //     } else {
                            //         resolve(
                            //             ConfigureGroupPropertiesResponse.getSomeDevicesConfigured(
                            //                 ProtoUtils.GroupProtoUtils.getGroupProto(updatedGroup)
                            //             )
                            //         );
                            //     }
                            // } else {
                            //     resolve(ConfigureGroupPropertiesResponse.getNoDevicesWereConfigured());
                            // }
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map