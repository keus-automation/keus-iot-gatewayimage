"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class ConfigureGroupPropertiesResp {
    static getConfigureGroupPropertiesQueued(requestId) {
        const resp = new group_structures_pb_1.ConfigureGroupPropertiesResponse();
        resp.setCode(800);
        resp.setMessage('Configure Group Properties Queued');
        resp.setSuccess(true);
        resp.setRequestId(requestId);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGroupPropertiesResp.responseType);
    }
    static getInvalidPropertySet() {
        const resp = new group_structures_pb_1.ConfigureGroupPropertiesResponse();
        resp.setCode(801);
        resp.setMessage('Get Invalid Property Set');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGroupPropertiesResp.responseType);
    }
    static getInvalidGroupId() {
        const resp = new group_structures_pb_1.ConfigureGroupPropertiesResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Group Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGroupPropertiesResp.responseType);
    }
    static getInternalServerError() {
        const resp = new group_structures_pb_1.ConfigureGroupPropertiesResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGroupPropertiesResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new group_structures_pb_1.ConfigureGroupPropertiesResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGroupPropertiesResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new group_structures_pb_1.ConfigureGroupPropertiesResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGroupPropertiesResp.responseType);
    }
}
exports.default = ConfigureGroupPropertiesResp;
ConfigureGroupPropertiesResp.responseType = system_constants_1.ProtoPackageName + '.ConfigureGroupPropertiesResponse';
//# sourceMappingURL=response.js.map