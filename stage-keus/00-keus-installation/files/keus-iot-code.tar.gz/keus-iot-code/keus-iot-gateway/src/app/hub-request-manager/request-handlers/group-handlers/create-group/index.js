"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const GroupUtils = __importStar(require("../../../../../utilities/gateway/group-utils"));
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const HomeUtils = __importStar(require("../../../../../utilities/gateway/home-utils"));
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const local_client_1 = require("../../../local-client");
const group_structures_pb_2 = require("../../../../device-manager/providers/generated/groups/group_structures_pb");
const general_1 = require("../../../../../utilities/general");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (createGroupReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!createGroupReq.getGroupName() || !createGroupReq.getGroupName().length) {
                    throw new errors_1.GroupErrors.InvalidGroupName();
                }
                else {
                    const room = await keus_home_1.default.getRoomById(createGroupReq.getGroupRoom());
                    if (!room) {
                        throw new errors_1.HomeErrors.InvalidRoomId();
                    }
                    else {
                        const section = room.sectionList.find(section => section.sectionId == createGroupReq.getGroupSection());
                        if (!section) {
                            throw new errors_1.HomeErrors.InvalidSectionId();
                        }
                        else {
                            const roomIdsInArea = HomeUtils.getRoomIdsFromRoomList(await keus_home_1.default.getRoomsByArea(room.areaId));
                            const groupList = await keus_group_1.default.getGroupsByRooms(roomIdsInArea);
                            const filteredGroupList = groupList.filter(function (group) {
                                return (group.groupName == createGroupReq.getGroupName() &&
                                    group.groupSection == section.sectionId &&
                                    group.groupRoom == createGroupReq.getGroupRoom());
                            });
                            if (filteredGroupList.length) {
                                throw new errors_1.GroupErrors.DuplicateGroupName();
                            }
                            else {
                                //Change to zigbee call for the group id
                                const createDMGroupReq = new group_structures_pb_2.DMCreateGroup();
                                createDMGroupReq.setGroupArea(room.areaId);
                                // const groupId = GroupUtils.generateGroupIdForArea(groupList);
                                const createDMGroupRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(createDMGroupReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMCreateGroup'));
                                if (!createDMGroupRsp.getSuccess()) {
                                    throw new Error(createDMGroupRsp.getMessage());
                                }
                                let groupId = createDMGroupRsp.getGroupId();
                                // const groupId = 27;
                                if (groupId < 0) {
                                    throw new errors_1.GroupErrors.GroupLimitReached();
                                }
                                else {
                                    const newGroup = {
                                        groupId: groupId,
                                        groupName: createGroupReq.getGroupName(),
                                        groupType: createGroupReq.getGroupType(),
                                        groupSection: createGroupReq.getGroupSection(),
                                        groupRoom: createGroupReq.getGroupRoom(),
                                        isHidden: false,
                                        isConfigured: false,
                                        isHighPower: false,
                                        groupVoiceName: createGroupReq.getGroupName(),
                                        groupState: GroupUtils.getDefaultGroupState(createGroupReq.getGroupType()),
                                        groupProperties: GroupUtils.getDefaultGroupProperties(createGroupReq.getGroupType()),
                                        groupSyncState: {
                                            syncState: group_structures_pb_1.GROUP_SYNC_STATES.GROUPINSYNC,
                                            lastRequestId: '-',
                                            lastRequestType: group_structures_pb_1.GROUP_JOB_TYPES.GROUP_CONFIGURE,
                                            lastRequestParameters: {},
                                            lastRequestTime: Date.now(),
                                            syncedDevices: []
                                        },
                                        deviceList: [],
                                        lastUpdateTime: Date.now(),
                                        lastUpdateBy: system_constants_1.SystemNumber,
                                        lastUpdateSource: system_constants_1.UpdateSourceMapping.SYSTEM,
                                        lastUpdateUser: system_constants_1.SystemUser
                                    };
                                    console.log('-----------new gorup state', newGroup.groupState);
                                    await keus_group_1.default.addGroup(newGroup);
                                    resolve(response_1.default.getCreateGroupSuccessful(ProtoUtils.GroupProtoUtils.getGroupProto(newGroup)));
                                }
                            }
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.GroupErrors.InvalidGroupName:
                        resolve(response_1.default.getInvalidGroupName());
                        break;
                    case errors_1.HomeErrors.InvalidRoomId:
                        resolve(response_1.default.getInvalidRoomId());
                        break;
                    case errors_1.HomeErrors.InvalidSectionId:
                        resolve(response_1.default.getInvalidSectionId());
                        break;
                    case errors_1.GroupErrors.DuplicateGroupName:
                        resolve(response_1.default.getDuplicateGroupName());
                        break;
                    case errors_1.GroupErrors.GroupLimitReached:
                        resolve(response_1.default.getGroupLimitReached());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map