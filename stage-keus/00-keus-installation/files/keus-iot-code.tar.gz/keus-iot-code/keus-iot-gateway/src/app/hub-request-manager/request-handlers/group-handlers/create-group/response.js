"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class CreateGroupResp {
    static getCreateGroupSuccessful(group) {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(800);
        resp.setMessage('Add Group Successful');
        resp.setSuccess(true);
        resp.setGroup(group);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getInvalidGroupName() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Group Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getInvalidGroupType() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Group Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getInvalidRoomId() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(803);
        resp.setMessage('Invalid Room Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getInvalidSectionId() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Section Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getGroupLimitReached() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(805);
        resp.setMessage('Group Limit Reached');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getIncompatibleDeviceTypes() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(806);
        resp.setMessage('Incompatible Device Types');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getDeviceInAnotherGroup() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(807);
        resp.setMessage('Device In Another Group');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getDuplicateGroupName() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(808);
        resp.setMessage('Duplicate Group Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getInternalServerError() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new group_structures_pb_1.CreateGroupResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateGroupResp.responseType);
    }
}
exports.default = CreateGroupResp;
CreateGroupResp.responseType = system_constants_1.ProtoPackageName + '.CreateGroupResponse';
//# sourceMappingURL=response.js.map