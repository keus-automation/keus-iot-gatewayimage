"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const group_structures_pb_2 = require("../../../../device-manager/providers/generated/groups/group_structures_pb");
const local_client_1 = require("../../../local-client");
const system_constants_2 = require("../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../utilities/general");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (deleteGroupReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!deleteGroupReq.getGroupId() || !deleteGroupReq.getGroupRoom()) {
                    throw new errors_1.GroupErrors.InvalidGroupId();
                }
                else {
                    const group = await keus_group_1.default.getGroupById(deleteGroupReq.getGroupId(), deleteGroupReq.getGroupRoom());
                    if (!group) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    else {
                        let groupRoom = await keus_home_1.default.getRoomById(deleteGroupReq.getGroupRoom());
                        const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_2.MultiGateway.GatewayMode.MAIN_GATEWAY);
                        // await Zigbee call here and get reqId
                        const dmDeleteGroupReq = new group_structures_pb_2.DMDeleteGroup();
                        dmDeleteGroupReq.setGroupId(group.groupId);
                        dmDeleteGroupReq.setGroupArea(groupRoom.areaId);
                        dmDeleteGroupReq.setForceDelete(false);
                        dmDeleteGroupReq.setReportServiceName(system_constants_2.getGatewayManagerServiceName(gateway[0].gatewayId));
                        const dmDeleteGroupRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_2.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmDeleteGroupReq.serializeBinary(), system_constants_2.DeviceManager.ProtoPackageName + '.DMDeleteGroup'));
                        if (!dmDeleteGroupRsp.getSuccess()) {
                            throw new Error(dmDeleteGroupRsp.getMessage());
                        }
                        const reqId = dmDeleteGroupRsp.getRequestId();
                        //zigbee call end
                        const syncState = {
                            syncState: group_structures_pb_1.GROUP_SYNC_STATES.GROUPSYNCPENDING,
                            lastRequestId: reqId,
                            lastRequestParameters: {},
                            lastRequestTime: Date.now(),
                            lastRequestType: group_structures_pb_1.GROUP_JOB_TYPES.GROUP_DELETE,
                            syncedDevices: []
                        };
                        const updatedGroup = await keus_group_1.default.updateGroupSyncState(group.groupId, group.groupRoom, syncState);
                        resolve(response_1.default.getDeleteGroupQueued(reqId));
                        //Remove groups from all existing inwall switches
                        // const roomInwallList = await KeusDeviceModel.getInwallDevicesByRoomSection(
                        //     group.groupRoom,
                        //     group.groupSection
                        // );
                        //Remove groups from all existing scenes
                        // const sceneList = await KeusSceneModel.getScenesByRoomSection(
                        //     group.groupRoom,
                        //     group.groupSection
                        // );
                        //Remove groups from all existing schedules
                        //Remove groups from all existing favorites
                        // await KeusDeviceModel.updateDeviceGroups(group.deviceList, NoGroupId);
                        // await KeusGroupModel.deleteGroupById(group.groupId, group.groupRoom);
                        // resolve(DeleteGroupResponse.getDeleteGroupSuccessful());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GroupErrors.InvalidGroupId:
                        resolve(response_1.default.getInvalidGroupId());
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map