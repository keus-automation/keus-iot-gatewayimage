"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class DeleteGroupResp {
    static getDeleteGroupQueued(reqId) {
        const resp = new group_structures_pb_1.DeleteGroupResponse();
        resp.setCode(800);
        resp.setMessage('Delete Group Queued');
        resp.setSuccess(true);
        resp.setRequestId(reqId);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteGroupResp.responseType);
    }
    static getInvalidGroupId() {
        const resp = new group_structures_pb_1.DeleteGroupResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Group Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteGroupResp.responseType);
    }
    static getInternalServerError() {
        const resp = new group_structures_pb_1.DeleteGroupResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteGroupResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new group_structures_pb_1.DeleteGroupResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteGroupResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new group_structures_pb_1.DeleteGroupResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteGroupResp.responseType);
    }
}
exports.default = DeleteGroupResp;
DeleteGroupResp.responseType = system_constants_1.ProtoPackageName + '.DeleteGroupResponse';
//# sourceMappingURL=response.js.map