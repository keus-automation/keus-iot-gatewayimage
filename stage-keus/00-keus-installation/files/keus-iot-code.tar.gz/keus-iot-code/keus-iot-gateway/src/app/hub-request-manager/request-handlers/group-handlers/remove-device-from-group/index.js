"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const group_constants_1 = require("../../../../../constants/group/group-constants");
// import { DebugZMRequest } from 'device-manager/providers/generated/zigbee_pb';
const general_1 = require("../../../../../utilities/general");
const group_structures_pb_2 = require("../../../../device-manager/providers/generated/groups/group_structures_pb");
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const local_client_1 = require("../../../local-client");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const device_categories_1 = __importDefault(require("../../../../../constants/device/device-categories"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (removeDeviceFromGroupReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!removeDeviceFromGroupReq.getGroupId() || !removeDeviceFromGroupReq.getGroupRoom()) {
                    response_1.default.getInvalidGroupId();
                }
                else if (!removeDeviceFromGroupReq.getDeviceId()) {
                    response_1.default.getInvalidDeviceId();
                }
                else {
                    const group = await keus_group_1.default.getGroupById(removeDeviceFromGroupReq.getGroupId(), removeDeviceFromGroupReq.getGroupRoom());
                    const device = await keus_device_1.default.getDeviceById(removeDeviceFromGroupReq.getDeviceId());
                    if (!group) {
                        response_1.default.getInvalidGroupId();
                    }
                    else if (!device) {
                        response_1.default.getInvalidDeviceId();
                    }
                    else {
                        let updatedGroup;
                        if (device.deviceCategory == device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode) {
                            let deviceProps = device.deviceProperties;
                            let applianceList = deviceProps.appliance;
                            let appliance = applianceList.find(function (app) {
                                return app.applianceId == removeDeviceFromGroupReq.getApplianceId();
                            });
                            console.log(applianceList, removeDeviceFromGroupReq.getApplianceId());
                            appliance.inGroup = false;
                            appliance.groupId = group_constants_1.NoGroupId;
                            appliance.groupRoom = '';
                            let final_device_properties = {
                                outputPorts: deviceProps.outputPorts,
                                appliance: applianceList,
                                switch: deviceProps.switch
                            };
                            const room = await keus_home_1.default.getRoomById(removeDeviceFromGroupReq.getGroupRoom());
                            const dmRemoveDeviceFromGroupReq = new group_structures_pb_2.DMRemoveDeviceFromGroup();
                            dmRemoveDeviceFromGroupReq.setDeviceId(removeDeviceFromGroupReq.getDeviceId());
                            dmRemoveDeviceFromGroupReq.setGroupArea(room.areaId);
                            dmRemoveDeviceFromGroupReq.setGroupId(removeDeviceFromGroupReq.getGroupId());
                            dmRemoveDeviceFromGroupReq.setApplianceId(appliance.applianceId);
                            dmRemoveDeviceFromGroupReq.setForceDelete(removeDeviceFromGroupReq.getForceDelete());
                            const dmRemoveDeviceFromGroupRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveDeviceFromGroupReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveDeviceFromGroup'));
                            if (!dmRemoveDeviceFromGroupRsp.getSuccess()) {
                                throw new Error(dmRemoveDeviceFromGroupRsp.getMessage());
                            }
                            await keus_device_1.default.updateDeviceProperties(device.deviceId, final_device_properties, true);
                            let grp;
                            switch (group.groupType) {
                                case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
                                    grp = group.groupProperties;
                                    break;
                                case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                                    grp = group.groupProperties;
                                    break;
                                case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                                    grp = group.groupProperties;
                                    break;
                                case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                                    grp = group.groupProperties;
                                    break;
                            }
                            grp.deviceList = grp.deviceList.filter(function (dl) {
                                return dl.deviceId != removeDeviceFromGroupReq.getDeviceId() && dl.applianceId != removeDeviceFromGroupReq.getApplianceId();
                            });
                            updatedGroup = await keus_group_1.default.configureGroupProperties(group.groupId, group.groupRoom, grp, false);
                        }
                        else {
                            if (device.inGroup && device.deviceGroup != group.groupId) {
                                response_1.default.getDeviceInAnotherGroup();
                            }
                            else {
                                const room = await keus_home_1.default.getRoomById(removeDeviceFromGroupReq.getGroupRoom());
                                const dmRemoveDeviceFromGroupReq = new group_structures_pb_2.DMRemoveDeviceFromGroup();
                                dmRemoveDeviceFromGroupReq.setDeviceId(removeDeviceFromGroupReq.getDeviceId());
                                dmRemoveDeviceFromGroupReq.setGroupArea(room.areaId);
                                dmRemoveDeviceFromGroupReq.setGroupId(removeDeviceFromGroupReq.getGroupId());
                                dmRemoveDeviceFromGroupReq.setForceDelete(removeDeviceFromGroupReq.getForceDelete());
                                const dmRemoveDeviceFromGroupRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveDeviceFromGroupReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveDeviceFromGroup'));
                                if (!dmRemoveDeviceFromGroupRsp.getSuccess()) {
                                    throw new Error(dmRemoveDeviceFromGroupRsp.getMessage());
                                }
                                await keus_device_1.default.updateDeviceGroup(device.deviceId, group_constants_1.NoGroupId, removeDeviceFromGroupReq.getGroupRoom());
                                var updatedDeviceList;
                                updatedDeviceList = group.deviceList.filter(function (deviceId) {
                                    return deviceId != removeDeviceFromGroupReq.getDeviceId();
                                });
                                updatedGroup = await keus_group_1.default.updateGroupDeviceList(group.groupId, group.groupRoom, updatedDeviceList);
                            }
                        }
                        resolve(response_1.default.getRemoveDeviceFromGroupSuccessful(ProtoUtils.GroupProtoUtils.getGroupProto(updatedGroup)));
                    }
                }
            }
            catch (e) {
                console.log(e);
                switch (e.constructor) {
                    default:
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map