"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../utilities/general");
const local_client_1 = require("../../../local-client");
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const cloud_client_1 = require("../../../cloud-client");
const zigbee_dimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_dimmable_driver_pb");
const zigbee_nondimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_nondimmable_driver_pb");
const dali_dimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/dali_dimmable_driver_pb");
const dali_nondimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/dali_nondimmable_driver_pb");
const zigbee_inline_dimmer_pb_1 = require("../../../protos/generated/hub/devices/zigbee_inline_dimmer_pb");
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const zigbee_rgbwwa_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const zigbee_embedded_switch_pb_1 = require("../../../protos/generated/hub/devices/zigbee_embedded_switch_pb");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const reqType = system_constants_1.ProtoPackageName + '.UpdateGroupState';
const eventType = system_constants_1.ProtoPackageName + '.UpdateGroupEvent';
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (reportGroupActivity, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                const roomList = await keus_home_1.default.getRoomsByArea(reportGroupActivity.getGroupIdentifier().getAreaId());
                const groupList = await keus_group_1.default.getGroupsByRooms(home_utils_1.getRoomIdsFromRoomList(roomList));
                const group = groupList.find(function (grp) {
                    return grp.groupId == reportGroupActivity.getGroupIdentifier().getGroupId();
                });
                const groupState = reportGroupActivity.getGroupState();
                const updateGroupStateReq = new group_structures_pb_1.UpdateGroupState();
                var updateState;
                var invalidStateSet = false;
                if (!group) {
                    resolve(response_1.default.getInvalidGroupId());
                }
                else {
                    updateGroupStateReq.setGroupId(group.groupId);
                    updateGroupStateReq.setGroupRoom(group.groupRoom);
                    switch (group.groupType) {
                        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
                            const zddProps = group.groupProperties;
                            var zddState = {
                                driverState: groupState ? zddProps.defaultState : groupState
                            };
                            updateState = zddState;
                            const zddProtoState = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverState();
                            zddProtoState.setDriverState(zddState.driverState);
                            updateGroupStateReq.setZdimmableDriverState(zddProtoState);
                            break;
                        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
                            var zndState = {
                                driverState: groupState
                            };
                            updateState = zndState;
                            const zndProtoState = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverState();
                            zndProtoState.setDriverState(zddState.driverState);
                            updateGroupStateReq.setZnondimmableDriverState(zndProtoState);
                            break;
                        case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
                            const dddProps = group.groupProperties;
                            var dddState = {
                                driverState: groupState ? dddProps.defaultState : groupState
                            };
                            updateState = dddState;
                            const dddProtoState = new dali_dimmable_driver_pb_1.DaliDimmableDriverState();
                            dddProtoState.setDriverState(dddState.driverState);
                            updateGroupStateReq.setDdimmableDriverState(dddProtoState);
                            break;
                        case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
                            var dndState = {
                                driverState: groupState
                            };
                            updateState = dndState;
                            const dndProtoState = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverState();
                            dndProtoState.setDriverState(dndState.driverState);
                            updateGroupStateReq.setDnondimmableDriverState(dndProtoState);
                            break;
                        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
                            const zidProps = group.groupProperties;
                            var zidState = {
                                deviceState: groupState ? zidProps.defaultState : groupState
                            };
                            updateState = zidState;
                            const zidProtoState = new zigbee_inline_dimmer_pb_1.ZigbeeInlineDimmerState();
                            zidProtoState.setDeviceState(zidState.deviceState);
                            updateGroupStateReq.setZinlineDimmerState(zidProtoState);
                            break;
                        case group_structures_pb_1.GROUP_TYPES.RGBWWA:
                            const zrgbwwaProps = group.groupProperties;
                            let zrgbwwaDbState = group.groupState;
                            var rgbwwaState = {
                                deviceState: groupState,
                                updateType: zrgbwwaProps.defaultUpdateType
                            };
                            const zrgbGroupState = new zigbee_rgbwwa_driver_pb_1.GroupZigbeeRgbwwaState();
                            zrgbGroupState.setUpdateType(zrgbwwaProps.defaultUpdateType);
                            zrgbGroupState.setDeviceState(groupState);
                            if (zrgbwwaProps.defaultUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                                rgbwwaState.rgbState = {
                                    red: zrgbwwaProps.defaultRgbAction.red,
                                    green: zrgbwwaProps.defaultRgbAction.green,
                                    blue: zrgbwwaProps.defaultRgbAction.blue,
                                    deviceState: groupState,
                                    pattern: zrgbwwaProps.defaultRgbAction.pattern
                                };
                                rgbwwaState.wwaState = {
                                    warmWhite: zrgbwwaDbState.wwaState.warmWhite,
                                    coolWhite: zrgbwwaDbState.wwaState.coolWhite,
                                    amber: zrgbwwaDbState.wwaState.amber,
                                    deviceState: zrgbwwaDbState.wwaState.deviceState
                                };
                                const rgbProto = new zigbee_rgbwwa_driver_pb_1.RGB();
                                rgbProto.setRed(zrgbwwaProps.defaultRgbAction.red);
                                rgbProto.setBlue(zrgbwwaProps.defaultRgbAction.blue);
                                rgbProto.setGreen(zrgbwwaProps.defaultRgbAction.green);
                                rgbProto.setPattern(zrgbwwaProps.defaultRgbAction.pattern);
                                rgbProto.setDeviceState(groupState);
                                zrgbGroupState.setRgbState(rgbProto);
                            }
                            else {
                                rgbwwaState.wwaState = {
                                    warmWhite: zrgbwwaProps.defaultWwaAction.warmWhite,
                                    coolWhite: zrgbwwaProps.defaultWwaAction.coolWhite,
                                    amber: zrgbwwaProps.defaultWwaAction.amber,
                                    deviceState: groupState
                                };
                                rgbwwaState.rgbState = {
                                    red: zrgbwwaDbState.rgbState.red,
                                    green: zrgbwwaDbState.rgbState.green,
                                    blue: zrgbwwaDbState.rgbState.blue,
                                    deviceState: zrgbwwaDbState.rgbState.deviceState,
                                    pattern: zrgbwwaDbState.rgbState.pattern
                                };
                                const wwaProto = new zigbee_rgbwwa_driver_pb_1.WWA();
                                wwaProto.setWarmWhite(zrgbwwaProps.defaultWwaAction.warmWhite);
                                wwaProto.setCoolWhite(zrgbwwaProps.defaultWwaAction.coolWhite);
                                wwaProto.setAmber(zrgbwwaProps.defaultWwaAction.amber);
                                wwaProto.setDeviceState(groupState);
                                zrgbGroupState.setWwaState(wwaProto);
                            }
                            updateState = rgbwwaState;
                            updateGroupStateReq.setZrgbwwaState(zrgbGroupState);
                            break;
                        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
                            var onOffState = {
                                switchState: groupState
                            };
                            updateState = onOffState;
                            const onOffApplProtoState = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
                            onOffApplProtoState.setSwitchState(onOffState.switchState);
                            updateGroupStateReq.setAppOnffState(onOffApplProtoState);
                            break;
                        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                            var sdState = {
                                switchState: groupState
                            };
                            updateState = sdState;
                            const singleDimmerProtoState = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
                            singleDimmerProtoState.setSwitchState(sdState.switchState);
                            updateGroupStateReq.setAppSingleDimmerState(singleDimmerProtoState);
                            break;
                        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                            var fanState = {
                                fanState: groupState
                            };
                            updateState = fanState;
                            const fanProtoState = new zigbee_embedded_switch_pb_1.FanApplianceState();
                            fanProtoState.setFanState(fanState.fanState);
                            updateGroupStateReq.setAppFanState(fanProtoState);
                            break;
                        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                            const groupDbState = group.groupState;
                            var ctState = {
                                lightState: groupState,
                                warmWhiteState: groupDbState.warmWhiteState,
                                coolWhiteState: groupDbState.coolWhiteState
                            };
                            updateState = ctState;
                            const ctProtoState = new zigbee_embedded_switch_pb_1.ColorTunableApplianceState();
                            ctProtoState.setLightState(ctState.lightState);
                            ctProtoState.setWarmWhiteState(ctState.warmWhiteState);
                            ctProtoState.setCoolWhiteState(ctState.coolWhiteState);
                            break;
                        default:
                            invalidStateSet = true;
                    }
                    if (invalidStateSet) {
                        resolve(response_1.default.getInvalidStateSet());
                    }
                    else {
                        const updatedGroup = await keus_group_1.default.updateGroupStateAndSource(group.groupId, group.groupRoom, updateState, phone, system_constants_1.UpdateSourceMapping.MANUAL, reportGroupActivity.getActivityTime(), user.userName);
                        // let roomDetails = await KeusHomeModel.getRoomById(group.groupRoom);
                        // let activityObj = await getGroupActivityObj(user, group, roomDetails, updateGroupStateReq, {
                        //     activitySource: UpdateSourceMapping.SYSTEM
                        // });
                        // await KeusActivityModel.insertActivity(activityObj);
                        //-----------------------Update Group State State Event--------------------------------
                        console.log('Throwing Group Event');
                        const updtGroupEvent = new group_structures_pb_1.UpdateGroupEvent();
                        updtGroupEvent.setUpdateState(updateGroupStateReq);
                        updtGroupEvent.setActivitySource(system_constants_1.UpdateSourceMapping.MANUAL);
                        updtGroupEvent.setActivityUser(phone);
                        updtGroupEvent.setActivityTime(reportGroupActivity.getActivityTime());
                        const eventArg = general_1.PackIntoAny(updtGroupEvent.serializeBinary(), eventType);
                        local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                        cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                        resolve(response_1.default.getUpdateGroupStateSuccessful(ProtoUtils.GroupProtoUtils.getGroupProto(updatedGroup)));
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map