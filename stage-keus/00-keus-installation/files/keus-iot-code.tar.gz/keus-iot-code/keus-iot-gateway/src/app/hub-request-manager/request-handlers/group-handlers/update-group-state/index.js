"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../utilities/general");
const group_structures_pb_2 = require("../../../../device-manager/providers/generated/groups/group_structures_pb");
const local_client_1 = require("../../../local-client");
const zigbee_dimmable_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_dimmable_driver_pb");
const dali_dimmable_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/dali_dimmable_driver_pb");
const zigbee_rgbwwa_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_rgbwwa_driver_pb");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const keus_activity_1 = __importDefault(require("../../../../../models/database-models/keus-activity"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const activity_utils_1 = require("../../../../../utilities/gateway/activity-utils");
const cloud_client_1 = require("../../../cloud-client");
const reqType = system_constants_1.ProtoPackageName + '.UpdateGroupState';
const zigbee_embedded_switch_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_embedded_switch_pb");
const device_constants_pb_1 = require("../../../../device-manager/providers/generated/devices/device_constants_pb");
const dali_colour_tunable_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/dali_colour_tunable_driver_pb");
const eventType = system_constants_1.ProtoPackageName + '.UpdateGroupEvent';
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (updateGroupStateReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                if (!updateGroupStateReq.getGroupId() || !updateGroupStateReq.getGroupRoom()) {
                    resolve(response_1.default.getInvalidGroupId());
                }
                else {
                    const execTime = Date.now();
                    const group = await keus_group_1.default.getGroupById(updateGroupStateReq.getGroupId(), updateGroupStateReq.getGroupRoom());
                    let user = await keus_user_1.default.getUserByPhone(phone);
                    await home_utils_1.checkAccessForUser(user, group.groupRoom);
                    if (!group) {
                        resolve(response_1.default.getInvalidGroupId());
                    }
                    else {
                        var finalState = 0;
                        var updateState;
                        var invalidStateSet = false;
                        let room = await keus_home_1.default.getRoomById(updateGroupStateReq.getGroupRoom());
                        const dmUpdateGroupStateReq = new group_structures_pb_2.DMUpdateGroupState();
                        dmUpdateGroupStateReq.setGroupId(updateGroupStateReq.getGroupId());
                        dmUpdateGroupStateReq.setGroupArea(room.areaId);
                        // const groupId = GroupUtils.generateGroupIdForArea(groupList);
                        switch (group.groupType) {
                            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
                                if (!updateGroupStateReq.hasZdimmableDriverState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    var zddState = {
                                        driverState: updateGroupStateReq.getZdimmableDriverState().getDriverState()
                                    };
                                    updateState = zddState;
                                    finalState = zddState.driverState;
                                    let dmZddState = new zigbee_dimmable_driver_pb_1.DMZigbeeDimmableDriverState();
                                    dmZddState.setDriverState(finalState);
                                    dmUpdateGroupStateReq.setDmzdimmableDriverState(dmZddState);
                                    dmUpdateGroupStateReq.setGroupType(group_structures_pb_2.DMGROUP_TYPES.ZIGBEE_DIMMABLE);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
                                if (!updateGroupStateReq.hasZnondimmableDriverState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    var zndState = {
                                        driverState: updateGroupStateReq.getZnondimmableDriverState().getDriverState()
                                    };
                                    updateState = zndState;
                                    finalState = zndState.driverState;
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
                                if (!updateGroupStateReq.hasDdimmableDriverState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    var dddState = {
                                        driverState: updateGroupStateReq.getDdimmableDriverState().getDriverState()
                                    };
                                    updateState = dddState;
                                    finalState = dddState.driverState;
                                    let dmDddState = new dali_dimmable_driver_pb_1.DMDaliDimmableDriverState();
                                    dmDddState.setDriverState(finalState);
                                    dmUpdateGroupStateReq.setDmddimmableDriverState(dmDddState);
                                    dmUpdateGroupStateReq.setGroupType(group_structures_pb_2.DMGROUP_TYPES.DALI_DIMMABLE);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
                                if (!updateGroupStateReq.hasDcolortunableDriverState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    var dctdState = {
                                        driverState: updateGroupStateReq.getDcolortunableDriverState().getDriverState(),
                                        colorTemperature: updateGroupStateReq.getDcolortunableDriverState().getColorTemperature(),
                                        lastUpdateBy: phone,
                                        lastUpdateSource: system_constants_1.UpdateSourceMapping.ANDROID,
                                        lastUpdateUser: user.userName,
                                        lastUpdateTime: Date.now()
                                    };
                                    updateState = dctdState;
                                    let DmDctdUpdateObj = new dali_colour_tunable_driver_pb_1.DMDaliColourTunableDriverState();
                                    DmDctdUpdateObj.setDriverState(dctdState.driverState);
                                    DmDctdUpdateObj.setDriverTemp(dctdState.colorTemperature);
                                    dmUpdateGroupStateReq.setDmdcolourTunableDriverState(DmDctdUpdateObj);
                                    dmUpdateGroupStateReq.setGroupType(group_structures_pb_2.DMGROUP_TYPES.DALI_COLOR_TUNABLE);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
                                if (!updateGroupStateReq.hasDnondimmableDriverState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    var dndState = {
                                        driverState: updateGroupStateReq.getDnondimmableDriverState().getDriverState()
                                    };
                                    updateState = dndState;
                                    finalState = dndState.driverState;
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
                                if (!updateGroupStateReq.hasZinlineDimmerState()) {
                                    invalidStateSet = true;
                                }
                                else
                                    var zidState = {
                                        deviceState: updateGroupStateReq.getZinlineDimmerState().getDeviceState()
                                    };
                                updateState = zidState;
                                break;
                            case group_structures_pb_1.GROUP_TYPES.RGBWWA:
                                if (!updateGroupStateReq.hasZrgbwwaState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    let rgbwwaDeviceupdateState;
                                    let dmRgbwwaState = new zigbee_rgbwwa_driver_pb_1.DMZigbeeRgbwwaState();
                                    let rgbwwaDbState = group.groupState;
                                    console.log("-----------------this is db state ", rgbwwaDbState);
                                    var rgbwwaState = {
                                        deviceState: updateGroupStateReq.getZrgbwwaState().getDeviceState(),
                                        updateType: updateGroupStateReq.getZrgbwwaState().getUpdateType(),
                                    };
                                    if (updateGroupStateReq.getZrgbwwaState().hasRgbState()) {
                                        rgbwwaState.rgbState = {
                                            red: updateGroupStateReq.getZrgbwwaState().getRgbState().getRed(),
                                            green: updateGroupStateReq.getZrgbwwaState().getRgbState().getGreen(),
                                            blue: updateGroupStateReq.getZrgbwwaState().getRgbState().getBlue(),
                                            deviceState: updateGroupStateReq.getZrgbwwaState().getRgbState().getDeviceState(),
                                            pattern: updateGroupStateReq.getZrgbwwaState().getRgbState().getPattern()
                                        };
                                        rgbwwaState.wwaState = {
                                            warmWhite: rgbwwaDbState.wwaState.warmWhite,
                                            coolWhite: rgbwwaDbState.wwaState.coolWhite,
                                            amber: rgbwwaDbState.wwaState.amber,
                                            deviceState: rgbwwaDbState.wwaState.deviceState
                                        };
                                        dmRgbwwaState.setLastUpdateType(device_constants_pb_1.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE);
                                        let dmrgb = new zigbee_rgbwwa_driver_pb_1.DMRGB();
                                        dmrgb.setRed(updateGroupStateReq.getZrgbwwaState().getRgbState().getRed());
                                        dmrgb.setGreen(updateGroupStateReq.getZrgbwwaState().getRgbState().getGreen());
                                        dmrgb.setBlue(updateGroupStateReq.getZrgbwwaState().getRgbState().getBlue());
                                        console.log('this is rgb device state', updateGroupStateReq.getZrgbwwaState().getRgbState().getDeviceState());
                                        dmrgb.setDeviceState(updateGroupStateReq.getZrgbwwaState().getRgbState().getDeviceState());
                                        dmrgb.setPattern(updateGroupStateReq.getZrgbwwaState().getRgbState().getPattern());
                                        dmRgbwwaState.setLastUpdatedRgbAction(dmrgb);
                                    }
                                    else {
                                        rgbwwaState.wwaState = {
                                            warmWhite: updateGroupStateReq.getZrgbwwaState().getWwaState().getWarmWhite(),
                                            coolWhite: updateGroupStateReq.getZrgbwwaState().getWwaState().getCoolWhite(),
                                            amber: updateGroupStateReq.getZrgbwwaState().getWwaState().getAmber(),
                                            deviceState: updateGroupStateReq.getZrgbwwaState().getWwaState().getDeviceState(),
                                        };
                                        console.log('this is group update state and wwa update state', rgbwwaState.wwaState);
                                        rgbwwaState.rgbState = {
                                            red: rgbwwaDbState.rgbState.red,
                                            green: rgbwwaDbState.rgbState.green,
                                            blue: rgbwwaDbState.rgbState.blue,
                                            deviceState: rgbwwaDbState.rgbState.deviceState,
                                            pattern: rgbwwaDbState.rgbState.pattern
                                        };
                                        dmRgbwwaState.setLastUpdateType(device_constants_pb_1.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE);
                                        let dmwwa = new zigbee_rgbwwa_driver_pb_1.DMWWA();
                                        dmwwa.setWarmWhite(updateGroupStateReq.getZrgbwwaState().getWwaState().getWarmWhite());
                                        dmwwa.setCoolWhite(updateGroupStateReq.getZrgbwwaState().getWwaState().getCoolWhite());
                                        dmwwa.setAmber(updateGroupStateReq.getZrgbwwaState().getWwaState().getAmber());
                                        dmwwa.setDeviceState(updateGroupStateReq.getZrgbwwaState().getWwaState().getDeviceState());
                                        console.log('---------------this is wwa device state', updateGroupStateReq.getZrgbwwaState().getWwaState().getDeviceState());
                                        dmRgbwwaState.setLastUpdatedWwaAction(dmwwa);
                                    }
                                    updateState = rgbwwaState;
                                    dmUpdateGroupStateReq.setDmzrgbwwaState(dmRgbwwaState);
                                    dmUpdateGroupStateReq.setGroupType(group_structures_pb_2.DMGROUP_TYPES.RGBWWA);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
                                if (!updateGroupStateReq.hasAppOnffState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    var onOffState = {
                                        switchState: updateGroupStateReq.getAppOnffState().getSwitchState()
                                    };
                                    updateState = onOffState;
                                    let dmApplOnOffState = new zigbee_embedded_switch_pb_1.DMOnOffApplianceState();
                                    dmApplOnOffState.setSwitchState(onOffState.switchState);
                                    dmUpdateGroupStateReq.setDmappOnffState(dmApplOnOffState);
                                    dmUpdateGroupStateReq.setGroupType(group_structures_pb_2.DMGROUP_TYPES.APPLIANCE_ON_OFF);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                                if (!updateGroupStateReq.hasAppSingleDimmerState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    var sdState = {
                                        switchState: updateGroupStateReq.getAppSingleDimmerState().getSwitchState()
                                    };
                                    updateState = sdState;
                                    let dmApplSingleDimmerState = new zigbee_embedded_switch_pb_1.DMSingleDimmerApplianceState();
                                    dmApplSingleDimmerState.setSwitchState(sdState.switchState);
                                    dmUpdateGroupStateReq.setDmappSingleDimmerState(dmApplSingleDimmerState);
                                    dmUpdateGroupStateReq.setGroupType(group_structures_pb_2.DMGROUP_TYPES.APPLIANCE_SINGLE_DIMMER);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                                if (!updateGroupStateReq.hasAppFanState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    var fanState = {
                                        fanState: updateGroupStateReq.getAppFanState().getFanState()
                                    };
                                    updateState = fanState;
                                    let dmAppFanState = new zigbee_embedded_switch_pb_1.DMFanApplianceState();
                                    dmAppFanState.setFanState(fanState.fanState);
                                    dmUpdateGroupStateReq.setDmappFanState(dmAppFanState);
                                    dmUpdateGroupStateReq.setGroupType(group_structures_pb_2.DMGROUP_TYPES.APPLIANCE_FAN);
                                }
                                break;
                            case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                                if (!updateGroupStateReq.hasAppColorTunableState()) {
                                    invalidStateSet = true;
                                }
                                else {
                                    var ctState = {
                                        lightState: updateGroupStateReq.getAppColorTunableState().getLightState(),
                                        warmWhiteState: updateGroupStateReq
                                            .getAppColorTunableState()
                                            .getWarmWhiteState(),
                                        coolWhiteState: updateGroupStateReq
                                            .getAppColorTunableState()
                                            .getCoolWhiteState()
                                    };
                                    updateState = ctState;
                                    let dmAppCTState = new zigbee_embedded_switch_pb_1.DMColorTunableApplianceState();
                                    dmAppCTState.setCoolWhiteState(ctState.coolWhiteState);
                                    dmAppCTState.setWarmWhiteState(ctState.warmWhiteState);
                                    dmAppCTState.setLightState(ctState.lightState);
                                    dmUpdateGroupStateReq.setDmappColorTunableState(dmAppCTState);
                                    dmUpdateGroupStateReq.setGroupType(group_structures_pb_2.DMGROUP_TYPES.APPLIANCE_COLOR_TUNABLE);
                                }
                                break;
                            default:
                                invalidStateSet = true;
                        }
                        if (invalidStateSet) {
                            resolve(response_1.default.getInvalidStateSet());
                        }
                        else {
                            console.log('REACHING HERE ===============================================');
                            const dmUpdateGroupStateRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmUpdateGroupStateReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMUpdateGroupState'));
                            if (!dmUpdateGroupStateRsp.getSuccess()) {
                                throw new Error(dmUpdateGroupStateRsp.getMessage());
                            }
                            console.log('AFTER ZIGBEE');
                            //DO WORK AROUND
                            //  await KeusDeviceModel.updateGroupDeviceStates(group.deviceList, updateState);
                            const updatedGroup = await keus_group_1.default.updateGroupStateAndSource(group.groupId, group.groupRoom, updateState, phone, system_constants_1.UpdateSourceMapping.ANDROID, execTime, user.userName);
                            let roomDetails = await keus_home_1.default.getRoomById(group.groupRoom);
                            let activityObj = await activity_utils_1.getGroupActivityObj(user, group, roomDetails, updateGroupStateReq, {
                                activitySource: system_constants_1.UpdateSourceMapping.ANDROID
                            });
                            await keus_activity_1.default.insertActivity(activityObj);
                            //-----------------------Update Group State State Event--------------------------------
                            const updtGroupEvent = new group_structures_pb_1.UpdateGroupEvent();
                            updtGroupEvent.setUpdateState(updateGroupStateReq);
                            updtGroupEvent.setActivitySource(system_constants_1.UpdateSourceMapping.ANDROID);
                            updtGroupEvent.setActivityUser(phone);
                            updtGroupEvent.setActivityTime(execTime);
                            const eventArg = general_1.PackIntoAny(updtGroupEvent.serializeBinary(), eventType);
                            local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                            cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                            //Test register device event - Delete after testing
                            // let registerDeviceInfo = await KeusDeviceModel.getDeviceById('0x00124b0021b708a0');
                            // const registerResponse = RegisterDeviceResponse.getRegisterSuccessful(
                            //     getDeviceProto(registerDeviceInfo)
                            // );
                            // printFullObject(registerDeviceInfo);
                            // printFullObject(registerResponse);
                            // // const eventArg2 = PackIntoAny(registerResponse.serializeBinary(), ProtoPackageName + '.RegisterDeviceResponse');
                            // GatewayProvidersManager.publishEvent(
                            //     GatewayProvidersManager.getMainGatewayServiceName(),
                            //     registerResponse
                            // );
                            // CloudProvidersManager.publishEvent(CloudProvidersManager.getMainGatewayServiceName(), registerResponse);
                            resolve(response_1.default.getUpdateGroupStateSuccessful(ProtoUtils.GroupProtoUtils.getGroupProto(updatedGroup)));
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
function RGBWWA_RGB_UPDATE(RGBWWA_RGB_UPDATE) {
    throw new Error('Function not implemented.');
}
//# sourceMappingURL=index.js.map