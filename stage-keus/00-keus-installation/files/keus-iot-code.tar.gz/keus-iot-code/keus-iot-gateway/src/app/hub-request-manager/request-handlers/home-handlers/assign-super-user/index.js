"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_to_cloud_pb_1 = require("../../../protos/generated/cloud/gateway_to_cloud_pb");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../errors/errors");
const home_constants_1 = require("../../../../../constants/gateway/home-constants");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const rpc_maker_util_1 = require("../../../../../utilities/gateway/rpc-maker-util");
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
exports.default = async (superUserData, userPhone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let allUsers, targetUser;
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                //Temporary Fix Remove later
                if (!userPhone.length) {
                    userPhone = gatewayDetails[0].serviceUser;
                }
                targetUser = await keus_user_1.default.getUserByPhone(superUserData.getTargetPhone());
                let user = await keus_user_1.default.getUserByPhone(userPhone);
                console.log('THESE ARE USERS', targetUser, user);
                let serviceUser = gatewayDetails[0].serviceUser == userPhone;
                allUsers = await keus_user_1.default.getAllUsers();
                let superUserCheck = await home_utils_1.checkForSuperUser(allUsers, gatewayDetails);
                let userAccessLevel = await home_utils_1.getAccessLevel(user);
                console.log('THESE ARE BOOL VALUES', serviceUser, superUserCheck, userAccessLevel);
                if (!gatewayDetails.length || !gatewayDetails[0].isRegisteredToCloud) {
                    final_resp = response_1.default.getGatewayNotRegisteredToCloud();
                }
                else if (serviceUser && superUserCheck) {
                    final_resp = response_1.default.getInvalidUserAccess();
                }
                else if (!serviceUser && userAccessLevel != home_constants_1.UserRoles.SuperAdmin) {
                    final_resp = response_1.default.getInvalidUserAccess();
                }
                else if (user.phone == superUserData.getTargetPhone()) {
                    final_resp = response_1.default.getOperationNotAllowed();
                }
                else {
                    let cloudReqObj = new gateway_to_cloud_pb_1.AssignSuperUser();
                    cloudReqObj.setOtp(superUserData.getOtp());
                    cloudReqObj.setPhone(userPhone);
                    cloudReqObj.setTargetPhone(superUserData.getTargetPhone());
                    cloudReqObj.setGatewayId(gatewayDetails[0].gatewayId);
                    cloudReqObj.setGatewayKey(gatewayDetails[0].gatewayKey);
                    let cloudRpcResponse = await rpc_maker_util_1.MakeAuthCloudRpc(general_1.PackIntoAny(cloudReqObj.serializeBinary(), system_constants_1.ProtoCloudPackageName + '.AssignSuperUser'));
                    if (cloudRpcResponse.getSuccess()) {
                        let targetUserCloudData = JSON.parse(cloudRpcResponse.getTargetUserInfo());
                        if (targetUser) {
                            targetUser = Object.assign(targetUser, targetUserCloudData);
                            await keus_user_1.default.updateUser(superUserData.getTargetPhone(), targetUser);
                        }
                        else {
                            let newTargetUser = Object.assign({}, targetUserCloudData);
                            await keus_user_1.default.insertUser(newTargetUser);
                        }
                        if (!serviceUser) {
                            let userCloudData = JSON.parse(cloudRpcResponse.getUserInfo());
                            user = Object.assign(user, userCloudData);
                            await keus_user_1.default.updateUser(user.phone, user);
                        }
                        final_resp = response_1.default.getAssignSuperUserSuccess();
                    }
                    else {
                        throw new errors_1.GeneralErrors.RpcResponseFalseError(cloudRpcResponse.getMessage());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.RpcMakerError:
                        final_resp = response_1.default.getConnectionError();
                        break;
                    case errors_1.GeneralErrors.RpcResponseFalseError:
                        final_resp = response_1.default.getCloudRpcError(e.message);
                        break;
                    default:
                        final_resp = response_1.default.getInternalServerError();
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map