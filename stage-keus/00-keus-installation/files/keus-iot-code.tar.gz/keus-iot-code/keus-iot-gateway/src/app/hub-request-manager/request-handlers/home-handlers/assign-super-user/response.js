"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_pb_1 = require("../../../protos/generated/hub/home/permissions_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class AssignSuperUserResp {
    static getAssignSuperUserSuccess() {
        const resp = new permissions_pb_1.AssignSuperUserResponse();
        resp.setCode(800);
        resp.setMessage('superadmin assigned succesful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), AssignSuperUserResp.responseType);
    }
    static getOperationNotAllowed() {
        const resp = new permissions_pb_1.AssignSuperUserResponse();
        resp.setCode(801);
        resp.setMessage('operations not allowed');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AssignSuperUserResp.responseType);
    }
    static getGatewayNotRegisteredToCloud() {
        const resp = new permissions_pb_1.AssignSuperUserResponse();
        resp.setCode(804);
        resp.setMessage('Get Gateway Not Registered To Cloud');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AssignSuperUserResp.responseType);
    }
    static getInvalidUserAccess() {
        const resp = new permissions_pb_1.AssignSuperUserResponse();
        resp.setCode(805);
        resp.setMessage('Get Invalid Access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AssignSuperUserResp.responseType);
    }
    static getCloudRpcError(cloudmsg) {
        const resp = new permissions_pb_1.AssignSuperUserResponse();
        resp.setCode(802);
        resp.setMessage(cloudmsg);
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AssignSuperUserResp.responseType);
    }
    static getConnectionError() {
        const resp = new permissions_pb_1.AssignSuperUserResponse();
        resp.setCode(803);
        resp.setMessage('Connection Error');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AssignSuperUserResp.responseType);
    }
    static getInternalServerError() {
        const resp = new permissions_pb_1.AssignSuperUserResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), AssignSuperUserResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new permissions_pb_1.AssignSuperUserResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AssignSuperUserResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new permissions_pb_1.AssignSuperUserResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AssignSuperUserResp.responseType);
    }
}
exports.default = AssignSuperUserResp;
AssignSuperUserResp.responseType = system_constants_1.ProtoPackageName + '.AssignSuperUserResponse';
//# sourceMappingURL=response.js.map