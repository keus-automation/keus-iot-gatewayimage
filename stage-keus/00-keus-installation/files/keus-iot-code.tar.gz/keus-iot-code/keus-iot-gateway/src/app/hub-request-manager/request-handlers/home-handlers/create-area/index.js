"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const home_structures_pb_2 = require("../../../../device-manager/providers/generated/home/home_structures_pb");
const local_client_1 = require("../../../local-client");
const general_1 = require("../../../../../utilities/general");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (createAreaReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!createAreaReq.getAreaName() || !createAreaReq.getAreaName().length) {
                    resolve(response_1.default.getInvalidAreaName());
                }
                else {
                    const areaList = await keus_home_1.default.getAllAreas();
                    const dupArea = areaList.filter(function (area) {
                        return area.areaName == createAreaReq.getAreaName();
                    });
                    if (dupArea && dupArea.length) {
                        resolve(response_1.default.getDuplicateAreaName());
                    }
                    else {
                        const dmCreateAreaReq = new home_structures_pb_2.DMCreateArea();
                        const dmCreateAreaRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmCreateAreaReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMCreateArea'));
                        if (!dmCreateAreaRsp.getSuccess()) {
                            throw new Error(dmCreateAreaRsp.getMessage());
                        }
                        const areaId = dmCreateAreaRsp.getAreaId();
                        // const areaId = HomeUtils.generateAreaId(areaList);
                        if (areaId < 0) {
                            resolve(response_1.default.getAreaLimitReached());
                        }
                        else {
                            await keus_home_1.default.addArea({
                                areaId: areaId,
                                areaName: createAreaReq.getAreaName(),
                                areaSyncInfo: {
                                    syncRequestId: '-',
                                    syncRequestParams: {},
                                    syncRequestTime: Date.now(),
                                    syncRequestType: home_structures_pb_1.AREA_JOB_TYPES.AREA_NONE,
                                    syncStatus: home_structures_pb_1.AREA_SYNC_STATES.AREAINSYNC
                                }
                            });
                            resolve(response_1.default.getCreateAreaSuccessful(ProtoUtils.HomeProtoUtils.getAreaProto({
                                areaId: areaId,
                                areaName: createAreaReq.getAreaName(),
                                areaSyncInfo: {
                                    syncRequestId: '-',
                                    syncRequestParams: {},
                                    syncRequestTime: Date.now(),
                                    syncRequestType: home_structures_pb_1.AREA_JOB_TYPES.AREA_NONE,
                                    syncStatus: home_structures_pb_1.AREA_SYNC_STATES.AREAINSYNC
                                }
                            })));
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map