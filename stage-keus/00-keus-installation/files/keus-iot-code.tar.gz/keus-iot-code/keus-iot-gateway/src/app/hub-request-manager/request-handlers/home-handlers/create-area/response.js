"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class CreateAreaResp {
    static getCreateAreaSuccessful(area) {
        const resp = new home_structures_pb_1.CreateAreaResponse();
        resp.setCode(800);
        resp.setMessage('Create Area Successful');
        resp.setSuccess(true);
        resp.setArea(area);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateAreaResp.responseType);
    }
    static getDuplicateAreaName() {
        const resp = new home_structures_pb_1.CreateAreaResponse();
        resp.setCode(801);
        resp.setMessage('Duplicate Area Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateAreaResp.responseType);
    }
    static getInvalidAreaName() {
        const resp = new home_structures_pb_1.CreateAreaResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Area Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateAreaResp.responseType);
    }
    static getAreaLimitReached() {
        const resp = new home_structures_pb_1.CreateAreaResponse();
        resp.setCode(803);
        resp.setMessage('Area Limit reached');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateAreaResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.CreateAreaResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateAreaResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.CreateAreaResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateAreaResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.CreateAreaResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateAreaResp.responseType);
    }
}
exports.default = CreateAreaResp;
CreateAreaResp.responseType = system_constants_1.ProtoPackageName + '.CreateAreaResponse';
//# sourceMappingURL=response.js.map