"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class CreateFloorResp {
    static getCreateFloorSuccessful(floor) {
        const resp = new home_structures_pb_1.CreateFloorResponse();
        resp.setCode(800);
        resp.setMessage('Create Floor Successful');
        resp.setSuccess(true);
        resp.setFloor(floor);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateFloorResp.responseType);
    }
    static getDuplicateFloorName() {
        const resp = new home_structures_pb_1.CreateFloorResponse();
        resp.setCode(801);
        resp.setMessage('Duplicate Floor Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateFloorResp.responseType);
    }
    static getInvalidFloorName() {
        const resp = new home_structures_pb_1.CreateFloorResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Floor Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateFloorResp.responseType);
    }
    static getDuplicateFloorId() {
        const resp = new home_structures_pb_1.CreateFloorResponse();
        resp.setCode(803);
        resp.setMessage('Duplicate Floor Id. Please try again');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateFloorResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.CreateFloorResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateFloorResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.CreateFloorResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateFloorResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.CreateFloorResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateFloorResp.responseType);
    }
}
exports.default = CreateFloorResp;
CreateFloorResp.responseType = system_constants_1.ProtoPackageName + '.CreateFloorResponse';
//# sourceMappingURL=response.js.map