"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const home_constants_1 = require("../../../../../constants/gateway/home-constants");
const HomeUtils = __importStar(require("../../../../../utilities/gateway/home-utils"));
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const home_constants_2 = require("../../../../../constants/gateway/home-constants");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (createRoomReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!createRoomReq.getRoomName() ||
                    !createRoomReq.getRoomName().length ||
                    createRoomReq.getRoomName() == home_constants_2.DefaultRoomName) {
                    resolve(response_1.default.getInvalidRoomName());
                }
                else if (!home_constants_1.RoomTypeMap[createRoomReq.getRoomType()]) {
                    resolve(response_1.default.getInvalidRoomType());
                }
                else if (createRoomReq.getRoomType() == home_constants_1.RoomTypeMap.DEFAULT) {
                    resolve(response_1.default.getOperationNotAllowed());
                }
                else if (home_constants_1.RoomImageTypeList.indexOf(createRoomReq.getRoomImageType()) < 0) {
                    resolve(response_1.default.getInvalidRoomImageType());
                }
                else {
                    const floor = await keus_home_1.default.getFloorById(createRoomReq.getFloorId());
                    const area = await keus_home_1.default.getAreaById(createRoomReq.getAreaId());
                    if (!floor) {
                        resolve(response_1.default.getInvalidFloorId());
                    }
                    else if (!area) {
                        resolve(response_1.default.getInvalidAreaId());
                    }
                    else {
                        var roomList = await keus_home_1.default.getAllRooms();
                        var floorDupRoomList = roomList.filter(function (room) {
                            return (room.floorId == createRoomReq.getFloorId() &&
                                room.roomName == createRoomReq.getRoomName());
                        });
                        if (floorDupRoomList.length) {
                            resolve(response_1.default.getDuplicateRoomName());
                        }
                        else {
                            const roomId = HomeUtils.generateRoomId();
                            const newRoom = {
                                roomId: roomId,
                                roomName: createRoomReq.getRoomName(),
                                roomType: createRoomReq.getRoomType(),
                                roomImageType: createRoomReq.getRoomImageType(),
                                floorId: createRoomReq.getFloorId(),
                                areaId: createRoomReq.getAreaId(),
                                sectionList: [
                                    {
                                        sectionId: home_constants_2.DefaultSectionId,
                                        sectionName: home_constants_2.DefaultSectionName
                                    }
                                ]
                            };
                            await keus_home_1.default.addRoom(newRoom);
                            resolve(response_1.default.getCreateRoomSuccessful(ProtoUtils.HomeProtoUtils.getRoomProto(newRoom)));
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map