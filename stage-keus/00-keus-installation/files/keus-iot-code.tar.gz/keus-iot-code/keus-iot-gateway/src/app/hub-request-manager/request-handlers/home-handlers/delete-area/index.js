"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const home_constants_1 = require("../../../../../constants/gateway/home-constants");
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (deleteAreaReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (deleteAreaReq.getAreaId() == null) {
                    resolve(response_1.default.getInvalidAreaId());
                }
                else if (deleteAreaReq.getAreaId() < home_constants_1.AreaStartId) {
                    resolve(response_1.default.getOperationNotAllowed());
                }
                else {
                    const roomList = await keus_home_1.default.getRoomsByArea(deleteAreaReq.getAreaId());
                    if (roomList.length) {
                        resolve(response_1.default.getAreaNotEmpty(ProtoUtils.HomeProtoUtils.getRoomProtoList(roomList)));
                    }
                    else {
                        await keus_home_1.default.deleteAreaById(deleteAreaReq.getAreaId());
                        resolve(response_1.default.getDeleteAreaSuccessful(deleteAreaReq.getAreaId()));
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map