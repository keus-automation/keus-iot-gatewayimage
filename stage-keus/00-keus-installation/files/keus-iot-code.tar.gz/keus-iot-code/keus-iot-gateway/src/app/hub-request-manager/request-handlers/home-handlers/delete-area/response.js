"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class DeleteAreaResp {
    static getDeleteAreaSuccessful(areaId) {
        const resp = new home_structures_pb_1.DeleteAreaResponse();
        resp.setCode(800);
        resp.setMessage('Delete Area Successful');
        resp.setSuccess(true);
        resp.setAreaId(areaId);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteAreaResp.responseType);
    }
    static getInvalidAreaId() {
        const resp = new home_structures_pb_1.DeleteAreaResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Area Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteAreaResp.responseType);
    }
    static getAreaNotEmpty(roomList) {
        const resp = new home_structures_pb_1.DeleteAreaResponse();
        resp.setCode(802);
        resp.setMessage('Area has existing rooms. Please move them before deleting');
        resp.setSuccess(false);
        resp.setRoomsList(roomList);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteAreaResp.responseType);
    }
    static getOperationNotAllowed() {
        const resp = new home_structures_pb_1.DeleteAreaResponse();
        const opNotAllowed = response_helper_1.default.getOperationNotAllowed();
        resp.setCode(opNotAllowed.code);
        resp.setMessage(opNotAllowed.message);
        resp.setSuccess(opNotAllowed.success);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteAreaResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.DeleteAreaResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteAreaResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.DeleteAreaResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteAreaResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.DeleteAreaResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteAreaResp.responseType);
    }
}
exports.default = DeleteAreaResp;
DeleteAreaResp.responseType = system_constants_1.ProtoPackageName + '.DeleteAreaResponse';
//# sourceMappingURL=response.js.map