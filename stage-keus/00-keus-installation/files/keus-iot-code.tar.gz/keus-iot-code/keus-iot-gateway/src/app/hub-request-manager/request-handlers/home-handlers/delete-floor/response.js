"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class DeleteFloorResp {
    static getDeleteFloorSuccessful() {
        const resp = new home_structures_pb_1.DeleteFloorResponse();
        resp.setCode(800);
        resp.setMessage('Delete Floor Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteFloorResp.responseType);
    }
    static getInvalidFloorId() {
        const resp = new home_structures_pb_1.DeleteFloorResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Floor Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteFloorResp.responseType);
    }
    static getRoomsExist(roomList) {
        const resp = new home_structures_pb_1.DeleteFloorResponse();
        resp.setCode(802);
        resp.setMessage('Floor has existing rooms');
        resp.setSuccess(false);
        resp.setRoomsList(roomList);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteFloorResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.DeleteFloorResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteFloorResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.DeleteFloorResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteFloorResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.DeleteFloorResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteFloorResp.responseType);
    }
}
exports.default = DeleteFloorResp;
DeleteFloorResp.responseType = system_constants_1.ProtoPackageName + '.DeleteFloorResponse';
//# sourceMappingURL=response.js.map