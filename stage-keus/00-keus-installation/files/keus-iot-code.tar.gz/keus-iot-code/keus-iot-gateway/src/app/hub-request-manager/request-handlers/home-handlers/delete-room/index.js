"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const home_constants_1 = require("../../../../../constants/gateway/home-constants");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (deleteRoomReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!deleteRoomReq.getRoomId()) {
                    resolve(response_1.default.getInvalidRoomId());
                }
                else if (deleteRoomReq.getRoomId() == home_constants_1.DefaultRoomId) {
                    resolve(response_1.default.getOperationNotAllowed());
                }
                else {
                    //What to about not empty contents in rooms?
                    const deviceList = [];
                    const groupList = [];
                    const sceneList = [];
                    const scheduleList = [];
                    // const deviceList = await KeusDeviceModel.getDevicesByRoom(deleteRoomReq.getRoomId());
                    // const groupList = await KeusGroupModel.getGroupsByRoom(deleteRoomReq.getRoomId());
                    // const sceneList = await KeusSceneModel.getScenesByRoom(deleteRoomReq.getRoomId());
                    // const scheduleList = await KeusScheduleModel.getSchedulesByRoom(deleteRoomReq.getRoomId());
                    // const favPinList = await KeusFavPinList.getFavByRoom(deleteRoomReq.getRoomId());
                    // remoteLIst, favPinList, other checks
                    if (deviceList.length || groupList.length || sceneList.length || scheduleList.length) {
                        resolve(response_1.default.getRoomNotEmpty());
                    }
                    else {
                        const room = await keus_home_1.default.deleteRoomById(deleteRoomReq.getRoomId());
                        resolve(response_1.default.getDeleteRoomSuccessful(deleteRoomReq.getRoomId()));
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map