"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class DeleteRoomResp {
    static getDeleteRoomSuccessful(roomId) {
        const resp = new home_structures_pb_1.DeleteRoomResponse();
        resp.setCode(800);
        resp.setMessage('Delete Room Successful');
        resp.setSuccess(true);
        resp.setRoomId(roomId);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteRoomResp.responseType);
    }
    static getInvalidRoomId() {
        const resp = new home_structures_pb_1.DeleteRoomResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Room Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteRoomResp.responseType);
    }
    static getRoomNotEmpty() {
        const resp = new home_structures_pb_1.DeleteRoomResponse();
        resp.setCode(802);
        resp.setMessage('Room has devices/scenes/groups. Please delete');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteRoomResp.responseType);
    }
    static getOperationNotAllowed() {
        const resp = new home_structures_pb_1.DeleteRoomResponse();
        const opNotAllowed = response_helper_1.default.getOperationNotAllowed();
        resp.setCode(opNotAllowed.code);
        resp.setMessage(opNotAllowed.message);
        resp.setSuccess(opNotAllowed.success);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteRoomResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.DeleteRoomResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteRoomResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.DeleteRoomResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteRoomResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.DeleteRoomResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteRoomResp.responseType);
    }
}
exports.default = DeleteRoomResp;
DeleteRoomResp.responseType = system_constants_1.ProtoPackageName + '.DeleteRoomResponse';
//# sourceMappingURL=response.js.map