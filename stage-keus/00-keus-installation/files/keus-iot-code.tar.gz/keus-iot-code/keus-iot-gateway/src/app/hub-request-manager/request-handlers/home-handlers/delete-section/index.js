"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const home_constants_1 = require("../../../../../constants/gateway/home-constants");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (deleteSectionReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!deleteSectionReq.getRoomId()) {
                    resolve(response_1.default.getInvalidRoomId());
                }
                else if (deleteSectionReq.getSectionId() == home_constants_1.DefaultSectionId) {
                    resolve(response_1.default.getOperationNotAllowed());
                }
                else {
                    const room = await keus_home_1.default.getRoomById(deleteSectionReq.getRoomId());
                    if (!room) {
                        resolve(response_1.default.getInvalidRoomId());
                    }
                    else {
                        const filteredSectionList = [];
                        var currentSection;
                        room.sectionList.forEach(function (section) {
                            if (section.sectionId != deleteSectionReq.getSectionId()) {
                                filteredSectionList.push(section);
                            }
                            else {
                                currentSection = section;
                            }
                        });
                        if (!currentSection) {
                            resolve(response_1.default.getInvalidSectionId());
                        }
                        else {
                            //What to about not empty contents in sections?
                            const deviceList = [];
                            const groupList = [];
                            const sceneList = [];
                            const scheduleList = [];
                            await keus_device_1.default.updateDevicesSection(deleteSectionReq.getRoomId(), deleteSectionReq.getSectionId(), home_constants_1.DefaultSectionId);
                            // const groupList = await KeusGroupModel.getGroupsBySection(deleteSectionReq.getSectionId(), deleteSectionReq.getRoomId());
                            // const sceneList = await KeusSceneModel.getScenesBySection(deleteSectionReq.getSectionId(), deleteSectionReq.getRoomId());
                            // const scheduleList = await KeusScheduleModel.getSchedulesBySection(deleteSectionReq.getSectionId(), deleteSectionReq.getRoomId());
                            await keus_home_1.default.updateRoom(room.roomId, {
                                sectionList: filteredSectionList
                            });
                            resolve(response_1.default.getDeleteSectionSuccessful());
                            //send event for mass update
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map