"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class EditFloorResp {
    static getEditFloorSuccessful(floor) {
        const resp = new home_structures_pb_1.EditFloorResponse();
        resp.setCode(800);
        resp.setMessage('Edit Floor Successful');
        resp.setSuccess(true);
        resp.setFloor(floor);
        return general_1.PackIntoAny(resp.serializeBinary(), EditFloorResp.responseType);
    }
    static getInvalidFloorId() {
        const resp = new home_structures_pb_1.EditFloorResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Floor Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditFloorResp.responseType);
    }
    static getInvalidFloorName() {
        const resp = new home_structures_pb_1.EditFloorResponse();
        resp.setCode(802);
        resp.setMessage('Invalid floor name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditFloorResp.responseType);
    }
    static getDuplicateFloorName() {
        const resp = new home_structures_pb_1.EditFloorResponse();
        resp.setCode(803);
        resp.setMessage('Duplicate floor name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditFloorResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.EditFloorResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), EditFloorResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.EditFloorResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditFloorResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.EditFloorResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditFloorResp.responseType);
    }
}
exports.default = EditFloorResp;
EditFloorResp.responseType = system_constants_1.ProtoPackageName + '.EditFloorResponse';
//# sourceMappingURL=response.js.map