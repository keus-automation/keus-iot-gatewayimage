"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const home_constants_1 = require("../../../../../constants/gateway/home-constants");
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const home_constants_2 = require("../../../../../constants/gateway/home-constants");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (editRoomReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!editRoomReq.getRoomId()) {
                    resolve(response_1.default.getInvalidRoomId());
                }
                else if (!editRoomReq.getRoomName() ||
                    !editRoomReq.getRoomName().length ||
                    editRoomReq.getRoomName() == home_constants_1.DefaultRoomName) {
                    resolve(response_1.default.getInvalidRoomName());
                }
                else if (!home_constants_1.RoomTypeMap[editRoomReq.getRoomType()]) {
                    resolve(response_1.default.getInvalidRoomType());
                }
                else if (home_constants_1.RoomImageTypeList.indexOf(editRoomReq.getRoomImageType()) < 0) {
                    resolve(response_1.default.getInvalidRoomImageType());
                }
                else if (editRoomReq.getRoomType() == home_constants_1.RoomTypeMap.DEFAULT ||
                    editRoomReq.getRoomId() == home_constants_2.DefaultRoomId) {
                    resolve(response_1.default.getOperationNotAllowed());
                }
                else {
                    const floor = await keus_home_1.default.getFloorById(editRoomReq.getFloorId());
                    if (!floor) {
                        resolve(response_1.default.getInvalidFloorId());
                    }
                    else {
                        var roomList = await keus_home_1.default.getRoomsByFloor(floor.floorId);
                        var floorDupRoomList = roomList.filter(function (room) {
                            return room.roomName == editRoomReq.getRoomName() && room.roomId != editRoomReq.getRoomId();
                        });
                        if (floorDupRoomList.length) {
                            resolve(response_1.default.getDuplicateRoomName());
                        }
                        else {
                            const roomUpdates = {
                                floorId: editRoomReq.getFloorId(),
                                roomType: editRoomReq.getRoomType(),
                                roomImageType: editRoomReq.getRoomImageType(),
                                roomName: editRoomReq.getRoomName()
                            };
                            const updatedRoom = await keus_home_1.default.updateRoom(editRoomReq.getRoomId(), roomUpdates);
                            if (!updatedRoom) {
                                resolve(response_1.default.getInvalidRoomId());
                            }
                            else {
                                updatedRoom.floorId = editRoomReq.getFloorId();
                                updatedRoom.roomType = editRoomReq.getRoomType();
                                updatedRoom.roomImageType = editRoomReq.getRoomImageType();
                                updatedRoom.roomName = editRoomReq.getRoomName();
                                resolve(response_1.default.getEditRoomSuccessful(ProtoUtils.HomeProtoUtils.getRoomProto(updatedRoom)));
                            }
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map