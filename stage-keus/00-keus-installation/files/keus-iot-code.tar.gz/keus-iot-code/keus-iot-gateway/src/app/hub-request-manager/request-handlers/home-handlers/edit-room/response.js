"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class EditRoomResp {
    static getEditRoomSuccessful(room) {
        const resp = new home_structures_pb_1.EditRoomResponse();
        resp.setCode(800);
        resp.setMessage('Edit Room Successful');
        resp.setSuccess(true);
        resp.setRoom(room);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getInvalidRoomId() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        resp.setCode(806);
        resp.setMessage('Invalid Room Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getInvalidRoomName() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Room Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getInvalidRoomType() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Room Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getInvalidRoomImageType() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        resp.setCode(803);
        resp.setMessage('Invalid Room Image Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getInvalidFloorId() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Floor Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getDuplicateRoomName() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        resp.setCode(805);
        resp.setMessage('Room already exists on floor');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getOperationNotAllowed() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        const opNotAllowed = response_helper_1.default.getOperationNotAllowed();
        resp.setCode(opNotAllowed.code);
        resp.setMessage(opNotAllowed.message);
        resp.setSuccess(opNotAllowed.success);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.EditRoomResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditRoomResp.responseType);
    }
}
exports.default = EditRoomResp;
EditRoomResp.responseType = system_constants_1.ProtoPackageName + '.EditRoomResponse';
//# sourceMappingURL=response.js.map