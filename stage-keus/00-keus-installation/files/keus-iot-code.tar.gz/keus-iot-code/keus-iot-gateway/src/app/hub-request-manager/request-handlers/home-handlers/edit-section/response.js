"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class EditSectionResp {
    static getEditSectionSuccessful(section) {
        const resp = new home_structures_pb_1.EditSectionResponse();
        resp.setCode(800);
        resp.setMessage('Edit Section Successful');
        resp.setSuccess(true);
        resp.setSection(section);
        return general_1.PackIntoAny(resp.serializeBinary(), EditSectionResp.responseType);
    }
    static getInvalidRoomId() {
        const resp = new home_structures_pb_1.EditSectionResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Room Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditSectionResp.responseType);
    }
    static getInvalidSectionName() {
        const resp = new home_structures_pb_1.EditSectionResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Section Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditSectionResp.responseType);
    }
    static getDuplicateSectionName() {
        const resp = new home_structures_pb_1.EditSectionResponse();
        resp.setCode(803);
        resp.setMessage('Duplicate Section Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditSectionResp.responseType);
    }
    static getInvalidSectionId() {
        const resp = new home_structures_pb_1.EditSectionResponse();
        resp.setCode(803);
        resp.setMessage('Invalid Section Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditSectionResp.responseType);
    }
    static getOperationNotAllowed() {
        const resp = new home_structures_pb_1.EditSectionResponse();
        const opNotAllowed = response_helper_1.default.getOperationNotAllowed();
        resp.setCode(opNotAllowed.code);
        resp.setMessage(opNotAllowed.message);
        resp.setSuccess(opNotAllowed.success);
        return general_1.PackIntoAny(resp.serializeBinary(), EditSectionResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.EditSectionResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), EditSectionResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.EditSectionResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditSectionResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.EditSectionResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), EditSectionResp.responseType);
    }
}
exports.default = EditSectionResp;
EditSectionResp.responseType = system_constants_1.ProtoPackageName + '.EditSectionResponse';
//# sourceMappingURL=response.js.map