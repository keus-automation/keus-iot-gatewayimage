"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (getFloorList) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                const floorList = await keus_home_1.default.getAllFloors();
                resolve(response_1.default.getFloorListSuccessful(ProtoUtils.HomeProtoUtils.getFloorProtoList(floorList)));
            }
            catch (e) {
                switch (e.constructor) {
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map