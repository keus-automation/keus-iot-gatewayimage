"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const keus_ir_remote_1 = __importDefault(require("../../../../../models/database-models/keus-ir-remote"));
const keus_schedule_1 = __importDefault(require("../../../../../models/database-models/keus-schedule"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (getHubDataReq) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                //Get all areas
                const areaList = ProtoUtils.HomeProtoUtils.getAreaProtoList(await keus_home_1.default.getAllAreas());
                //Get all floors
                const floorList = ProtoUtils.HomeProtoUtils.getFloorProtoList(await keus_home_1.default.getAllFloors());
                //Get all rooms
                const roomList = ProtoUtils.HomeProtoUtils.getRoomProtoList(await keus_home_1.default.getAllRooms());
                //Get all devices
                const deviceList = ProtoUtils.DeviceProtoUtils.getDeviceProtoList(await keus_device_1.default.getAllDevices());
                //Get all groups
                const groupList = ProtoUtils.GroupProtoUtils.getGroupProtoList(await keus_group_1.default.getAllGroups());
                // const groupList = [];
                //Get all scenes
                const sceneList = ProtoUtils.SceneProtoUtils.getSceneProtoList(await keus_scene_1.default.getAllScenes());
                // const sceneList = [];
                //Get all Ir Remotes
                const irRemoteList = ProtoUtils.DeviceProtoUtils.getIRRemoteProtoList(await keus_ir_remote_1.default.getAllIRRemotes());
                //get all schedules
                const schedulesList = ProtoUtils.ScheduleProtoUtils.getScheduleProtoList(await keus_schedule_1.default.getAllSchedules());
                //get all minigateways
                var miniGatewayList = [];
                const gatewayList = await keus_gateway_1.default.getGateway();
                if (gatewayList && gatewayList.length) {
                    const gatewayInfo = gatewayList[0];
                    miniGatewayList = ProtoUtils.GatewayProtoUtils.getMiniGatewayProtoList(gatewayInfo.miniGateways);
                }
                resolve(response_1.default.getHubDataSuccessful(areaList, floorList, roomList, deviceList, groupList, sceneList, irRemoteList, schedulesList, miniGatewayList));
            }
            catch (e) {
                console.log('get hub data error-------------------', e);
                switch (e.constructor) {
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map