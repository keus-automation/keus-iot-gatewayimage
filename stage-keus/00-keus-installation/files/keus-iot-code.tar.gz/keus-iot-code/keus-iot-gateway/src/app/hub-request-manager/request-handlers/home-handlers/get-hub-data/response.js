"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class GetHubDataResp {
    static getHubDataSuccessful(areaArray, floorArray, roomArray, deviceArray, groupArray, sceneArray, irRemoteList, scheduleList, miniGatewayList) {
        const resp = new home_structures_pb_1.GetHubDataResponse();
        resp.setCode(800);
        resp.setMessage('Get Hub Data Successful');
        resp.setSuccess(true);
        resp.setAreasList(areaArray);
        resp.setFloorsList(floorArray);
        resp.setRoomsList(roomArray);
        resp.setDevicesList(deviceArray);
        resp.setGroupsList(groupArray);
        resp.setScenesList(sceneArray);
        resp.setIrremotesList(irRemoteList);
        resp.setSchedulesList(scheduleList);
        resp.setMiniGatewayList(miniGatewayList);
        return general_1.PackIntoAny(resp.serializeBinary(), GetHubDataResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.GetHubDataResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), GetHubDataResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.GetHubDataResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetHubDataResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.GetHubDataResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetHubDataResp.responseType);
    }
}
exports.default = GetHubDataResp;
GetHubDataResp.responseType = system_constants_1.ProtoPackageName + '.GetHubDataResponse';
//# sourceMappingURL=response.js.map