"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_pb_1 = require("../../../protos/generated/hub/home/user_pb");
const gateway_to_cloud_pb_1 = require("../../../protos/generated/cloud/gateway_to_cloud_pb");
const reponse_1 = __importDefault(require("./reponse"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const general_1 = require("../../../../../utilities/general");
const rpc_maker_util_1 = require("../../../../../utilities/gateway/rpc-maker-util");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
exports.default = async (incomingObj) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                console.log('HITTING GET USER INFO');
                let cloudReqObj = new gateway_to_cloud_pb_1.GetUserDetails();
                cloudReqObj.setPhone(incomingObj.getPhone());
                let cloudRpcResponse = await rpc_maker_util_1.MakeAuthCloudRpc(general_1.PackIntoAny(cloudReqObj.serializeBinary(), system_constants_1.ProtoCloudPackageName + '.GetUserDetails'));
                console.log('HITTING GET USER INFO', cloudRpcResponse);
                if (cloudRpcResponse.getSuccess()) {
                    let UserCloudObj = JSON.parse(cloudRpcResponse.getUserData());
                    console.log('GOT CLODU RPC RESPONSE', UserCloudObj);
                    let userRespObj = new user_pb_1.UserInfoResponseObj();
                    userRespObj.setPhone(UserCloudObj.phone);
                    userRespObj.setEmail(UserCloudObj.email);
                    userRespObj.setUserName(UserCloudObj.userName);
                    userRespObj.setEmialVerified(UserCloudObj.emailVerified);
                    userRespObj.setPhoneVerified(UserCloudObj.phoneVerified);
                    final_resp = reponse_1.default.getFetchUserSuccess(userRespObj);
                }
                else {
                    throw new errors_1.GeneralErrors.RpcResponseFalseError(cloudRpcResponse.getMessage());
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.RpcMakerError:
                        console.log('THIS IS RAKERPC ERROR', e);
                        final_resp = reponse_1.default.getConnectionError();
                        break;
                    case errors_1.GeneralErrors.RpcResponseFalseError:
                        console.log('THIS IS Response false error ERROR', e);
                        final_resp = reponse_1.default.getCloudRpcError(e.message);
                        break;
                    default:
                        console.log('THIS IS INTERNAL SERVER ERROR', e);
                        final_resp = reponse_1.default.getInternalServerError();
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map