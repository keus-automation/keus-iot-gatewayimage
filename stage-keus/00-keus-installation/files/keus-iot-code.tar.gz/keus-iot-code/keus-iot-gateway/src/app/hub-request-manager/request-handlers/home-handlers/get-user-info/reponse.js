"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_pb_1 = require("../../../protos/generated/hub/home/user_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class GetUserInfoResp {
    static getFetchUserSuccess(userdata) {
        const resp = new user_pb_1.GetUserInfoResponse();
        resp.setCode(800);
        resp.setMessage('user fetch success');
        resp.setSuccess(true);
        resp.setUserData(userdata);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserInfoResp.responseType);
    }
    static getCloudRpcError(cloudmsg) {
        const resp = new user_pb_1.GetUserInfoResponse();
        resp.setCode(802);
        resp.setMessage(cloudmsg);
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserInfoResp.responseType);
    }
    static getConnectionError() {
        const resp = new user_pb_1.GetUserInfoResponse();
        resp.setCode(803);
        resp.setMessage('Connection Error');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserInfoResp.responseType);
    }
    static getInternalServerError() {
        const resp = new user_pb_1.GetUserInfoResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserInfoResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new user_pb_1.GetUserInfoResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserInfoResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new user_pb_1.GetUserInfoResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserInfoResp.responseType);
    }
}
exports.default = GetUserInfoResp;
GetUserInfoResp.responseType = system_constants_1.ProtoPackageName + '.GetUserInfoResponse';
//# sourceMappingURL=reponse.js.map