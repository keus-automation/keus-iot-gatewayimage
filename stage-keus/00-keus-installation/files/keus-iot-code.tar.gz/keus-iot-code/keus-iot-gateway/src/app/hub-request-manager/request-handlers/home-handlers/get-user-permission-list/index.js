"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_pb_1 = require("../../../protos/generated/hub/home/permissions_pb");
const gateway_to_cloud_pb_1 = require("../../../protos/generated/cloud/gateway_to_cloud_pb");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const general_1 = require("../../../../../utilities/general");
const rpc_maker_util_1 = require("../../../../../utilities/gateway/rpc-maker-util");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
exports.default = async (incomingObj, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                console.log('HITTING GET USER INFO');
                let cloudReqObj = new gateway_to_cloud_pb_1.GetUsersDetails();
                let allUsers = await keus_user_1.default.getUsers();
                let userReqType = [];
                allUsers.forEach(user => {
                    if (user.userName != 'demo user' && user.phone != '+919999999999') {
                        let feederType = new gateway_to_cloud_pb_1.GetUsersType();
                        feederType.setPhone(user.phone);
                        userReqType.push(feederType);
                    }
                });
                cloudReqObj.setUserKeysList(userReqType);
                let cloudRpcResponse = await rpc_maker_util_1.MakeAuthCloudRpc(general_1.PackIntoAny(cloudReqObj.serializeBinary(), system_constants_1.ProtoCloudPackageName + '.GetUsersDetails'));
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                // console.log('HITTING GET USER INFO', cloudRpcResponse);
                if (cloudRpcResponse.getSuccess()) {
                    let UserCloudObj = JSON.parse(cloudRpcResponse.getUserData());
                    let final_permision_data_array = [];
                    console.log('this is cloud user list', UserCloudObj);
                    for (let i = 0; i < UserCloudObj.length; i++) {
                        let userRespObj = new permissions_pb_1.UserData();
                        userRespObj.setPhone(UserCloudObj[i].phone);
                        userRespObj.setEmail(UserCloudObj[i].email);
                        userRespObj.setUserName(UserCloudObj[i].userName);
                        userRespObj.setDateOfBirth(UserCloudObj[i].dateOfBirth);
                        userRespObj.setGender(UserCloudObj[i].gender);
                        userRespObj.setLocation(UserCloudObj[i].location);
                        //   console.log('this is before parse', UserCloudObj[i].homesList);
                        let homesList = JSON.parse(UserCloudObj[i].homesList);
                        // console.log('this is aftr parse', homesList);
                        //console.log(homesList[0]);
                        let homeDetails;
                        for (let j = 0; j < homesList.length; j++) {
                            if (homesList[j].gatewayId == gatewayDetails[0].gatewayId) {
                                homeDetails = homesList[j];
                                // console.log('this is home details', homeDetails);
                            }
                        }
                        userRespObj.setAccessLevel(homeDetails.accessLevel);
                        userRespObj.setRoomsListList(homeDetails.roomsList);
                        final_permision_data_array.push(userRespObj);
                    }
                    final_resp = response_1.default.getFetchPermissionsUserSuccess(final_permision_data_array);
                    console.log('this is final resp from hub of get permissions', final_resp);
                }
                else {
                    throw new errors_1.GeneralErrors.RpcResponseFalseError(cloudRpcResponse.getMessage());
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.RpcMakerError:
                        console.log('THIS IS RAKERPC ERROR', e);
                        final_resp = response_1.default.getConnectionError();
                        break;
                    case errors_1.GeneralErrors.RpcResponseFalseError:
                        console.log('THIS IS Response false error ERROR', e);
                        final_resp = response_1.default.getCloudRpcError(e.message);
                        break;
                    default:
                        console.log('THIS IS INTERNAL SERVER ERROR', e);
                        final_resp = response_1.default.getInternalServerError();
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map