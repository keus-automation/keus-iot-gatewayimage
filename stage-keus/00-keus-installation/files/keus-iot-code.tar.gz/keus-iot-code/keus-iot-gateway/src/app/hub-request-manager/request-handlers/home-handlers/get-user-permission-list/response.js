"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_pb_1 = require("../../../protos/generated/hub/home/permissions_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class GetUserPermissionListResp {
    static getFetchPermissionsUserSuccess(userdata) {
        const resp = new permissions_pb_1.GetUserPermissionListResponse();
        resp.setCode(800);
        resp.setMessage('user fetch success');
        resp.setSuccess(true);
        resp.setUserPermissionsList(userdata);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserPermissionListResp.responseType);
    }
    static getCloudRpcError(cloudmsg) {
        const resp = new permissions_pb_1.GetUserPermissionListResponse();
        resp.setCode(802);
        resp.setMessage(cloudmsg);
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserPermissionListResp.responseType);
    }
    static getConnectionError() {
        const resp = new permissions_pb_1.GetUserPermissionListResponse();
        resp.setCode(803);
        resp.setMessage('Connection Error');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserPermissionListResp.responseType);
    }
    static getInternalServerError() {
        const resp = new permissions_pb_1.GetUserPermissionListResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserPermissionListResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new permissions_pb_1.GetUserPermissionListResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserPermissionListResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new permissions_pb_1.GetUserPermissionListResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), GetUserPermissionListResp.responseType);
    }
}
exports.default = GetUserPermissionListResp;
GetUserPermissionListResp.responseType = system_constants_1.ProtoPackageName + '.GetUserPermissionListResponse';
//# sourceMappingURL=response.js.map