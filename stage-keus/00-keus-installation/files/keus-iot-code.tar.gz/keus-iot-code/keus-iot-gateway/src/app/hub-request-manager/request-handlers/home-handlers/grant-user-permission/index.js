"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_pb_1 = require("../../../protos/generated/hub/home/permissions_pb");
const gateway_to_cloud_pb_1 = require("../../../protos/generated/cloud/gateway_to_cloud_pb");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const rpc_maker_util_1 = require("../../../../../utilities/gateway/rpc-maker-util");
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
exports.default = async (grantPermissionData, userPhone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                let allUsers, targetUser;
                targetUser = await keus_user_1.default.getUserByPhone(grantPermissionData.getTargetPhone());
                let user = await keus_user_1.default.getUserByPhone(userPhone);
                let serviceUser = gatewayDetails[0].serviceUser == userPhone ? true : false;
                let userAccessLevel = await home_utils_1.getAccessLevel(user);
                let targetUserAccessLevel = await home_utils_1.getAccessLevel(targetUser);
                if (userAccessLevel < gateway_to_cloud_pb_1.USER_ROLES.ADMIN ||
                    userAccessLevel <= targetUserAccessLevel ||
                    serviceUser ||
                    !user) {
                    final_resp = response_1.default.getInvalidUserAccess();
                }
                else if (grantPermissionData.getAccessLevel() == gateway_to_cloud_pb_1.USER_ROLES.SUPER_ADMIN || userPhone == grantPermissionData.getTargetPhone()) {
                    final_resp = response_1.default.getOperationNotAllowed();
                }
                if (!gatewayDetails.length || !gatewayDetails[0].isRegisteredToCloud) {
                    final_resp = response_1.default.getGatewayNotRegisteredToCloud();
                }
                else {
                    let cloudReqObj = new gateway_to_cloud_pb_1.GrantUserPermission();
                    cloudReqObj.setTargetPhone(grantPermissionData.getTargetPhone());
                    cloudReqObj.setAccessLevel(grantPermissionData.getAccessLevel());
                    cloudReqObj.setRoomsListList(grantPermissionData.getRoomsListList());
                    let cloudRpcResponse = await rpc_maker_util_1.MakeAuthCloudRpc(general_1.PackIntoAny(cloudReqObj.serializeBinary(), system_constants_1.ProtoCloudPackageName + '.GrantUserPermission'));
                    if (cloudRpcResponse.getSuccess()) {
                        let targetUserCloudData = JSON.parse(cloudRpcResponse.getTargetUserInfo());
                        if (targetUser) {
                            await keus_user_1.default.updateUser(grantPermissionData.getTargetPhone(), targetUserCloudData);
                        }
                        else {
                            let newTargetUser = Object.assign({}, targetUserCloudData);
                            await keus_user_1.default.insertUser(newTargetUser);
                        }
                        let userProfileData = new permissions_pb_1.UserData();
                        userProfileData.setPhone(targetUserCloudData.phone);
                        userProfileData.setEmail(targetUserCloudData.email);
                        userProfileData.setUserName(targetUserCloudData.userName);
                        userProfileData.setDateOfBirth(targetUserCloudData.dateOfBirth);
                        userProfileData.setGender(targetUserCloudData.gender);
                        userProfileData.setLocation(targetUserCloudData.location);
                        userProfileData.setAccessLevel(grantPermissionData.getAccessLevel());
                        userProfileData.setRoomsListList(grantPermissionData.getRoomsListList());
                        final_resp = response_1.default.getAssignPermissionSuccess(userProfileData);
                    }
                    else {
                        throw new errors_1.GeneralErrors.RpcResponseFalseError(cloudRpcResponse.getMessage());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.RpcMakerError:
                        final_resp = response_1.default.getConnectionError();
                        break;
                    case errors_1.GeneralErrors.RpcResponseFalseError:
                        final_resp = response_1.default.getCloudRpcError(e.message);
                        break;
                    default:
                        final_resp = response_1.default.getInternalServerError();
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map