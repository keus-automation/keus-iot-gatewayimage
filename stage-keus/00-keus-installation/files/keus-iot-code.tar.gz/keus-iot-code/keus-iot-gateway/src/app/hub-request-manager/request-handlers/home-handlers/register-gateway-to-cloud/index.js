"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const SystemConstants = __importStar(require("../../../../../constants/gateway/system-constants"));
const ApiUtils = __importStar(require("../../../../../utilities/gateway/api-utils"));
const internalIp = require('internal-ip');
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
exports.default = async (configureData, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                let gatewayDetails = await keus_gateway_1.default.getGatewayById(configureData.getGatewayId());
                if (!gatewayDetails) {
                    final_resp = response_1.default.getInvalidGatewayData();
                }
                else if (gatewayDetails.isRegisteredToCloud) {
                    final_resp = response_1.default.getGatewayAlreadyRegistered();
                }
                else {
                    try {
                        let ipGateway = await internalIp.v4();
                        let registerGatewayToCloudResp = await ApiUtils.makePostRequest(SystemConstants.opsCloudApiUrl + SystemConstants.opsEndPointRegisterGatewayToCloud, {
                            gatwayId: gatewayDetails.gatewayId,
                            gatwayKey: gatewayDetails.gatewayKey,
                            gatewayIp: ipGateway
                        });
                        if (registerGatewayToCloudResp.success) {
                            await keus_gateway_1.default.makeRegisterMasterToCloudTrue(gatewayDetails.gatewayId);
                            final_resp = response_1.default.getRegisterGatewayCloudSuccessful();
                        }
                        else if (registerGatewayToCloudResp.code == 802) {
                            await keus_gateway_1.default.setWronglyConfiguredTrue(gatewayDetails.gatewayId);
                            final_resp = response_1.default.GatewayAlreadyUsedInCloud();
                        }
                        else {
                            final_resp = response_1.default.getCloudAPiError(registerGatewayToCloudResp.message);
                        }
                    }
                    catch (e) {
                        final_resp = response_1.default.getGatewayCloudConnectionError();
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        final_resp = response_1.default.getUserNotAdmin();
                        break;
                    default:
                        console.log('get gateway status error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map