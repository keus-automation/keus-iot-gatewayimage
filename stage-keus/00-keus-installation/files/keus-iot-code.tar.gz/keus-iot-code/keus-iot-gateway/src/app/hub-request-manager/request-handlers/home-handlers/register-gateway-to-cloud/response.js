"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_setup_pb_1 = require("../../../protos/generated/hub/gatewaysetup/gateway_setup_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class RegisterGatewayToCloudResp {
    static getRegisterGatewayCloudSuccessful() {
        const resp = new gateway_setup_pb_1.RegisterGatewayToCloudResponse();
        resp.setCode(800);
        resp.setMessage('gateway cloud registration successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), RegisterGatewayToCloudResp.responseType);
    }
    static GatewayAlreadyUsedInCloud() {
        const resp = new gateway_setup_pb_1.RegisterGatewayToCloudResponse();
        resp.setCode(802);
        resp.setMessage('gateway already in use please use new gateway details');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RegisterGatewayToCloudResp.responseType);
    }
    static getCloudAPiError(e) {
        const resp = new gateway_setup_pb_1.RegisterGatewayToCloudResponse();
        resp.setCode(804);
        resp.setMessage('Cloud Api Error' + e);
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), RegisterGatewayToCloudResp.responseType);
    }
    static getGatewayCloudConnectionError() {
        const resp = new gateway_setup_pb_1.RegisterGatewayToCloudResponse();
        resp.setCode(803);
        resp.setMessage('gateway configured successful cloud connection error');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), RegisterGatewayToCloudResp.responseType);
    }
    static getInvalidGatewayData() {
        const resp = new gateway_setup_pb_1.RegisterGatewayToCloudResponse();
        resp.setCode(805);
        resp.setMessage('Invalid Gateway Data');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), RegisterGatewayToCloudResp.responseType);
    }
    static getGatewayAlreadyRegistered() {
        const resp = new gateway_setup_pb_1.RegisterGatewayToCloudResponse();
        resp.setCode(804);
        resp.setMessage('Gateway Already Registered');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), RegisterGatewayToCloudResp.responseType);
    }
    static getInternalServerError() {
        const resp = new gateway_setup_pb_1.RegisterGatewayToCloudResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), RegisterGatewayToCloudResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new gateway_setup_pb_1.RegisterGatewayToCloudResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RegisterGatewayToCloudResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new gateway_setup_pb_1.RegisterGatewayToCloudResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RegisterGatewayToCloudResp.responseType);
    }
}
exports.default = RegisterGatewayToCloudResp;
RegisterGatewayToCloudResp.responseType = system_constants_1.ProtoPackageName + '.RegisterGatewayToCloudResponse';
//# sourceMappingURL=response.js.map