"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace + ': Register Device' });
const responseType = system_constants_1.ProtoPackageName + '.ReportZigbeeExecutionResponse';
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const HomeUtils = __importStar(require("../../../../../utilities/gateway/home-utils"));
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const scene_types_1 = require("../../../../../constants/scene/scene-types");
const dali_dimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/dali_dimmable_driver_pb");
const zigbee_dimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_dimmable_driver_pb");
exports.default = async (reportZigbeeExecReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                logInst.log('Report Zigbee Execution Called');
                const zigbeeExecutionList = reportZigbeeExecReq.getZigbeeExecutionList();
                const roomsList = await keus_home_1.default.getRoomsByArea(reportZigbeeExecReq.getAreaId());
                const roomIds = HomeUtils.getRoomIdsFromRoomList(roomsList);
                const groupList = await keus_group_1.default.getGroupsByRooms(roomIds);
                const sceneList = await keus_scene_1.default.getScenesByRooms(roomIds);
                const deviceUpdateMap = new Map();
                const groupUpdateMap = new Map();
                zigbeeExecutionList.forEach(function (execCommand) {
                    switch (execCommand.getExecutionType()) {
                        case home_structures_pb_1.ZIGBEE_EXECUTION_TYPES.ZIGBEE_GROUP_EXEC:
                            const groupUpdates = getGroupDeviceUpdateList(execCommand.getGroupExecution(), groupList, execCommand.getExecutionTimestamp());
                            if (groupUpdates) {
                                const groupState = groupUpdates.groupUpdate;
                                const deviceUpdateList = groupUpdates.updateList;
                                //Add activity log
                                groupUpdateMap.set(groupState.groupId, groupState);
                                deviceUpdateList.forEach(function (devUpdate) {
                                    deviceUpdateMap.set(devUpdate.deviceId, devUpdate);
                                });
                            }
                            break;
                        case home_structures_pb_1.ZIGBEE_EXECUTION_TYPES.ZIGBEE_SCENE_EXEC:
                            const sceneUpdate = execCommand.getSceneExecution();
                            const curScene = sceneList.find(function (scn) {
                                return scn.sceneId == sceneUpdate.getSceneId();
                            });
                            if (curScene) {
                                curScene.actionList.forEach(async function (scnAction) {
                                    switch (scnAction.actionType) {
                                        case scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER:
                                            const scnDaliGrpAction = scnAction.actionItem;
                                            const dGroupAction = new dali_dimmable_driver_pb_1.DaliDimmableDriverAction();
                                            dGroupAction.setDriverState(scnDaliGrpAction.driverState);
                                            const dgrpState = new group_structures_pb_1.GroupState();
                                            const dgrpIdentifier = new group_structures_pb_1.GroupIdentifier();
                                            dgrpIdentifier.setGroupId(scnDaliGrpAction.groupId);
                                            dgrpIdentifier.setAreaId(reportZigbeeExecReq.getAreaId());
                                            dgrpState.setGroupIdentifier(dgrpIdentifier);
                                            dgrpState.setDdimmableDriverState(dGroupAction);
                                            const groupUpdates = getGroupDeviceUpdateList(dgrpState, groupList, execCommand.getExecutionTimestamp());
                                            if (groupUpdates) {
                                                const groupState = groupUpdates.groupUpdate;
                                                const deviceUpdateList = groupUpdates.updateList;
                                                //Add activity log
                                                groupUpdateMap.set(groupState.groupId, groupState);
                                                deviceUpdateList.forEach(function (devUpdate) {
                                                    deviceUpdateMap.set(devUpdate.deviceId, devUpdate);
                                                });
                                            }
                                        case scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER:
                                            const scnZigbeeGrpAction = scnAction.actionItem;
                                            const zGroupAction = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverAction();
                                            zGroupAction.setDriverState(scnZigbeeGrpAction.driverState);
                                            const zgrpState = new group_structures_pb_1.GroupState();
                                            const zgrpIdentifier = new group_structures_pb_1.GroupIdentifier();
                                            zgrpIdentifier.setGroupId(scnZigbeeGrpAction.groupId);
                                            zgrpIdentifier.setAreaId(reportZigbeeExecReq.getAreaId());
                                            zgrpState.setGroupIdentifier(zgrpIdentifier);
                                            zgrpState.setZdimmableDriverState(zGroupAction);
                                            const zGroupUpdates = getGroupDeviceUpdateList(zgrpState, groupList, execCommand.getExecutionTimestamp());
                                            if (zGroupUpdates) {
                                                const groupState = zGroupUpdates.groupUpdate;
                                                const deviceUpdateList = zGroupUpdates.updateList;
                                                //Add activity log
                                                groupUpdateMap.set(groupState.groupId, groupState);
                                                deviceUpdateList.forEach(function (devUpdate) {
                                                    deviceUpdateMap.set(devUpdate.deviceId, devUpdate);
                                                });
                                            }
                                            break;
                                        case scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER:
                                            const scnZCCAction = scnAction.actionItem;
                                            const zCurtainUpdates = getCurtainDeviceUpdateList(scnZCCAction, execCommand.getExecutionTimestamp());
                                            zCurtainUpdates.forEach(function (updt) {
                                                deviceUpdateMap.set(updt.deviceId, updt);
                                            });
                                            break;
                                        case scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER:
                                            const scnZACFCAction = scnAction.actionItem;
                                            const fanDevice = await keus_device_1.default.getDeviceById(scnZACFCAction.deviceId);
                                            const zACFanUpdates = getACFanControllerUpdateList(scnZACFCAction, fanDevice, execCommand.getExecutionTimestamp());
                                            zACFanUpdates.forEach(function (updt) {
                                                deviceUpdateMap.set(updt.deviceId, updt);
                                            });
                                            break;
                                        case scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE:
                                            var zSCUpdates;
                                            const scnSmartConsoleAction = (scnAction.actionItem);
                                            const smartConsoleDevice = await keus_device_1.default.getDeviceById(scnSmartConsoleAction.deviceId);
                                            zSCUpdates = getSmartConsoleUpdateList(scnSmartConsoleAction, deviceUpdateMap.get(scnSmartConsoleAction.deviceId)
                                                ? deviceUpdateMap.get(scnSmartConsoleAction.deviceId)
                                                    .deviceProperties
                                                : smartConsoleDevice.deviceProperties, execCommand.getExecutionTimestamp());
                                            zSCUpdates.forEach(function (updt) {
                                                deviceUpdateMap.set(updt.deviceId, updt);
                                            });
                                            break;
                                    }
                                });
                            }
                    }
                });
                // GatewayProvidersManager.publishEvent(GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                // CloudProvidersManager.publishEvent(CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                await keus_device_1.default;
                resolve(response_1.default.getReportSuccess());
            }
            catch (e) {
                console.log('Register Device error', e);
                switch (e.constructor) {
                    default:
                        logInst.log('Error: ', e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
function getGroupDeviceUpdateList(execGroup, groupList, timeStamp, updateSource = system_constants_1.UpdateSourceMapping.MANUAL) {
    const updateList = [];
    const selGroup = groupList.find(function (listGroup) {
        return execGroup.getGroupIdentifier().getGroupId() == listGroup.groupId;
    });
    if (!selGroup) {
        return null;
    }
    else {
        var groupState;
        switch (selGroup.groupType) {
            case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
                const dDimDriverState = execGroup.getDdimmableDriverState().getDriverState();
                const iDDimDriverState = {
                    driverState: dDimDriverState
                };
                groupState = iDDimDriverState;
                break;
            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
                const zDimDriverState = execGroup.getZdimmableDriverState().getDriverState();
                const iZDimDriverState = {
                    driverState: zDimDriverState
                };
                groupState = iZDimDriverState;
                break;
        }
        selGroup.deviceList.forEach(function (deviceId) {
            updateList.push({
                deviceId: deviceId,
                deviceState: groupState,
                lastUpdateTime: timeStamp,
                lastUpdateSource: updateSource,
                lastUpdateBy: system_constants_1.SystemNumber,
                lastUpdateUser: system_constants_1.SystemUser
            });
        });
        return {
            groupUpdate: {
                groupId: selGroup.groupId,
                groupRoom: selGroup.groupRoom,
                groupState: groupState,
                lastUpdateTime: timeStamp,
                lastUpdateSource: updateSource,
                lastUpdateBy: system_constants_1.SystemNumber,
                lastUpdateUser: system_constants_1.SystemUser
            },
            updateList: updateList
        };
    }
}
function getCurtainDeviceUpdateList(sCurtainState, timestamp, updateSource = system_constants_1.UpdateSourceMapping.MANUAL) {
    const updateList = [];
    const curtainState = {
        curtainState: sCurtainState.curtainState
    };
    updateList.push({
        deviceId: sCurtainState.deviceId,
        deviceState: curtainState,
        lastUpdateTime: timestamp,
        lastUpdateSource: updateSource,
        lastUpdateBy: system_constants_1.SystemNumber,
        lastUpdateUser: system_constants_1.SystemUser
    });
    return updateList;
}
function getACFanControllerUpdateList(sACFanState, fanDevice, timestamp, updateSource = system_constants_1.UpdateSourceMapping.MANUAL) {
    const updateList = [];
    const curState = fanDevice.deviceState;
    const zACFanState = {
        fanState: sACFanState.fanState || sACFanState.fanState == 0 ? sACFanState.fanState : curState.fanState,
        lightState: sACFanState.lightState || sACFanState.lightState == 0 ? sACFanState.lightState : curState.lightState
    };
    updateList.push({
        deviceId: sACFanState.deviceId,
        deviceState: zACFanState,
        lastUpdateTime: timestamp,
        lastUpdateSource: updateSource,
        lastUpdateBy: system_constants_1.SystemNumber,
        lastUpdateUser: system_constants_1.SystemUser
    });
    return updateList;
}
function getSmartConsoleUpdateList(scnSmartConsoleAction, smartConsoleProperties, timestamp, updateSource = system_constants_1.UpdateSourceMapping.MANUAL) {
    const smartConsoleProps = smartConsoleProperties;
    const updateList = [];
    smartConsoleProps.relays.forEach(function (relay) {
        if (relay.relayId == scnSmartConsoleAction.relayId) {
            relay.lastUpdateTime = timestamp;
            relay.lastUpdateSource = updateSource;
            relay.lastUpdateBy = system_constants_1.SystemNumber;
            relay.lastUpdateUser = system_constants_1.SystemUser;
            relay.relayState = scnSmartConsoleAction.relayState;
        }
    });
    updateList.push({
        deviceId: scnSmartConsoleAction.deviceId,
        deviceProperties: smartConsoleProps
    });
    return updateList;
}
//# sourceMappingURL=index.js.map