"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_to_cloud_pb_1 = require("../../../protos/generated/cloud/gateway_to_cloud_pb");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const general_1 = require("../../../../../utilities/general");
const rpc_maker_util_1 = require("../../../../../utilities/gateway/rpc-maker-util");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
exports.default = async (incomingObj, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                let cloudReqObj = new gateway_to_cloud_pb_1.RequestOtpFromGateway();
                cloudReqObj.setPhone(incomingObj.getPhone());
                let cloudRpcResponse = await rpc_maker_util_1.MakeAuthCloudRpc(general_1.PackIntoAny(cloudReqObj.serializeBinary(), system_constants_1.ProtoCloudPackageName + '.RequestOtpFromGateway'));
                if (cloudRpcResponse.getSuccess()) {
                    final_resp = response_1.default.getOtpSendSuccess();
                }
                else {
                    throw new errors_1.GeneralErrors.RpcResponseFalseError(cloudRpcResponse.getMessage());
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        final_resp = response_1.default.getUserNotAdmin();
                        break;
                    case errors_1.GeneralErrors.RpcMakerError:
                        final_resp = response_1.default.getConnectionError();
                        break;
                    case errors_1.GeneralErrors.RpcResponseFalseError:
                        final_resp = response_1.default.getCloudRpcError(e.message);
                        break;
                    default:
                        final_resp = response_1.default.getInternalServerError();
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map