"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_pb_1 = require("../../../protos/generated/hub/home/user_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class RequestOtpResp {
    static getOtpSendSuccess() {
        const resp = new user_pb_1.RequestOtpResponse();
        resp.setCode(800);
        resp.setMessage('Otp Send Success');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), RequestOtpResp.responseType);
    }
    static getCloudRpcError(cloudmsg) {
        const resp = new user_pb_1.RequestOtpResponse();
        resp.setCode(802);
        resp.setMessage(cloudmsg);
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RequestOtpResp.responseType);
    }
    static getConnectionError() {
        const resp = new user_pb_1.RequestOtpResponse();
        resp.setCode(803);
        resp.setMessage('Connection Error');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RequestOtpResp.responseType);
    }
    static getInternalServerError() {
        const resp = new user_pb_1.RequestOtpResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), RequestOtpResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new user_pb_1.RequestOtpResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RequestOtpResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new user_pb_1.RequestOtpResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), RequestOtpResp.responseType);
    }
}
exports.default = RequestOtpResp;
RequestOtpResp.responseType = system_constants_1.ProtoPackageName + '.RequestOtpResponse';
//# sourceMappingURL=response.js.map