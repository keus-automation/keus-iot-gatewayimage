"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const general_1 = require("../../../../../utilities/general");
const local_client_1 = require("../../../local-client");
const index_1 = __importDefault(require("../../../../../services/logger-service/index"));
const system_constants_2 = require("../../../../../constants/gateway/system-constants");
const logInst = new index_1.default({ enable: true, namespace: system_constants_2.GatewayLogNamespace + ': Enter Pair Mode' });
const errors_1 = require("../../../../../errors/errors");
exports.default = async (updateGatewayColorReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                //Check user permissions & check if zigbee is ready
                logInst.log('Update Gateway Color called');
                // let user = await KeusUserModel.getUserByPhone(phone);
                // await checkUserIsAdmin(user);
                let updateGatewayColorProto = new home_structures_pb_1.UpdateGatewayColor();
                updateGatewayColorProto.setGatewayId(updateGatewayColorReq.getGatewayId());
                updateGatewayColorProto.setRed(updateGatewayColorReq.getRed());
                updateGatewayColorProto.setGreen(updateGatewayColorReq.getGreen());
                updateGatewayColorProto.setBlue(updateGatewayColorReq.getBlue());
                updateGatewayColorProto.setBrightness(updateGatewayColorReq.getBrightness());
                let res = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(updateGatewayColorProto.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.UpdateGatewayColor'));
                logInst.log('Update Gateway Color Successful');
                resolve(response_1.default.getUpdateGatewayColorSuccessful());
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map