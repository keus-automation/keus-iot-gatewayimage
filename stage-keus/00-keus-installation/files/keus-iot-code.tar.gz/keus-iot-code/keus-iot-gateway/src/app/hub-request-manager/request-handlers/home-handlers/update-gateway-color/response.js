"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class UpdateGatewayColorResp {
    static getUpdateGatewayColorSuccessful() {
        const resp = new home_structures_pb_1.UpdateGatewayColorResponse();
        resp.setCode(800);
        resp.setMessage('Updated Gateway color');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateGatewayColorResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new home_structures_pb_1.UpdateGatewayColorResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateGatewayColorResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new home_structures_pb_1.UpdateGatewayColorResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateGatewayColorResp.responseType);
    }
    static getZigbeeControllerNotReady() {
        const resp = new home_structures_pb_1.UpdateGatewayColorResponse();
        resp.setCode(801);
        resp.setMessage('Zigbee Controller Not Ready');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateGatewayColorResp.responseType);
    }
    static getInternalServerError() {
        const resp = new home_structures_pb_1.UpdateGatewayColorResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), UpdateGatewayColorResp.responseType);
    }
}
exports.default = UpdateGatewayColorResp;
UpdateGatewayColorResp.responseType = system_constants_1.ProtoPackageName + '.UpdateGatewayColorResponse';
//# sourceMappingURL=response.js.map