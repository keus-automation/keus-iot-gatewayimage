"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
//Home Handlers
const HomeHandlers = __importStar(require("./home-handlers"));
exports.HomeHandlers = HomeHandlers;
//Device Handlers
const DeviceHandlers = __importStar(require("./device-handlers"));
exports.DeviceHandlers = DeviceHandlers;
//Scene Handlers
const SceneHandlers = __importStar(require("./scene-handlers"));
exports.SceneHandlers = SceneHandlers;
//Group Handlers
const GroupHandlers = __importStar(require("./group-handlers"));
exports.GroupHandlers = GroupHandlers;
//Activity Handlers
const ActivityHandlers = __importStar(require("./activity-handlers"));
exports.ActivityHandlers = ActivityHandlers;
//unauth handlers
const UnauthHandlers = __importStar(require("./unauth-handlers"));
exports.UnauthHandlers = UnauthHandlers;
//Schedule Handlers
const ScheduleHandlers = __importStar(require("./schedule-handlers"));
exports.ScheduleHandlers = ScheduleHandlers;
//Voice Handlers
const VoiceHandlers = __importStar(require("./voice-handlers"));
exports.VoiceHandlers = VoiceHandlers;
//Gateway Handlers
const MiniGatewayHandlers = __importStar(require("./gateway-handlers"));
exports.MiniGatewayHandlers = MiniGatewayHandlers;
//# sourceMappingURL=index.js.map