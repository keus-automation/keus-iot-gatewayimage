"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const scene_types_1 = require("../../../../../constants/scene/scene-types");
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const SceneUtils = __importStar(require("../../../../../utilities/gateway/scene-utils"));
const device_categories_1 = __importDefault(require("../../../../../constants/device/device-categories"));
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const errors_1 = require("../../../../../errors/errors");
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const local_client_1 = require("../../../local-client");
const general_1 = require("../../../../../utilities/general");
const zigbee_ac_fan_controller_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_ac_fan_controller_pb");
const zigbee_dc_fan_controller_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_dc_fan_controller_pb");
const zigbee_curtain_controller_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_curtain_controller_pb");
const dali_dimmable_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/dali_dimmable_driver_pb");
const zigbee_ir_blaster_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_ir_blaster_pb");
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const default_configuration_constants_1 = require("../../../../../constants/device/default-configuration-constants");
const smart_console_pb_1 = require("../../../../device-manager/providers/generated/devices/smart_console_pb");
const zigbee_dimmable_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_dimmable_driver_pb");
const keus_ir_remote_1 = __importDefault(require("../../../../../models/database-models/keus-ir-remote"));
const zigbee_embedded_switch_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_embedded_switch_pb");
const scene_structures_pb_1 = require("../../../../device-manager/providers/generated/scenes/scene_structures_pb");
const device_constants_pb_2 = require("../../../../device-manager/providers/generated/devices/device_constants_pb");
const zigbee_rgbwwa_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/zigbee_rgbwwa_driver_pb");
const dali_colour_tunable_driver_pb_1 = require("../../../../device-manager/providers/generated/devices/dali_colour_tunable_driver_pb");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
async function checkAreaCompatibility(sceneRoom, checkRoom) {
    const roomList = await keus_home_1.default.getRoomsInSameArea(sceneRoom);
    return roomList.indexOf(checkRoom) >= 0;
}
exports.default = async (addActionToSceneReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                // await checkUserIsAdmin(user);
                if (!addActionToSceneReq.getSceneRoom()) {
                    throw new errors_1.HomeErrors.InvalidRoomId();
                }
                else {
                    const room = await keus_home_1.default.getRoomById(addActionToSceneReq.getSceneRoom());
                    if (!room) {
                        throw new errors_1.HomeErrors.InvalidRoomId();
                    }
                    else {
                        const sceneId = addActionToSceneReq.getSceneId();
                        const scene = await keus_scene_1.default.getSceneById(sceneId, room.roomId);
                        let dmAddActionToSceneReq = new scene_structures_pb_1.DMAddActionToScene();
                        dmAddActionToSceneReq.setSceneArea(room.areaId);
                        dmAddActionToSceneReq.setSceneId(sceneId);
                        let dmSceneAction = new scene_structures_pb_1.DMSceneAction();
                        var filteredActionList;
                        var newAction, tempAction;
                        if (!scene) {
                            throw new errors_1.SceneErrors.InvalidSceneId();
                        }
                        else {
                            const actionInfo = addActionToSceneReq.getActionItem();
                            //console.log("\n\nAdd action to scene request");
                            //console.log(addActionToSceneReq.toObject());
                            var actionId = actionInfo.getActionId()
                                ? actionInfo.getActionId()
                                : SceneUtils.generateActionIdForScene();
                            var zigbeeActionId = SceneUtils.generateZigbeeActionIdForScene(scene.actionList);
                            dmSceneAction.setZigbeeActionId(zigbeeActionId);
                            const filteredTimeslot = scene.timeslotList.filter(function (timeslot) {
                                return timeslot.timeslotId == actionInfo.getTimeslotId();
                            });
                            if (zigbeeActionId < 0) {
                                throw new errors_1.SceneErrors.SceneActionLimitReached();
                            }
                            else if (!filteredTimeslot.length) {
                                throw new errors_1.SceneErrors.InvalidTimeslotId();
                            }
                            else {
                                console.log('This is action type ', actionInfo.getActionType());
                                switch (actionInfo.getActionType()) {
                                    //Area scene action
                                    case scene_types_1.SceneActionTypes.AREASCENEACTION:
                                        const ascnAction = actionInfo.getAreaSceneAction();
                                        if (scene.sceneScope != scene_constants_pb_1.SCENE_SCOPE.GLOBAL) {
                                            throw new errors_1.SceneErrors.SceneIsNotGlobal();
                                        }
                                        else if (!ascnAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const areaScene = await keus_scene_1.default.getSceneById(ascnAction.getSceneId(), ascnAction.getRoomId());
                                            const areaSceneRoom = await keus_home_1.default.getRoomById(ascnAction.getRoomId());
                                            if (!areaScene || !areaSceneRoom) {
                                                throw new errors_1.SceneErrors.InvalidSceneId();
                                            }
                                            else {
                                                let filteredSceneList = scene.actionList.filter(function (action) {
                                                    let actionItem = action.actionItem;
                                                    return actionItem.sceneId == ascnAction.getSceneId() && actionItem.roomId == ascnAction.getRoomId();
                                                });
                                                if (filteredSceneList.length) {
                                                    throw new errors_1.SceneErrors.InvalidSceneId();
                                                }
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const zascnTempAction = {
                                                    sceneId: ascnAction.getSceneId(),
                                                    roomId: ascnAction.getRoomId()
                                                };
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                //Add area scene action and call zigbee
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.AREASCENEACTION,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC,
                                                    syncRequestId: '-',
                                                    actionItem: zascnTempAction
                                                };
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.AREASCENEACTION);
                                                let dmAddActionToGlobalScene = new scene_structures_pb_1.DMAddSceneToGlobalScene();
                                                dmAddActionToGlobalScene.setGSceneId(scene.sceneId);
                                                dmAddActionToGlobalScene.setAreaId(areaSceneRoom.areaId);
                                                dmAddActionToGlobalScene.setSceneId(ascnAction.getSceneId());
                                                // console.log(dmAddActionToGlobalScene.toObject());
                                                // console.log("\n\n");
                                                let dmAddActionToGlobalSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToGlobalScene.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddSceneToGlobalScene'));
                                                if (!dmAddActionToGlobalSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToGlobalSceneRsp.getMessage());
                                                }
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneSuccessful(actionId));
                                            }
                                        }
                                        break;
                                    //Smart console relay action
                                    case scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE:
                                        const scAction = actionInfo.getZscRelayAction();
                                        if (!scAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const scDevice = await keus_device_1.default.getDeviceById(scAction.getDeviceId());
                                            if (!scDevice) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                                            }
                                            else if (scDevice.deviceCategory !=
                                                device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceType();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, scDevice.deviceRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                const scDeviceProperties = (scDevice.deviceProperties);
                                                if (scAction.getRelayId() >= scDeviceProperties.relays.length) {
                                                    throw new errors_1.DeviceErrors.InvalidRelayId();
                                                }
                                                else {
                                                    filteredActionList = [];
                                                    scene.actionList.forEach(function (action) {
                                                        if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE &&
                                                            action.timeslotId == actionInfo.getTimeslotId()) {
                                                            var scTempAction = (action.actionItem);
                                                            if (!(scTempAction.deviceId == scAction.getDeviceId() &&
                                                                scTempAction.relayId == scAction.getRelayId())) {
                                                                filteredActionList.push(action);
                                                            }
                                                            else {
                                                                zigbeeActionId = action.zigbeeActionId;
                                                                dmSceneAction.setZigbeeActionId(zigbeeActionId);
                                                            }
                                                        }
                                                        else {
                                                            filteredActionList.push(action);
                                                        }
                                                    });
                                                    const scRelayAction = {
                                                        deviceId: scAction.getDeviceId(),
                                                        relayId: scAction.getRelayId(),
                                                        relayState: scAction.getRelayState()
                                                    };
                                                    //Add current switch action to zigbee and await call
                                                    dmSceneAction.setActionType(scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE);
                                                    let dmSmartConsoleRelayAction = new smart_console_pb_1.DMSmartConsoleRelayAction();
                                                    dmSmartConsoleRelayAction.setDeviceId(scRelayAction.deviceId);
                                                    dmSmartConsoleRelayAction.setRelayId(scRelayAction.relayId);
                                                    dmSmartConsoleRelayAction.setRelayState(scRelayAction.relayState);
                                                    dmSceneAction.setZscRelayAction(dmSmartConsoleRelayAction);
                                                    dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                    let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                    console.log('This is rsp', dmAddActionToSceneRsp);
                                                    if (!dmAddActionToSceneRsp.getSuccess()) {
                                                        throw new Error(dmAddActionToSceneRsp.getMessage());
                                                    }
                                                    newAction = {
                                                        actionId: actionId,
                                                        zigbeeActionId: zigbeeActionId,
                                                        actionType: scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE,
                                                        timeslotId: actionInfo.getTimeslotId(),
                                                        syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC,
                                                        syncRequestId: '-',
                                                        actionItem: scRelayAction
                                                    };
                                                    filteredActionList.push(newAction);
                                                    await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                    resolve(response_1.default.getAddActionToSceneSuccessful(actionId));
                                                }
                                            }
                                        }
                                        break;
                                    //Embedded Switch Action
                                    case scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH:
                                        const esAction = actionInfo.getEmbeddedApplianceAction();
                                        if (!esAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const esDevice = await keus_device_1.default.getDeviceById(esAction.getDeviceId());
                                            if (!esDevice) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                                            }
                                            else if (esDevice.deviceCategory !=
                                                device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceType();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, esDevice.deviceRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                const esDeviceProperties = (esDevice.deviceProperties);
                                                let applianceDetails = esDeviceProperties.appliance.find(function (appliance) {
                                                    return appliance.applianceId == esAction.getApplianceId();
                                                });
                                                if (applianceDetails.inGroup) {
                                                    throw new errors_1.GroupErrors.DeviceInAnotherGroup();
                                                }
                                                filteredActionList = [];
                                                scene.actionList.forEach(function (action) {
                                                    if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH &&
                                                        action.timeslotId == actionInfo.getTimeslotId()) {
                                                        var esTempAction = action.actionItem;
                                                        if (esTempAction.deviceId == esAction.getDeviceId()) {
                                                            if (esTempAction.applianceId != esAction.getApplianceId()) {
                                                                //Generate the scene action item for other switches
                                                                filteredActionList.push(action);
                                                            }
                                                        }
                                                        else {
                                                            filteredActionList.push(action);
                                                        }
                                                    }
                                                    else {
                                                        filteredActionList.push(action);
                                                    }
                                                });
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                let applianceAction;
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH);
                                                let dmEmbeddedApplianceAction = new zigbee_embedded_switch_pb_1.DMEmbeddedApplianceAction();
                                                dmEmbeddedApplianceAction.setDeviceId(esDevice.deviceId);
                                                dmEmbeddedApplianceAction.setApplianceId(esAction.getApplianceId());
                                                switch (esAction.getApplianceType()) {
                                                    case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                                                        dmEmbeddedApplianceAction.setApplianceType(device_constants_pb_2.DMEMBEDDED_APPLIANCE_TYPES.ON_OFF);
                                                        let dmonoffAction = new zigbee_embedded_switch_pb_1.DMOnOffApplianceState();
                                                        dmonoffAction.setSwitchState(esAction.getOnOffState().getSwitchState());
                                                        dmEmbeddedApplianceAction.setOnOffState(dmonoffAction);
                                                        let onoffAction = {
                                                            switchState: esAction.getOnOffState().getSwitchState()
                                                        };
                                                        applianceAction = onoffAction;
                                                        break;
                                                    case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                                                        dmEmbeddedApplianceAction.setApplianceType(device_constants_pb_2.DMEMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER);
                                                        let dmSdAction = new zigbee_embedded_switch_pb_1.DMSingleDimmerApplianceState();
                                                        dmSdAction.setSwitchState(esAction.getSingleDimmerState().getSwitchState());
                                                        dmEmbeddedApplianceAction.setSingleDimmerState(dmSdAction);
                                                        let sdAction = {
                                                            switchState: esAction
                                                                .getSingleDimmerState()
                                                                .getSwitchState()
                                                        };
                                                        applianceAction = sdAction;
                                                        break;
                                                    case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                                                        dmEmbeddedApplianceAction.setApplianceType(device_constants_pb_2.DMEMBEDDED_APPLIANCE_TYPES.FAN);
                                                        let dmfanAction = new zigbee_embedded_switch_pb_1.DMFanApplianceState();
                                                        dmfanAction.setFanState(esAction.getFanState().getFanState());
                                                        dmEmbeddedApplianceAction.setFanState(dmfanAction);
                                                        let fanAction = {
                                                            fanState: esAction.getFanState().getFanState()
                                                        };
                                                        applianceAction = fanAction;
                                                        break;
                                                    case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                                                        dmEmbeddedApplianceAction.setApplianceType(device_constants_pb_2.DMEMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE);
                                                        let dmCtAction = new zigbee_embedded_switch_pb_1.DMColorTunableApplianceState();
                                                        dmCtAction.setLightState(esAction.getColorTunableState().getLightState());
                                                        dmCtAction.setWarmWhiteState(esAction.getColorTunableState().getWarmWhiteState());
                                                        dmCtAction.setCoolWhiteState(esAction.getColorTunableState().getCoolWhiteState());
                                                        dmEmbeddedApplianceAction.setColorTunableState(dmCtAction);
                                                        let ctAction = {
                                                            lightState: esAction.getColorTunableState().getLightState(),
                                                            warmWhiteState: esAction
                                                                .getColorTunableState()
                                                                .getWarmWhiteState(),
                                                            coolWhiteState: esAction
                                                                .getColorTunableState()
                                                                .getCoolWhiteState()
                                                        };
                                                        applianceAction = ctAction;
                                                        break;
                                                }
                                                dmSceneAction.setEmbeddedApplianceAction(dmEmbeddedApplianceAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                let final_action = {
                                                    applianceId: esAction.getApplianceId(),
                                                    applianceState: applianceAction,
                                                    applianceType: esAction.getApplianceType(),
                                                    deviceId: esAction.getDeviceId()
                                                };
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC,
                                                    syncRequestId: '-',
                                                    actionItem: final_action
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneSuccessful(actionId));
                                            }
                                        }
                                        break;
                                    //Curtain Controller Action
                                    case scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER:
                                        const zccAction = actionInfo.getZcurtainControllerAction();
                                        if (!zccAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const zccDevice = await keus_device_1.default.getDeviceById(zccAction.getDeviceId());
                                            if (!zccDevice) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                                            }
                                            else if (zccDevice.deviceCategory !=
                                                device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER')
                                                    .deviceCategoryCode) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceType();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, zccDevice.deviceRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const zccTempAction = {
                                                    deviceId: zccAction.getDeviceId(),
                                                    curtainState: zccAction.getCurtainState()
                                                };
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                //Add current curtain action and call zigbee with invert signal check on device
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC,
                                                    syncRequestId: '-',
                                                    actionItem: zccTempAction
                                                };
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER);
                                                var tempCurtainState;
                                                const zccDeviceProps = (zccDevice.deviceProperties);
                                                tempCurtainState = zccTempAction.curtainState;
                                                let dmCurtainSceneAction = new zigbee_curtain_controller_pb_1.DMZigbeeCurtainControllerAction();
                                                dmCurtainSceneAction.setDeviceId(zccTempAction.deviceId);
                                                dmCurtainSceneAction.setCurtainState(tempCurtainState);
                                                dmSceneAction.setZcurtainControllerAction(dmCurtainSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneSuccessful(actionId));
                                            }
                                        }
                                        break;
                                    //AC Fan controller Action
                                    case scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER:
                                        const zacfcAction = actionInfo.getZacfanControllerAction();
                                        if (!zacfcAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const zacfcDevice = await keus_device_1.default.getDeviceById(zacfcAction.getDeviceId());
                                            if (!zacfcDevice) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                                            }
                                            else if (zacfcDevice.deviceCategory !=
                                                device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER')
                                                    .deviceCategoryCode) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceType();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, zacfcDevice.deviceRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER);
                                                let dmFanSceneAction = new zigbee_ac_fan_controller_pb_1.DMZigbeeACFanControllerAction();
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const zacfcTempAction = {
                                                    deviceId: zacfcAction.getDeviceId(),
                                                    updateType: zacfcAction.getUpdateType()
                                                };
                                                dmFanSceneAction.setUpdateType(zacfcTempAction.updateType);
                                                if (zacfcAction.getUpdateType() ==
                                                    device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_FAN_UPDATE) {
                                                    zacfcTempAction.fanState = zacfcAction.getFanState();
                                                    dmFanSceneAction.setFanState(zacfcTempAction.fanState);
                                                }
                                                else if (zacfcAction.getUpdateType() ==
                                                    device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_LIGHT_UPDATE) {
                                                    zacfcTempAction.lightState = zacfcAction.getLightState();
                                                    dmFanSceneAction.setLightState(zacfcTempAction.lightState);
                                                }
                                                else {
                                                    zacfcTempAction.lightState = zacfcAction.getLightState();
                                                    zacfcTempAction.fanState = zacfcAction.getFanState();
                                                    dmFanSceneAction.setFanState(zacfcTempAction.fanState);
                                                    dmFanSceneAction.setLightState(zacfcTempAction.lightState);
                                                }
                                                console.log('this is action Id ', actionId, scene.actionList);
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('this is fan action Item', currentAction);
                                                //Add current fan action and call zigbee
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC,
                                                    syncRequestId: '-',
                                                    actionItem: zacfcTempAction
                                                };
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                dmFanSceneAction.setDeviceId(zacfcTempAction.deviceId);
                                                dmSceneAction.setZacfanControllerAction(dmFanSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneSuccessful(actionId));
                                            }
                                        }
                                        break;
                                    //DC Fan Controller Action
                                    case scene_types_1.SceneActionTypes.ZIGBEEDCFANCONTROLLER:
                                        const zdcfcAction = actionInfo.getZdcfanControllerAction();
                                        if (!zdcfcAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const zdcfcDevice = await keus_device_1.default.getDeviceById(zdcfcAction.getDeviceId());
                                            if (!zdcfcDevice) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                                            }
                                            else if (zdcfcDevice.deviceCategory !=
                                                device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER')
                                                    .deviceCategoryCode) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceType();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, zdcfcDevice.deviceRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.ZIGBEEDCFANCONTROLLER);
                                                let dmFanSceneAction = new zigbee_dc_fan_controller_pb_1.DMZigbeeDCFanControllerAction();
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const zdcfcTempAction = {
                                                    deviceId: zdcfcAction.getDeviceId(),
                                                    updateType: zdcfcAction.getUpdateType()
                                                };
                                                dmFanSceneAction.setUpdateType(zdcfcTempAction.updateType);
                                                if (zdcfcAction.getUpdateType() ==
                                                    device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_FAN_UPDATE) {
                                                    zdcfcTempAction.fanState = zdcfcAction.getFanState();
                                                    dmFanSceneAction.setFanState(zdcfcTempAction.fanState);
                                                }
                                                else if (zdcfcAction.getUpdateType() ==
                                                    device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_LIGHT_UPDATE) {
                                                    zdcfcTempAction.lightState = {
                                                        lightState: zdcfcAction.getLightState().getLightState(),
                                                        lightTemperature: zdcfcAction
                                                            .getLightState()
                                                            .getLightTemperature()
                                                    };
                                                    let dmFanLightState = new zigbee_dc_fan_controller_pb_1.DMDCFanControllerLightState();
                                                    dmFanLightState.setLightState(zdcfcTempAction.lightState.lightState);
                                                    dmFanLightState.setLightTemperature(zdcfcTempAction.lightState.lightTemperature);
                                                    dmFanSceneAction.setLightState(dmFanLightState);
                                                }
                                                else {
                                                    zdcfcTempAction.lightState = {
                                                        lightState: zdcfcAction.getLightState().getLightState(),
                                                        lightTemperature: zdcfcAction
                                                            .getLightState()
                                                            .getLightTemperature()
                                                    };
                                                    zdcfcTempAction.fanState = zdcfcAction.getFanState();
                                                    dmFanSceneAction.setFanState(zdcfcTempAction.fanState);
                                                    let dmFanLightState = new zigbee_dc_fan_controller_pb_1.DMDCFanControllerLightState();
                                                    dmFanLightState.setLightState(zdcfcTempAction.lightState.lightState);
                                                    dmFanLightState.setLightTemperature(zdcfcTempAction.lightState.lightTemperature);
                                                    dmFanSceneAction.setLightState(dmFanLightState);
                                                }
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                //Add current fan action and call zigbee
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.ZIGBEEDCFANCONTROLLER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC,
                                                    syncRequestId: '-',
                                                    actionItem: zdcfcTempAction
                                                };
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                dmFanSceneAction.setDeviceId(zdcfcTempAction.deviceId);
                                                dmSceneAction.setZdcfanControllerAction(dmFanSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneSuccessful(actionId));
                                            }
                                        }
                                        break;
                                    //RGBWWA Driver Action
                                    case scene_types_1.SceneActionTypes.ZIGBEERGBWWADRIVER:
                                        const zrgbwwaAction = actionInfo.getZrgbwwwaDriverAction();
                                        console.log(zrgbwwaAction);
                                        if (!zrgbwwaAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const zrgbwwaDevice = await keus_device_1.default.getDeviceById(zrgbwwaAction.getDeviceId());
                                            if (!zrgbwwaDevice) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                                            }
                                            else if (zrgbwwaDevice.deviceCategory !=
                                                device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceCategoryCode) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceType();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, zrgbwwaDevice.deviceRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else if (zrgbwwaDevice.inGroup) {
                                                throw new errors_1.GroupErrors.DeviceInAnotherGroup();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const zrgbwwaTempAction = {
                                                    deviceId: zrgbwwaAction.getDeviceId(),
                                                    updateType: zrgbwwaAction.getUpdateType(),
                                                    deviceState: zrgbwwaAction.getDeviceState()
                                                };
                                                let dmrgbAction = new zigbee_rgbwwa_driver_pb_1.DMZigbeeRgbwwaAction();
                                                dmrgbAction.setDeviceId(zrgbwwaTempAction.deviceId);
                                                dmrgbAction.setDeviceState(zrgbwwaAction.getDeviceState());
                                                if (zrgbwwaAction.getUpdateType() ==
                                                    device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                                                    zrgbwwaTempAction.rgbState = {
                                                        red: zrgbwwaAction.getRgbState().getRed(),
                                                        blue: zrgbwwaAction.getRgbState().getBlue(),
                                                        green: zrgbwwaAction.getRgbState().getGreen(),
                                                        pattern: zrgbwwaAction.getRgbState().getPattern(),
                                                        deviceState: zrgbwwaAction.getDeviceState()
                                                    };
                                                    dmrgbAction.setUpdateType(device_constants_pb_2.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE);
                                                    let dmRgb = new zigbee_rgbwwa_driver_pb_1.DMRGB();
                                                    dmRgb.setRed(zrgbwwaAction.getRgbState().getRed());
                                                    dmRgb.setBlue(zrgbwwaAction.getRgbState().getBlue());
                                                    dmRgb.setGreen(zrgbwwaAction.getRgbState().getGreen());
                                                    dmRgb.setPattern(zrgbwwaAction.getRgbState().getPattern());
                                                    dmRgb.setDeviceState(zrgbwwaAction.getRgbState().getDeviceState());
                                                    dmrgbAction.setRgbState(dmRgb);
                                                }
                                                else if (zrgbwwaAction.getUpdateType() ==
                                                    device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                                                    zrgbwwaTempAction.wwaState = {
                                                        warmWhite: zrgbwwaAction.getWwaState().getWarmWhite(),
                                                        coolWhite: zrgbwwaAction.getWwaState().getCoolWhite(),
                                                        amber: zrgbwwaAction.getWwaState().getAmber(),
                                                        deviceState: zrgbwwaAction.getDeviceState()
                                                    };
                                                    dmrgbAction.setUpdateType(device_constants_pb_2.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE);
                                                    let dmWwa = new zigbee_rgbwwa_driver_pb_1.DMWWA();
                                                    dmWwa.setAmber(zrgbwwaAction.getWwaState().getAmber());
                                                    dmWwa.setCoolWhite(zrgbwwaAction.getWwaState().getCoolWhite());
                                                    dmWwa.setWarmWhite(zrgbwwaAction.getWwaState().getWarmWhite());
                                                    dmWwa.setDeviceState(zrgbwwaAction.getWwaState().getDeviceState());
                                                    dmrgbAction.setWwaState(dmWwa);
                                                }
                                                //Add current rgb action and call zigbee
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('This is RGBWWA device TO SCENE');
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.ZIGBEERGBWWADRIVER);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                dmSceneAction.setZrgbwwwaDriverAction(dmrgbAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                                dmAddActionToSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.ZIGBEERGBWWADRIVER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC,
                                                    syncRequestId: dmAddActionToSceneRsp.getRequestId(),
                                                    actionItem: zrgbwwaTempAction
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneSuccessful(actionId));
                                            }
                                        }
                                        break;
                                    //Group Action - Zigbee Dimmable Action
                                    case scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER:
                                        const zddAction = actionInfo.getZdimmableDriverAction();
                                        if (!zddAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const groupItem = await keus_group_1.default.getGroupById(zddAction.getGroupId(), zddAction.getRoomId());
                                            if (!groupItem) {
                                                throw new errors_1.GroupErrors.InvalidGroupId();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, groupItem.groupRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const zddTempAction = {
                                                    groupId: zddAction.getGroupId(),
                                                    roomId: zddAction.getRoomId(),
                                                    driverState: zddAction.getDriverState()
                                                };
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('This is zigbee dimmable scene ');
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                let dmZigbeeDimmableSceneAction = new zigbee_dimmable_driver_pb_1.DMZigbeeDimmableDriverAction();
                                                dmZigbeeDimmableSceneAction.setAreaId(room.areaId);
                                                dmZigbeeDimmableSceneAction.setGroupId(zddTempAction.groupId);
                                                dmZigbeeDimmableSceneAction.setDriverState(zddTempAction.driverState);
                                                dmSceneAction.setZdimmableDriverAction(dmZigbeeDimmableSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                                dmAddActionToSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                //Add current group action and call zigbee
                                                const zddReqId = dmAddActionToSceneRsp.getRequestId();
                                                //Add current group action and call zigbee
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING,
                                                    syncRequestId: zddReqId,
                                                    actionItem: zddTempAction
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneQueued(actionId));
                                            }
                                        }
                                        break;
                                    //Group Action - Dali Dimmable Action
                                    case scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER:
                                        console.log('This is dali dimmable group configuration');
                                        const dddAction = actionInfo.getDdimmableDriverAction();
                                        if (!dddAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const groupItem = await keus_group_1.default.getGroupById(dddAction.getGroupId(), dddAction.getRoomId());
                                            if (!groupItem) {
                                                throw new errors_1.GroupErrors.InvalidGroupId();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, groupItem.groupRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const dddTempAction = {
                                                    groupId: dddAction.getGroupId(),
                                                    roomId: dddAction.getRoomId(),
                                                    driverState: dddAction.getDriverState() > default_configuration_constants_1.DaliDimmableDriverMaxValue
                                                        ? default_configuration_constants_1.DaliDimmableDriverMaxValue
                                                        : dddAction.getDriverState()
                                                };
                                                const room = await keus_home_1.default.getRoomById(dddTempAction.roomId);
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('This is dali dimmable group configuration');
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                let dmdaliDimmableSceneAction = new dali_dimmable_driver_pb_1.DMDaliDimmableDriverAction();
                                                dmdaliDimmableSceneAction.setAreaId(room.areaId);
                                                dmdaliDimmableSceneAction.setGroupId(dddTempAction.groupId);
                                                dmdaliDimmableSceneAction.setDriverState(dddTempAction.driverState);
                                                dmSceneAction.setDdimmableDriverAction(dmdaliDimmableSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                                dmAddActionToSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                //Add current group action and call zigbee
                                                const dddReqId = dmAddActionToSceneRsp.getRequestId();
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING,
                                                    syncRequestId: dddReqId,
                                                    actionItem: dddTempAction
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneQueued(actionId));
                                            }
                                        }
                                    //Group Action - Dali color tunable
                                    case scene_types_1.SceneActionTypes.DALICOLORTUNABLEDRIVER:
                                        console.log('This is dali COLOR TUNable action configuration');
                                        const dctdAction = actionInfo.getDcolortunableDriverAction();
                                        if (!dctdAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const groupItem = await keus_group_1.default.getGroupById(dctdAction.getGroupId(), dctdAction.getGroupRoom());
                                            if (!groupItem) {
                                                throw new errors_1.GroupErrors.InvalidGroupId();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, groupItem.groupRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const dctdTempAction = {
                                                    groupId: dctdAction.getGroupId(),
                                                    roomId: dctdAction.getGroupRoom(),
                                                    driverState: {
                                                        driverState: dctdAction.getDriverState().getDriverState() > default_configuration_constants_1.DaliColorTunableMaxValue
                                                            ? default_configuration_constants_1.DaliColorTunableMaxValue
                                                            : dctdAction.getDriverState().getDriverState(),
                                                        colorTemperature: dctdAction.getDriverState().getColorTemperature() > default_configuration_constants_1.DaliColorTunableMaxTemperature
                                                            ? default_configuration_constants_1.DaliColorTunableMaxTemperature
                                                            : dctdAction.getDriverState().getColorTemperature(),
                                                        lastUpdateBy: "",
                                                        lastUpdateSource: "",
                                                        lastUpdateTime: Date.now(),
                                                        lastUpdateUser: ""
                                                    }
                                                };
                                                const room = await keus_home_1.default.getRoomById(dctdTempAction.roomId);
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('This is dali Color Tunable group configuration');
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.DALICOLORTUNABLEDRIVER);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                //ADD DM PART
                                                let dmdaliCtSceneAction = new dali_colour_tunable_driver_pb_1.DMDaliColourTunableDriverAction();
                                                dmdaliCtSceneAction.setAreaId(room.areaId);
                                                dmdaliCtSceneAction.setGroupId(dctdTempAction.groupId);
                                                dmdaliCtSceneAction.setDriverState(dctdTempAction.driverState.driverState);
                                                dmdaliCtSceneAction.setDriverTemp(dctdTempAction.driverState.colorTemperature);
                                                dmSceneAction.setDcolourtunableDriverAction(dmdaliCtSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                                dmAddActionToSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                const dddReqId = dmAddActionToSceneRsp.getRequestId();
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.DALICOLORTUNABLEDRIVER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING,
                                                    syncRequestId: dddReqId,
                                                    actionItem: dctdTempAction
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneQueued(actionId));
                                            }
                                        }
                                    case scene_types_1.SceneActionTypes.GROUPAPPLIANCEONOFF:
                                        console.log('This group appliance on off configuration');
                                        let gaofAction = actionInfo.getGrpOnoffAction();
                                        if (!gaofAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const groupItem = await keus_group_1.default.getGroupById(gaofAction.getGroupId(), gaofAction.getRoomId());
                                            if (!groupItem) {
                                                throw new errors_1.GroupErrors.InvalidGroupId();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, groupItem.groupRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const gaofTempAction = {
                                                    groupId: gaofAction.getGroupId(),
                                                    roomId: gaofAction.getRoomId(),
                                                    switchState: gaofAction.getSwitchState()
                                                };
                                                const room = await keus_home_1.default.getRoomById(gaofTempAction.roomId);
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('This is appliance on off group configuration');
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.GROUPAPPLIANCEONOFF);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                let dmGroupOnOffSceneAction = new zigbee_embedded_switch_pb_1.DMGroupOnOffApplianceAction();
                                                dmGroupOnOffSceneAction.setAreaId(room.areaId);
                                                dmGroupOnOffSceneAction.setGroupId(gaofTempAction.groupId);
                                                dmGroupOnOffSceneAction.setSwitchState(gaofTempAction.switchState);
                                                dmSceneAction.setGrpOnoffAction(dmGroupOnOffSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                                dmAddActionToSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.GROUPAPPLIANCEONOFF,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING,
                                                    syncRequestId: dmAddActionToSceneRsp.getRequestId(),
                                                    actionItem: gaofTempAction
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneQueued(actionId));
                                            }
                                        }
                                    case scene_types_1.SceneActionTypes.GROUPAPPLIANCESINGLEDIMMER:
                                        console.log('This group appliance single dimmer configuration');
                                        let gasdAction = actionInfo.getGrpSingledimmerAction();
                                        if (!gasdAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const groupItem = await keus_group_1.default.getGroupById(gasdAction.getGroupId(), gasdAction.getRoomId());
                                            if (!groupItem) {
                                                throw new errors_1.GroupErrors.InvalidGroupId();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, groupItem.groupRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const gasdTempAction = {
                                                    groupId: gasdAction.getGroupId(),
                                                    roomId: gasdAction.getRoomId(),
                                                    switchState: gasdAction.getSwitchState()
                                                };
                                                const room = await keus_home_1.default.getRoomById(gasdTempAction.roomId);
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('This is appliance single dimmer group configuration');
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.GROUPAPPLIANCESINGLEDIMMER);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                let dmGroupSingleDimmerSceneAction = new zigbee_embedded_switch_pb_1.DMGroupSingleDimmerApplianceAction();
                                                dmGroupSingleDimmerSceneAction.setAreaId(room.areaId);
                                                dmGroupSingleDimmerSceneAction.setGroupId(gasdTempAction.groupId);
                                                dmGroupSingleDimmerSceneAction.setSwitchState(gasdTempAction.switchState);
                                                dmSceneAction.setGrpSingledimmerAction(dmGroupSingleDimmerSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                                dmAddActionToSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.GROUPAPPLIANCESINGLEDIMMER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING,
                                                    syncRequestId: dmAddActionToSceneRsp.getRequestId(),
                                                    actionItem: gasdTempAction
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneQueued(actionId));
                                            }
                                        }
                                    case scene_types_1.SceneActionTypes.GROUPAPPLIANCEFAN:
                                        console.log('This group appliance fan configuration');
                                        let gafAction = actionInfo.getGrpFanAction();
                                        if (!gafAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const groupItem = await keus_group_1.default.getGroupById(gafAction.getGroupId(), gafAction.getRoomId());
                                            if (!groupItem) {
                                                throw new errors_1.GroupErrors.InvalidGroupId();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, groupItem.groupRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const gafTempAction = {
                                                    groupId: gafAction.getGroupId(),
                                                    roomId: gafAction.getRoomId(),
                                                    fanState: gafAction.getFanState()
                                                };
                                                const room = await keus_home_1.default.getRoomById(gafTempAction.roomId);
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('This is appliance fan group configuration');
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.GROUPAPPLIANCEFAN);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                let dmGroupFanSceneAction = new zigbee_embedded_switch_pb_1.DMGroupFanApplianceAction();
                                                dmGroupFanSceneAction.setAreaId(room.areaId);
                                                dmGroupFanSceneAction.setGroupId(gafTempAction.groupId);
                                                dmGroupFanSceneAction.setFanState(gafTempAction.fanState);
                                                dmSceneAction.setGrpFanAction(dmGroupFanSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                                dmAddActionToSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.GROUPAPPLIANCEFAN,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING,
                                                    syncRequestId: dmAddActionToSceneRsp.getRequestId(),
                                                    actionItem: gafTempAction
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneQueued(actionId));
                                            }
                                        }
                                    case scene_types_1.SceneActionTypes.GROUPAPPLIANCECOLORTUNABLE:
                                        console.log('This group appliance on off configuration');
                                        let gactAction = actionInfo.getGrpColortunableAction();
                                        if (!gactAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const groupItem = await keus_group_1.default.getGroupById(gactAction.getGroupId(), gactAction.getRoomId());
                                            if (!groupItem) {
                                                throw new errors_1.GroupErrors.InvalidGroupId();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, groupItem.groupRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const gactTempAction = {
                                                    groupId: gactAction.getGroupId(),
                                                    roomId: gactAction.getRoomId(),
                                                    lightState: gactAction.getLightState(),
                                                    warmWhiteState: gactAction.getWarmWhiteState(),
                                                    coolWhiteState: gactAction.getCoolWhiteState()
                                                };
                                                const room = await keus_home_1.default.getRoomById(gactTempAction.roomId);
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('This is appliance color tunable group configuration');
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.GROUPAPPLIANCECOLORTUNABLE);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                let dmGroupColorTunableSceneAction = new zigbee_embedded_switch_pb_1.DMGroupColorTunableApplianceAction();
                                                dmGroupColorTunableSceneAction.setAreaId(room.areaId);
                                                dmGroupColorTunableSceneAction.setGroupId(gactTempAction.groupId);
                                                dmGroupColorTunableSceneAction.setWarmWhiteState(gactTempAction.warmWhiteState);
                                                dmGroupColorTunableSceneAction.setCoolWhiteState(gactTempAction.coolWhiteState);
                                                dmGroupColorTunableSceneAction.setLightState(gactTempAction.lightState);
                                                dmSceneAction.setGrpColortunableAction(dmGroupColorTunableSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                                dmAddActionToSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.GROUPAPPLIANCECOLORTUNABLE,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING,
                                                    syncRequestId: dmAddActionToSceneRsp.getRequestId(),
                                                    actionItem: gactTempAction
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneQueued(actionId));
                                            }
                                        }
                                    //RGBWWA Group Action
                                    case scene_types_1.SceneActionTypes.GROUPRGBWWADRIVER:
                                        const grgbwwaAction = actionInfo.getGrpZrgbwwaAction();
                                        console.log(grgbwwaAction);
                                        if (!grgbwwaAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const groupItem = await keus_group_1.default.getGroupById(grgbwwaAction.getGroupId(), grgbwwaAction.getRoomId());
                                            if (!groupItem) {
                                                throw new errors_1.GroupErrors.InvalidGroupId();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, groupItem.groupRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                const grgbwwaTempAction = {
                                                    groupId: grgbwwaAction.getGroupId(),
                                                    roomId: grgbwwaAction.getRoomId(),
                                                    updateType: grgbwwaAction.getUpdateType(),
                                                    deviceState: grgbwwaAction.getDeviceState()
                                                };
                                                const room = await keus_home_1.default.getRoomById(grgbwwaTempAction.roomId);
                                                let dmGroupRgbwwaAction = new zigbee_rgbwwa_driver_pb_1.DMGroupZigbeeRgbwwaAction();
                                                dmGroupRgbwwaAction.setAreaId(room.areaId);
                                                dmGroupRgbwwaAction.setGroupId(grgbwwaTempAction.groupId);
                                                dmGroupRgbwwaAction.setDeviceState(grgbwwaTempAction.deviceState);
                                                if (grgbwwaAction.getUpdateType() ==
                                                    device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                                                    grgbwwaTempAction.rgbState = {
                                                        red: grgbwwaAction.getRgbState().getRed(),
                                                        blue: grgbwwaAction.getRgbState().getBlue(),
                                                        green: grgbwwaAction.getRgbState().getGreen(),
                                                        pattern: grgbwwaAction.getRgbState().getPattern(),
                                                        deviceState: grgbwwaAction.getRgbState().getDeviceState()
                                                    };
                                                    dmGroupRgbwwaAction.setUpdateType(device_constants_pb_2.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE);
                                                    let dmRgb = new zigbee_rgbwwa_driver_pb_1.DMRGB();
                                                    dmRgb.setRed(grgbwwaAction.getRgbState().getRed());
                                                    dmRgb.setBlue(grgbwwaAction.getRgbState().getBlue());
                                                    dmRgb.setGreen(grgbwwaAction.getRgbState().getGreen());
                                                    dmRgb.setPattern(grgbwwaAction.getRgbState().getPattern());
                                                    dmRgb.setDeviceState(grgbwwaAction.getRgbState().getDeviceState());
                                                    dmGroupRgbwwaAction.setRgbState(dmRgb);
                                                }
                                                else if (grgbwwaAction.getUpdateType() ==
                                                    device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                                                    grgbwwaTempAction.wwaState = {
                                                        warmWhite: grgbwwaAction.getWwaState().getWarmWhite(),
                                                        coolWhite: grgbwwaAction.getWwaState().getCoolWhite(),
                                                        amber: grgbwwaAction.getWwaState().getAmber(),
                                                        deviceState: grgbwwaAction.getWwaState().getDeviceState()
                                                    };
                                                    dmGroupRgbwwaAction.setUpdateType(device_constants_pb_2.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE);
                                                    let dmWwa = new zigbee_rgbwwa_driver_pb_1.DMWWA();
                                                    dmWwa.setAmber(grgbwwaAction.getWwaState().getAmber());
                                                    dmWwa.setCoolWhite(grgbwwaAction.getWwaState().getCoolWhite());
                                                    dmWwa.setWarmWhite(grgbwwaAction.getWwaState().getWarmWhite());
                                                    dmWwa.setDeviceState(grgbwwaAction.getWwaState().getDeviceState());
                                                    dmGroupRgbwwaAction.setWwaState(dmWwa);
                                                }
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                console.log('This is RGBWWA group TO SCENE');
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.GROUPRGBWWADRIVER);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                dmSceneAction.setGrpZrgbwwaAction(dmGroupRgbwwaAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                                dmAddActionToSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                //Add current rgb action and call zigbee
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.GROUPRGBWWADRIVER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC,
                                                    syncRequestId: dmAddActionToSceneRsp.getRequestId(),
                                                    actionItem: grgbwwaTempAction
                                                };
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneSuccessful(actionId));
                                            }
                                        }
                                        break;
                                    //IR Blaster Action
                                    case scene_types_1.SceneActionTypes.ZIGBEEIRBLASTER:
                                        const irbAction = actionInfo.getZirBlasterAction();
                                        if (!irbAction) {
                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                        }
                                        else {
                                            const irDevice = await keus_device_1.default.getDeviceById(irbAction.getIrDevice());
                                            const irRemote = await keus_ir_remote_1.default.getIRRemoteById(irbAction.getRemoteId());
                                            console.log('THIS IS SCENE ROOM & DEVICE ROOM', scene.sceneRoom, irDevice.deviceRoom, checkAreaCompatibility(scene.sceneRoom, irDevice.deviceRoom));
                                            if (!irDevice) {
                                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                                            }
                                            else if (!irRemote) {
                                                throw new errors_1.DeviceErrors.InvalidRemoteId();
                                            }
                                            else if (!checkAreaCompatibility(scene.sceneRoom, irDevice.deviceRoom)) {
                                                throw new errors_1.DeviceErrors.DeviceNotInSameArea();
                                            }
                                            else {
                                                dmSceneAction.setActionType(scene_types_1.SceneActionTypes.ZIGBEEIRBLASTER);
                                                let dmIRBSceneAction = new zigbee_ir_blaster_pb_1.ZigbeeIRBlasterAction();
                                                dmIRBSceneAction.setIrDevice(irRemote.irDevice);
                                                dmIRBSceneAction.setCompanyId(irRemote.companyId);
                                                dmIRBSceneAction.setModelId(irRemote.modelId);
                                                dmIRBSceneAction.setRemoteType(irRemote.remoteType);
                                                filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                                let irBlastAction;
                                                switch (irRemote.remoteType) {
                                                    case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                                                        const zirACAction = new zigbee_ir_blaster_pb_1.IRACBlastAction();
                                                        const irACAction = irbAction.getAcActionInfo();
                                                        if (!irACAction) {
                                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                                        }
                                                        else {
                                                            const acRemoteProps = (irRemote.remoteProperties);
                                                            zirACAction.setPowerOn(irACAction.getPowerOn());
                                                            zirACAction.setSwingHLevel(irACAction.getSwingHLevel());
                                                            zirACAction.setSwingVLevel(irACAction.getSwingVLevel());
                                                            zirACAction.setTemperature(irACAction.getTemperature());
                                                            zirACAction.setMode(irACAction.getMode());
                                                            zirACAction.setFanLevel(irACAction.getFanLevel());
                                                            dmIRBSceneAction.setAcActionInfo(zirACAction);
                                                            const irACTempAction = {
                                                                powerOn: irACAction.getPowerOn(),
                                                                temperature: irACAction.getTemperature(),
                                                                swingHLevel: acRemoteProps.swingHEnabled
                                                                    ? irACAction.getSwingHLevel()
                                                                    : null,
                                                                swingVLevel: acRemoteProps.swingVEnabled
                                                                    ? irACAction.getSwingVLevel()
                                                                    : null,
                                                                mode: acRemoteProps.modeEnabled
                                                                    ? irACAction.getMode()
                                                                    : null,
                                                                fanLevel: acRemoteProps.fanEnabled
                                                                    ? irACAction.getFanLevel()
                                                                    : null
                                                            };
                                                            irBlastAction = irACTempAction;
                                                        }
                                                        break;
                                                    case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                                                        const zirTVAction = new zigbee_ir_blaster_pb_1.IRTVBlastAction();
                                                        const irTVAction = irbAction.getTvActionInfo();
                                                        if (!irTVAction) {
                                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                                        }
                                                        else {
                                                            const tvRemoteProps = (irRemote.remoteProperties);
                                                            zirTVAction.setUpdateType(irTVAction.getUpdateType());
                                                            zirTVAction.setPowerOn(irTVAction.getPowerOn());
                                                            zirTVAction.setMode(irTVAction.getMode());
                                                            zirTVAction.setSource(irTVAction.getSource());
                                                            zirTVAction.setChannelNumber(irTVAction.getChannelNumber());
                                                            dmIRBSceneAction.setTvActionInfo(zirTVAction);
                                                            const irTVTempAction = {
                                                                updateType: irTVAction.getUpdateType(),
                                                                powerOn: irTVAction.getPowerOn(),
                                                                mode: tvRemoteProps.modeEnabled
                                                                    ? irTVAction.getMode()
                                                                    : null,
                                                                source: tvRemoteProps.sourceEnabled
                                                                    ? irTVAction.getSource()
                                                                    : null
                                                            };
                                                            irBlastAction = irTVTempAction;
                                                        }
                                                        break;
                                                    case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                                                        const zirPRAction = new zigbee_ir_blaster_pb_1.IRPRBlastAction();
                                                        const irPRAction = irbAction.getPrActionInfo();
                                                        if (!irPRAction) {
                                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                                        }
                                                        else {
                                                            const prRemoteProps = (irRemote.remoteProperties);
                                                            zirPRAction.setUpdateType(irPRAction.getUpdateType());
                                                            zirPRAction.setPowerOn(irPRAction.getPowerOn());
                                                            zirPRAction.setMode(irPRAction.getMode());
                                                            zirPRAction.setSource(irPRAction.getSource());
                                                            dmIRBSceneAction.setPrActionInfo(zirPRAction);
                                                            const irPRTempAction = {
                                                                updateType: irPRAction.getUpdateType(),
                                                                powerOn: irPRAction.getPowerOn(),
                                                                mode: prRemoteProps.modeEnabled
                                                                    ? irPRAction.getMode()
                                                                    : null,
                                                                source: prRemoteProps.sourceEnabled
                                                                    ? irPRAction.getSource()
                                                                    : null
                                                            };
                                                            irBlastAction = irPRTempAction;
                                                        }
                                                        break;
                                                    case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                                                        const zirAMPAction = new zigbee_ir_blaster_pb_1.IRAMPBlastAction();
                                                        const irAMPAction = irbAction.getAmpActionInfo();
                                                        if (!irAMPAction) {
                                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                                        }
                                                        else {
                                                            const ampRemoteProps = (irRemote.remoteProperties);
                                                            zirAMPAction.setUpdateType(irAMPAction.getUpdateType());
                                                            zirAMPAction.setPowerOn(irAMPAction.getPowerOn());
                                                            zirAMPAction.setMode(irAMPAction.getMode());
                                                            zirAMPAction.setSource(irAMPAction.getSource());
                                                            dmIRBSceneAction.setAmpActionInfo(zirAMPAction);
                                                            const irAMPTempAction = {
                                                                updateType: irAMPAction.getUpdateType(),
                                                                powerOn: irAMPAction.getPowerOn(),
                                                                mode: ampRemoteProps.modeEnabled
                                                                    ? irAMPAction.getMode()
                                                                    : null,
                                                                source: ampRemoteProps.sourceEnabled
                                                                    ? irAMPAction.getSource()
                                                                    : null
                                                            };
                                                            irBlastAction = irAMPTempAction;
                                                        }
                                                        break;
                                                    case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                                                        const zirFANAction = new zigbee_ir_blaster_pb_1.IRFANBlastAction();
                                                        const irFANAction = irbAction.getFanActionInfo();
                                                        if (!irFANAction) {
                                                            throw new errors_1.GeneralErrors.InvalidParameterSet();
                                                        }
                                                        else {
                                                            const fanRemoteProps = (irRemote.remoteProperties);
                                                            zirFANAction.setPowerOn(irFANAction.getPowerOn());
                                                            zirFANAction.setSpeedLevel(irFANAction.getSpeedLevel());
                                                            zirFANAction.setMode(irFANAction.getMode());
                                                            zirFANAction.setLedState(irFANAction.getLedState());
                                                            dmIRBSceneAction.setFanActionInfo(zirFANAction);
                                                            const irFANTempAction = {
                                                                powerOn: irFANAction.getPowerOn(),
                                                                speedLevel: irFANAction.getSpeedLevel(),
                                                                mode: fanRemoteProps.modeEnabled
                                                                    ? irFANAction.getMode()
                                                                    : null,
                                                                ledState: fanRemoteProps.ledEnabled
                                                                    ? irFANAction.getLedState()
                                                                    : 0
                                                            };
                                                            irBlastAction = irFANTempAction;
                                                        }
                                                        break;
                                                    default:
                                                        throw new errors_1.DeviceErrors.InvalidRemoteType();
                                                }
                                                let currentAction = scene.actionList.find(action => action.actionId == actionId);
                                                //Add current IR action and call zigbee
                                                const zirbTempAction = {
                                                    remoteId: irRemote.remoteId,
                                                    remoteType: irRemote.remoteType,
                                                    irDevice: irRemote.irDevice,
                                                    irBlastAction: irBlastAction
                                                };
                                                newAction = {
                                                    actionId: actionId,
                                                    zigbeeActionId: currentAction
                                                        ? currentAction.zigbeeActionId
                                                        : zigbeeActionId,
                                                    actionType: scene_types_1.SceneActionTypes.ZIGBEEIRBLASTER,
                                                    timeslotId: actionInfo.getTimeslotId(),
                                                    syncStatus: scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONINSYNC,
                                                    syncRequestId: '-',
                                                    actionItem: zirbTempAction
                                                };
                                                console.log('This is IR blaster action info', currentAction, zigbeeActionId);
                                                if (currentAction) {
                                                    dmSceneAction.setZigbeeActionId(currentAction.zigbeeActionId);
                                                }
                                                dmSceneAction.setZirBlasterAction(dmIRBSceneAction);
                                                dmAddActionToSceneReq.setActionItem(dmSceneAction);
                                                let dmAddActionToSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmAddActionToSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMAddActionToScene'));
                                                console.log('This is rsp', dmAddActionToSceneRsp);
                                                if (!dmAddActionToSceneRsp.getSuccess()) {
                                                    throw new Error(dmAddActionToSceneRsp.getMessage());
                                                }
                                                filteredActionList.push(newAction);
                                                await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                                resolve(response_1.default.getAddActionToSceneSuccessful(actionId));
                                                break;
                                            }
                                        }
                                    default:
                                        console.log('HITTING DEFAULT CASE', actionInfo.getActionType());
                                        resolve(response_1.default.getInvalidDeviceType());
                                }
                            }
                        }
                    }
                }
            }
            catch (e) {
                console.log('Add action to scene', e);
                switch (e.constructor) {
                    case errors_1.HomeErrors.InvalidRoomId:
                        resolve(response_1.default.getInvalidRoomId());
                        break;
                    case errors_1.SceneErrors.InvalidSceneId:
                        resolve(response_1.default.getInvalidSceneId());
                        break;
                    case errors_1.GeneralErrors.InvalidParameterSet:
                        resolve(response_1.default.getInvalidActionType());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId());
                        break;
                    case errors_1.DeviceErrors.InvalidDeviceType:
                        resolve(response_1.default.getInvalidDeviceType());
                        break;
                    case errors_1.DeviceErrors.DeviceNotInSameArea:
                        resolve(response_1.default.getDeviceNotInSameArea());
                        break;
                    case errors_1.SceneErrors.InvalidTimeslotId:
                        resolve(response_1.default.getInvalidTimeslotId());
                        break;
                    case errors_1.DeviceErrors.InvalidSwitchId:
                        resolve(response_1.default.getInvalidSwitchId());
                        break;
                    case errors_1.GroupErrors.DeviceInAnotherGroup:
                        resolve(response_1.default.getDeviceInAnotherGroup());
                        break;
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.SceneErrors.SceneActionLimitReached:
                        resolve(response_1.default.getSceneActionLimitReached());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map