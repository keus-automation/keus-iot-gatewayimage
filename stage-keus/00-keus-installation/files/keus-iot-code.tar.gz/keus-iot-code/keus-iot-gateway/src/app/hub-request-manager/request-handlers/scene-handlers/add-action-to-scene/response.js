"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const scene_structures_pb_1 = require("../../../protos/generated/hub/scenes/scene_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class AddActionToSceneResp {
    static getAddActionToSceneSuccessful(actionId) {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(800);
        resp.setMessage('Add Action Successful');
        resp.setSuccess(true);
        resp.setActionId(actionId);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getAddActionToSceneQueued(actionId) {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(900);
        resp.setMessage('Add Action Queued');
        resp.setSuccess(true);
        resp.setActionId(actionId);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInvalidSceneId() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Scene Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInvalidTimeslotId() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Timeslot Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInvalidActionType() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(803);
        resp.setMessage('Invalid Action Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInvalidDeviceId() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Device Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInvalidDeviceType() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(805);
        resp.setMessage('Invalid Device Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getDeviceNotInSameArea() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(806);
        resp.setMessage('Device Not In Same Area');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInvalidSwitchId() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Switch Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getDeviceInAnotherGroup() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(811);
        resp.setMessage('Device In Another Group');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInvalidRoomId() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Room Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInvalidSectionId() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(805);
        resp.setMessage('Invalid Section Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getSceneLimitReached() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(806);
        resp.setMessage('Scene Limit Reached');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getSceneActionLimitReached() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(806);
        resp.setMessage('Scene Action Limit Reached');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getDuplicateSceneName() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(807);
        resp.setMessage('Duplicate Scene Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInternalServerError() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new scene_structures_pb_1.AddActionToSceneResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AddActionToSceneResp.responseType);
    }
}
exports.default = AddActionToSceneResp;
AddActionToSceneResp.responseType = system_constants_1.ProtoPackageName + '.AddActionToSceneResponse';
//# sourceMappingURL=response.js.map