"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const SceneUtils = __importStar(require("../../../../../utilities/gateway/scene-utils"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const proto_utils_1 = require("../../../../../utilities/gateway/proto-utils");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (addTimeslotToSceneReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const scene = await keus_scene_1.default.getSceneById(addTimeslotToSceneReq.getSceneId(), addTimeslotToSceneReq.getSceneRoom());
                if (!scene) {
                    throw new errors_1.SceneErrors.InvalidSceneId();
                }
                else if (scene.sceneExecutionType != scene_constants_pb_1.SCENE_EXECTYPE.ADVANCED) {
                    throw new errors_1.SceneErrors.InvalidSceneType();
                }
                else {
                    const generatedTimeslotId = SceneUtils.generateTimeslotIdForScene();
                    const filteredTimeslots = scene.timeslotList.filter(function (timeslot) {
                        return timeslot.timeslotId == generatedTimeslotId;
                    });
                    if (filteredTimeslots.length) {
                        throw new errors_1.SceneErrors.TimeslotIdGenerationFailed();
                    }
                    else {
                        const timeslot = {
                            timeslotId: generatedTimeslotId,
                            timeslotDelay: addTimeslotToSceneReq.getTimeslotDelay()
                        };
                        scene.timeslotList.push(timeslot);
                        await keus_scene_1.default.updateSceneTimeslotList(scene.sceneId, scene.sceneRoom, scene.timeslotList);
                        resolve(response_1.default.getAddTimeslotToSceneSuccessful(proto_utils_1.SceneProtoUtils.getTimeslotProto(timeslot)));
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.SceneErrors.InvalidSceneId:
                        resolve(response_1.default.getInvalidSceneId());
                        break;
                    case errors_1.SceneErrors.InvalidSceneType:
                        resolve(response_1.default.getInvalidSceneType());
                        break;
                    case errors_1.SceneErrors.TimeslotIdGenerationFailed:
                        resolve(response_1.default.getIdGenerationError());
                        break;
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map