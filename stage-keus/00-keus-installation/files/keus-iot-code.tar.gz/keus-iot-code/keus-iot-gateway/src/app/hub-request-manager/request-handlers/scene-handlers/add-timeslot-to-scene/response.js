"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const scene_structures_pb_1 = require("../../../protos/generated/hub/scenes/scene_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class CreateSceneResp {
    static getAddTimeslotToSceneSuccessful(timeslot) {
        const resp = new scene_structures_pb_1.AddTimeslotToSceneResponse();
        resp.setCode(800);
        resp.setMessage('Add timeslot to scene successful');
        resp.setSuccess(true);
        resp.setTimeslot(timeslot);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidSceneId() {
        const resp = new scene_structures_pb_1.AddTimeslotToSceneResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Scene Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidSceneType() {
        const resp = new scene_structures_pb_1.AddTimeslotToSceneResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Scene Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getIdGenerationError() {
        const resp = new scene_structures_pb_1.AddTimeslotToSceneResponse();
        resp.setCode(803);
        resp.setMessage('Id Generation Error, Try Again');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInternalServerError() {
        const resp = new scene_structures_pb_1.AddTimeslotToSceneResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new scene_structures_pb_1.AddTimeslotToSceneResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new scene_structures_pb_1.AddTimeslotToSceneResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
}
exports.default = CreateSceneResp;
CreateSceneResp.responseType = system_constants_1.ProtoPackageName + '.AddTimeslotToSceneResponse';
//# sourceMappingURL=response.js.map