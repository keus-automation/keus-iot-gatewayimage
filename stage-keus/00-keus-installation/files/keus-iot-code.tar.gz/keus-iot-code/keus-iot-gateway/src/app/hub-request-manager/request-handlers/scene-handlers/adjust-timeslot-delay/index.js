"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const scene_constants_1 = require("../../../../../constants/scene/scene-constants");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (adjustTimeslotDelayReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                const scene = await keus_scene_1.default.getSceneById(adjustTimeslotDelayReq.getSceneId(), adjustTimeslotDelayReq.getSceneRoom());
                if (!scene) {
                    throw new errors_1.SceneErrors.InvalidSceneId();
                }
                else if (scene.sceneExecutionType != scene_constants_pb_1.SCENE_EXECTYPE.ADVANCED) {
                    throw new errors_1.SceneErrors.InvalidSceneType();
                }
                else if (adjustTimeslotDelayReq.getTimeslotId() == scene_constants_1.DefaultTimeslotId) {
                    throw new errors_1.SceneErrors.InvalidTimeslotId();
                }
                else {
                    //Zigbee call to devices to adjust timeslot
                    const timeslot = scene.timeslotList.find(tslot => tslot.timeslotId == adjustTimeslotDelayReq.getTimeslotId());
                    if (!timeslot) {
                        throw new errors_1.SceneErrors.InvalidTimeslotId();
                    }
                    else {
                        // Call zigbee function to adjust time for the timeslot
                        const reqId = 'ABCDE';
                        scene.sceneSyncInfo.syncRequestId = reqId;
                        scene.sceneSyncInfo.syncRequestTime = Date.now();
                        scene.sceneSyncInfo.syncRequestType = scene_constants_pb_1.SCENE_JOB_TYPES.SCENE_ADJTSDELAY;
                        scene.sceneSyncInfo.syncRequestParams = {
                            timeslotId: adjustTimeslotDelayReq.getTimeslotId(),
                            timeslotDelay: adjustTimeslotDelayReq.getTimeslotDelay()
                        };
                        scene.sceneSyncInfo.syncStatus = scene_constants_pb_1.SCENE_SYNC_STATES.SCENESYNCPENDING;
                        await keus_scene_1.default.updateSceneSyncState(scene.sceneId, scene.sceneRoom, scene.sceneSyncInfo);
                        resolve(response_1.default.getAdjustTimeslotDelayQueued());
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.SceneErrors.InvalidSceneId:
                        resolve(response_1.default.getInvalidSceneId());
                        break;
                    case errors_1.SceneErrors.InvalidSceneType:
                        resolve(response_1.default.getInvalidSceneType());
                        break;
                    case errors_1.SceneErrors.InvalidTimeslotId:
                        resolve(response_1.default.getInvalidTimeslotId());
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map