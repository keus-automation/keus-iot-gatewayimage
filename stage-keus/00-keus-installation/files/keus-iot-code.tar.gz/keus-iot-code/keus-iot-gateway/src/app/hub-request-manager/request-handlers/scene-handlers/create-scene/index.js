"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const HomeUtils = __importStar(require("../../../../../utilities/gateway/home-utils"));
const ProtoUtils = __importStar(require("../../../../../utilities/gateway/proto-utils"));
const scene_constants_1 = require("../../../../../constants/scene/scene-constants");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const scene_structures_pb_1 = require("../../../../device-manager/providers/generated/scenes/scene_structures_pb");
const local_client_1 = require("../../../local-client");
const general_1 = require("../../../../../utilities/general");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (createSceneReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!createSceneReq.getSceneName()) {
                    throw new errors_1.SceneErrors.InvalidSceneName();
                }
                else {
                    const room = await keus_home_1.default.getRoomById(createSceneReq.getSceneRoom());
                    if (!room) {
                        throw new errors_1.HomeErrors.InvalidRoomId();
                    }
                    else {
                        const filteredSectionList = room.sectionList.filter(function (section) {
                            return section.sectionId == createSceneReq.getSceneSection();
                        });
                        if (!filteredSectionList.length) {
                            throw new errors_1.HomeErrors.InvalidSectionId();
                        }
                        else {
                            const roomIds = HomeUtils.getRoomIdsFromRoomList(await keus_home_1.default.getRoomsByArea(room.areaId));
                            const areaScenes = await keus_scene_1.default.getScenesByRooms(roomIds);
                            const dupScenes = areaScenes.filter(function (scene) {
                                return (scene.sceneRoom == room.roomId &&
                                    scene.sceneSection == createSceneReq.getSceneSection() &&
                                    scene.sceneName == createSceneReq.getSceneName());
                            });
                            if (dupScenes.length) {
                                throw new errors_1.SceneErrors.DuplicateSceneName();
                            }
                            else {
                                //Call zigbee here for scene Id
                                const dmCreateSceneReq = new scene_structures_pb_1.DMCreateScene();
                                dmCreateSceneReq.setSceneArea(room.areaId);
                                const dmCreateSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmCreateSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMCreateScene'));
                                if (!dmCreateSceneRsp.getSuccess()) {
                                    throw new Error(dmCreateSceneRsp.getMessage());
                                }
                                const sceneId = dmCreateSceneRsp.getSceneId();
                                // const sceneId = SceneUtils.generateSceneIdForArea(areaScenes);
                                if (sceneId == -1) {
                                    throw new errors_1.SceneErrors.SceneLimitReached();
                                }
                                else {
                                    const timeslot = {
                                        timeslotId: scene_constants_1.DefaultTimeslotId,
                                        timeslotDelay: scene_constants_1.DefaultTimeslotDelay
                                    };
                                    const newScene = {
                                        sceneId: sceneId,
                                        sceneName: createSceneReq.getSceneName(),
                                        timeslotList: [timeslot],
                                        actionList: [],
                                        sceneExecutionType: createSceneReq.getSceneExecutionType(),
                                        sceneRoom: createSceneReq.getSceneRoom(),
                                        sceneSection: createSceneReq.getSceneSection(),
                                        sceneScope: createSceneReq.getSceneScope(),
                                        sceneType: createSceneReq.getSceneType(),
                                        lastUpdateBy: system_constants_1.SystemNumber,
                                        lastUpdateSource: system_constants_1.UpdateSourceMapping.SYSTEM,
                                        lastUpdateUser: system_constants_1.SystemUser,
                                        lastUpdateTime: Date.now(),
                                        sceneSyncInfo: {
                                            syncRequestId: '-',
                                            syncStatus: scene_constants_pb_1.SCENE_SYNC_STATES.SCENEINSYNC,
                                            syncRequestTime: Date.now(),
                                            syncRequestType: scene_constants_pb_1.SCENE_JOB_TYPES.SCENE_NONE,
                                            syncRequestParams: {}
                                        }
                                    };
                                    keus_scene_1.default.insertScene(newScene);
                                    resolve(response_1.default.getCreateSceneSuccessful(ProtoUtils.SceneProtoUtils.getSceneProto(newScene)));
                                }
                            }
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.SceneErrors.InvalidSceneName:
                        resolve(response_1.default.getInvalidSceneName());
                        break;
                    case errors_1.HomeErrors.InvalidRoomId:
                        resolve(response_1.default.getInvalidRoomId());
                        break;
                    case errors_1.HomeErrors.InvalidSectionId:
                        resolve(response_1.default.getInvalidSectionId());
                        break;
                    case errors_1.SceneErrors.DuplicateSceneName:
                        resolve(response_1.default.getDuplicateSceneName());
                        break;
                    case errors_1.SceneErrors.SceneLimitReached:
                        resolve(response_1.default.getSceneLimitReached());
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map