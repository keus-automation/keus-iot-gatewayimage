"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const scene_structures_pb_1 = require("../../../protos/generated/hub/scenes/scene_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class CreateSceneResp {
    static getCreateSceneSuccessful(scene) {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(800);
        resp.setMessage('Add Scene Successful');
        resp.setSuccess(true);
        resp.setScene(scene);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidSceneName() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Scene Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidSceneType() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Scene Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidSceneExecutionType() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(803);
        resp.setMessage('Invalid Scene Execution Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidRoomId() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Room Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidSectionId() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(805);
        resp.setMessage('Invalid Section Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getSceneLimitReached() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(806);
        resp.setMessage('Scene Limit Reached');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getDuplicateSceneName() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(807);
        resp.setMessage('Duplicate Scene Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInternalServerError() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new scene_structures_pb_1.CreateSceneResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
}
exports.default = CreateSceneResp;
CreateSceneResp.responseType = system_constants_1.ProtoPackageName + '.CreateSceneResponse';
//# sourceMappingURL=response.js.map