"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (editSceneNameReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!editSceneNameReq.getSceneName()) {
                    throw new errors_1.SceneErrors.InvalidSceneName();
                }
                else {
                    const scene = await keus_scene_1.default.getSceneById(editSceneNameReq.getSceneId(), editSceneNameReq.getSceneRoom());
                    if (!scene) {
                        throw new errors_1.SceneErrors.InvalidSceneId();
                    }
                    else if (scene.sceneType != scene_constants_pb_1.SCENE_TYPE.CUSTOM) {
                        throw new errors_1.SceneErrors.InvalidSceneType();
                    }
                    else {
                        const roomScenes = await keus_scene_1.default.getScenesByRooms([scene.sceneRoom]);
                        const dupScenes = roomScenes.filter(function (sceneItem) {
                            return (sceneItem.sceneRoom == scene.sceneRoom &&
                                sceneItem.sceneSection == scene.sceneSection &&
                                sceneItem.sceneName == scene.sceneName);
                        });
                        if (dupScenes.length) {
                            throw new errors_1.SceneErrors.DuplicateSceneName();
                        }
                        else {
                            await keus_scene_1.default.updateSceneName(scene.sceneId, scene.sceneRoom, editSceneNameReq.getSceneName());
                            resolve(response_1.default.getEditSceneNameSuccessful());
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.SceneErrors.InvalidSceneName:
                        resolve(response_1.default.getInvalidSceneName());
                        break;
                    case errors_1.SceneErrors.DuplicateSceneName:
                        resolve(response_1.default.getDuplicateSceneName());
                        break;
                    case errors_1.SceneErrors.InvalidSceneId:
                        resolve(response_1.default.getInvalidSceneId());
                        break;
                    case errors_1.SceneErrors.InvalidSceneType:
                        resolve(response_1.default.getInvalidSceneType());
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map