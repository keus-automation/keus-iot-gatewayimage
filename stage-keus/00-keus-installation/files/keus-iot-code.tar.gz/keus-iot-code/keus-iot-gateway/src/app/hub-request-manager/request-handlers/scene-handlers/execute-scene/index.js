"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const scene_structures_pb_1 = require("../../../protos/generated/hub/scenes/scene_structures_pb");
const response_1 = __importDefault(require("./response"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const system_constants_2 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const keus_activity_1 = __importDefault(require("../../../../../models/database-models/keus-activity"));
const activity_utils_1 = require("../../../../../utilities/gateway/activity-utils");
const general_1 = require("../../../../../utilities/general");
const local_client_1 = require("../../../local-client");
const cloud_client_1 = require("../../../cloud-client");
const scene_structures_pb_2 = require("../../../../device-manager/providers/generated/scenes/scene_structures_pb");
const reqType = system_constants_1.ProtoPackageName + '.ExecuteScene';
const eventType = system_constants_1.ProtoPackageName + '.SceneExecutionEvent';
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (executeSceneReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                if (!executeSceneReq.getSceneRoom()) {
                    throw new errors_1.HomeErrors.InvalidRoomId();
                }
                else {
                    const execTime = Date.now();
                    const scene = await keus_scene_1.default.getSceneById(executeSceneReq.getSceneId(), executeSceneReq.getSceneRoom());
                    console.log('EXECUTING SCENE', executeSceneReq.getSceneId(), executeSceneReq.getSceneRoom());
                    let user = await keus_user_1.default.getUserByPhone(phone);
                    await home_utils_1.checkAccessForUser(user, scene.sceneRoom);
                    const room = await keus_home_1.default.getRoomById(executeSceneReq.getSceneRoom());
                    if (!scene) {
                        throw new errors_1.SceneErrors.InvalidSceneId();
                    }
                    else if (!room) {
                        throw new errors_1.HomeErrors.InvalidRoomId();
                    }
                    else {
                        //Make zigbee call to execute the scene. Add area information
                        let dmExecuteSceneReq = new scene_structures_pb_2.DMExecuteScene();
                        dmExecuteSceneReq.setSceneArea(room.areaId);
                        dmExecuteSceneReq.setSceneId(scene.sceneId);
                        let dmExecuteSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmExecuteSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMExecuteScene'));
                        if (!dmExecuteSceneRsp.getSuccess()) {
                            console.log("error in zigbee layer");
                            throw new Error(dmExecuteSceneRsp.getMessage());
                        }
                        await keus_scene_1.default.updateSceneExecution(scene.sceneId, scene.sceneRoom, execTime, phone, user.userName, system_constants_2.UpdateSourceMapping.ANDROID);
                        let roomDetails = await keus_home_1.default.getRoomById(scene.sceneRoom);
                        let activityObj = await activity_utils_1.getSceneActivityObj(user, scene, roomDetails, {
                            activitySource: system_constants_2.UpdateSourceMapping.ANDROID
                        });
                        await keus_activity_1.default.insertActivity(activityObj);
                        //-----------------------Update Group State State Event--------------------------------
                        const execSceneEvent = new scene_structures_pb_1.SceneExecutionEvent();
                        execSceneEvent.setSceneId(scene.sceneId);
                        execSceneEvent.setSceneRoom(scene.sceneRoom);
                        //execSceneEvent.setActivityTime(execTime);
                        execSceneEvent.setActivitySource(system_constants_2.UpdateSourceMapping.ANDROID);
                        execSceneEvent.setActivityUser(phone);
                        const eventArg = general_1.PackIntoAny(execSceneEvent.serializeBinary(), eventType);
                        console.log('---------------------------------final call is completed 1111');
                        local_client_1.GatewayProvidersManager.publishEvent(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), eventArg);
                        cloud_client_1.CloudProvidersManager.publishEvent(cloud_client_1.CloudProvidersManager.getMainGatewayServiceName(), eventArg);
                        console.log('---------------------------------final call is completed');
                        resolve(response_1.default.getExecuteSceneSuccessful());
                    }
                }
            }
            catch (e) {
                console.log("------------------- this is execute scene error", e);
                switch (e.constructor) {
                    case errors_1.HomeErrors.InvalidRoomId:
                        resolve(response_1.default.getInvalidSceneRoom());
                        break;
                    case errors_1.SceneErrors.InvalidSceneId:
                        resolve(response_1.default.getInvalidSceneId());
                        break;
                    case errors_1.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map