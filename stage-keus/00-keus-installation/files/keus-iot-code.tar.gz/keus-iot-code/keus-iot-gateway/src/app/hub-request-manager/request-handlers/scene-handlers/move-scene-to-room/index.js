"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (moveSceneToRoomReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!moveSceneToRoomReq.getNewSceneRoom() || !moveSceneToRoomReq.getNewSceneSection()) {
                    throw new errors_1.HomeErrors.InvalidRoomId();
                }
                else {
                    const scene = await keus_scene_1.default.getSceneById(moveSceneToRoomReq.getSceneId(), moveSceneToRoomReq.getSceneRoom());
                    if (!scene) {
                        throw new errors_1.SceneErrors.InvalidSceneId();
                    }
                    else if (scene.sceneScope == scene_constants_pb_1.SCENE_SCOPE.GLOBAL) {
                        throw new errors_1.SceneErrors.CannotMoveGlobalScene();
                    }
                    else {
                        const roomList = await keus_home_1.default.getAllRooms();
                        const curRoom = roomList.find(room => room.roomId == scene.sceneRoom);
                        const newRoom = roomList.find(room => room.roomId == moveSceneToRoomReq.getNewSceneRoom());
                        if (!newRoom || !curRoom) {
                            throw new errors_1.HomeErrors.InvalidRoomId();
                        }
                        else if (curRoom.areaId != newRoom.areaId) {
                            throw new errors_1.SceneErrors.CannotMoveToDifferentArea();
                        }
                        else {
                            const filteredSectionList = newRoom.sectionList.filter(function (section) {
                                return section.sectionId == moveSceneToRoomReq.getNewSceneSection();
                            });
                            if (!filteredSectionList.length) {
                                throw new errors_1.HomeErrors.InvalidSectionId();
                            }
                            else {
                                const roomScenes = await keus_scene_1.default.getScenesByRooms([newRoom.roomId]);
                                const dupScenes = roomScenes.filter(function (sceneItem) {
                                    return (sceneItem.sceneRoom == newRoom.roomId &&
                                        sceneItem.sceneSection == moveSceneToRoomReq.getNewSceneSection() &&
                                        sceneItem.sceneName == scene.sceneName);
                                });
                                if (dupScenes.length) {
                                    throw new errors_1.SceneErrors.DuplicateSceneName();
                                }
                                else {
                                    const newScene = {
                                        sceneId: scene.sceneId,
                                        sceneRoom: moveSceneToRoomReq.getNewSceneRoom(),
                                        sceneSection: moveSceneToRoomReq.getNewSceneSection(),
                                        sceneName: scene.sceneName,
                                        sceneExecutionType: scene.sceneExecutionType,
                                        sceneScope: scene.sceneScope,
                                        sceneSyncInfo: scene.sceneSyncInfo,
                                        actionList: scene.actionList,
                                        sceneType: scene.sceneType,
                                        timeslotList: scene.timeslotList,
                                        lastUpdateBy: scene.lastUpdateBy,
                                        lastUpdateSource: scene.lastUpdateSource,
                                        lastUpdateTime: scene.lastUpdateTime,
                                        lastUpdateUser: scene.lastUpdateUser
                                    };
                                    await keus_scene_1.default.deleteSceneById(scene.sceneId, scene.sceneRoom);
                                    await keus_scene_1.default.insertScene(newScene);
                                    resolve(response_1.default.getMoveSceneToRoomSuccessful());
                                }
                            }
                        }
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.HomeErrors.InvalidRoomId:
                        resolve(response_1.default.getInvalidSceneRoom());
                        break;
                    case errors_1.HomeErrors.InvalidSectionId:
                        resolve(response_1.default.getInvalidSceneSection());
                        break;
                    case errors_1.SceneErrors.InvalidSceneId:
                        resolve(response_1.default.getInvalidSceneId());
                        break;
                    case errors_1.SceneErrors.CannotMoveGlobalScene:
                        resolve(response_1.default.getCannotMoveGlobalScene());
                        break;
                    case errors_1.SceneErrors.CannotMoveToDifferentArea:
                        resolve(response_1.default.getCannotMoveToDifferentArea());
                        break;
                    case errors_1.SceneErrors.DuplicateSceneName:
                        resolve(response_1.default.getDuplicateSceneName());
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map