"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const scene_types_1 = require("../../../../../constants/scene/scene-types");
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const errors_1 = require("../../../../../errors/errors");
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const scene_structures_pb_1 = require("../../../../device-manager/providers/generated/scenes/scene_structures_pb");
const local_client_1 = require("../../../local-client");
const general_1 = require("../../../../../utilities/general");
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (removeActionFromSceneReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (!removeActionFromSceneReq.getSceneRoom()) {
                    throw new errors_1.HomeErrors.InvalidRoomId();
                }
                else {
                    const room = await keus_home_1.default.getRoomById(removeActionFromSceneReq.getSceneRoom());
                    if (!room) {
                        throw new errors_1.HomeErrors.InvalidRoomId();
                    }
                    else {
                        const sceneId = removeActionFromSceneReq.getSceneId();
                        const scene = await keus_scene_1.default.getSceneById(sceneId, room.roomId);
                        var filteredActionList;
                        if (!scene) {
                            throw new errors_1.SceneErrors.InvalidSceneId();
                        }
                        else {
                            const actionId = removeActionFromSceneReq.getActionId();
                            console.log("\n-------------\nthis is action info", removeActionFromSceneReq.toObject());
                            const actionInfo = scene.actionList.find(action => action.actionId == actionId);
                            console.log(actionInfo);
                            if (!actionInfo) {
                                throw new errors_1.SceneErrors.InvalidActionId();
                            }
                            else {
                                let dmRemoveActionFromSceneReq = new scene_structures_pb_1.DMRemoveActionFromScene();
                                dmRemoveActionFromSceneReq.setSceneArea(room.areaId);
                                dmRemoveActionFromSceneReq.setSceneId(sceneId);
                                dmRemoveActionFromSceneReq.setZigbeeActionId(actionInfo.zigbeeActionId);
                                dmRemoveActionFromSceneReq.setForceDelete(removeActionFromSceneReq.getForceDelete());
                                switch (actionInfo.actionType) {
                                    //Area Scene Action
                                    case scene_types_1.SceneActionTypes.AREASCENEACTION:
                                        const ascnAction = actionInfo.actionItem;
                                        const areaSceneRoom = await keus_home_1.default.getRoomById(ascnAction.roomId);
                                        if (!areaSceneRoom) {
                                            throw new errors_1.SceneErrors.InvalidSceneId();
                                        }
                                        else {
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            //Make zigbee call to remove the action from device
                                            const dmRemoveAreaSceneFromGlobal = new scene_structures_pb_1.DMRemoveSceneFromGlobalScene();
                                            dmRemoveAreaSceneFromGlobal.setGSceneId(scene.sceneId);
                                            dmRemoveAreaSceneFromGlobal.setAreaId(areaSceneRoom.areaId);
                                            dmRemoveAreaSceneFromGlobal.setSceneId(ascnAction.sceneId);
                                            let dmRemoveAreaSceneFromGlobalRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveAreaSceneFromGlobal.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveSceneFromGlobalScene'));
                                            if (!dmRemoveAreaSceneFromGlobalRsp.getSuccess()) {
                                                throw new Error(dmRemoveAreaSceneFromGlobalRsp.getMessage());
                                            }
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                            break;
                                        }
                                    //Smart console relay action
                                    case scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE:
                                        const scAction = actionInfo.actionItem;
                                        const scDevice = await keus_device_1.default.getDeviceById(scAction.deviceId);
                                        if (!scDevice) {
                                            console.log('HITTING REMOVE ENTIRE DEVICE');
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE) {
                                                    const scSceneAction = action.actionItem;
                                                    return scSceneAction.deviceId != scAction.deviceId;
                                                }
                                                return true;
                                            });
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            const scDeviceProperties = (scDevice.deviceProperties);
                                            filteredActionList = [];
                                            scene.actionList.forEach(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE &&
                                                    action.timeslotId == actionInfo.timeslotId) {
                                                    var scTempAction = action.actionItem;
                                                    if (!(scTempAction.deviceId == scAction.deviceId &&
                                                        scTempAction.relayId == scAction.relayId)) {
                                                        filteredActionList.push(action);
                                                    }
                                                }
                                                else {
                                                    filteredActionList.push(action);
                                                }
                                            });
                                            //Call Remove Zigbee Action
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE);
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        break;
                                    //Zigbee Embedded switch
                                    case scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH:
                                        const esAction = actionInfo.actionItem;
                                        const esDevice = await keus_device_1.default.getDeviceById(esAction.deviceId);
                                        if (!esDevice) {
                                            console.log('HITTING REMOVE ENTIRE DEVICE');
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH) {
                                                    const esSceneAction = action.actionItem;
                                                    return esSceneAction.deviceId != esAction.deviceId;
                                                }
                                                return true;
                                            });
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            const esDeviceProperties = (esDevice.deviceProperties);
                                            filteredActionList = [];
                                            var esCurrentActionList = [];
                                            scene.actionList.forEach(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH &&
                                                    action.timeslotId == actionInfo.timeslotId) {
                                                    var esTempAction = action.actionItem;
                                                    if (esTempAction.deviceId == esAction.deviceId) {
                                                        if (esTempAction.applianceId != esAction.applianceId) {
                                                            //Generate the scene action item for other switches
                                                            filteredActionList.push(action);
                                                            esCurrentActionList.push(action);
                                                        }
                                                    }
                                                    else {
                                                        filteredActionList.push(action);
                                                    }
                                                }
                                                else {
                                                    filteredActionList.push(action);
                                                }
                                            });
                                            /*
                                                scene delete is being handled in zigbee layer
                                                When last action zigbee will delete scene as well
                                            */
                                            //Call Remove Zigbee Action
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH);
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        break;
                                    //Zigbee Curtain Controller
                                    case scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER:
                                        const zccAction = actionInfo.actionItem;
                                        const zccDevice = await keus_device_1.default.getDeviceById(zccAction.deviceId);
                                        if (!zccDevice) {
                                            console.log('HITTING REMOVE ENTIRE DEVICE');
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER) {
                                                    const zccSceneAction = (action.actionItem);
                                                    return zccAction.deviceId != zccSceneAction.deviceId;
                                                }
                                                return true;
                                            });
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            //Make zigbee call to remove the action from device
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER);
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        break;
                                    //AC Fan controller
                                    case scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER:
                                        const zacfcAction = actionInfo.actionItem;
                                        const zacfcDevice = await keus_device_1.default.getDeviceById(zacfcAction.deviceId);
                                        if (!zacfcDevice) {
                                            console.log('HITTING REMOVE ENTIRE DEVICE');
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER) {
                                                    const zacfcSceneAction = (action.actionItem);
                                                    return zacfcAction.deviceId != zacfcSceneAction.deviceId;
                                                }
                                                return true;
                                            });
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            //Make zigbee call to remove the action from device
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER);
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        break;
                                    //DC Fan Controller
                                    case scene_types_1.SceneActionTypes.ZIGBEEDCFANCONTROLLER:
                                        const zdcfcAction = actionInfo.actionItem;
                                        const zdcfcDevice = await keus_device_1.default.getDeviceById(zdcfcAction.deviceId);
                                        if (!zdcfcDevice) {
                                            console.log('HITTING REMOVE ENTIRE DEVICE');
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEEDCFANCONTROLLER) {
                                                    const zdcfcSceneAction = (action.actionItem);
                                                    return zdcfcAction.deviceId != zdcfcSceneAction.deviceId;
                                                }
                                                return true;
                                            });
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            //Make zigbee call to remove the action from device
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.ZIGBEEDCFANCONTROLLER);
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        break;
                                    //Zigbee RGBWWA Driver
                                    case scene_types_1.SceneActionTypes.ZIGBEERGBWWADRIVER:
                                        const zrgbwwaAction = actionInfo.actionItem;
                                        const zrgbwwaDevice = await keus_device_1.default.getDeviceById(zrgbwwaAction.deviceId);
                                        if (!zrgbwwaDevice) {
                                            console.log('HITTING REMOVE ENTIRE DEVICE');
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEERGBWWADRIVER) {
                                                    const zrgbwwaSceneAction = (action.actionItem);
                                                    return zrgbwwaAction.deviceId != zrgbwwaSceneAction.deviceId;
                                                }
                                                return true;
                                            });
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            //Make zigbee call to remove the action from device
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        break;
                                    //Zigbee Dimmable Driver group
                                    case scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER:
                                        const zddAction = actionInfo.actionItem;
                                        const zddGroup = await keus_group_1.default.getGroupById(zddAction.groupId, zddAction.roomId);
                                        if (!zddGroup) {
                                            //Remove all group actions from the scene
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER) {
                                                    const zddSceneAction = action.actionItem;
                                                    return !(zddSceneAction.roomId == zddAction.roomId &&
                                                        zddSceneAction.groupId == zddAction.groupId);
                                                }
                                                return true;
                                            });
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            //Make zigbee call and get request id
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER);
                                            const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                            dmRemoveActionFromSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            const reqId = dmRemoveActionFromSceneRsp.getRequestId();
                                            actionInfo.syncStatus = scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING;
                                            actionInfo.syncRequestId = reqId;
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneQueued());
                                        }
                                        break;
                                    //Dali Dimmable Driver group
                                    case scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER:
                                        const dddAction = actionInfo.actionItem;
                                        const dddGroup = await keus_group_1.default.getGroupById(dddAction.groupId, dddAction.roomId);
                                        if (!dddGroup) {
                                            //Remove all group actions from the scene
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER) {
                                                    const dddSceneAction = action.actionItem;
                                                    return !(dddSceneAction.roomId == dddAction.roomId &&
                                                        dddSceneAction.groupId == dddAction.groupId);
                                                }
                                                return true;
                                            });
                                            console.log('THIS IS FILETERED ACTION LIST', filteredActionList);
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            //Make zigbee call and get request id
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER);
                                            const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                            dmRemoveActionFromSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            const reqId = dmRemoveActionFromSceneRsp.getRequestId();
                                            actionInfo.syncStatus = scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING;
                                            actionInfo.syncRequestId = reqId;
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneQueued());
                                        }
                                        break;
                                    //group appliance on off
                                    case scene_types_1.SceneActionTypes.GROUPAPPLIANCEONOFF:
                                        const gaooAction = actionInfo.actionItem;
                                        const gaooGroup = await keus_group_1.default.getGroupById(gaooAction.groupId, gaooAction.roomId);
                                        if (!gaooGroup) {
                                            //Remove all group actions from the scene
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.GROUPAPPLIANCEONOFF) {
                                                    const gaooSceneAction = action.actionItem;
                                                    return !(gaooSceneAction.roomId == gaooAction.roomId &&
                                                        gaooSceneAction.groupId == gaooAction.groupId);
                                                }
                                                return true;
                                            });
                                            console.log('THIS IS FILETERED ACTION LIST', filteredActionList);
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            //Make zigbee call and get request id
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.GROUPAPPLIANCEONOFF);
                                            const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                            dmRemoveActionFromSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            const reqId = dmRemoveActionFromSceneRsp.getRequestId();
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneQueued());
                                        }
                                        break;
                                    //Group appliance single dimmer
                                    case scene_types_1.SceneActionTypes.GROUPAPPLIANCESINGLEDIMMER:
                                        const gasdAction = actionInfo.actionItem;
                                        const gasdGroup = await keus_group_1.default.getGroupById(gasdAction.groupId, gasdAction.roomId);
                                        if (!gasdGroup) {
                                            //Remove all group actions from the scene
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.GROUPAPPLIANCESINGLEDIMMER) {
                                                    const gasdSceneAction = action.actionItem;
                                                    return !(gasdSceneAction.roomId == gasdAction.roomId &&
                                                        gasdSceneAction.groupId == gasdAction.groupId);
                                                }
                                                return true;
                                            });
                                            console.log('THIS IS FILETERED ACTION LIST', filteredActionList);
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            //Make zigbee call and get request id
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.GROUPAPPLIANCESINGLEDIMMER);
                                            const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                            dmRemoveActionFromSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            const reqId = dmRemoveActionFromSceneRsp.getRequestId();
                                            actionInfo.syncStatus = scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING;
                                            actionInfo.syncRequestId = reqId;
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneQueued());
                                        }
                                        break;
                                    //Group appliance fan
                                    case scene_types_1.SceneActionTypes.GROUPAPPLIANCEFAN:
                                        const gafAction = actionInfo.actionItem;
                                        const gafGroup = await keus_group_1.default.getGroupById(gafAction.groupId, gafAction.roomId);
                                        if (!gafGroup) {
                                            //Remove all group actions from the scene
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.GROUPAPPLIANCEFAN) {
                                                    const gafSceneAction = action.actionItem;
                                                    return !(gafSceneAction.roomId == gafAction.roomId &&
                                                        gafSceneAction.groupId == gafAction.groupId);
                                                }
                                                return true;
                                            });
                                            console.log('THIS IS FILETERED ACTION LIST', filteredActionList);
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            //Make zigbee call and get request id
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.GROUPAPPLIANCEFAN);
                                            const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                            dmRemoveActionFromSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            const reqId = dmRemoveActionFromSceneRsp.getRequestId();
                                            actionInfo.syncStatus = scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING;
                                            actionInfo.syncRequestId = reqId;
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneQueued());
                                        }
                                        break;
                                    //Group Appliance color tunable
                                    case scene_types_1.SceneActionTypes.GROUPAPPLIANCECOLORTUNABLE:
                                        const gactAction = actionInfo.actionItem;
                                        const gactGroup = await keus_group_1.default.getGroupById(gactAction.groupId, gactAction.roomId);
                                        if (!gactGroup) {
                                            //Remove all group actions from the scene
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.GROUPAPPLIANCECOLORTUNABLE) {
                                                    const gactSceneAction = action.actionItem;
                                                    return !(gactSceneAction.roomId == gactAction.roomId &&
                                                        gactSceneAction.groupId == gactAction.groupId);
                                                }
                                                return true;
                                            });
                                            console.log('THIS IS FILETERED ACTION LIST', filteredActionList);
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            //Make zigbee call and get request id
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.GROUPAPPLIANCECOLORTUNABLE);
                                            const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                            dmRemoveActionFromSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            const reqId = dmRemoveActionFromSceneRsp.getRequestId();
                                            actionInfo.syncStatus = scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING;
                                            actionInfo.syncRequestId = reqId;
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneQueued());
                                        }
                                        break;
                                    //Zigbee RGBWWA group
                                    case scene_types_1.SceneActionTypes.GROUPRGBWWADRIVER:
                                        const grgbwwaAction = actionInfo.actionItem;
                                        const zrgbGroup = await keus_group_1.default.getGroupById(grgbwwaAction.groupId, grgbwwaAction.roomId);
                                        if (!zrgbGroup) {
                                            //Remove all group actions from the scene
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.GROUPRGBWWADRIVER) {
                                                    const zrgbgrpSceneAction = action.actionItem;
                                                    return !(zrgbgrpSceneAction.roomId == grgbwwaAction.roomId &&
                                                        zrgbgrpSceneAction.groupId == grgbwwaAction.groupId);
                                                }
                                                return true;
                                            });
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            //Make zigbee call and get request id
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.GROUPRGBWWADRIVER);
                                            const gateway = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                                            dmRemoveActionFromSceneReq.setReportServiceName(system_constants_1.getGatewayManagerServiceName(gateway[0].gatewayId));
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            const reqId = dmRemoveActionFromSceneRsp.getRequestId();
                                            actionInfo.syncStatus = scene_constants_pb_1.ACTION_SYNC_STATES.ACTIONSYNCPENDING;
                                            actionInfo.syncRequestId = reqId;
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneQueued());
                                        }
                                        break;
                                    //AC Fan controller
                                    case scene_types_1.SceneActionTypes.ZIGBEEIRBLASTER:
                                        const zirbAction = actionInfo.actionItem;
                                        const zirbDevice = await keus_device_1.default.getDeviceById(zirbAction.irDevice);
                                        if (!zirbDevice) {
                                            console.log('HITTING REMOVE ENTIRE DEVICE');
                                            filteredActionList = scene.actionList.filter(function (action) {
                                                if (action.actionType == scene_types_1.SceneActionTypes.ZIGBEEIRBLASTER) {
                                                    const zirbSceneAction = action.actionItem;
                                                    return zirbAction.irDevice != zirbSceneAction.irDevice;
                                                }
                                                return true;
                                            });
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        else {
                                            filteredActionList = scene.actionList.filter(action => action.actionId != actionId);
                                            //Make zigbee call to remove the action from device
                                            dmRemoveActionFromSceneReq.setActionType(scene_types_1.SceneActionTypes.ZIGBEEIRBLASTER);
                                            let dmRemoveActionFromSceneRsp = await local_client_1.GatewayProvidersManager.makeRPC(system_constants_1.DeviceManager.DeviceManagerGatewayServicePrefix, general_1.PackIntoAny(dmRemoveActionFromSceneReq.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.DMRemoveActionFromScene'));
                                            console.log('This is rsp', dmRemoveActionFromSceneRsp);
                                            if (!dmRemoveActionFromSceneRsp.getSuccess()) {
                                                throw new Error(dmRemoveActionFromSceneRsp.getMessage());
                                            }
                                            await keus_scene_1.default.updateSceneActionList(scene.sceneId, scene.sceneRoom, filteredActionList);
                                            resolve(response_1.default.getRemoveActionFromSceneSuccessful());
                                        }
                                        break;
                                    default:
                                        resolve(response_1.default.getInvalidDeviceType());
                                }
                            }
                        }
                    }
                }
            }
            catch (e) {
                console.log('ERROR IS ', e);
                switch (e.constructor) {
                    case errors_1.HomeErrors.InvalidRoomId:
                        resolve(response_1.default.getInvalidRoomId());
                        break;
                    case errors_1.SceneErrors.InvalidSceneId:
                        resolve(response_1.default.getInvalidSceneId());
                        break;
                    case errors_1.SceneErrors.InvalidActionId:
                        resolve(response_1.default.getInvalidActionId());
                        break;
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map