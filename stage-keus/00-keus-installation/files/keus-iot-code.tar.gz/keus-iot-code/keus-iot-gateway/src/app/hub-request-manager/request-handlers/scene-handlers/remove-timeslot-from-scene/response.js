"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const scene_structures_pb_1 = require("../../../protos/generated/hub/scenes/scene_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class CreateSceneResp {
    static getRemoveTimeslotFromSceneSuccessful() {
        const resp = new scene_structures_pb_1.RemoveTimeslotFromSceneResponse();
        resp.setCode(800);
        resp.setMessage('Remove timeslot from scene successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getRemoveTimeslotFromSceneQueued() {
        const resp = new scene_structures_pb_1.RemoveTimeslotFromSceneResponse();
        resp.setCode(800);
        resp.setMessage('Remove timeslot from scene queued');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidSceneId() {
        const resp = new scene_structures_pb_1.RemoveTimeslotFromSceneResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Scene Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidTimeslotId() {
        const resp = new scene_structures_pb_1.RemoveTimeslotFromSceneResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Timeslot Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInvalidSceneType() {
        const resp = new scene_structures_pb_1.RemoveTimeslotFromSceneResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Scene Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInternalServerError() {
        const resp = new scene_structures_pb_1.RemoveTimeslotFromSceneResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new scene_structures_pb_1.RemoveTimeslotFromSceneResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new scene_structures_pb_1.RemoveTimeslotFromSceneResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), CreateSceneResp.responseType);
    }
}
exports.default = CreateSceneResp;
CreateSceneResp.responseType = system_constants_1.ProtoPackageName + '.RemoveTimeslotFromSceneResponse';
//# sourceMappingURL=response.js.map