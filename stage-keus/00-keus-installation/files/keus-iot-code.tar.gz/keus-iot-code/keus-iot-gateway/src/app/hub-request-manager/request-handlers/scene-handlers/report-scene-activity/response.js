"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const scene_structures_pb_1 = require("../../../protos/generated/hub/scenes/scene_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class ExecuteSceneResp {
    static getExecuteSceneSuccessful() {
        const resp = new scene_structures_pb_1.ExecuteSceneResponse();
        resp.setCode(800);
        resp.setMessage('Execute Scene Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ExecuteSceneResp.responseType);
    }
    static getInvalidSceneId() {
        const resp = new scene_structures_pb_1.ExecuteSceneResponse();
        resp.setCode(804);
        resp.setMessage('Invalid Scene Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ExecuteSceneResp.responseType);
    }
    static getInvalidSceneRoom() {
        const resp = new scene_structures_pb_1.ExecuteSceneResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Scene Room');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ExecuteSceneResp.responseType);
    }
    static getInvalidSceneType() {
        const resp = new scene_structures_pb_1.ExecuteSceneResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Scene Type');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ExecuteSceneResp.responseType);
    }
    static getDuplicateSceneName() {
        const resp = new scene_structures_pb_1.ExecuteSceneResponse();
        resp.setCode(803);
        resp.setMessage('Duplicate Scene Name');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ExecuteSceneResp.responseType);
    }
    static getInternalServerError() {
        const resp = new scene_structures_pb_1.ExecuteSceneResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ExecuteSceneResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new scene_structures_pb_1.ExecuteSceneResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ExecuteSceneResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new scene_structures_pb_1.ExecuteSceneResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ExecuteSceneResp.responseType);
    }
}
exports.default = ExecuteSceneResp;
ExecuteSceneResp.responseType = system_constants_1.ProtoPackageName + '.ExecuteSceneResponse';
//# sourceMappingURL=response.js.map