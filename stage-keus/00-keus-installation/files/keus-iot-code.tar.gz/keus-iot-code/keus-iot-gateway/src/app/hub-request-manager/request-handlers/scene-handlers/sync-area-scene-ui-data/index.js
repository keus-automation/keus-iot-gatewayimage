"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const home_constants_1 = require("../../../../../constants/gateway/home-constants");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (syncAreaSceneUIDataReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                if (syncAreaSceneUIDataReq.getAreaId() == null) {
                    throw new errors_1.HomeErrors.InvalidAreaId();
                }
                else if (syncAreaSceneUIDataReq.getAreaId() < home_constants_1.AreaStartId) {
                    throw new errors_1.GeneralErrors.OperationsNotAllowed();
                }
                else {
                    const area = await keus_home_1.default.getAreaById(syncAreaSceneUIDataReq.getAreaId());
                    if (!area) {
                        throw new errors_1.HomeErrors.InvalidAreaId();
                    }
                    else {
                        //Make zigbee request here
                        const reqId = '-';
                        const areaSyncInfo = {
                            syncRequestId: reqId,
                            syncRequestParams: {},
                            syncRequestTime: Date.now(),
                            syncRequestType: home_structures_pb_1.AREA_JOB_TYPES.AREA_SYNCSCENEUI,
                            syncStatus: home_structures_pb_1.AREA_SYNC_STATES.AREASYNCPENDING
                        };
                        await keus_home_1.default.updateAreaSyncState(area.areaId, areaSyncInfo);
                        resolve(response_1.default.getSyncAreaSceneUIDataQueued(reqId));
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        resolve(response_1.default.getUserNotAdmin());
                        break;
                    case errors_1.HomeErrors.InvalidAreaId:
                        resolve(response_1.default.getInvalidAreaId());
                        break;
                    case errors_1.GeneralErrors.OperationsNotAllowed:
                        resolve(response_1.default.getOperationNotAllowed());
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map