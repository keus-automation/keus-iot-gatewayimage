"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const scene_structures_pb_1 = require("../../../protos/generated/hub/scenes/scene_structures_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class SyncAreaSceneUIDataResp {
    static getSyncAreaSceneUIDataQueued(requestId) {
        const resp = new scene_structures_pb_1.SyncAreaSceneUIDataResponse();
        resp.setCode(800);
        resp.setMessage('Sync Area Scene UI Data Queued');
        resp.setSuccess(true);
        resp.setRequestId(requestId);
        return general_1.PackIntoAny(resp.serializeBinary(), SyncAreaSceneUIDataResp.responseType);
    }
    static getInvalidAreaId() {
        const resp = new scene_structures_pb_1.SyncAreaSceneUIDataResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Area Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), SyncAreaSceneUIDataResp.responseType);
    }
    static getOperationNotAllowed() {
        const resp = new scene_structures_pb_1.SyncAreaSceneUIDataResponse();
        const opNotAllowed = response_helper_1.default.getOperationNotAllowed();
        resp.setCode(opNotAllowed.code);
        resp.setMessage(opNotAllowed.message);
        resp.setSuccess(opNotAllowed.success);
        return general_1.PackIntoAny(resp.serializeBinary(), SyncAreaSceneUIDataResp.responseType);
    }
    static getInternalServerError() {
        const resp = new scene_structures_pb_1.SyncAreaSceneUIDataResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), SyncAreaSceneUIDataResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new scene_structures_pb_1.SyncAreaSceneUIDataResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), SyncAreaSceneUIDataResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new scene_structures_pb_1.SyncAreaSceneUIDataResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), SyncAreaSceneUIDataResp.responseType);
    }
}
exports.default = SyncAreaSceneUIDataResp;
SyncAreaSceneUIDataResp.responseType = system_constants_1.ProtoPackageName + '.SyncAreaSceneUIDataResponse';
//# sourceMappingURL=response.js.map