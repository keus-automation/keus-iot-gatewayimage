"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const schedule_structure_pb_1 = require("../../../protos/generated/hub/schedules/schedule_structure_pb");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const keus_schedule_1 = __importStar(require("../../../../../models/database-models/keus-schedule"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_1 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const schedules_manager_1 = require("../../../schedules-manager");
const default_configuration_constants_1 = require("../../../../../constants/device/default-configuration-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (createScheduleReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                console.log('this is create scheudle request');
                console.log('this repeatlist', createScheduleReq.getRepeatList());
                let scheduleObject = {
                    scheduleId: await keus_schedule_1.generateScheduleId(),
                    scheduleName: createScheduleReq.getScheduleName(),
                    scheduleRoom: createScheduleReq.getScheduleRoom(),
                    scheduleSection: createScheduleReq.getScheduleSection(),
                    scheduleType: createScheduleReq.getScheduleType(),
                    scheduleActionType: createScheduleReq.getScheduleActionType(),
                    startTime: createScheduleReq.getStartTime(),
                    endTime: createScheduleReq.getEndTime() ? createScheduleReq.getEndTime() : 0,
                    repeat: createScheduleReq.getRepeatList(),
                    scheduleAction: {},
                    createdBy: user.phone,
                    createdByName: user.userName,
                    activeStatus: createScheduleReq.getActiveStatus()
                };
                switch (createScheduleReq.getScheduleActionType()) {
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DIMMABLE_DRIVER:
                        let dbaction = {
                            groupId: createScheduleReq.getZdimmableDriverAction().getGroupId(),
                            roomId: createScheduleReq.getZdimmableDriverAction().getRoomId(),
                            driverState: createScheduleReq.getZdimmableDriverAction().getDriverState()
                        };
                        scheduleObject.scheduleAction = dbaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_NON_DIMMABLE_DRIVER:
                        let dbnddaction = {
                            groupId: createScheduleReq.getZnondimmableDriverAction().getGroupId(),
                            roomId: createScheduleReq.getZnondimmableDriverAction().getRoomId(),
                            driverState: createScheduleReq.getZnondimmableDriverAction().getDriverState()
                        };
                        scheduleObject.scheduleAction = dbnddaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_DIMMABLE_DRIVER:
                        let dbdddaction = {
                            groupId: createScheduleReq.getDdimmableDriverAction().getGroupId(),
                            roomId: createScheduleReq.getDdimmableDriverAction().getRoomId(),
                            driverState: createScheduleReq.getDdimmableDriverAction().getDriverState()
                        };
                        scheduleObject.scheduleAction = dbdddaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_COLOR_TUNABLE_DRIVER:
                        let dbdctdaction = {
                            groupId: createScheduleReq.getDcolortunableDriverAction().getGroupId(),
                            roomId: createScheduleReq.getDcolortunableDriverAction().getGroupRoom(),
                            driverState: {
                                driverState: createScheduleReq.getDcolortunableDriverAction().getDriverState().getDriverState() > default_configuration_constants_1.DaliColorTunableMaxValue
                                    ? default_configuration_constants_1.DaliColorTunableMaxValue
                                    : createScheduleReq.getDcolortunableDriverAction().getDriverState().getDriverState(),
                                colorTemperature: createScheduleReq.getDcolortunableDriverAction().getDriverState().getColorTemperature() > default_configuration_constants_1.DaliColorTunableMaxTemperature
                                    ? default_configuration_constants_1.DaliColorTunableMaxTemperature
                                    : createScheduleReq.getDcolortunableDriverAction().getDriverState().getColorTemperature(),
                                lastUpdateBy: "",
                                lastUpdateSource: "",
                                lastUpdateTime: Date.now(),
                                lastUpdateUser: ""
                            }
                        };
                        scheduleObject.scheduleAction = dbdctdaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_NON_DIMMABLE_DRIVER:
                        let dbdndaction = {
                            groupId: createScheduleReq.getDnondimmableDriverAction().getGroupId(),
                            roomId: createScheduleReq.getDnondimmableDriverAction().getRoomId(),
                            driverState: createScheduleReq.getDnondimmableDriverAction().getDriverState()
                        };
                        scheduleObject.scheduleAction = dbdndaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_CURTAIN_CONTROLLER:
                        let dbccaction = {
                            curtainState: createScheduleReq.getZcurtainControllerAction().getCurtainState(),
                            deviceId: createScheduleReq.getZcurtainControllerAction().getDeviceId()
                        };
                        scheduleObject.scheduleAction = dbccaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_EMBEDDED_SWITCH:
                        let esAction = createScheduleReq.getEmbeddedApplianceAction();
                        let applianceAction;
                        switch (esAction.getApplianceType()) {
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                                let onoffAction = {
                                    switchState: esAction.getOnOffState().getSwitchState()
                                };
                                applianceAction = onoffAction;
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                                let sdAction = {
                                    switchState: esAction.getSingleDimmerState().getSwitchState()
                                };
                                applianceAction = sdAction;
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                                let fanAction = {
                                    fanState: esAction.getFanState().getFanState()
                                };
                                applianceAction = fanAction;
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                                let ctAction = {
                                    lightState: esAction.getColorTunableState().getLightState(),
                                    warmWhiteState: esAction.getColorTunableState().getWarmWhiteState(),
                                    coolWhiteState: esAction.getColorTunableState().getCoolWhiteState()
                                };
                                applianceAction = ctAction;
                                break;
                        }
                        let final_action = {
                            applianceId: esAction.getApplianceId(),
                            applianceState: applianceAction,
                            applianceType: esAction.getApplianceType(),
                            deviceId: esAction.getDeviceId()
                        };
                        scheduleObject.scheduleAction = final_action;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_ON0FF:
                        let gponoff = {
                            roomId: createScheduleReq.getGrpOnoffAction().getRoomId(),
                            groupId: createScheduleReq.getGrpOnoffAction().getGroupId(),
                            switchState: createScheduleReq.getGrpOnoffAction().getSwitchState()
                        };
                        scheduleObject.scheduleAction = gponoff;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_SINGLE_DIMMER:
                        let gpsd = {
                            roomId: createScheduleReq.getGrpSingledimmerAction().getRoomId(),
                            groupId: createScheduleReq.getGrpSingledimmerAction().getGroupId(),
                            switchState: createScheduleReq.getGrpSingledimmerAction().getSwitchState()
                        };
                        scheduleObject.scheduleAction = gpsd;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_FAN:
                        let gpfan = {
                            roomId: createScheduleReq.getGrpFanAction().getRoomId(),
                            groupId: createScheduleReq.getGrpFanAction().getGroupId(),
                            fanState: createScheduleReq.getGrpFanAction().getFanState()
                        };
                        scheduleObject.scheduleAction = gpfan;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_COLOR_TUNABLE:
                        let gpct = {
                            roomId: createScheduleReq.getGrpColortunableAction().getRoomId(),
                            groupId: createScheduleReq.getGrpColortunableAction().getGroupId(),
                            lightState: createScheduleReq.getGrpColortunableAction().getLightState(),
                            warmWhiteState: createScheduleReq.getGrpColortunableAction().getWarmWhiteState(),
                            coolWhiteState: createScheduleReq.getGrpColortunableAction().getCoolWhiteState()
                        };
                        scheduleObject.scheduleAction = gpct;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_AC_FAN_CONTROLLER:
                        let dbacfaction = {
                            fanState: createScheduleReq.getZacfanControllerAction().getFanState(),
                            deviceId: createScheduleReq.getZacfanControllerAction().getDeviceId(),
                            lightState: createScheduleReq.getZacfanControllerAction().getLightState(),
                            updateType: createScheduleReq.getZacfanControllerAction().getUpdateType()
                        };
                        scheduleObject.scheduleAction = dbacfaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DC_FAN_CONTROLLER:
                        const updateType = createScheduleReq.getZdcfanControllerAction().getUpdateType();
                        let dbdcfaction = {
                            fanState: createScheduleReq.getZdcfanControllerAction().getFanState(),
                            deviceId: createScheduleReq.getZdcfanControllerAction().getDeviceId(),
                            lightState: {
                                lightState: updateType == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_LIGHT_UPDATE ||
                                    updateType == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_BOTH_UPDATE
                                    ? createScheduleReq
                                        .getZdcfanControllerAction()
                                        .getLightState()
                                        .getLightState()
                                    : 0,
                                lightTemperature: updateType == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_LIGHT_UPDATE ||
                                    updateType == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_BOTH_UPDATE
                                    ? createScheduleReq
                                        .getZdcfanControllerAction()
                                        .getLightState()
                                        .getLightTemperature()
                                    : 0
                            },
                            updateType: createScheduleReq.getZdcfanControllerAction().getUpdateType()
                        };
                        scheduleObject.scheduleAction = dbdcfaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_RGBWWA:
                        const rgbwwaUpdateType = createScheduleReq.getZrgbwwwaDriverAction().getUpdateType();
                        let dbrgbwwaaction = {
                            deviceId: createScheduleReq.getZrgbwwwaDriverAction().getDeviceId(),
                            updateType: createScheduleReq.getZrgbwwwaDriverAction().getUpdateType(),
                            deviceState: createScheduleReq.getZrgbwwwaDriverAction().getDeviceState(),
                            wwaState: {
                                warmWhite: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? createScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getWwaState()
                                        .getWarmWhite()
                                    : 0,
                                coolWhite: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? createScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getWwaState()
                                        .getCoolWhite()
                                    : 0,
                                amber: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? createScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getWwaState()
                                        .getAmber()
                                    : 0,
                                deviceState: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? createScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getWwaState()
                                        .getDeviceState()
                                    : 0
                            },
                            rgbState: {
                                red: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getRed()
                                    : 0,
                                green: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getGreen()
                                    : 0,
                                blue: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getBlue()
                                    : 0,
                                pattern: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getPattern()
                                    : 0,
                                deviceState: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getDeviceState()
                                    : 0
                            }
                        };
                        scheduleObject.scheduleAction = dbrgbwwaaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_ZIGBEE_RGBWWA:
                        const grgbwwaUpdateType = createScheduleReq.getGrpZrgbwwaAction().getUpdateType();
                        let gdbrgbwwaaction = {
                            groupId: createScheduleReq.getGrpZrgbwwaAction().getGroupId(),
                            roomId: createScheduleReq.getGrpZrgbwwaAction().getRoomId(),
                            updateType: createScheduleReq.getGrpZrgbwwaAction().getUpdateType(),
                            deviceState: createScheduleReq.getGrpZrgbwwaAction().getDeviceState(),
                            wwaState: {
                                warmWhite: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? createScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getWwaState()
                                        .getWarmWhite()
                                    : 0,
                                coolWhite: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? createScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getWwaState()
                                        .getCoolWhite()
                                    : 0,
                                amber: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? createScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getWwaState()
                                        .getAmber()
                                    : 0,
                                deviceState: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? createScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getWwaState()
                                        .getDeviceState()
                                    : 0
                            },
                            rgbState: {
                                red: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getRed()
                                    : 0,
                                green: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getGreen()
                                    : 0,
                                blue: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getBlue()
                                    : 0,
                                pattern: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getPattern()
                                    : 0,
                                deviceState: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? createScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getDeviceState()
                                    : 0
                            }
                        };
                        scheduleObject.scheduleAction = gdbrgbwwaaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_SMART_CONSOLE_RELAY:
                        let dbzscraction = {
                            relayState: createScheduleReq.getZscRelayAction().getRelayState(),
                            relayId: createScheduleReq.getZscRelayAction().getRelayId(),
                            deviceId: createScheduleReq.getZscRelayAction().getDeviceId()
                        };
                        scheduleObject.scheduleAction = dbzscraction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_IR_REMOTE: ///needed clarity
                        let dbiraction = {
                            remoteId: createScheduleReq.getZirBlasterAction().getRemoteId(),
                            remoteType: createScheduleReq.getZirBlasterAction().getRemoteType(),
                            irDevice: createScheduleReq.getZirBlasterAction().getIrDevice(),
                            irBlastAction: {}
                        };
                        switch (createScheduleReq.getZirBlasterAction().getRemoteType()) {
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                                let acdbaction = {
                                    powerOn: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getPowerOn(),
                                    temperature: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getTemperature(),
                                    swingHLevel: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getSwingHLevel(),
                                    swingVLevel: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getSwingVLevel(),
                                    fanLevel: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getFanLevel(),
                                    mode: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getMode()
                                };
                                dbiraction.irBlastAction = acdbaction;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                                let tvdbaction = {
                                    updateType: createScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getUpdateType(),
                                    powerOn: createScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getPowerOn(),
                                    channelNumber: createScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getChannelNumber(),
                                    source: createScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getSource(),
                                    mode: createScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getMode()
                                };
                                dbiraction.irBlastAction = tvdbaction;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                                let ampdbaction = {
                                    powerOn: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAmpActionInfo()
                                        .getPowerOn(),
                                    updateType: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAmpActionInfo()
                                        .getUpdateType(),
                                    source: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAmpActionInfo()
                                        .getSource(),
                                    mode: createScheduleReq
                                        .getZirBlasterAction()
                                        .getAmpActionInfo()
                                        .getMode()
                                };
                                dbiraction.irBlastAction = ampdbaction;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                                let fandbaction = {
                                    powerOn: createScheduleReq
                                        .getZirBlasterAction()
                                        .getFanActionInfo()
                                        .getPowerOn(),
                                    speedLevel: createScheduleReq
                                        .getZirBlasterAction()
                                        .getFanActionInfo()
                                        .getSpeedLevel(),
                                    mode: createScheduleReq
                                        .getZirBlasterAction()
                                        .getFanActionInfo()
                                        .getMode(),
                                    ledState: createScheduleReq
                                        .getZirBlasterAction()
                                        .getFanActionInfo()
                                        .getLedState()
                                };
                                dbiraction.irBlastAction = fandbaction;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                                let prdbaction = {
                                    powerOn: createScheduleReq
                                        .getZirBlasterAction()
                                        .getPrActionInfo()
                                        .getPowerOn(),
                                    mode: createScheduleReq
                                        .getZirBlasterAction()
                                        .getPrActionInfo()
                                        .getMode(),
                                    source: createScheduleReq
                                        .getZirBlasterAction()
                                        .getPrActionInfo()
                                        .getSource(),
                                    updateType: createScheduleReq
                                        .getZirBlasterAction()
                                        .getPrActionInfo()
                                        .getUpdateType()
                                };
                                dbiraction.irBlastAction = prdbaction;
                                break;
                        }
                        scheduleObject.scheduleAction = dbiraction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.SCENE_EXECUTION:
                        let dbsceneaction = {
                            sceneId: createScheduleReq.getSceneAction().getSceneId(),
                            sceneRoom: createScheduleReq.getSceneAction().getSceneRoom()
                        };
                        scheduleObject.scheduleAction = dbsceneaction;
                        break;
                    default:
                        break;
                }
                await schedules_manager_1.SchedulesManager.getInstance().scheduleJob(scheduleObject);
                // ADD schedule object by sending @finalSchedulerObject as params
                await keus_schedule_1.default.insertSchedule(scheduleObject);
                final_resp = response_1.default.getCreateScheduleSuccessful(scheduleObject.scheduleId);
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.UserNotAdminError:
                        final_resp = response_1.default.getUserNotAdmin();
                        break;
                    default:
                        logInst.log(e);
                        final_resp = response_1.default.getInternalServerError();
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map