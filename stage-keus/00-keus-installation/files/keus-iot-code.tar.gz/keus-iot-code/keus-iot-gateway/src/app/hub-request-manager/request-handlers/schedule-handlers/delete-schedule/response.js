"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const schedule_structure_pb_1 = require("../../../protos/generated/hub/schedules/schedule_structure_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class DeleteScheduleResp {
    static getDeleteScheduleSuccessful() {
        const resp = new schedule_structure_pb_1.DeleteScheduleResponse();
        resp.setCode(800);
        resp.setMessage('delete schedule success');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteScheduleResp.responseType);
    }
    static getInvalidScheduleId() {
        const resp = new schedule_structure_pb_1.DeleteScheduleResponse();
        resp.setCode(801);
        resp.setMessage('invalid schedule id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteScheduleResp.responseType);
    }
    static getInternalServerError() {
        const resp = new schedule_structure_pb_1.DeleteScheduleResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteScheduleResp.responseType);
    }
    static getUserNotAdmin() {
        const resp = new schedule_structure_pb_1.DeleteScheduleResponse();
        resp.setCode(808);
        resp.setMessage('User doesnt have admin access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteScheduleResp.responseType);
    }
    static getInsufficientUserAccess() {
        const resp = new schedule_structure_pb_1.DeleteScheduleResponse();
        resp.setCode(809);
        resp.setMessage('invalid user access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), DeleteScheduleResp.responseType);
    }
}
exports.default = DeleteScheduleResp;
DeleteScheduleResp.responseType = system_constants_1.ProtoPackageName + '.DeleteScheduleResponse';
//# sourceMappingURL=response.js.map