"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const keus_schedule_1 = __importDefault(require("../../../../../models/database-models/keus-schedule"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (editScheduleReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                let scheduleObject = await keus_schedule_1.default.getScheduleById(editScheduleReq.getScheduleId());
                if (!scheduleObject) {
                    throw new errors_1.ScheduleErrors.InvalidScheduleId();
                }
                scheduleObject.scheduleType = editScheduleReq.getScheduleType();
                scheduleObject.scheduleName = editScheduleReq.getScheduleName();
                scheduleObject.scheduleRoom = editScheduleReq.getScheduleRoom();
                scheduleObject.scheduleSection = editScheduleReq.getScheduleSection();
                scheduleObject.startTime = editScheduleReq.getStartTime();
                scheduleObject.endTime = editScheduleReq.getEndTime() ? editScheduleReq.getEndTime() : 0;
                scheduleObject.repeat = editScheduleReq.getRepeatList();
                scheduleObject.createdBy = user.phone;
                scheduleObject.createdByName = user.userName;
                // get scheduler object
                //edit scheduler object
                await keus_schedule_1.default.updateSchedule(scheduleObject);
                final_resp = response_1.default.getEditScheduleSuccessful(scheduleObject.scheduleId);
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.ScheduleErrors.InvalidScheduleId:
                        final_resp = response_1.default.getInvalidScheduleId();
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        final_resp = response_1.default.getUserNotAdmin();
                        break;
                    default:
                        logInst.log(e);
                        final_resp = response_1.default.getInternalServerError();
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map