"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const schedule_structure_pb_1 = require("../../../protos/generated/hub/schedules/schedule_structure_pb");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const keus_schedule_1 = __importDefault(require("../../../../../models/database-models/keus-schedule"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const errors_1 = require("../../../../../errors/errors");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const errors_2 = require("../../../../../errors/errors");
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const schedules_manager_1 = require("../../../schedules-manager");
const default_configuration_constants_1 = require("../../../../../constants/device/default-configuration-constants");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (editScheduleReq, phone) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let user = await keus_user_1.default.getUserByPhone(phone);
                await home_utils_1.checkUserIsAdmin(user);
                let scheduleObject = await keus_schedule_1.default.getScheduleById(editScheduleReq.getScheduleId());
                if (!scheduleObject) {
                    throw new errors_1.ScheduleErrors.InvalidScheduleId();
                }
                scheduleObject.scheduleType = editScheduleReq.getScheduleType();
                scheduleObject.scheduleName = editScheduleReq.getScheduleName();
                scheduleObject.scheduleRoom = editScheduleReq.getScheduleRoom();
                scheduleObject.scheduleSection = editScheduleReq.getScheduleSection();
                scheduleObject.scheduleActionType = editScheduleReq.getScheduleActionType();
                scheduleObject.startTime = editScheduleReq.getStartTime();
                scheduleObject.endTime = editScheduleReq.getEndTime() ? editScheduleReq.getEndTime() : 0;
                scheduleObject.repeat = editScheduleReq.getRepeatList();
                scheduleObject.createdBy = user.phone;
                scheduleObject.createdByName = user.userName;
                switch (editScheduleReq.getScheduleActionType()) {
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DIMMABLE_DRIVER:
                        let dbaction = {
                            groupId: editScheduleReq.getZdimmableDriverAction().getGroupId(),
                            roomId: editScheduleReq.getZdimmableDriverAction().getRoomId(),
                            driverState: editScheduleReq.getZdimmableDriverAction().getDriverState()
                        };
                        scheduleObject.scheduleAction = dbaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_NON_DIMMABLE_DRIVER:
                        let dbnddaction = {
                            groupId: editScheduleReq.getZnondimmableDriverAction().getGroupId(),
                            roomId: editScheduleReq.getZnondimmableDriverAction().getRoomId(),
                            driverState: editScheduleReq.getZnondimmableDriverAction().getDriverState()
                        };
                        scheduleObject.scheduleAction = dbnddaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_DIMMABLE_DRIVER:
                        let dbdddaction = {
                            groupId: editScheduleReq.getDdimmableDriverAction().getGroupId(),
                            roomId: editScheduleReq.getDdimmableDriverAction().getRoomId(),
                            driverState: editScheduleReq.getDdimmableDriverAction().getDriverState()
                        };
                        scheduleObject.scheduleAction = dbdddaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_COLOR_TUNABLE_DRIVER:
                        let dbdctdaction = {
                            groupId: editScheduleReq.getDcolortunableDriverAction().getGroupId(),
                            roomId: editScheduleReq.getDcolortunableDriverAction().getGroupRoom(),
                            driverState: {
                                driverState: editScheduleReq.getDcolortunableDriverAction().getDriverState().getDriverState() > default_configuration_constants_1.DaliColorTunableMaxValue
                                    ? default_configuration_constants_1.DaliColorTunableMaxValue
                                    : editScheduleReq.getDcolortunableDriverAction().getDriverState().getDriverState(),
                                colorTemperature: editScheduleReq.getDcolortunableDriverAction().getDriverState().getColorTemperature() > default_configuration_constants_1.DaliColorTunableMaxTemperature
                                    ? default_configuration_constants_1.DaliColorTunableMaxTemperature
                                    : editScheduleReq.getDcolortunableDriverAction().getDriverState().getColorTemperature(),
                                lastUpdateBy: "",
                                lastUpdateSource: "",
                                lastUpdateTime: Date.now(),
                                lastUpdateUser: ""
                            }
                        };
                        scheduleObject.scheduleAction = dbdctdaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_NON_DIMMABLE_DRIVER:
                        let dbdndaction = {
                            groupId: editScheduleReq.getDnondimmableDriverAction().getGroupId(),
                            roomId: editScheduleReq.getDnondimmableDriverAction().getRoomId(),
                            driverState: editScheduleReq.getDnondimmableDriverAction().getDriverState()
                        };
                        scheduleObject.scheduleAction = dbdndaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_CURTAIN_CONTROLLER:
                        let dbccaction = {
                            curtainState: editScheduleReq.getZcurtainControllerAction().getCurtainState(),
                            deviceId: editScheduleReq.getZcurtainControllerAction().getDeviceId()
                        };
                        scheduleObject.scheduleAction = dbccaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_EMBEDDED_SWITCH:
                        let esAction = editScheduleReq.getEmbeddedApplianceAction();
                        let applianceAction;
                        switch (esAction.getApplianceType()) {
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                                let onoffAction = {
                                    switchState: esAction.getOnOffState().getSwitchState()
                                };
                                applianceAction = onoffAction;
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                                let sdAction = {
                                    switchState: esAction.getSingleDimmerState().getSwitchState()
                                };
                                applianceAction = sdAction;
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                                let fanAction = {
                                    fanState: esAction.getFanState().getFanState()
                                };
                                applianceAction = fanAction;
                                break;
                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                                let ctAction = {
                                    lightState: esAction.getColorTunableState().getLightState(),
                                    warmWhiteState: esAction.getColorTunableState().getWarmWhiteState(),
                                    coolWhiteState: esAction.getColorTunableState().getCoolWhiteState()
                                };
                                applianceAction = ctAction;
                                break;
                        }
                        let final_action = {
                            applianceId: esAction.getApplianceId(),
                            applianceState: applianceAction,
                            applianceType: esAction.getApplianceType(),
                            deviceId: esAction.getDeviceId()
                        };
                        scheduleObject.scheduleAction = final_action;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_ON0FF:
                        let gponoff = {
                            roomId: editScheduleReq.getGrpOnoffAction().getRoomId(),
                            groupId: editScheduleReq.getGrpOnoffAction().getGroupId(),
                            switchState: editScheduleReq.getGrpOnoffAction().getSwitchState()
                        };
                        scheduleObject.scheduleAction = gponoff;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_SINGLE_DIMMER:
                        let gpsd = {
                            roomId: editScheduleReq.getGrpSingledimmerAction().getRoomId(),
                            groupId: editScheduleReq.getGrpSingledimmerAction().getGroupId(),
                            switchState: editScheduleReq.getGrpSingledimmerAction().getSwitchState()
                        };
                        scheduleObject.scheduleAction = gpsd;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_FAN:
                        let gpfan = {
                            roomId: editScheduleReq.getGrpFanAction().getRoomId(),
                            groupId: editScheduleReq.getGrpFanAction().getGroupId(),
                            fanState: editScheduleReq.getGrpFanAction().getFanState()
                        };
                        scheduleObject.scheduleAction = gpfan;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_COLOR_TUNABLE:
                        let gpct = {
                            roomId: editScheduleReq.getGrpColortunableAction().getRoomId(),
                            groupId: editScheduleReq.getGrpColortunableAction().getGroupId(),
                            lightState: editScheduleReq.getGrpColortunableAction().getLightState(),
                            warmWhiteState: editScheduleReq.getGrpColortunableAction().getWarmWhiteState(),
                            coolWhiteState: editScheduleReq.getGrpColortunableAction().getCoolWhiteState()
                        };
                        scheduleObject.scheduleAction = gpct;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_AC_FAN_CONTROLLER:
                        let dbacfaction = {
                            fanState: editScheduleReq.getZacfanControllerAction().getFanState(),
                            deviceId: editScheduleReq.getZacfanControllerAction().getDeviceId(),
                            lightState: editScheduleReq.getZacfanControllerAction().getLightState(),
                            updateType: editScheduleReq.getZacfanControllerAction().getUpdateType()
                        };
                        scheduleObject.scheduleAction = dbacfaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DC_FAN_CONTROLLER:
                        const updateType = editScheduleReq.getZdcfanControllerAction().getUpdateType();
                        let dbdcfaction = {
                            fanState: editScheduleReq.getZdcfanControllerAction().getFanState(),
                            deviceId: editScheduleReq.getZdcfanControllerAction().getDeviceId(),
                            lightState: {
                                lightState: updateType == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_LIGHT_UPDATE ||
                                    updateType == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_BOTH_UPDATE
                                    ? editScheduleReq
                                        .getZdcfanControllerAction()
                                        .getLightState()
                                        .getLightState()
                                    : 0,
                                lightTemperature: updateType == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_LIGHT_UPDATE ||
                                    updateType == device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_BOTH_UPDATE
                                    ? editScheduleReq
                                        .getZdcfanControllerAction()
                                        .getLightState()
                                        .getLightTemperature()
                                    : 0
                            },
                            updateType: editScheduleReq.getZdcfanControllerAction().getUpdateType()
                        };
                        scheduleObject.scheduleAction = dbdcfaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_RGBWWA:
                        const rgbwwaUpdateType = editScheduleReq.getZrgbwwwaDriverAction().getUpdateType();
                        let dbrgbwwaaction = {
                            deviceId: editScheduleReq.getZrgbwwwaDriverAction().getDeviceId(),
                            updateType: editScheduleReq.getZrgbwwwaDriverAction().getUpdateType(),
                            deviceState: editScheduleReq.getZrgbwwwaDriverAction().getDeviceState(),
                            wwaState: {
                                warmWhite: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? editScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getWwaState()
                                        .getWarmWhite()
                                    : 0,
                                coolWhite: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? editScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getWwaState()
                                        .getCoolWhite()
                                    : 0,
                                amber: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? editScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getWwaState()
                                        .getAmber()
                                    : 0,
                                deviceState: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? editScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getWwaState()
                                        .getDeviceState()
                                    : 0
                            },
                            rgbState: {
                                red: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getRed()
                                    : 0,
                                green: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getGreen()
                                    : 0,
                                blue: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getBlue()
                                    : 0,
                                pattern: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getPattern()
                                    : 0,
                                deviceState: rgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getZrgbwwwaDriverAction()
                                        .getRgbState()
                                        .getDeviceState()
                                    : 0
                            }
                        };
                        scheduleObject.scheduleAction = dbrgbwwaaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_ZIGBEE_RGBWWA:
                        const grgbwwaUpdateType = editScheduleReq.getGrpZrgbwwaAction().getUpdateType();
                        let gdbrgbwwaaction = {
                            groupId: editScheduleReq.getGrpZrgbwwaAction().getGroupId(),
                            roomId: editScheduleReq.getGrpZrgbwwaAction().getRoomId(),
                            updateType: editScheduleReq.getGrpZrgbwwaAction().getUpdateType(),
                            deviceState: editScheduleReq.getGrpZrgbwwaAction().getDeviceState(),
                            wwaState: {
                                warmWhite: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? editScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getWwaState()
                                        .getWarmWhite()
                                    : 0,
                                coolWhite: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? editScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getWwaState()
                                        .getCoolWhite()
                                    : 0,
                                amber: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? editScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getWwaState()
                                        .getAmber()
                                    : 0,
                                deviceState: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE
                                    ? editScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getWwaState()
                                        .getDeviceState()
                                    : 0
                            },
                            rgbState: {
                                red: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getRed()
                                    : 0,
                                green: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getGreen()
                                    : 0,
                                blue: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getBlue()
                                    : 0,
                                pattern: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getPattern()
                                    : 0,
                                deviceState: grgbwwaUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE
                                    ? editScheduleReq
                                        .getGrpZrgbwwaAction()
                                        .getRgbState()
                                        .getDeviceState()
                                    : 0
                            }
                        };
                        scheduleObject.scheduleAction = gdbrgbwwaaction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_SMART_CONSOLE_RELAY:
                        let dbzscraction = {
                            relayState: editScheduleReq.getZscRelayAction().getRelayState(),
                            relayId: editScheduleReq.getZscRelayAction().getRelayId(),
                            deviceId: editScheduleReq.getZscRelayAction().getDeviceId()
                        };
                        scheduleObject.scheduleAction = dbzscraction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_IR_REMOTE: ///needed clarity
                        let dbiraction = {
                            remoteId: editScheduleReq.getZirBlasterAction().getRemoteId(),
                            remoteType: editScheduleReq.getZirBlasterAction().getRemoteType(),
                            irDevice: editScheduleReq.getZirBlasterAction().getIrDevice(),
                            irBlastAction: {}
                        };
                        switch (editScheduleReq.getZirBlasterAction().getRemoteType()) {
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                                let acdbaction = {
                                    powerOn: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getPowerOn(),
                                    temperature: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getTemperature(),
                                    swingHLevel: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getSwingHLevel(),
                                    swingVLevel: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getSwingVLevel(),
                                    fanLevel: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getFanLevel(),
                                    mode: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAcActionInfo()
                                        .getMode()
                                };
                                dbiraction.irBlastAction = acdbaction;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                                let tvdbaction = {
                                    updateType: editScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getUpdateType(),
                                    powerOn: editScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getPowerOn(),
                                    channelNumber: editScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getChannelNumber(),
                                    source: editScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getSource(),
                                    mode: editScheduleReq
                                        .getZirBlasterAction()
                                        .getTvActionInfo()
                                        .getMode()
                                };
                                dbiraction.irBlastAction = tvdbaction;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                                let ampdbaction = {
                                    powerOn: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAmpActionInfo()
                                        .getPowerOn(),
                                    updateType: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAmpActionInfo()
                                        .getUpdateType(),
                                    source: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAmpActionInfo()
                                        .getSource(),
                                    mode: editScheduleReq
                                        .getZirBlasterAction()
                                        .getAmpActionInfo()
                                        .getMode()
                                };
                                dbiraction.irBlastAction = ampdbaction;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                                let fandbaction = {
                                    powerOn: editScheduleReq
                                        .getZirBlasterAction()
                                        .getFanActionInfo()
                                        .getPowerOn(),
                                    speedLevel: editScheduleReq
                                        .getZirBlasterAction()
                                        .getFanActionInfo()
                                        .getSpeedLevel(),
                                    mode: editScheduleReq
                                        .getZirBlasterAction()
                                        .getFanActionInfo()
                                        .getMode(),
                                    ledState: editScheduleReq
                                        .getZirBlasterAction()
                                        .getFanActionInfo()
                                        .getLedState()
                                };
                                dbiraction.irBlastAction = fandbaction;
                                break;
                            case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                                let prdbaction = {
                                    powerOn: editScheduleReq
                                        .getZirBlasterAction()
                                        .getPrActionInfo()
                                        .getPowerOn(),
                                    mode: editScheduleReq
                                        .getZirBlasterAction()
                                        .getPrActionInfo()
                                        .getMode(),
                                    source: editScheduleReq
                                        .getZirBlasterAction()
                                        .getPrActionInfo()
                                        .getSource(),
                                    updateType: editScheduleReq
                                        .getZirBlasterAction()
                                        .getPrActionInfo()
                                        .getUpdateType()
                                };
                                dbiraction.irBlastAction = prdbaction;
                                break;
                        }
                        scheduleObject.scheduleAction = dbiraction;
                        break;
                    case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.SCENE_EXECUTION:
                        let dbsceneaction = {
                            sceneId: editScheduleReq.getSceneAction().getSceneId(),
                            sceneRoom: editScheduleReq.getSceneAction().getSceneRoom()
                        };
                        scheduleObject.scheduleAction = dbsceneaction;
                        break;
                    default:
                        break;
                }
                await schedules_manager_1.SchedulesManager.getInstance().scheduleJob(scheduleObject);
                // update schedule object and send @finalSchedulerObject to the scheduler
                await keus_schedule_1.default.updateSchedule(scheduleObject);
                final_resp = response_1.default.getEditScheduleSuccessful(scheduleObject.scheduleId);
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.ScheduleErrors.InvalidScheduleId:
                        final_resp = response_1.default.getInvalidScheduleId();
                        break;
                    case errors_2.GeneralErrors.UserNotAdminError:
                        final_resp = response_1.default.getUserNotAdmin();
                        break;
                    default:
                        logInst.log(e);
                        final_resp = response_1.default.getInternalServerError();
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map