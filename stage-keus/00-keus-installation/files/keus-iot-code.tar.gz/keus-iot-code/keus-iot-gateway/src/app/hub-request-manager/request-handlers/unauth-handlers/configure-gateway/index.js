"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const HomeConstants = __importStar(require("../../../../../constants/gateway/home-constants"));
const SystemConstants = __importStar(require("../../../../../constants/gateway/system-constants"));
const ApiUtils = __importStar(require("../../../../../utilities/gateway/api-utils"));
const internalIp = require('internal-ip');
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const home_structures_pb_1 = require("../../../protos/generated/hub/home/home_structures_pb");
exports.default = async (configureData) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                let newGatewayObj = await home_utils_1.GenerateGatewayData({
                    gatewayId: configureData.getGatewayId(),
                    gatewayKey: configureData.getGatewayKey(),
                    hubVersion: configureData.getHubVersion(),
                    serviceUser: configureData.getServiceUser(),
                    serviceUserPassword: configureData.getServiceUserPassword(),
                    mainGatewayIp: ''
                });
                if (gatewayDetails.length && !gatewayDetails[0].wronglyConfigured) {
                    console.log('gateway already configured');
                    final_resp = response_1.default.getGatewayAlreadyConfigured();
                }
                else {
                    if (gatewayDetails.length) {
                        await keus_gateway_1.default.deleteGateway(gatewayDetails[0].gatewayId);
                    }
                    await keus_gateway_1.default.createGateway(newGatewayObj);
                    await keus_home_1.default.addArea({
                        areaId: HomeConstants.DefaultAreaId,
                        areaName: HomeConstants.DefaultAreaName,
                        areaSyncInfo: {
                            syncRequestId: '-',
                            syncRequestParams: {},
                            syncRequestTime: Date.now(),
                            syncRequestType: home_structures_pb_1.AREA_JOB_TYPES.AREA_NONE,
                            syncStatus: home_structures_pb_1.AREA_SYNC_STATES.AREAINSYNC
                        }
                    });
                    await keus_home_1.default.addFloor({
                        floorId: HomeConstants.DefaultFloorId,
                        floorName: HomeConstants.DefaultFloorName
                    });
                    await keus_home_1.default.addRoom({
                        roomId: HomeConstants.DefaultRoomId,
                        roomName: HomeConstants.DefaultRoomName,
                        areaId: HomeConstants.DefaultAreaId,
                        floorId: HomeConstants.DefaultFloorId,
                        roomImageType: HomeConstants.RoomImageTypeList[0],
                        roomType: HomeConstants.RoomTypeMap.DEFAULT,
                        sectionList: [
                            {
                                sectionId: HomeConstants.DefaultSectionId,
                                sectionName: HomeConstants.DefaultSectionName
                            }
                        ]
                    });
                    let userObj = {
                        phone: SystemConstants.SystemNumber,
                        email: '',
                        emailVerified: true,
                        phoneVerified: true,
                        userName: SystemConstants.SystemUser,
                        location: 'Home',
                        lastUpdatedTime: Date.now(),
                        gender: 'any',
                        dateOfBirth: Date.now(),
                        homesList: JSON.stringify([
                            { gatewayId: configureData.getGatewayId(), accessLevel: 3, roomsList: [] }
                        ]),
                        favoriteHome: configureData.getGatewayId()
                    };
                    await keus_user_1.default.insertUser(userObj);
                    try {
                        let ipGateway = await internalIp.v4();
                        console.log('this is ops api url', SystemConstants.opsCloudApiUrl + SystemConstants.opsEndPointRegisterGatewayToCloud);
                        let registerGatewayToCloudResp = await ApiUtils.makePostRequest(SystemConstants.opsCloudApiUrl + SystemConstants.opsEndPointRegisterGatewayToCloud, {
                            gatewayId: newGatewayObj.gatewayId,
                            gatewayKey: newGatewayObj.gatewayKey,
                            gatewayIp: ipGateway
                        });
                        console.log('gateway configured success');
                        if (registerGatewayToCloudResp.success) {
                            await keus_gateway_1.default.makeRegisterMasterToCloudTrue(newGatewayObj.gatewayId);
                            final_resp = response_1.default.getConfigureGatewaySuccessful();
                        }
                        else if (registerGatewayToCloudResp.code == 802) {
                            await keus_gateway_1.default.setWronglyConfiguredTrue(newGatewayObj.gatewayId);
                            await keus_home_1.default.deleteRoomById(HomeConstants.DefaultRoomId);
                            await keus_home_1.default.deleteFloorById(HomeConstants.DefaultFloorId);
                            await keus_home_1.default.deleteAreaById(HomeConstants.DefaultAreaId);
                            await keus_user_1.default.deleteUserById(userObj.phone);
                            final_resp = response_1.default.GatewayAlreadyUsedInCloud();
                        }
                        else {
                            console.log(registerGatewayToCloudResp);
                            final_resp = response_1.default.getConfigureGatewaywithoutcloudSuccessful(registerGatewayToCloudResp.message);
                        }
                    }
                    catch (e) {
                        console.log('register master to cloud api error', e);
                        final_resp = response_1.default.getConfigureGatewaySuccessCloudConnectionError();
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    default:
                        console.log('configure gateway error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map