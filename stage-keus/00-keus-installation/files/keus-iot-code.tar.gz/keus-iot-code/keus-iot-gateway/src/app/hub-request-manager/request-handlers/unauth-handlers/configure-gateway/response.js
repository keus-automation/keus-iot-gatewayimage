"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_setup_pb_1 = require("../../../protos/generated/hub/gatewaysetup/gateway_setup_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class ConfigureGatewayResp {
    static getConfigureGatewaySuccessful() {
        const resp = new gateway_setup_pb_1.ConfigureGatewayResponse();
        resp.setCode(800);
        resp.setMessage('gateway configured successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGatewayResp.responseType);
    }
    static getConfigureGatewaywithoutcloudSuccessful(e) {
        const resp = new gateway_setup_pb_1.ConfigureGatewayResponse();
        resp.setCode(801);
        resp.setMessage('Cloud Api Error' + e);
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGatewayResp.responseType);
    }
    static getConfigureGatewaySuccessCloudConnectionError() {
        const resp = new gateway_setup_pb_1.ConfigureGatewayResponse();
        resp.setCode(802);
        resp.setMessage('gateway configured successful cloud connection error');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGatewayResp.responseType);
    }
    static GatewayAlreadyUsedInCloud() {
        const resp = new gateway_setup_pb_1.ConfigureGatewayResponse();
        resp.setCode(803);
        resp.setMessage('gateway already in use please use new gateway details');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGatewayResp.responseType);
    }
    static getGatewayAlreadyConfigured() {
        const resp = new gateway_setup_pb_1.ConfigureGatewayResponse();
        resp.setCode(804);
        resp.setMessage('Gateway Already Configured');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGatewayResp.responseType);
    }
    static getInternalServerError() {
        const resp = new gateway_setup_pb_1.ConfigureGatewayResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), ConfigureGatewayResp.responseType);
    }
}
exports.default = ConfigureGatewayResp;
ConfigureGatewayResp.responseType = system_constants_1.ProtoPackageName + '.ConfigureGatewayResponse';
//# sourceMappingURL=response.js.map