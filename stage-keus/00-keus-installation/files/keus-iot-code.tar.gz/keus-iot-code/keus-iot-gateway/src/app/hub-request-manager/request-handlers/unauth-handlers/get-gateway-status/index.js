"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const gateway_setup_pb_1 = require("../../../protos/generated/hub/gatewaysetup/gateway_setup_pb");
const response_1 = __importDefault(require("./response"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const home_utils_2 = require("../../../../../utilities/gateway/home-utils");
const timed_promise_1 = require("../../../../../utilities/timed-promise");
exports.default = async (configureData) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                let gatewayStatus = new gateway_setup_pb_1.GatewayStatus();
                if (gatewayDetails.length) {
                    let users = await keus_user_1.default.getAllUsers();
                    let gateways = await keus_gateway_1.default.getGateway();
                    gatewayStatus.setGatewayId(gatewayDetails[0].gatewayId);
                    gatewayStatus.setIsConfigured(gatewayDetails[0].isConfigured);
                    gatewayStatus.setIsRegisteredToCloud(gatewayDetails[0].isRegisteredToCloud);
                    gatewayStatus.setIsSuperUserAssigned(await home_utils_2.checkForSuperUser(users, gateways));
                    gatewayStatus.setSuperUserPhone(await home_utils_1.getSuperUser(users, gateways));
                    gatewayStatus.setGatewayMode(gateway_setup_pb_1.GatewayModes.GATEWAY_MAIN);
                }
                else {
                    gatewayStatus.setGatewayId('');
                    gatewayStatus.setIsConfigured(false);
                    gatewayStatus.setIsRegisteredToCloud(false);
                    gatewayStatus.setIsSuperUserAssigned(false);
                    gatewayStatus.setGatewayMode(gateway_setup_pb_1.GatewayModes.GATEWAY_MAIN);
                }
                final_resp = response_1.default.getGatewayStatusSuccess(gatewayStatus);
            }
            catch (e) {
                switch (e.constructor) {
                    default:
                        console.log('get gateway status error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map