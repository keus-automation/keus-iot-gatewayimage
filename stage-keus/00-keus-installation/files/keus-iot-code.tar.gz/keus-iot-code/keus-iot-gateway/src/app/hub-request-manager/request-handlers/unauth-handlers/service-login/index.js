"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const home_utils_1 = require("../../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const keus_userdevice_1 = __importDefault(require("../../../../../models/database-models/keus-userdevice"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
exports.default = async (reqData) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                if (!gatewayDetails.length) {
                    final_resp = response_1.default.getGatewayNotConfigured();
                }
                let seed = gatewayDetails[0].seed;
                let serviceUser = await home_utils_1.decryptStringWithSeed(reqData.getServiceUser(), seed);
                let serviceUserPassword = await home_utils_1.decryptStringWithSeed(reqData.getServiceUserPassword(), seed);
                if (gatewayDetails[0].serviceUser != serviceUser) {
                    final_resp = response_1.default.getServiceUserDoesntHaveAccess();
                }
                if (gatewayDetails[0].serviceUserPassword != serviceUserPassword) {
                    final_resp = response_1.default.getInvalidServiceUserPassword();
                }
                else {
                    let user = await keus_user_1.default.getUserByPhone(serviceUser);
                    if (!user) {
                        let userObj = {
                            phone: serviceUser,
                            email: serviceUserPassword,
                            emailVerified: true,
                            phoneVerified: true,
                            userName: 'demo user',
                            location: 'ops office',
                            lastUpdatedTime: Date.now(),
                            gender: 'any',
                            dateOfBirth: Date.now(),
                            homesList: JSON.stringify([
                                { gatewayId: gatewayDetails[0].gatewayId, accessLevel: 3, roomsList: [] }
                            ]),
                            favoriteHome: gatewayDetails[0].gatewayId
                        };
                        await keus_user_1.default.insertUser(userObj);
                    }
                    let userDeviceDetails = await keus_userdevice_1.default.authenticateUserDevice({
                        deviceId: reqData.getDeviceId(),
                        deviceName: reqData.getDeviceName(),
                        phone: serviceUser,
                        remember: false,
                        deviceType: reqData.getDeviceType(),
                        servicePhone: reqData.getServicePhone()
                    });
                    final_resp = response_1.default.getServiceLoginSuccess(userDeviceDetails.deviceKey, userDeviceDetails.secretKey);
                    console.log('Successfully sent device key & secret key', userDeviceDetails.deviceKey, userDeviceDetails.secretKey);
                }
            }
            catch (e) {
                switch (e.constructor) {
                    default:
                        console.log('get service login error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map