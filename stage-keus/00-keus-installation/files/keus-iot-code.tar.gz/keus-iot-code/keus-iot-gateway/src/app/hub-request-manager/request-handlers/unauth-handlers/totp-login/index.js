"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const response_1 = __importDefault(require("./response"));
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const keus_userdevice_1 = __importDefault(require("../../../../../models/database-models/keus-userdevice"));
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const errors_1 = require("../../../../../errors/errors");
const otplib_1 = require("otplib");
exports.default = async (reqData) => {
    return timed_promise_1.TPromise(function () {
        return new Promise(async function (resolve, reject) {
            let final_resp;
            try {
                console.log('this is totp phone ', reqData.getPhone());
                let user = await keus_user_1.default.getUserByPhone(reqData.getPhone());
                if (!user) {
                    throw new errors_1.GeneralErrors.InvalidUserAccessError();
                }
                else {
                    let homesList = JSON.parse(user.homesList);
                    let totpSecretKey = homesList[0].secretKey;
                    otplib_1.totp.options = {
                        step: 60,
                        window: [1, 0]
                    };
                    let totpValidity = otplib_1.totp.check(`${reqData.getOtp()}`, totpSecretKey);
                    console.log('this is totp validity', totpValidity);
                    if (totpValidity) {
                        let userDeviceDetails = await keus_userdevice_1.default.authenticateUserDevice({
                            deviceId: reqData.getDeviceId(),
                            deviceName: reqData.getDeviceName(),
                            phone: reqData.getPhone(),
                            remember: true,
                            deviceType: reqData.getDeviceType()
                        });
                        final_resp = response_1.default.getTotpLoginSuccess(userDeviceDetails.deviceKey, userDeviceDetails.secretKey);
                        console.log('totp login success');
                    }
                    else {
                        console.log('inavlid otp');
                        final_resp = response_1.default.getInvalidTotpCode();
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.InvalidUserAccessError:
                        final_resp = response_1.default.getUserDoesntHaveAccess();
                        break;
                    default:
                        console.log('get totp login error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(final_resp);
        });
    });
};
//# sourceMappingURL=index.js.map