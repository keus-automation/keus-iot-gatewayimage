"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_pb_1 = require("../../../protos/generated/hub/home/user_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class TotpLoginResp {
    static getTotpLoginSuccess(deviceKey, secretKey) {
        const resp = new user_pb_1.TotpLoginResponse();
        resp.setCode(800);
        resp.setMessage('Service Login Success');
        resp.setSuccess(true);
        resp.setDeviceKey(deviceKey);
        resp.setSecretKey(secretKey);
        return general_1.PackIntoAny(resp.serializeBinary(), TotpLoginResp.responseType);
    }
    static getUserDoesntHaveAccess() {
        const resp = new user_pb_1.TotpLoginResponse();
        resp.setCode(801);
        resp.setMessage('User Doesnt have access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), TotpLoginResp.responseType);
    }
    static getInvalidTotpCode() {
        const resp = new user_pb_1.TotpLoginResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Totp Code');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), TotpLoginResp.responseType);
    }
    static getInternalServerError() {
        const resp = new user_pb_1.TotpLoginResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), TotpLoginResp.responseType);
    }
}
exports.default = TotpLoginResp;
TotpLoginResp.responseType = system_constants_1.ProtoPackageName + '.TotpLoginResponse';
//# sourceMappingURL=response.js.map