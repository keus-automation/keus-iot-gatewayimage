"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const AlexaVoiceUtils = __importStar(require("../alexa-voice-utils"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const device_categories_1 = __importDefault(require("../../../../../constants/device/device-categories"));
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const keus_ir_remote_1 = __importDefault(require("../../../../../models/database-models/keus-ir-remote"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (alexaDiscoverReq) => {
    return timed_promise_1.TPromise(function () {
        console.log('alexa discover devices');
        return new Promise(async function (resolve, reject) {
            try {
                const alexaDeviceList = [];
                const roomList = await keus_home_1.default.getAllRooms();
                const deviceList = await keus_device_1.default.getAllDevices();
                // //Get Group devices
                const groupList = await keus_group_1.default.getAllGroups();
                groupList.forEach(function (grp) {
                    const grpDevice = AlexaVoiceUtils.getAlexaVoiceGroupDevice(grp, roomList);
                    if (grpDevice) {
                        alexaDeviceList.push(JSON.stringify(grpDevice));
                    }
                });
                //Get Scene Devices
                const sceneList = await keus_scene_1.default.getAllScenes();
                sceneList.forEach(function (scn) {
                    const scnDevice = AlexaVoiceUtils.getAlexaVoiceSceneDevice(scn, roomList);
                    if (scnDevice) {
                        alexaDeviceList.push(JSON.stringify(scnDevice));
                    }
                });
                // //Get Curtain Devices
                const curtainDevices = deviceList.filter(function (dev) {
                    return (dev.deviceCategory ==
                        device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode && !dev.inGroup);
                });
                curtainDevices.forEach(function (crt) {
                    const crtDevice = AlexaVoiceUtils.getAlexaVoiceCurtainDevice(crt, roomList);
                    if (crtDevice) {
                        alexaDeviceList.push(JSON.stringify(crtDevice));
                    }
                });
                // embedded appliances
                const embeddedAppliance = deviceList.filter(function (dev) {
                    return dev.deviceCategory == device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode;
                });
                embeddedAppliance.forEach(function (esApp) {
                    const esProps = esApp.deviceProperties;
                    const applianceList = esProps.appliance;
                    applianceList.forEach(function (app) {
                        const applianceDev = AlexaVoiceUtils.getAlexaVoiceEmbeddedAppliance(esApp, app, roomList);
                        console.log("current appliance is ", applianceDev);
                        if (applianceDev) {
                            alexaDeviceList.push(JSON.stringify(applianceDev));
                        }
                    });
                });
                // //Get AC Fan Controller Devices
                const acFanDevices = deviceList.filter(function (dev) {
                    return (dev.deviceCategory ==
                        device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceCategoryCode && !dev.inGroup);
                });
                acFanDevices.forEach(function (acfan) {
                    const acFanDevice = AlexaVoiceUtils.getAlexaAcFanDevice(acfan, roomList);
                    if (acFanDevice) {
                        alexaDeviceList.push(JSON.stringify(acFanDevice));
                    }
                });
                // // //Get DC Fan Controller Devices
                const dcFanDevices = deviceList.filter(function (dev) {
                    return (dev.deviceCategory ==
                        device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER').deviceCategoryCode && !dev.inGroup);
                });
                dcFanDevices.forEach(function (dcFan) {
                    const dcFanDevice = AlexaVoiceUtils.getAlexaDcFanDevice(dcFan, roomList);
                    if (dcFanDevice) {
                        alexaDeviceList.push(JSON.stringify(dcFanDevice));
                    }
                });
                // //Get Smart Console Relays
                const scDevices = deviceList.filter(function (dev) {
                    return dev.deviceCategory == device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode;
                });
                scDevices.forEach(function (sc) {
                    const devProps = sc.deviceProperties;
                    devProps.buttons.forEach(function (btn) {
                        if (btn.buttonType == device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_RELAYCONTROLLER) {
                            const rlyProps = btn.buttonProperties;
                            const relay = devProps.relays.find(function (rly) {
                                return rly.relayId == rlyProps.relayId;
                            });
                            if (relay) {
                                const scRelayDevice = AlexaVoiceUtils.getAlexaVoiceSCRelayDevice(relay, roomList, sc);
                                if (scRelayDevice) {
                                    alexaDeviceList.push(JSON.stringify(scRelayDevice));
                                }
                            }
                        }
                    });
                });
                // //Get IR AC Remotes
                const irRemotes = await keus_ir_remote_1.default.getAllIRRemotes();
                const acRemotes = irRemotes.filter(function (rmt) {
                    return rmt.remoteType == device_constants_pb_1.IR_REMOTE_TYPES.IR_AC;
                });
                acRemotes.forEach(function (acRmt) {
                    const irDevice = deviceList.find(function (dev) {
                        return dev.deviceId == acRmt.irDevice;
                    });
                    if (irDevice) {
                        const irACDevice = AlexaVoiceUtils.getAlexaVoiceIRACDevice(acRmt, roomList, irDevice);
                        if (irACDevice) {
                            alexaDeviceList.push(JSON.stringify(irACDevice));
                        }
                    }
                });
                // //Get Room Lights (All On & All Off map for rooms)
                roomList.forEach(function (room) {
                    room.sectionList.forEach(function (section) {
                        const roomDevice = AlexaVoiceUtils.getAlexaVoiceFullRoomDevice(room, section);
                        if (roomDevice) {
                            alexaDeviceList.push(JSON.stringify(roomDevice));
                        }
                    });
                });
                // //Get RBGWWA
                const rgbwwaDevices = deviceList.filter(function (device) {
                    return (device.deviceCategory ==
                        device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceCategoryCode && !device.inGroup);
                });
                rgbwwaDevices.forEach(function (rgbwwa) {
                    const rgbwwaDevice = AlexaVoiceUtils.getAlexaVoiceRGBWWADevice(rgbwwa, roomList);
                    if (rgbwwaDevice) {
                        alexaDeviceList.push(JSON.stringify(rgbwwaDevice));
                    }
                });
                const gatewayList = await keus_gateway_1.default.getGateway();
                const mainGateway = gatewayList.find(function (gtw) {
                    return gtw.gatewayMode == system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY;
                });
                const filteredUserList = mainGateway.alexaLinkedUserList.filter(function (ph) {
                    return ph != alexaDiscoverReq.getPhone();
                });
                filteredUserList.push(alexaDiscoverReq.getPhone());
                await keus_gateway_1.default.setAlexaLinkStatus(mainGateway.gatewayId, true, filteredUserList);
                console.log("this is alexa list count", alexaDeviceList.length);
                resolve(response_1.default.getDiscoverDevicesSuccessful(alexaDeviceList));
            }
            catch (e) {
                switch (e.constructor) {
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map