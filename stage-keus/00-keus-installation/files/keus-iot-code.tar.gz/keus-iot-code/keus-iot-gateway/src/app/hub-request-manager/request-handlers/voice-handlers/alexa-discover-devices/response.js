"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const alexa_pb_1 = require("../../../protos/generated/hub/voice/alexa_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class AlexaDiscoverDevicesResp {
    static getDiscoverDevicesSuccessful(deviceList) {
        const resp = new alexa_pb_1.AlexaDiscoverDevicesResponse();
        resp.setCode(800);
        resp.setMessage('Discover Devices Successful');
        resp.setSuccess(true);
        resp.setAlexaEndpointsList(deviceList);
        return general_1.PackIntoAny(resp.serializeBinary(), AlexaDiscoverDevicesResp.responseType);
    }
    static getInternalServerError() {
        const resp = new alexa_pb_1.AlexaDiscoverDevicesResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), AlexaDiscoverDevicesResp.responseType);
    }
}
exports.default = AlexaDiscoverDevicesResp;
AlexaDiscoverDevicesResp.responseType = system_constants_1.ProtoPackageName + '.AlexaDiscoverDevicesResponse';
//# sourceMappingURL=response.js.map