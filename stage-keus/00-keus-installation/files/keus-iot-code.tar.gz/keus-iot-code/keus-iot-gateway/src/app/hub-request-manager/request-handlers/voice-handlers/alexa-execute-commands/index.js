"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const VH = __importStar(require("../alexa-voice-utils"));
const HomeUtils = __importStar(require("../../../../../utilities/gateway/home-utils"));
const errors_1 = require("../../../../../errors/errors");
const scene_structures_pb_1 = require("../../../protos/generated/hub/scenes/scene_structures_pb");
const scene_handlers_1 = require("../../scene-handlers");
const zigbee_ac_fan_controller_pb_1 = require("../../../protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const dali_dimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/dali_dimmable_driver_pb");
const zigbee_embedded_switch_pb_1 = require("../../../protos/generated/hub/devices/zigbee_embedded_switch_pb");
const zigbee_dimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_dimmable_driver_pb");
const dali_nondimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/dali_nondimmable_driver_pb");
const zigbee_nondimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_nondimmable_driver_pb");
const zigbee_embedded_switch_pb_2 = require("../../../protos/generated/hub/devices/zigbee_embedded_switch_pb");
const group_handlers_1 = require("../../group-handlers");
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const zigbee_curtain_controller_pb_1 = require("../../../protos/generated/hub/devices/zigbee_curtain_controller_pb");
const zigbee_curtain_controller_1 = require("../../device-handlers/zigbee-curtain-controller");
const zigbee_fan_controllers_1 = require("../../device-handlers/zigbee-fan-controllers");
const zigbee_dc_fan_controller_pb_1 = require("../../../protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const smart_console_pb_1 = require("../../../protos/generated/hub/devices/smart_console_pb");
const smart_consoles_1 = require("../../device-handlers/smart-consoles");
const zigbee_ir_blaster_pb_1 = require("../../../protos/generated/hub/devices/zigbee_ir_blaster_pb");
const zigbee_ir_blaster_1 = require("../../device-handlers/zigbee-ir-blaster");
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const zigbee_rgbwwa_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const update_rgbwwa_state_1 = __importDefault(require("../../device-handlers/zigbee-rgbwwa-drivers/update-rgbwwa-state"));
const rpc_maker_util_1 = require("../../../../../utilities/gateway/rpc-maker-util");
const zigbee_inline_dimmer_pb_1 = require("../../../protos/generated/hub/devices/zigbee_inline_dimmer_pb");
const keus_ir_remote_1 = __importDefault(require("../../../../../models/database-models/keus-ir-remote"));
const update_appliance_state_1 = __importDefault(require("../../device-handlers/zigbee-embedded-switches/update-appliance-state"));
const dali_color_tunable_driver_pb_1 = require("../../../protos/generated/hub/devices/dali_color_tunable_driver_pb");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (alexaExecReq) => {
    return timed_promise_1.TPromise(function () {
        console.log('Hit alexa Execute Command');
        return new Promise(async function (resolve, reject) {
            const alexaRequest = JSON.parse(alexaExecReq.getRequestData());
            const requestNamespace = alexaRequest.directive.header.namespace;
            const requestName = alexaRequest.directive.header.name;
            const requestPayload = alexaRequest.directive.payload;
            const errResponseForAlexa = {
                "event": {
                    "header": {
                        "namespace": "Alexa",
                        "name": "ErrorResponse",
                        "messageId": alexaRequest.directive.header.messageId,
                        "payloadVersion": "3"
                    },
                    "endpoint": {
                        "endpointId": alexaRequest.directive.endpoint.endpointId
                    },
                    "payload": {
                        "type": "ENDPOINT_UNREACHABLE",
                        "message": "The endpoint is unreachable or offline",
                    }
                }
            };
            const headerNotSupported = {
                "event": {
                    "header": {
                        "namespace": "Alexa",
                        "name": "ErrorResponse",
                        "messageId": alexaRequest.directive.header.messageId,
                        "payloadVersion": "3"
                    },
                    "endpoint": {
                        "endpointId": alexaRequest.directive.endpoint.endpointId
                    },
                    "payload": {
                        "type": "INVALID_DIRECTIVE",
                        "message": "The directive is not supported by the skill, or is malformed.",
                    }
                }
            };
            try {
                console.log('Hit alexa Execute Command in try');
                const keusDev = VH.getKeusId(alexaRequest.directive.endpoint.endpointId);
                console.log('this is keus endpoint-----------------', alexaRequest.directive.endpoint.endpointId);
                const user = await keus_user_1.default.getUserByPhone(alexaExecReq.getPhone());
                if (!HomeUtils.checkUserIsAdmin(user)) {
                    throw new errors_1.GeneralErrors.InvalidUserAccessError();
                }
                else {
                    console.log('this is kdevice split ------------', keusDev);
                    switch (keusDev.kDevType) {
                        case VH.kVoiceSceneDevice:
                            if (requestNamespace == 'Alexa.SceneController' && requestName == 'Activate') {
                                const executeSceneReq = new scene_structures_pb_1.ExecuteScene();
                                executeSceneReq.setSceneId(keusDev.sceneId);
                                executeSceneReq.setSceneRoom(keusDev.sceneRoom);
                                const executeSceneResp = rpc_maker_util_1.UnPackFromAny(await scene_handlers_1.ExecuteScene(executeSceneReq, alexaExecReq.getPhone()));
                                if (executeSceneResp.getSuccess()) {
                                    console.log("-------------------scene exe success");
                                    resolve(response_1.default.getSendResponse(JSON.stringify({
                                        "event": {
                                            "header": {
                                                "namespace": "Alexa.SceneController",
                                                "name": "ActivationStarted",
                                                "messageId": alexaRequest.directive.header.messageId,
                                                "correlationToken": alexaRequest.directive.header.correlationToken,
                                                "payloadVersion": "3"
                                            },
                                            "endpoint": {
                                                "scope": {
                                                    "type": "BearerToken",
                                                    "token": alexaRequest.directive.endpoint.scope.token
                                                },
                                                "endpointId": alexaRequest.directive.endpoint.endpointId
                                            },
                                            "payload": {
                                                "cause": {
                                                    "type": "VOICE_INTERACTION"
                                                },
                                                "timestamp": new Date().toISOString()
                                            }
                                        },
                                        "context": {}
                                    })));
                                }
                                else {
                                    console.log("-------------------scene exe fail");
                                    resolve(response_1.default.getSendResponse(JSON.stringify(errResponseForAlexa)));
                                }
                            }
                            else {
                                resolve(response_1.default.getSendResponse(JSON.stringify(headerNotSupported)));
                            }
                            break;
                        case VH.kVoiceGroupDevice:
                            console.log('came in group control');
                            let groupResp;
                            let grpRespContext;
                            const execGroup = await keus_group_1.default.getGroupById(keusDev.groupId, keusDev.groupRoom);
                            const updateGroupStateReq = new group_structures_pb_1.UpdateGroupState();
                            if (!execGroup) {
                                groupResp = errResponseForAlexa;
                            }
                            else {
                                updateGroupStateReq.setGroupId(execGroup.groupId);
                                updateGroupStateReq.setGroupRoom(execGroup.groupRoom);
                                switch (execGroup.groupType) {
                                    case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
                                        const daliDimmableGrpStateReq = new dali_dimmable_driver_pb_1.DaliDimmableDriverState();
                                        if (requestNamespace == "Alexa.PowerController") {
                                            requestName == 'TurnOn' ? daliDimmableGrpStateReq.setDriverState(255) : daliDimmableGrpStateReq.setDriverState(0);
                                            updateGroupStateReq.setDdimmableDriverState(daliDimmableGrpStateReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else if (requestNamespace == "Alexa.BrightnessController" && requestName == 'SetBrightness') {
                                            console.log('this is brigntness update', Math.round(255 * (requestPayload.brightness / 100)));
                                            daliDimmableGrpStateReq.setDriverState(Math.round(255 * (requestPayload.brightness / 100)));
                                            updateGroupStateReq.setDdimmableDriverState(daliDimmableGrpStateReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.BrightnessController",
                                                        "name": "brightness",
                                                        "value": requestPayload.brightness,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            groupResp = headerNotSupported;
                                        }
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
                                        const daliColorTunableGrpStateReq = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverState();
                                        let gDctState = execGroup.groupState;
                                        daliColorTunableGrpStateReq.setLastUpdateBy(alexaExecReq.getPhone());
                                        daliColorTunableGrpStateReq.setLastUpdateSource('alexa');
                                        daliColorTunableGrpStateReq.setLastUpdateTime(Date.now());
                                        daliColorTunableGrpStateReq.setLastUpdateUser('Alexa');
                                        switch (requestNamespace) {
                                            case "Alexa.ColorTemperatureController":
                                                if (requestName == "SetColorTemperature") {
                                                    daliColorTunableGrpStateReq.setDriverState(255);
                                                    daliColorTunableGrpStateReq.setColorTemperature(requestPayload.colorTemperatureInKelvin);
                                                    updateGroupStateReq.setDcolortunableDriverState(daliColorTunableGrpStateReq);
                                                    grpRespContext = {
                                                        "properties": [
                                                            {
                                                                "namespace": "Alexa.ColorTemperatureController",
                                                                "name": "colorTemperatureInKelvin",
                                                                "value": requestPayload.colorTemperatureInKelvin,
                                                                "timeOfSample": new Date().toISOString(),
                                                                "uncertaintyInMilliseconds": 500
                                                            }
                                                        ]
                                                    };
                                                }
                                                else {
                                                    groupResp = headerNotSupported;
                                                }
                                                break;
                                            case "Alexa.PowerController":
                                                requestName == 'TurnOn' ? daliColorTunableGrpStateReq.setDriverState(255) : daliColorTunableGrpStateReq.setDriverState(0);
                                                daliColorTunableGrpStateReq.setColorTemperature(gDctState.colorTemperature);
                                                updateGroupStateReq.setDcolortunableDriverState(daliColorTunableGrpStateReq);
                                                grpRespContext = {
                                                    "properties": [
                                                        {
                                                            "namespace": "Alexa.PowerController",
                                                            "name": "powerState",
                                                            "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                            "timeOfSample": new Date().toISOString(),
                                                            "uncertaintyInMilliseconds": 500
                                                        }
                                                    ]
                                                };
                                                break;
                                            default:
                                                groupResp = errResponseForAlexa;
                                        }
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
                                        const zigbeeDimmableGrpStateReq = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverState();
                                        if (requestNamespace == "Alexa.PowerController") {
                                            requestName == 'TurnOn' ? zigbeeDimmableGrpStateReq.setDriverState(255) : zigbeeDimmableGrpStateReq.setDriverState(0);
                                            updateGroupStateReq.setZdimmableDriverState(zigbeeDimmableGrpStateReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else if (requestNamespace == "Alexa.BrightnessController" && requestName == 'SetBrightness') {
                                            console.log('this is brigntness update', Math.round(255 * (requestPayload.brightness / 100)));
                                            zigbeeDimmableGrpStateReq.setDriverState(Math.round(255 * (requestPayload.brightness / 100)));
                                            updateGroupStateReq.setZdimmableDriverState(zigbeeDimmableGrpStateReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.BrightnessController",
                                                        "name": "brightness",
                                                        "value": requestPayload.brightness,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            groupResp = headerNotSupported;
                                        }
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
                                        const daliNonDimmableGrpStateReq = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverState();
                                        if (requestNamespace == "Alexa.PowerController") {
                                            requestName == 'TurnOn' ? daliNonDimmableGrpStateReq.setDriverState(255) : daliNonDimmableGrpStateReq.setDriverState(0);
                                            updateGroupStateReq.setDnondimmableDriverState(daliNonDimmableGrpStateReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            groupResp = headerNotSupported;
                                        }
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
                                        const zigbeeNonDimmableGrpStateReq = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverState();
                                        if (requestNamespace == "Alexa.PowerController") {
                                            requestName == 'TurnOn' ? zigbeeNonDimmableGrpStateReq.setDriverState(255) : zigbeeNonDimmableGrpStateReq.setDriverState(0);
                                            updateGroupStateReq.setZnondimmableDriverState(zigbeeNonDimmableGrpStateReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            groupResp = headerNotSupported;
                                        }
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
                                        const zigbeeInlineGrpStateReq = new zigbee_inline_dimmer_pb_1.ZigbeeInlineDimmerState();
                                        if (requestNamespace == "Alexa.PowerController") {
                                            requestName == 'TurnOn' ? zigbeeInlineGrpStateReq.setDeviceState(255) : zigbeeInlineGrpStateReq.setDeviceState(0);
                                            updateGroupStateReq.setZinlineDimmerState(zigbeeInlineGrpStateReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else if (requestNamespace == "Alexa.BrightnessController" && requestName == 'SetBrightness') {
                                            console.log('this is brigntness update', Math.round(255 * (requestPayload.brightness / 100)));
                                            zigbeeInlineGrpStateReq.setDeviceState(Math.round(255 * (requestPayload.brightness / 100)));
                                            updateGroupStateReq.setZinlineDimmerState(zigbeeInlineGrpStateReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.BrightnessController",
                                                        "name": "brightness",
                                                        "value": requestPayload.brightness,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            groupResp = headerNotSupported;
                                        }
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
                                        const applianceOnOffGrpReq = new zigbee_embedded_switch_pb_2.OnOffApplianceState();
                                        if (requestNamespace == "Alexa.PowerController") {
                                            requestName == 'TurnOn' ? applianceOnOffGrpReq.setSwitchState(255) : applianceOnOffGrpReq.setSwitchState(0);
                                            updateGroupStateReq.setAppOnffState(applianceOnOffGrpReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            groupResp = headerNotSupported;
                                        }
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                                        const applianceSDimmerGrpReq = new zigbee_embedded_switch_pb_2.SingleDimmerApplianceState();
                                        if (requestNamespace == "Alexa.PowerController") {
                                            requestName == 'TurnOn' ? applianceSDimmerGrpReq.setSwitchState(255) : applianceSDimmerGrpReq.setSwitchState(0);
                                            updateGroupStateReq.setAppSingleDimmerState(applianceSDimmerGrpReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else if (requestNamespace == "Alexa.BrightnessController" && requestName == 'SetBrightness') {
                                            console.log('this is brightness value', Math.round(255 * (requestPayload.brightness / 100)));
                                            applianceSDimmerGrpReq.setSwitchState(Math.round(255 * (requestPayload.brightness / 100)));
                                            updateGroupStateReq.setAppSingleDimmerState(applianceSDimmerGrpReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.BrightnessController",
                                                        "name": "brightness",
                                                        "value": requestPayload.brightness,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            groupResp = headerNotSupported;
                                        }
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                                        const applianceFanGrpReq = new zigbee_embedded_switch_pb_2.FanApplianceState();
                                        if (requestNamespace == "Alexa.PowerController") { //change values
                                            requestName == 'TurnOn' ? applianceFanGrpReq.setFanState(255) : applianceFanGrpReq.setFanState(0);
                                            updateGroupStateReq.setAppFanState(applianceFanGrpReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else if (requestNamespace == "Alexa.RangeController" && requestName == 'SetRangeValue') {
                                            console.log('this is fan mode level', Math.round(255 * (requestPayload.rangeValue / 4)));
                                            applianceFanGrpReq.setFanState(Math.round(255 * (requestPayload.rangeValue / 4)));
                                            updateGroupStateReq.setAppFanState(applianceFanGrpReq);
                                            grpRespContext = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.RangeController",
                                                        "instance": "Fan.Speed",
                                                        "name": "rangeValue",
                                                        "value": requestPayload.rangeValue,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            groupResp = headerNotSupported;
                                        }
                                        break;
                                    // case GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                                    //     break;
                                    case group_structures_pb_1.GROUP_TYPES.RGBWWA:
                                        let grpRgbwwaReq = new zigbee_rgbwwa_driver_pb_1.GroupZigbeeRgbwwaState();
                                        let grgbWWAState = execGroup.groupState;
                                        grpRgbwwaReq.setDeviceState(255);
                                        switch (requestNamespace) {
                                            case "Alexa.ColorController":
                                                if (requestName == "SetColor") {
                                                    grpRgbwwaReq.setUpdateType(device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE);
                                                    let rgbConverted = VH.hsLToRgb(requestPayload.color.hue, requestPayload.color.saturation, requestPayload.color.brightness);
                                                    let rgbParams = new zigbee_rgbwwa_driver_pb_1.RGB();
                                                    console.log('this is hsl incoming values', requestPayload.color);
                                                    console.log("-------------------this is rgb converted values------------", rgbConverted);
                                                    rgbParams.setRed(rgbConverted[0]);
                                                    rgbParams.setGreen(rgbConverted[1]);
                                                    rgbParams.setBlue(rgbConverted[2]);
                                                    rgbParams.setPattern(grgbWWAState.rgbState.pattern);
                                                    rgbParams.setDeviceState(255);
                                                    grpRgbwwaReq.setRgbState(rgbParams);
                                                    grpRespContext = {
                                                        "properties": [
                                                            {
                                                                "namespace": "Alexa.ColorController",
                                                                "name": "color",
                                                                "value": {
                                                                    "hue": requestPayload.color.hue,
                                                                    "saturation": requestPayload.color.saturation,
                                                                    "brightness": requestPayload.color.brightness
                                                                },
                                                                "timeOfSample": new Date().toISOString(),
                                                                "uncertaintyInMilliseconds": 500
                                                            }
                                                        ]
                                                    };
                                                }
                                                else {
                                                    groupResp = headerNotSupported;
                                                }
                                                break;
                                            case "Alexa.ColorTemperatureController":
                                                if (requestName == "SetColorTemperature") {
                                                    grpRgbwwaReq.setUpdateType(device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE);
                                                    let cw = Math.min(255, requestPayload.colorTemperatureInKelvin >= VH.rgbwwaMidtemp
                                                        ? 255
                                                        : Math.floor(((requestPayload.colorTemperatureInKelvin - VH.rgbwwaMinTemp) / (VH.rgbwwaMaxTemp + 1 - requestPayload.colorTemperatureInKelvin)) * 255));
                                                    let ww = Math.min(255, requestPayload.colorTemperatureInKelvin <= VH.rgbwwaMidtemp
                                                        ? 255
                                                        : Math.floor(((VH.rgbwwaMaxTemp - requestPayload.colorTemperatureInKelvin) / (requestPayload.colorTemperatureInKelvin + 1 - VH.rgbwwaMinTemp)) * 255));
                                                    const wwaParams = new zigbee_rgbwwa_driver_pb_1.WWA();
                                                    wwaParams.setAmber(0);
                                                    wwaParams.setCoolWhite(cw);
                                                    wwaParams.setWarmWhite(ww);
                                                    wwaParams.setDeviceState(255);
                                                    console.log('/n wwa state', ww, "/n coolwhite", cw);
                                                    grpRgbwwaReq.setWwaState(wwaParams);
                                                    grpRespContext = {
                                                        "properties": [
                                                            {
                                                                "namespace": "Alexa.ColorTemperatureController",
                                                                "name": "colorTemperatureInKelvin",
                                                                "value": requestPayload.colorTemperatureInKelvin,
                                                                "timeOfSample": new Date().toISOString(),
                                                                "uncertaintyInMilliseconds": 500
                                                            }
                                                        ]
                                                    };
                                                }
                                                else {
                                                    groupResp = headerNotSupported;
                                                }
                                                break;
                                            case "Alexa.PowerController":
                                                requestName == 'TurnOn' ? grpRgbwwaReq.setDeviceState(255) : grpRgbwwaReq.setDeviceState(0);
                                                if (grgbWWAState.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                                                    grpRgbwwaReq.setUpdateType(device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE);
                                                    const rgbU = new zigbee_rgbwwa_driver_pb_1.RGB();
                                                    rgbU.setRed(grgbWWAState.rgbState.red);
                                                    rgbU.setGreen(grgbWWAState.rgbState.green);
                                                    rgbU.setBlue(grgbWWAState.rgbState.blue);
                                                    rgbU.setPattern(grgbWWAState.rgbState.pattern);
                                                    rgbU.setDeviceState(requestName == 'TurnOn' ? 255 : 0);
                                                    grpRgbwwaReq.setRgbState(rgbU);
                                                }
                                                else {
                                                    grpRgbwwaReq.setUpdateType(device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE);
                                                    const wwaU = new zigbee_rgbwwa_driver_pb_1.WWA();
                                                    wwaU.setAmber(grgbWWAState.wwaState.amber);
                                                    wwaU.setCoolWhite(grgbWWAState.wwaState.coolWhite);
                                                    wwaU.setWarmWhite(grgbWWAState.wwaState.warmWhite);
                                                    wwaU.setDeviceState(requestName == 'TurnOn' ? 255 : 0);
                                                    grpRgbwwaReq.setWwaState(wwaU);
                                                }
                                                grpRespContext = {
                                                    "properties": [
                                                        {
                                                            "namespace": "Alexa.PowerController",
                                                            "name": "powerState",
                                                            "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                            "timeOfSample": new Date().toISOString(),
                                                            "uncertaintyInMilliseconds": 500
                                                        }
                                                    ]
                                                };
                                                break;
                                        }
                                        updateGroupStateReq.setZrgbwwaState(grpRgbwwaReq);
                                        break;
                                    default:
                                        groupResp = errResponseForAlexa;
                                }
                            }
                            if (!groupResp) {
                                let updateGroupStateResp = rpc_maker_util_1.UnPackFromAny(await group_handlers_1.UpdateGroupState(updateGroupStateReq, alexaExecReq.getPhone()));
                                groupResp = {
                                    "event": {
                                        "header": {
                                            "namespace": "Alexa",
                                            "name": "Response",
                                            "messageId": alexaRequest.directive.header.messageId,
                                            "correlationToken": alexaRequest.directive.header.correlationToken,
                                            "payloadVersion": "3"
                                        },
                                        "endpoint": {
                                            "scope": {
                                                "type": "BearerToken",
                                                "token": alexaRequest.directive.endpoint.scope.token
                                            },
                                            "endpointId": alexaRequest.directive.endpoint.endpointId
                                        },
                                        "payload": {}
                                    },
                                    "context": grpRespContext
                                };
                            }
                            resolve(response_1.default.getSendResponse(JSON.stringify(groupResp)));
                            break;
                        case VH.kVoiceCurtainDevice:
                            let crt_resp;
                            let crtRespContext;
                            const crtDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                            if (!crtDevice) {
                                crt_resp = errResponseForAlexa;
                            }
                            else {
                                const updateCurtainStateReq = new zigbee_curtain_controller_pb_1.UpdateZigbeeCurtainControllerState();
                                updateCurtainStateReq.setDeviceId(crtDevice.deviceId);
                                if (requestNamespace == "Alexa.RangeController" && requestName == 'SetRangeValue') {
                                    requestPayload.rangeValue > 0 ? updateCurtainStateReq.setCurtainState(device_constants_pb_1.CURTAIN_CONTROLLER_ACTION.CC_OPEN) : updateCurtainStateReq.setCurtainState(device_constants_pb_1.CURTAIN_CONTROLLER_ACTION.CC_CLOSE);
                                    crtRespContext = {
                                        "properties": [
                                            {
                                                "namespace": "Alexa.RangeController",
                                                "instance": "Blind.Lift",
                                                "name": "rangeValue",
                                                "value": requestPayload.rangeValue,
                                                "timeOfSample": new Date().toISOString(),
                                                "uncertaintyInMilliseconds": 500
                                            }
                                        ]
                                    };
                                }
                                else {
                                    crt_resp = headerNotSupported;
                                }
                                if (!crt_resp) {
                                    const updateCurtainStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_curtain_controller_1.UpdateZigbeeCurtainControllerState(updateCurtainStateReq, alexaExecReq.getPhone()));
                                    crt_resp = {
                                        "event": {
                                            "header": {
                                                "namespace": "Alexa",
                                                "name": "Response",
                                                "messageId": alexaRequest.directive.header.messageId,
                                                "correlationToken": alexaRequest.directive.header.correlationToken,
                                                "payloadVersion": "3"
                                            },
                                            "endpoint": {
                                                "scope": {
                                                    "type": "BearerToken",
                                                    "token": alexaRequest.directive.endpoint.scope.token
                                                },
                                                "endpointId": alexaRequest.directive.endpoint.endpointId
                                            },
                                            "payload": {}
                                        },
                                        "context": crtRespContext
                                    };
                                }
                            }
                            resolve(response_1.default.getSendResponse(JSON.stringify(crt_resp)));
                            break;
                        case VH.kVoiceACFanDevice:
                            let acFanResp;
                            let acFanContext;
                            const updateACFCStateReq = new zigbee_ac_fan_controller_pb_1.UpdateZigbeeACFanControllerState();
                            updateACFCStateReq.setDeviceId(keusDev.deviceId);
                            if (requestNamespace == "Alexa.PowerController") { //change values
                                requestName == 'TurnOn' ? updateACFCStateReq.setFanState(zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_MAX) : updateACFCStateReq.setFanState(zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_OFF);
                                acFanContext = {
                                    "properties": [
                                        {
                                            "namespace": "Alexa.PowerController",
                                            "name": "powerState",
                                            "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                            "timeOfSample": new Date().toISOString(),
                                            "uncertaintyInMilliseconds": 500
                                        }
                                    ]
                                };
                            }
                            else if (requestNamespace == "Alexa.RangeController" && requestName == 'SetRangeValue') {
                                console.log('this is fan mode level', Math.round(255 * (requestPayload.rangeValue / 4)));
                                updateACFCStateReq.setFanState(requestPayload.rangeValue);
                                acFanContext = {
                                    "properties": [
                                        {
                                            "namespace": "Alexa.RangeController",
                                            "instance": "Fan.Speed",
                                            "name": "rangeValue",
                                            "value": requestPayload.rangeValue,
                                            "timeOfSample": new Date().toISOString(),
                                            "uncertaintyInMilliseconds": 500
                                        }
                                    ]
                                };
                            }
                            else {
                                acFanResp = headerNotSupported;
                            }
                            if (!acFanResp) {
                                updateACFCStateReq.setUpdateType(device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_FAN_UPDATE);
                                const updateACFCStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_fan_controllers_1.UpdateZigbeeACFanControllerState(updateACFCStateReq, alexaExecReq.getPhone()));
                                acFanResp = {
                                    "event": {
                                        "header": {
                                            "namespace": "Alexa",
                                            "name": "Response",
                                            "messageId": alexaRequest.directive.header.messageId,
                                            "correlationToken": alexaRequest.directive.header.correlationToken,
                                            "payloadVersion": "3"
                                        },
                                        "endpoint": {
                                            "scope": {
                                                "type": "BearerToken",
                                                "token": alexaRequest.directive.endpoint.scope.token
                                            },
                                            "endpointId": alexaRequest.directive.endpoint.endpointId
                                        },
                                        "payload": {}
                                    },
                                    "context": acFanContext
                                };
                            }
                            resolve(response_1.default.getSendResponse(JSON.stringify(acFanResp)));
                            break;
                        case VH.kVoiceDCFanDevice:
                            let dcFanResp;
                            let dcFanContext;
                            const updateDCFCStateReq = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerState();
                            updateDCFCStateReq.setDeviceId(keusDev.deviceId);
                            if (requestNamespace == "Alexa.PowerController") { //change values
                                requestName == 'TurnOn' ? updateDCFCStateReq.setFanState(zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_MAX) : updateDCFCStateReq.setFanState(zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_OFF);
                                dcFanContext = {
                                    "properties": [
                                        {
                                            "namespace": "Alexa.PowerController",
                                            "name": "powerState",
                                            "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                            "timeOfSample": new Date().toISOString(),
                                            "uncertaintyInMilliseconds": 500
                                        }
                                    ]
                                };
                            }
                            else if (requestNamespace == "Alexa.RangeController" && requestName == 'SetRangeValue') {
                                console.log('this is fan mode level', Math.round(255 * (requestPayload.rangeValue / 4)));
                                updateDCFCStateReq.setFanState(requestPayload.rangeValue);
                                dcFanContext = {
                                    "properties": [
                                        {
                                            "namespace": "Alexa.RangeController",
                                            "instance": "Fan.Speed",
                                            "name": "rangeValue",
                                            "value": requestPayload.rangeValue,
                                            "timeOfSample": new Date().toISOString(),
                                            "uncertaintyInMilliseconds": 500
                                        }
                                    ]
                                };
                            }
                            else {
                                dcFanResp = headerNotSupported;
                            }
                            if (!dcFanResp) {
                                updateDCFCStateReq.setUpdateType(device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_FAN_UPDATE);
                                const updateDCFCStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_fan_controllers_1.UpdateZigbeeDCFanControllerState(updateDCFCStateReq, alexaExecReq.getPhone()));
                                dcFanResp = {
                                    "event": {
                                        "header": {
                                            "namespace": "Alexa",
                                            "name": "Response",
                                            "messageId": alexaRequest.directive.header.messageId,
                                            "correlationToken": alexaRequest.directive.header.correlationToken,
                                            "payloadVersion": "3"
                                        },
                                        "endpoint": {
                                            "scope": {
                                                "type": "BearerToken",
                                                "token": alexaRequest.directive.endpoint.scope.token
                                            },
                                            "endpointId": alexaRequest.directive.endpoint.endpointId
                                        },
                                        "payload": {}
                                    },
                                    "context": dcFanContext
                                };
                            }
                            resolve(response_1.default.getSendResponse(JSON.stringify(dcFanResp)));
                            break;
                        case VH.kVoiceSCRelayDevice:
                            let relay_resp;
                            let relayContext;
                            const updateSCRelayStateReq = new smart_console_pb_1.SetConsoleRelayState();
                            updateSCRelayStateReq.setDeviceId(keusDev.deviceId);
                            updateSCRelayStateReq.setRelayId(keusDev.relayId);
                            if (requestNamespace == "Alexa.PowerController") {
                                requestName == 'TurnOn' ? updateSCRelayStateReq.setRelayState(255) : updateSCRelayStateReq.setRelayState(0);
                                relayContext = {
                                    "properties": [
                                        {
                                            "namespace": "Alexa.PowerController",
                                            "name": "powerState",
                                            "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                            "timeOfSample": new Date().toISOString(),
                                            "uncertaintyInMilliseconds": 500
                                        }
                                    ]
                                };
                            }
                            else {
                                relay_resp = headerNotSupported;
                            }
                            if (!relay_resp) {
                                const updateSCRelayStateResp = rpc_maker_util_1.UnPackFromAny(await smart_consoles_1.SetConsoleRelayState(updateSCRelayStateReq, alexaExecReq.getPhone()));
                                relay_resp = {
                                    "event": {
                                        "header": {
                                            "namespace": "Alexa",
                                            "name": "Response",
                                            "messageId": alexaRequest.directive.header.messageId,
                                            "correlationToken": alexaRequest.directive.header.correlationToken,
                                            "payloadVersion": "3"
                                        },
                                        "endpoint": {
                                            "scope": {
                                                "type": "BearerToken",
                                                "token": alexaRequest.directive.endpoint.scope.token
                                            },
                                            "endpointId": alexaRequest.directive.endpoint.endpointId
                                        },
                                        "payload": {}
                                    },
                                    "context": relayContext
                                };
                            }
                            resolve(response_1.default.getSendResponse(JSON.stringify(relay_resp)));
                            break;
                        case VH.kVoiceIRACDevice:
                            let acResp;
                            let ac_context;
                            const iracRemoteDevice = await keus_ir_remote_1.default.getIRRemoteById(keusDev.remoteId);
                            if (!iracRemoteDevice) {
                                acResp = errResponseForAlexa;
                            }
                            else {
                                const iracRemoteDeviceState = iracRemoteDevice.remoteState;
                                const blastIRCommandReq = new zigbee_ir_blaster_pb_1.BlastIRCommand();
                                blastIRCommandReq.setRemoteId(keusDev.remoteId);
                                blastIRCommandReq.setRemoteType(device_constants_pb_1.IR_REMOTE_TYPES.IR_AC);
                                const irACBlast = new zigbee_ir_blaster_pb_1.IRACBlast();
                                irACBlast.setFanLevel(iracRemoteDeviceState.fanLevel);
                                irACBlast.setSwingVLevel(iracRemoteDeviceState.swingVLevel);
                                irACBlast.setSwingHLevel(iracRemoteDeviceState.swingHLevel);
                                // irACBlast.setUpdateType(irACParamValue.updateType);
                                if (requestNamespace == "Alexa.PowerController") {
                                    irACBlast.setUpdateType(zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_ONOFF);
                                    requestName == 'TurnOn' ? irACBlast.setPowerOn(true) : irACBlast.setPowerOn(false);
                                    irACBlast.setMode(iracRemoteDeviceState.mode);
                                    irACBlast.setTemperature(iracRemoteDeviceState.temperature);
                                    ac_context = {
                                        "properties": [
                                            {
                                                "namespace": "Alexa.PowerController",
                                                "name": "powerState",
                                                "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                "timeOfSample": new Date().toISOString(),
                                                "uncertaintyInMilliseconds": 500
                                            }
                                        ]
                                    };
                                }
                                else if (requestNamespace == 'Alexa.ThermostatController') {
                                    switch (requestName) {
                                        case "SetTargetTemperature":
                                            irACBlast.setUpdateType(zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_TEMPERATURE);
                                            irACBlast.setPowerOn(true);
                                            irACBlast.setMode(iracRemoteDeviceState.mode);
                                            irACBlast.setTemperature(requestPayload.targetSetpoint.value);
                                            ac_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.ThermostatController",
                                                        "name": "thermostatMode",
                                                        "value": iracRemoteDeviceState.mode,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    },
                                                    {
                                                        "namespace": "Alexa.ThermostatController",
                                                        "name": "targetSetpoint",
                                                        "value": {
                                                            "value": requestPayload.targetSetpoint.value,
                                                            "scale": "CELSIUS"
                                                        },
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                    //     ,
                                                    //   {
                                                    //     "namespace": "Alexa.TemperatureSensor",
                                                    //     "name": "temperature",
                                                    //     "value": {
                                                    //       "value": 19.3,
                                                    //       "scale": "CELSIUS"
                                                    //     },
                                                    //     "timeOfSample": "2017-02-03T16:20:50.52Z",
                                                    //     "uncertaintyInMilliseconds": 1000
                                                    //   } 
                                                ]
                                            };
                                            break;
                                        case "SetThermostatMode":
                                            irACBlast.setUpdateType(zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_MODE);
                                            irACBlast.setPowerOn(true);
                                            irACBlast.setMode(requestPayload.thermostatMode.value);
                                            irACBlast.setTemperature(iracRemoteDeviceState.temperature);
                                            ac_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.ThermostatController",
                                                        "name": "thermostatMode",
                                                        "value": requestPayload.thermostatMode.value,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    },
                                                    {
                                                        "namespace": "Alexa.ThermostatController",
                                                        "name": "targetSetpoint",
                                                        "value": {
                                                            "value": iracRemoteDeviceState.temperature,
                                                            "scale": "CELSIUS"
                                                        },
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                    //     ,
                                                    //   {
                                                    //     "namespace": "Alexa.TemperatureSensor",
                                                    //     "name": "temperature",
                                                    //     "value": {
                                                    //       "value": 19.3,
                                                    //       "scale": "CELSIUS"
                                                    //     },
                                                    //     "timeOfSample": "2017-02-03T16:20:50.52Z",
                                                    //     "uncertaintyInMilliseconds": 1000
                                                    //   } 
                                                ]
                                            };
                                            break;
                                        default:
                                            acResp = headerNotSupported;
                                            break;
                                    }
                                }
                                else {
                                    acResp = headerNotSupported;
                                }
                                blastIRCommandReq.setAcBlastInfo(irACBlast);
                                if (!acResp) {
                                    const blastIRCommandResp = rpc_maker_util_1.UnPackFromAny(await zigbee_ir_blaster_1.BlastIRCommand(blastIRCommandReq, alexaExecReq.getPhone()));
                                    acResp = {
                                        "event": {
                                            "header": {
                                                "namespace": "Alexa",
                                                "name": "Response",
                                                "messageId": alexaRequest.directive.header.messageId,
                                                "correlationToken": alexaRequest.directive.header.correlationToken,
                                                "payloadVersion": "3"
                                            },
                                            "endpoint": {
                                                // "scope": {
                                                //     "type": "BearerToken",
                                                //     "token": alexaRequest.directive.endpoint.scope.token
                                                // },
                                                "endpointId": alexaRequest.directive.endpoint.endpointId
                                            },
                                            "payload": {}
                                        },
                                        "context": ac_context
                                    };
                                }
                            }
                            resolve(response_1.default.getSendResponse(JSON.stringify(acResp)));
                            break;
                        case VH.kVoiceRoomDevice:
                            // console.log('this is request name',requestName);
                            const execSceneList = await keus_scene_1.default.getSceneByRoomAndType(keusDev.roomId, requestName == 'TurnOn' ? scene_constants_pb_1.SCENE_TYPE.ALLON : scene_constants_pb_1.SCENE_TYPE.ALLOFF);
                            console.log('this is scene list', execSceneList);
                            let full_room_resp;
                            let fullRoomContext;
                            const executeRoomSceneReq = new scene_structures_pb_1.ExecuteScene();
                            if (!execSceneList.length) {
                                full_room_resp = errResponseForAlexa;
                            }
                            else {
                                const execScene = execSceneList[0];
                                executeRoomSceneReq.setSceneId(execScene.sceneId);
                                executeRoomSceneReq.setSceneRoom(execScene.sceneRoom);
                                fullRoomContext = {
                                    "properties": [
                                        {
                                            "namespace": "Alexa.PowerController",
                                            "name": "powerState",
                                            "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                            "timeOfSample": new Date().toISOString(),
                                            "uncertaintyInMilliseconds": 500
                                        }
                                    ]
                                };
                            }
                            if (!full_room_resp) {
                                const executeRoomSceneResp = rpc_maker_util_1.UnPackFromAny(await scene_handlers_1.ExecuteScene(executeRoomSceneReq, alexaExecReq.getPhone()));
                                full_room_resp = {
                                    "event": {
                                        "header": {
                                            "namespace": "Alexa",
                                            "name": "Response",
                                            "messageId": alexaRequest.directive.header.messageId,
                                            "correlationToken": alexaRequest.directive.header.correlationToken,
                                            "payloadVersion": "3"
                                        },
                                        "endpoint": {
                                            "scope": {
                                                "type": "BearerToken",
                                                "token": alexaRequest.directive.endpoint.scope.token
                                            },
                                            "endpointId": alexaRequest.directive.endpoint.endpointId
                                        },
                                        "payload": {}
                                    },
                                    "context": fullRoomContext
                                };
                            }
                            resolve(response_1.default.getSendResponse(JSON.stringify(full_room_resp)));
                            break;
                        case VH.kVoiceRGBWWADevice:
                            let rgb_resp;
                            let rgb_context;
                            const rgbwwaDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                            const rgbWWAState = rgbwwaDevice.deviceState;
                            const updateRGBWWAStateReq = new zigbee_rgbwwa_driver_pb_1.UpdateZigbeeRgbwwaState();
                            updateRGBWWAStateReq.setDeviceState(255);
                            updateRGBWWAStateReq.setDeviceId(keusDev.deviceId);
                            if (!rgbwwaDevice) {
                                rgb_resp = errResponseForAlexa;
                            }
                            else {
                                switch (requestNamespace) {
                                    case "Alexa.ColorController":
                                        if (requestName == "SetColor") {
                                            updateRGBWWAStateReq.setUpdateType(device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE);
                                            let rgbConverted = VH.hsLToRgb(requestPayload.color.hue, requestPayload.color.saturation, requestPayload.color.brightness);
                                            let rgbParams = new zigbee_rgbwwa_driver_pb_1.RGB();
                                            console.log('this is hsl incoming values', requestPayload.color);
                                            console.log("-------------------this is rgb converted values------------", rgbConverted);
                                            rgbParams.setRed(rgbConverted[0]);
                                            rgbParams.setGreen(rgbConverted[1]);
                                            rgbParams.setBlue(rgbConverted[2]);
                                            rgbParams.setPattern(rgbWWAState.lastUpdatedRGBAction.pattern);
                                            updateRGBWWAStateReq.setRgbState(rgbParams);
                                            rgb_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.ColorController",
                                                        "name": "color",
                                                        "value": {
                                                            "hue": requestPayload.color.hue,
                                                            "saturation": requestPayload.color.saturation,
                                                            "brightness": requestPayload.color.brightness
                                                        },
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            rgb_resp = headerNotSupported;
                                        }
                                        break;
                                    case "Alexa.ColorTemperatureController":
                                        if (requestName == "SetColorTemperature") {
                                            updateRGBWWAStateReq.setUpdateType(device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE);
                                            let cw = Math.min(255, requestPayload.colorTemperatureInKelvin >= VH.rgbwwaMidtemp
                                                ? 255
                                                : Math.floor(((requestPayload.colorTemperatureInKelvin - VH.rgbwwaMinTemp) / (VH.rgbwwaMaxTemp + 1 - requestPayload.colorTemperatureInKelvin)) * 255));
                                            let ww = Math.min(255, requestPayload.colorTemperatureInKelvin <= VH.rgbwwaMidtemp
                                                ? 255
                                                : Math.floor(((VH.rgbwwaMaxTemp - requestPayload.colorTemperatureInKelvin) / (requestPayload.colorTemperatureInKelvin + 1 - VH.rgbwwaMinTemp)) * 255));
                                            const wwaParams = new zigbee_rgbwwa_driver_pb_1.WWA();
                                            wwaParams.setAmber(0);
                                            wwaParams.setCoolWhite(cw);
                                            wwaParams.setWarmWhite(ww);
                                            updateRGBWWAStateReq.setWwaState(wwaParams);
                                            rgb_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.ColorTemperatureController",
                                                        "name": "colorTemperatureInKelvin",
                                                        "value": requestPayload.colorTemperatureInKelvin,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            rgb_resp = headerNotSupported;
                                        }
                                        break;
                                    case "Alexa.PowerController":
                                        requestName == 'TurnOn' ? updateRGBWWAStateReq.setDeviceState(255) : updateRGBWWAStateReq.setDeviceState(0);
                                        if (rgbWWAState.lastUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                                            updateRGBWWAStateReq.setUpdateType(device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE);
                                            const rgbU = new zigbee_rgbwwa_driver_pb_1.RGB();
                                            rgbU.setRed(rgbWWAState.lastUpdatedRGBAction.red);
                                            rgbU.setGreen(rgbWWAState.lastUpdatedRGBAction.green);
                                            rgbU.setBlue(rgbWWAState.lastUpdatedRGBAction.blue);
                                            rgbU.setPattern(rgbWWAState.lastUpdatedRGBAction.pattern);
                                            updateRGBWWAStateReq.setRgbState(rgbU);
                                        }
                                        else {
                                            updateRGBWWAStateReq.setUpdateType(device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE);
                                            const wwaU = new zigbee_rgbwwa_driver_pb_1.WWA();
                                            wwaU.setAmber(rgbWWAState.lastUpdatedWWAAction.amber);
                                            wwaU.setCoolWhite(rgbWWAState.lastUpdatedWWAAction.coolWhite);
                                            wwaU.setWarmWhite(rgbWWAState.lastUpdatedWWAAction.warmWhite);
                                            updateRGBWWAStateReq.setWwaState(wwaU);
                                        }
                                        rgb_context = {
                                            "properties": [
                                                {
                                                    "namespace": "Alexa.PowerController",
                                                    "name": "powerState",
                                                    "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                    "timeOfSample": new Date().toISOString(),
                                                    "uncertaintyInMilliseconds": 500
                                                }
                                            ]
                                        };
                                        break;
                                }
                            }
                            if (!rgb_resp) {
                                const updateRgbwwaStateResp = rpc_maker_util_1.UnPackFromAny(await update_rgbwwa_state_1.default(updateRGBWWAStateReq, alexaExecReq.getPhone()));
                                rgb_resp = {
                                    "event": {
                                        "header": {
                                            "namespace": "Alexa",
                                            "name": "Response",
                                            "messageId": alexaRequest.directive.header.messageId,
                                            "correlationToken": alexaRequest.directive.header.correlationToken,
                                            "payloadVersion": "3"
                                        },
                                        "endpoint": {
                                            "scope": {
                                                "type": "BearerToken",
                                                "token": alexaRequest.directive.endpoint.scope.token
                                            },
                                            "endpointId": alexaRequest.directive.endpoint.endpointId
                                        },
                                        "payload": {}
                                    },
                                    "context": rgb_context
                                };
                            }
                            resolve(response_1.default.getSendResponse(JSON.stringify(rgb_resp)));
                            break;
                        case VH.kVoiceESApplianceDevice:
                            let es_resp;
                            let es_context;
                            const appDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                            let deviceProps = appDevice.deviceProperties;
                            let applianceList = deviceProps.appliance;
                            let appliance = applianceList.find(function (app) {
                                return app.applianceId == keusDev.applianceId;
                            });
                            const updateApplianceReq = new zigbee_embedded_switch_pb_1.UpdateApplianceState();
                            updateApplianceReq.setDeviceId(keusDev.deviceId);
                            updateApplianceReq.setApplianceId(keusDev.applianceId);
                            if (!appDevice || !appliance) {
                                es_resp = errResponseForAlexa;
                            }
                            else {
                                switch (appliance.applianceType) {
                                    case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                                        let onoffReqobj = new zigbee_embedded_switch_pb_2.OnOffApplianceState();
                                        if (requestNamespace == "Alexa.PowerController") {
                                            requestName == 'TurnOn' ? onoffReqobj.setSwitchState(255) : onoffReqobj.setSwitchState(0);
                                            updateApplianceReq.setOnOffState(onoffReqobj);
                                            es_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            es_resp = headerNotSupported;
                                        }
                                        break;
                                    case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                                        let singledimmerReqObj = new zigbee_embedded_switch_pb_2.SingleDimmerApplianceState();
                                        if (requestNamespace == "Alexa.PowerController") {
                                            requestName == 'TurnOn' ? singledimmerReqObj.setSwitchState(255) : singledimmerReqObj.setSwitchState(0);
                                            updateApplianceReq.setSingleDimmerState(singledimmerReqObj);
                                            es_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else if (requestNamespace == "Alexa.BrightnessController" && requestName == 'SetBrightness') {
                                            console.log('this is brigntness update', Math.round(255 * (requestPayload.brightness / 100)));
                                            singledimmerReqObj.setSwitchState(Math.round(255 * (requestPayload.brightness / 100)));
                                            updateApplianceReq.setSingleDimmerState(singledimmerReqObj);
                                            es_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.BrightnessController",
                                                        "name": "brightness",
                                                        "value": requestPayload.brightness,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            es_resp = headerNotSupported;
                                        }
                                        break;
                                    case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                                        let fanReqObj = new zigbee_embedded_switch_pb_2.FanApplianceState();
                                        if (requestNamespace == "Alexa.PowerController") { //change values
                                            requestName == 'TurnOn' ? fanReqObj.setFanState(255) : fanReqObj.setFanState(0);
                                            updateApplianceReq.setFanState(fanReqObj);
                                            es_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else if (requestNamespace == "Alexa.RangeController" && requestName == 'SetRangeValue') {
                                            console.log('this is fan mode level', Math.round(255 * (requestPayload.rangeValue / 4)));
                                            fanReqObj.setFanState(Math.round(255 * (requestPayload.rangeValue / 4)));
                                            updateApplianceReq.setFanState(fanReqObj);
                                            es_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.RangeController",
                                                        "instance": "Fan.Speed",
                                                        "name": "rangeValue",
                                                        "value": requestPayload.rangeValue,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            es_resp = headerNotSupported;
                                        }
                                        break;
                                    case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                                        let colortunableReq = new zigbee_embedded_switch_pb_1.ColorTunableApplianceState();
                                        if (requestNamespace == 'Alexa.PowerController') {
                                            requestName == 'TurnOn' ? colortunableReq.setLightState(255) : colortunableReq.setLightState(0);
                                            let ctdbstate = appliance.applianceState;
                                            colortunableReq.setCoolWhiteState(ctdbstate.coolWhiteState);
                                            colortunableReq.setWarmWhiteState(ctdbstate.warmWhiteState);
                                            updateApplianceReq.setColorTunableState(colortunableReq);
                                            es_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.PowerController",
                                                        "name": "powerState",
                                                        "value": requestName == 'TurnOn' ? "ON" : "OFF",
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else if (requestName == "SetColorTemperature" && requestNamespace == 'Alexa.ColorTemperatureController') {
                                            let cw = Math.min(255, requestPayload.colorTemperatureInKelvin >= VH.rgbwwaMidtemp
                                                ? 255
                                                : Math.floor(((requestPayload.colorTemperatureInKelvin - VH.rgbwwaMinTemp) / (VH.rgbwwaMaxTemp + 1 - requestPayload.colorTemperatureInKelvin)) * 255));
                                            let ww = Math.min(255, requestPayload.colorTemperatureInKelvin <= VH.rgbwwaMidtemp
                                                ? 255
                                                : Math.floor(((VH.rgbwwaMaxTemp - requestPayload.colorTemperatureInKelvin) / (requestPayload.colorTemperatureInKelvin + 1 - VH.rgbwwaMinTemp)) * 255));
                                            colortunableReq.setLightState(255);
                                            colortunableReq.setWarmWhiteState(ww);
                                            colortunableReq.setCoolWhiteState(cw);
                                            updateApplianceReq.setColorTunableState(colortunableReq);
                                            es_context = {
                                                "properties": [
                                                    {
                                                        "namespace": "Alexa.ColorTemperatureController",
                                                        "name": "colorTemperatureInKelvin",
                                                        "value": requestPayload.colorTemperatureInKelvin,
                                                        "timeOfSample": new Date().toISOString(),
                                                        "uncertaintyInMilliseconds": 500
                                                    }
                                                ]
                                            };
                                        }
                                        else {
                                            es_resp = headerNotSupported;
                                        }
                                }
                                if (!es_resp) {
                                    const UpdateApplianceStateResp = rpc_maker_util_1.UnPackFromAny(await update_appliance_state_1.default(updateApplianceReq, alexaExecReq.getPhone()));
                                    es_resp = {
                                        "event": {
                                            "header": {
                                                "namespace": "Alexa",
                                                "name": "Response",
                                                "messageId": alexaRequest.directive.header.messageId,
                                                "correlationToken": alexaRequest.directive.header.correlationToken,
                                                "payloadVersion": "3"
                                            },
                                            "endpoint": {
                                                "scope": {
                                                    "type": "BearerToken",
                                                    "token": alexaRequest.directive.endpoint.scope.token
                                                },
                                                "endpointId": alexaRequest.directive.endpoint.endpointId
                                            },
                                            "payload": {}
                                        },
                                        "context": es_context
                                    };
                                }
                            }
                            resolve(response_1.default.getSendResponse(JSON.stringify(es_resp)));
                            break;
                    }
                }
            }
            catch (e) {
                console.log('this is error in execute command', e);
                switch (e.constructor) {
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getSendResponse(JSON.stringify(errResponseForAlexa)));
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map