"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const alexa_pb_1 = require("../../../protos/generated/hub/voice/alexa_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class AlexaExecuteCommandResp {
    static getSendResponse(deviceStatus) {
        const resp = new alexa_pb_1.AlexaExecuteCommandResponse();
        resp.setCode(800);
        resp.setMessage("alexa execute success");
        resp.setSuccess(true);
        resp.setAlexaResponse(deviceStatus);
        return general_1.PackIntoAny(resp.serializeBinary(), AlexaExecuteCommandResp.responseType);
    }
    static getInvalidDeviceId(deviceStatus) {
        const resp = new alexa_pb_1.AlexaExecuteCommandResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Endpoint Id');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AlexaExecuteCommandResp.responseType);
    }
    static getInvalidParameterSet(deviceStatus) {
        const resp = new alexa_pb_1.AlexaExecuteCommandResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Parameter Set for device');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AlexaExecuteCommandResp.responseType);
    }
    static getInsufficientUserAccess(deviceStatus) {
        const resp = new alexa_pb_1.AlexaExecuteCommandResponse();
        resp.setCode(803);
        resp.setMessage('Get Insufficient User Access');
        resp.setSuccess(false);
        return general_1.PackIntoAny(resp.serializeBinary(), AlexaExecuteCommandResp.responseType);
    }
    static getInternalServerError(deviceState) {
        const resp = new alexa_pb_1.AlexaExecuteCommandResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), AlexaExecuteCommandResp.responseType);
    }
}
exports.default = AlexaExecuteCommandResp;
AlexaExecuteCommandResp.responseType = system_constants_1.ProtoPackageName + '.AlexaExecuteCommandResponse';
//# sourceMappingURL=response.js.map