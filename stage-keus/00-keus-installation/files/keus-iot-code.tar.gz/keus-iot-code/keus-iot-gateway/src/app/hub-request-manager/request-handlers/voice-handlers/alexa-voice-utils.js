"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const home_constants_1 = require("../../../../constants/gateway/home-constants");
const errors_1 = require("../../../../errors/errors");
const device_constants_pb_1 = require("../../protos/generated/hub/devices/device_constants_pb");
const group_structures_pb_1 = require("../../protos/generated/hub/groups/group_structures_pb");
//constants
exports.rgbwwaMinTemp = 2200;
exports.rgbwwaMaxTemp = 7000;
exports.rgbwwaMidtemp = (exports.rgbwwaMinTemp + exports.rgbwwaMaxTemp) / 2;
exports.acunitSupportedModeList = ["OFF", "COOL", "AUTO", "HEAT"];
const roomLightsTag = 'Lights';
exports.manufacturerName = 'Keus';
exports.LightDisplayCategory = ["LIGHT"];
exports.FanDisplayCategory = ["FAN"];
exports.SwitchDisplayCategory = ["SWITCH"];
exports.SceneDisplayCategory = ["SCENE_TRIGGER"];
exports.CurtainDisplayCategory = ["INTERIOR_BLIND"];
exports.ACRemoteDisplayCaregory = ["THERMOSTAT", "TEMPERATURE_SENSOR"];
exports.kVoiceGroupDevice = 'GRP';
exports.kVoiceSceneDevice = 'SCN';
exports.kVoiceCurtainDevice = 'CC';
exports.kVoiceESApplianceDevice = 'ESAP';
exports.kVoiceACFanDevice = 'ACFC';
exports.kVoiceDCFanDevice = 'DCFC';
exports.kVoiceSCRelayDevice = 'SCR';
exports.kVoiceIRACDevice = 'IRAC';
exports.kVoiceRoomDevice = 'RMD';
exports.kVoiceRGBWWADevice = 'RGBWWA';
function getAlexaVoiceGroupDevice(group, roomList) {
    let groupObject;
    const room = roomList.find(function (room) {
        return room.roomId == group.groupRoom;
    });
    if (!room) {
        return null;
    }
    let fullName = room.roomName;
    if (group.groupSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == group.groupSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + group.groupName;
    switch (group.groupType) {
        case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "Lights Device with Brigntness control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                capabilities: [{
                        type: "AlexaInterface",
                        interface: "Alexa.PowerController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "powerState"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa.BrightnessController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "brightness"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa",
                        version: "3"
                    }]
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "Lights Device with Color Temperature control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                "capabilities": [
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.PowerController",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "powerState"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.ColorTemperatureController",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "colorTemperatureInKelvin"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa",
                        "version": "3"
                    }
                ]
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "Lights Device with Brigntness control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                capabilities: [{
                        type: "AlexaInterface",
                        interface: "Alexa.PowerController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "powerState"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa.BrightnessController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "brightness"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa",
                        version: "3"
                    }]
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "Lights Device with ON/OFF control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                capabilities: [{
                        type: "AlexaInterface",
                        interface: "Alexa.PowerController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "powerState"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa",
                        version: "3"
                    }]
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "Lights Device with ON/OFF control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                capabilities: [{
                        type: "AlexaInterface",
                        interface: "Alexa.PowerController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "powerState"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa",
                        version: "3"
                    }]
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "Lights Device with Brigntness control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                capabilities: [{
                        type: "AlexaInterface",
                        interface: "Alexa.PowerController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "powerState"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa.BrightnessController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "brightness"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa",
                        version: "3"
                    }]
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "Lights Device with Brigntness control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                capabilities: [{
                        type: "AlexaInterface",
                        interface: "Alexa.PowerController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "powerState"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa.BrightnessController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "brightness"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa",
                        version: "3"
                    }]
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "Switch Device with ON/OFF control",
                friendlyName: fullName,
                displayCategories: exports.SwitchDisplayCategory,
                cookie: {},
                capabilities: [{
                        type: "AlexaInterface",
                        interface: "Alexa.PowerController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "powerState"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa",
                        version: "3"
                    }]
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "FAN Device with ON/OFF control And speed modes",
                friendlyName: fullName,
                displayCategories: exports.FanDisplayCategory,
                cookie: {},
                capabilities: [
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.RangeController",
                        "instance": "Fan.Speed",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "rangeValue"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false,
                            "nonControllable": false
                        },
                        "capabilityResources": {
                            "friendlyNames": [
                                {
                                    "@type": "asset",
                                    "value": {
                                        "assetId": "Alexa.Setting.FanSpeed"
                                    }
                                },
                                {
                                    "@type": "text",
                                    "value": {
                                        "text": "Speed",
                                        "locale": "en-US"
                                    }
                                }
                                //   {
                                //     "@type": "text",
                                //     "value": {
                                //       "text": "Velocidad",
                                //       "locale": "es-MX"
                                //     }
                                //   },
                                //   {
                                //     "@type": "text",
                                //     "value": {
                                //       "text": "Vitesse",
                                //       "locale": "fr-CA"
                                //     }
                                //   }
                            ]
                        },
                        "configuration": {
                            "supportedRange": {
                                "minimumValue": 1,
                                "maximumValue": 4,
                                "precision": 1
                            },
                            "presets": [
                                {
                                    "rangeValue": 4,
                                    "presetResources": {
                                        "friendlyNames": [
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.Maximum"
                                                }
                                            },
                                            // {
                                            //   "@type": "asset",
                                            //   "value": {
                                            //     "assetId": "Alexa.Value.High"
                                            //   }
                                            // },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Highest",
                                                    "locale": "en-US"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Maximum",
                                                    "locale": "en-US"
                                                }
                                            },
                                        ]
                                    }
                                },
                                {
                                    "rangeValue": 3,
                                    "presetResources": {
                                        "friendlyNames": [
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.High"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "High",
                                                    "locale": "en-US"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Fast",
                                                    "locale": "en-US"
                                                }
                                            },
                                        ]
                                    }
                                },
                                {
                                    "rangeValue": 1,
                                    "presetResources": {
                                        "friendlyNames": [
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.Minimum"
                                                }
                                            },
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.Low"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Lowest",
                                                    "locale": "en-US"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Slow",
                                                    "locale": "en-US"
                                                }
                                            },
                                        ]
                                    }
                                },
                                {
                                    "rangeValue": 2,
                                    "presetResources": {
                                        "friendlyNames": [
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.Medium"
                                                }
                                            },
                                            // {
                                            //   "@type": "asset",
                                            //   "value": {
                                            //     "assetId": "Alexa.Value.Low"
                                            //   }
                                            // },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Medium",
                                                    "locale": "en-US"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Moderate",
                                                    "locale": "en-US"
                                                }
                                            },
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.PowerController",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "powerState"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa",
                        "version": "3"
                    }
                ]
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.RGBWWA:
            groupObject = {
                endpointId: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceGroupDevice + '-' + group.groupType,
                description: "Lights with Color and Color te control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                "capabilities": [
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.PowerController",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "powerState"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.ColorController",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "color"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.ColorTemperatureController",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "colorTemperatureInKelvin"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa",
                        "version": "3"
                    }
                ]
            };
            break;
    }
    return groupObject;
}
exports.getAlexaVoiceGroupDevice = getAlexaVoiceGroupDevice;
function getAlexaVoiceSceneDevice(scene, roomList) {
    let sceneObj;
    const room = roomList.find(function (room) {
        return room.roomId == scene.sceneRoom;
    });
    if (!room) {
        return null;
    }
    let fullName = room.roomName;
    if (scene.sceneSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == scene.sceneSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + scene.sceneName;
    sceneObj = {
        endpointId: exports.kVoiceSceneDevice + '-' + scene.sceneRoom + '-' + scene.sceneId,
        manufacturerName: exports.manufacturerName,
        modelName: exports.kVoiceSceneDevice + '-' + scene.sceneType,
        description: "SCENE EXECUTION",
        friendlyName: fullName,
        displayCategories: exports.SceneDisplayCategory,
        cookie: {},
        capabilities: [
            {
                type: "AlexaInterface",
                interface: "Alexa.SceneController",
                version: "3",
                supportsDeactivation: false
            },
            {
                type: "AlexaInterface",
                interface: "Alexa",
                version: "3"
            }
        ]
    };
    return sceneObj;
}
exports.getAlexaVoiceSceneDevice = getAlexaVoiceSceneDevice;
function getAlexaVoiceCurtainDevice(device, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + device.deviceName;
    deviceObj = {
        endpointId: exports.kVoiceCurtainDevice + '-' + device.deviceRoom + '-' + device.deviceId,
        manufacturerName: exports.manufacturerName,
        modelName: exports.kVoiceCurtainDevice + '-' + device.deviceType,
        description: "curtain device",
        friendlyName: fullName,
        displayCategories: exports.CurtainDisplayCategory,
        cookie: {},
        capabilities: [
            {
                "type": "AlexaInterface",
                "interface": "Alexa.RangeController",
                "instance": "Blind.Lift",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "rangeValue"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false
                },
                "capabilityResources": {
                    "friendlyNames": [
                        {
                            "@type": "asset",
                            "value": {
                                "assetId": "Alexa.Setting.Opening"
                            }
                        }
                    ]
                },
                "configuration": {
                    "supportedRange": {
                        "minimumValue": 0,
                        "maximumValue": 100,
                        "precision": 1
                    },
                    "unitOfMeasure": "Alexa.Unit.Percent"
                },
                "semantics": {
                    "actionMappings": [
                        {
                            "@type": "ActionsToDirective",
                            "actions": ["Alexa.Actions.Close"],
                            "directive": {
                                "name": "SetRangeValue",
                                "payload": {
                                    "rangeValue": 0
                                }
                            }
                        },
                        {
                            "@type": "ActionsToDirective",
                            "actions": ["Alexa.Actions.Open"],
                            "directive": {
                                "name": "SetRangeValue",
                                "payload": {
                                    "rangeValue": 100
                                }
                            }
                        },
                        {
                            "@type": "ActionsToDirective",
                            "actions": ["Alexa.Actions.Lower"],
                            "directive": {
                                "name": "SetRangeValue",
                                "payload": {
                                    "rangeValue": 0
                                }
                            }
                        },
                        {
                            "@type": "ActionsToDirective",
                            "actions": ["Alexa.Actions.Raise"],
                            "directive": {
                                "name": "SetRangeValue",
                                "payload": {
                                    "rangeValue": 100
                                }
                            }
                        }
                    ],
                    "stateMappings": [
                        {
                            "@type": "StatesToValue",
                            "states": ["Alexa.States.Closed"],
                            "value": 0
                        },
                        {
                            "@type": "StatesToRange",
                            "states": ["Alexa.States.Open"],
                            "range": {
                                "minimumValue": 1,
                                "maximumValue": 100
                            }
                        }
                    ]
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa",
                "version": "3"
            }
        ]
    };
    return deviceObj;
}
exports.getAlexaVoiceCurtainDevice = getAlexaVoiceCurtainDevice;
function getAlexaVoiceEmbeddedAppliance(device, appliace, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + appliace.applianceName;
    switch (appliace.applianceType) {
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
            deviceObj = {
                endpointId: exports.kVoiceESApplianceDevice + '-' + device.deviceRoom + '-' + device.deviceId + '-' + appliace.applianceId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceESApplianceDevice + '-' + appliace.applianceType,
                description: "Lights Device with ON/OFF control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                capabilities: [{
                        type: "AlexaInterface",
                        interface: "Alexa.PowerController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "powerState"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa",
                        version: "3"
                    }]
            };
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
            deviceObj = {
                endpointId: exports.kVoiceESApplianceDevice + '-' + device.deviceRoom + '-' + device.deviceId + '-' + appliace.applianceId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceESApplianceDevice + '-' + appliace.applianceType,
                description: "Lights Device with Brigntness control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                capabilities: [{
                        type: "AlexaInterface",
                        interface: "Alexa.PowerController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "powerState"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa.BrightnessController",
                        version: "3",
                        properties: {
                            supported: [
                                {
                                    name: "brightness"
                                }
                            ],
                            proactivelyReported: false,
                            retrievable: false
                        }
                    },
                    {
                        type: "AlexaInterface",
                        interface: "Alexa",
                        version: "3"
                    }]
            };
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
            deviceObj = {
                endpointId: exports.kVoiceESApplianceDevice + '-' + device.deviceRoom + '-' + device.deviceId + '-' + appliace.applianceId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceESApplianceDevice + '-' + appliace.applianceType,
                description: "FAN Device with ON/OFF control And speed modes",
                friendlyName: fullName,
                displayCategories: exports.FanDisplayCategory,
                cookie: {},
                capabilities: [
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.RangeController",
                        "instance": "Fan.Speed",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "rangeValue"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false,
                            "nonControllable": false
                        },
                        "capabilityResources": {
                            "friendlyNames": [
                                {
                                    "@type": "asset",
                                    "value": {
                                        "assetId": "Alexa.Setting.FanSpeed"
                                    }
                                },
                                {
                                    "@type": "text",
                                    "value": {
                                        "text": "Speed",
                                        "locale": "en-US"
                                    }
                                }
                                //   {
                                //     "@type": "text",
                                //     "value": {
                                //       "text": "Velocidad",
                                //       "locale": "es-MX"
                                //     }
                                //   },
                                //   {
                                //     "@type": "text",
                                //     "value": {
                                //       "text": "Vitesse",
                                //       "locale": "fr-CA"
                                //     }
                                //   }
                            ]
                        },
                        "configuration": {
                            "supportedRange": {
                                "minimumValue": 1,
                                "maximumValue": 4,
                                "precision": 1
                            },
                            "presets": [
                                {
                                    "rangeValue": 4,
                                    "presetResources": {
                                        "friendlyNames": [
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.Maximum"
                                                }
                                            },
                                            // {
                                            //   "@type": "asset",
                                            //   "value": {
                                            //     "assetId": "Alexa.Value.High"
                                            //   }
                                            // },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Highest",
                                                    "locale": "en-US"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Maximum",
                                                    "locale": "en-US"
                                                }
                                            },
                                        ]
                                    }
                                },
                                {
                                    "rangeValue": 3,
                                    "presetResources": {
                                        "friendlyNames": [
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.High"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "High",
                                                    "locale": "en-US"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Fast",
                                                    "locale": "en-US"
                                                }
                                            },
                                        ]
                                    }
                                },
                                {
                                    "rangeValue": 1,
                                    "presetResources": {
                                        "friendlyNames": [
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.Minimum"
                                                }
                                            },
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.Low"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Lowest",
                                                    "locale": "en-US"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Slow",
                                                    "locale": "en-US"
                                                }
                                            },
                                        ]
                                    }
                                },
                                {
                                    "rangeValue": 2,
                                    "presetResources": {
                                        "friendlyNames": [
                                            {
                                                "@type": "asset",
                                                "value": {
                                                    "assetId": "Alexa.Value.Medium"
                                                }
                                            },
                                            // {
                                            //   "@type": "asset",
                                            //   "value": {
                                            //     "assetId": "Alexa.Value.Low"
                                            //   }
                                            // },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Medium",
                                                    "locale": "en-US"
                                                }
                                            },
                                            {
                                                "@type": "text",
                                                "value": {
                                                    "text": "Moderate",
                                                    "locale": "en-US"
                                                }
                                            },
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.PowerController",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "powerState"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa",
                        "version": "3"
                    }
                ]
            };
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
            deviceObj = {
                endpointId: exports.kVoiceESApplianceDevice + '-' + device.deviceRoom + '-' + device.deviceId + '-' + appliace.applianceId,
                manufacturerName: exports.manufacturerName,
                modelName: exports.kVoiceESApplianceDevice + '-' + appliace.applianceType,
                description: "Light with color temperature control",
                friendlyName: fullName,
                displayCategories: exports.LightDisplayCategory,
                cookie: {},
                "capabilities": [
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.PowerController",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "powerState"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa.ColorTemperatureController",
                        "version": "3",
                        "properties": {
                            "supported": [
                                {
                                    "name": "colorTemperatureInKelvin"
                                }
                            ],
                            "proactivelyReported": false,
                            "retrievable": false
                        }
                    },
                    {
                        "type": "AlexaInterface",
                        "interface": "Alexa",
                        "version": "3"
                    }
                ]
            };
            break;
    }
    return deviceObj;
}
exports.getAlexaVoiceEmbeddedAppliance = getAlexaVoiceEmbeddedAppliance;
function getAlexaAcFanDevice(device, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + device.deviceName;
    deviceObj = {
        endpointId: exports.kVoiceACFanDevice + '-' + device.deviceRoom + '-' + device.deviceId,
        manufacturerName: exports.manufacturerName,
        modelName: exports.kVoiceACFanDevice + '-' + device.deviceType,
        description: "FAN Device with ON/OFF control And speed modes",
        friendlyName: fullName,
        displayCategories: exports.FanDisplayCategory,
        cookie: {},
        capabilities: [
            {
                "type": "AlexaInterface",
                "interface": "Alexa.RangeController",
                "instance": "Fan.Speed",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "rangeValue"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false,
                    "nonControllable": false
                },
                "capabilityResources": {
                    "friendlyNames": [
                        {
                            "@type": "asset",
                            "value": {
                                "assetId": "Alexa.Setting.FanSpeed"
                            }
                        },
                        {
                            "@type": "text",
                            "value": {
                                "text": "Speed",
                                "locale": "en-US"
                            }
                        }
                        //   {
                        //     "@type": "text",
                        //     "value": {
                        //       "text": "Velocidad",
                        //       "locale": "es-MX"
                        //     }
                        //   },
                        //   {
                        //     "@type": "text",
                        //     "value": {
                        //       "text": "Vitesse",
                        //       "locale": "fr-CA"
                        //     }
                        //   }
                    ]
                },
                "configuration": {
                    "supportedRange": {
                        "minimumValue": 1,
                        "maximumValue": 4,
                        "precision": 1
                    },
                    "presets": [
                        {
                            "rangeValue": 4,
                            "presetResources": {
                                "friendlyNames": [
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.Maximum"
                                        }
                                    },
                                    // {
                                    //   "@type": "asset",
                                    //   "value": {
                                    //     "assetId": "Alexa.Value.High"
                                    //   }
                                    // },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Highest",
                                            "locale": "en-US"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Maximum",
                                            "locale": "en-US"
                                        }
                                    },
                                ]
                            }
                        },
                        {
                            "rangeValue": 3,
                            "presetResources": {
                                "friendlyNames": [
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.High"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "High",
                                            "locale": "en-US"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Fast",
                                            "locale": "en-US"
                                        }
                                    },
                                ]
                            }
                        },
                        {
                            "rangeValue": 1,
                            "presetResources": {
                                "friendlyNames": [
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.Minimum"
                                        }
                                    },
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.Low"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Lowest",
                                            "locale": "en-US"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Slow",
                                            "locale": "en-US"
                                        }
                                    },
                                ]
                            }
                        },
                        {
                            "rangeValue": 2,
                            "presetResources": {
                                "friendlyNames": [
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.Medium"
                                        }
                                    },
                                    // {
                                    //   "@type": "asset",
                                    //   "value": {
                                    //     "assetId": "Alexa.Value.Low"
                                    //   }
                                    // },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Medium",
                                            "locale": "en-US"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Moderate",
                                            "locale": "en-US"
                                        }
                                    },
                                ]
                            }
                        }
                    ]
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa.PowerController",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "powerState"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa",
                "version": "3"
            }
        ]
    };
    return deviceObj;
}
exports.getAlexaAcFanDevice = getAlexaAcFanDevice;
function getAlexaDcFanDevice(device, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + device.deviceName;
    deviceObj = {
        endpointId: exports.kVoiceDCFanDevice + '-' + device.deviceRoom + '-' + device.deviceId,
        manufacturerName: exports.manufacturerName,
        modelName: exports.kVoiceDCFanDevice + '-' + device.deviceType,
        description: "FAN Device with ON/OFF control And speed modes",
        friendlyName: fullName,
        displayCategories: exports.FanDisplayCategory,
        cookie: {},
        capabilities: [
            {
                "type": "AlexaInterface",
                "interface": "Alexa.RangeController",
                "instance": "Fan.Speed",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "rangeValue"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false,
                    "nonControllable": false
                },
                "capabilityResources": {
                    "friendlyNames": [
                        {
                            "@type": "asset",
                            "value": {
                                "assetId": "Alexa.Setting.FanSpeed"
                            }
                        },
                        {
                            "@type": "text",
                            "value": {
                                "text": "Speed",
                                "locale": "en-US"
                            }
                        }
                        //   {
                        //     "@type": "text",
                        //     "value": {
                        //       "text": "Velocidad",
                        //       "locale": "es-MX"
                        //     }
                        //   },
                        //   {
                        //     "@type": "text",
                        //     "value": {
                        //       "text": "Vitesse",
                        //       "locale": "fr-CA"
                        //     }
                        //   }
                    ]
                },
                "configuration": {
                    "supportedRange": {
                        "minimumValue": 1,
                        "maximumValue": 4,
                        "precision": 1
                    },
                    "presets": [
                        {
                            "rangeValue": 4,
                            "presetResources": {
                                "friendlyNames": [
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.Maximum"
                                        }
                                    },
                                    // {
                                    //   "@type": "asset",
                                    //   "value": {
                                    //     "assetId": "Alexa.Value.High"
                                    //   }
                                    // },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Highest",
                                            "locale": "en-US"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Maximum",
                                            "locale": "en-US"
                                        }
                                    },
                                ]
                            }
                        },
                        {
                            "rangeValue": 3,
                            "presetResources": {
                                "friendlyNames": [
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.High"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "High",
                                            "locale": "en-US"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Fast",
                                            "locale": "en-US"
                                        }
                                    },
                                ]
                            }
                        },
                        {
                            "rangeValue": 1,
                            "presetResources": {
                                "friendlyNames": [
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.Minimum"
                                        }
                                    },
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.Low"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Lowest",
                                            "locale": "en-US"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Slow",
                                            "locale": "en-US"
                                        }
                                    },
                                ]
                            }
                        },
                        {
                            "rangeValue": 2,
                            "presetResources": {
                                "friendlyNames": [
                                    {
                                        "@type": "asset",
                                        "value": {
                                            "assetId": "Alexa.Value.Medium"
                                        }
                                    },
                                    // {
                                    //   "@type": "asset",
                                    //   "value": {
                                    //     "assetId": "Alexa.Value.Low"
                                    //   }
                                    // },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Medium",
                                            "locale": "en-US"
                                        }
                                    },
                                    {
                                        "@type": "text",
                                        "value": {
                                            "text": "Moderate",
                                            "locale": "en-US"
                                        }
                                    },
                                ]
                            }
                        }
                    ]
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa.PowerController",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "powerState"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa",
                "version": "3"
            }
        ]
    };
    return deviceObj;
}
exports.getAlexaDcFanDevice = getAlexaDcFanDevice;
function getAlexaVoiceSCRelayDevice(relay, roomList, device) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + relay.relayName;
    deviceObj = {
        endpointId: exports.kVoiceSCRelayDevice + '-' + device.deviceRoom + '-' + device.deviceId + '-' + relay.relayId,
        manufacturerName: exports.manufacturerName,
        modelName: exports.kVoiceSCRelayDevice + '-' + device.deviceType,
        description: "Switch Device with ON/OFF control",
        friendlyName: fullName,
        displayCategories: exports.SwitchDisplayCategory,
        cookie: {},
        capabilities: [{
                type: "AlexaInterface",
                interface: "Alexa.PowerController",
                version: "3",
                properties: {
                    supported: [
                        {
                            name: "powerState"
                        }
                    ],
                    proactivelyReported: false,
                    retrievable: false
                }
            },
            {
                type: "AlexaInterface",
                interface: "Alexa",
                version: "3"
            }]
    };
    return deviceObj;
}
exports.getAlexaVoiceSCRelayDevice = getAlexaVoiceSCRelayDevice;
function getAlexaVoiceIRACDevice(remote, roomList, device) {
    let deviceObj;
    const acRemoteProps = remote.remoteProperties;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + remote.remoteName;
    const availableModes = [];
    if (acRemoteProps.modeEnabled) {
        acRemoteProps.modeOptions.forEach(function (mode) {
            if (exports.acunitSupportedModeList.indexOf(mode.toUpperCase()) > -1) {
                availableModes.push(mode.toUpperCase());
            }
        });
    }
    deviceObj = {
        endpointId: exports.kVoiceIRACDevice + '-' + device.deviceRoom + '-' + device.deviceId + '-' + remote.remoteId,
        manufacturerName: exports.manufacturerName,
        modelName: exports.kVoiceIRACDevice + '-' + device.deviceType,
        description: "A/C Control",
        friendlyName: fullName,
        displayCategories: exports.ACRemoteDisplayCaregory,
        cookie: {},
        "capabilities": [
            {
                "type": "AlexaInterface",
                "interface": "Alexa.ThermostatController",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "targetSetpoint"
                        },
                        {
                            "name": "thermostatMode"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false
                },
                "configuration": {
                    "supportedModes": availableModes,
                    "supportsScheduling": false
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa.PowerController",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "powerState"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa",
                "version": "3"
            }
        ]
    };
    return deviceObj;
}
exports.getAlexaVoiceIRACDevice = getAlexaVoiceIRACDevice;
function getAlexaVoiceFullRoomDevice(room, section) {
    let deviceObj;
    var fullName = room.roomName;
    if (section.sectionId != home_constants_1.DefaultSectionId) {
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + roomLightsTag;
    deviceObj = {
        endpointId: exports.kVoiceRoomDevice + '-' + room.roomId,
        manufacturerName: exports.manufacturerName,
        modelName: exports.kVoiceRoomDevice + '-' + room.roomType,
        description: "All room lights",
        friendlyName: fullName,
        displayCategories: exports.LightDisplayCategory,
        cookie: {},
        capabilities: [{
                type: "AlexaInterface",
                interface: "Alexa.PowerController",
                version: "3",
                properties: {
                    supported: [
                        {
                            name: "powerState"
                        }
                    ],
                    proactivelyReported: false,
                    retrievable: false
                }
            },
            {
                type: "AlexaInterface",
                interface: "Alexa",
                version: "3"
            }]
    };
    return deviceObj;
}
exports.getAlexaVoiceFullRoomDevice = getAlexaVoiceFullRoomDevice;
function getAlexaVoiceRGBWWADevice(device, roomList) {
    console.log('came to rgb execution');
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + device.deviceName;
    deviceObj = {
        endpointId: exports.kVoiceRGBWWADevice + '-' + device.deviceRoom + '-' + device.deviceId,
        manufacturerName: exports.manufacturerName,
        modelName: exports.kVoiceRGBWWADevice + '-' + device.deviceType,
        description: "RGBWWA device",
        friendlyName: fullName,
        displayCategories: exports.LightDisplayCategory,
        cookie: {},
        "capabilities": [
            {
                "type": "AlexaInterface",
                "interface": "Alexa.PowerController",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "powerState"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa.ColorController",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "color"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa.ColorTemperatureController",
                "version": "3",
                "properties": {
                    "supported": [
                        {
                            "name": "colorTemperatureInKelvin"
                        }
                    ],
                    "proactivelyReported": false,
                    "retrievable": false
                }
            },
            {
                "type": "AlexaInterface",
                "interface": "Alexa",
                "version": "3"
            }
        ]
    };
    return deviceObj;
}
exports.getAlexaVoiceRGBWWADevice = getAlexaVoiceRGBWWADevice;
function getKeusId(deviceId) {
    const deviceParams = deviceId.split('-');
    switch (deviceParams[0]) {
        case exports.kVoiceSceneDevice:
            if (deviceParams.length != 3) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    sceneId: parseInt(deviceParams[2]),
                    sceneRoom: deviceParams[1]
                };
            }
            break;
        case exports.kVoiceGroupDevice:
            if (deviceParams.length != 3) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    groupId: parseInt(deviceParams[2]),
                    groupRoom: deviceParams[1]
                };
            }
            break;
        case exports.kVoiceCurtainDevice:
        case exports.kVoiceACFanDevice:
        case exports.kVoiceDCFanDevice:
            if (deviceParams.length != 3) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    deviceRoom: deviceParams[1]
                };
            }
            break;
        case exports.kVoiceSCRelayDevice:
            if (deviceParams.length != 4) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    relayId: parseInt(deviceParams[3]),
                    deviceRoom: deviceParams[1]
                };
            }
        case exports.kVoiceESApplianceDevice:
            if (deviceParams.length != 4) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    applianceId: deviceParams[3],
                    deviceRoom: deviceParams[1]
                };
            }
        case exports.kVoiceIRACDevice:
            if (deviceParams.length != 4) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    remoteId: deviceParams[3],
                    deviceRoom: deviceParams[1]
                };
            }
        case exports.kVoiceRoomDevice:
            if (deviceParams.length != 2) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    roomId: deviceParams[1]
                };
            }
        case exports.kVoiceRGBWWADevice:
            if (deviceParams.length != 3) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    deviceRoom: deviceParams[1]
                };
            }
            break;
        default:
            throw new errors_1.DeviceErrors.InvalidDeviceType();
    }
}
exports.getKeusId = getKeusId;
function hsLToRgb(h, s, v) {
    let C = v * s;
    let X = C * (1 - Math.abs(((h / 60) % 2) - 1));
    let m = v - C;
    let rgbb = getR1G1B1(h, C, X);
    let R1 = rgbb[0];
    let G1 = rgbb[1];
    let B1 = rgbb[2];
    return [Math.round((R1 + m) * 255), Math.round((G1 + m) * 255), Math.round((B1 + m) * 255)];
    function getR1G1B1(H, c, x) {
        switch (true) {
            case (H >= 0 && H < 60):
                return [c, x, 0];
                break;
            case (H >= 60 && H < 120):
                return [x, c, 0];
                break;
            case (H >= 120 && H < 180):
                return [0, c, x];
                break;
            case (H >= 180 && H < 240):
                return [0, x, c];
                break;
            case (H >= 240 && H < 300):
                return [x, 0, c];
                break;
            case (H >= 300 && H < 360):
                return [c, 0, x];
                break;
        }
    }
}
exports.hsLToRgb = hsLToRgb;
//# sourceMappingURL=alexa-voice-utils.js.map