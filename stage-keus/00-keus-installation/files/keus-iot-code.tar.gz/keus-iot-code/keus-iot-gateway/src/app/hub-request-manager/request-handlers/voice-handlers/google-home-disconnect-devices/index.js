"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const response_1 = __importDefault(require("./response"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (googleDisconnectReq) => {
    return timed_promise_1.TPromise(function () {
        console.log('Hit Google Home Disconnect Devices');
        return new Promise(async function (resolve, reject) {
            try {
                const gatewayList = await keus_gateway_1.default.getGateway();
                const mainGateway = gatewayList.find(function (gtw) {
                    return gtw.gatewayMode == system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY;
                });
                const filteredUserList = mainGateway.googleLinkedUserList.filter(function (ph) {
                    return ph != googleDisconnectReq.getPhone();
                });
                await keus_gateway_1.default.setGoogleHomeLinkStatus(mainGateway.gatewayId, filteredUserList.length ? true : false, filteredUserList);
                resolve(response_1.default.getDisconnectDevicesSuccessful());
            }
            catch (e) {
                switch (e.constructor) {
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map