"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const google_pb_1 = require("../../../protos/generated/hub/voice/google_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class GoogleHomeDisconnectDevicesResp {
    static getDisconnectDevicesSuccessful() {
        const resp = new google_pb_1.GoogleHomeDisconnectDevicesResponse();
        resp.setCode(800);
        resp.setMessage('Disconnect Devices Successful');
        resp.setSuccess(true);
        return general_1.PackIntoAny(resp.serializeBinary(), GoogleHomeDisconnectDevicesResp.responseType);
    }
    static getInternalServerError() {
        const resp = new google_pb_1.GoogleHomeDisconnectDevicesResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        return general_1.PackIntoAny(resp.serializeBinary(), GoogleHomeDisconnectDevicesResp.responseType);
    }
}
exports.default = GoogleHomeDisconnectDevicesResp;
GoogleHomeDisconnectDevicesResp.responseType = system_constants_1.ProtoPackageName + '.GoogleHomeDisconnectDevicesResponse';
//# sourceMappingURL=response.js.map