"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const google_pb_1 = require("../../../protos/generated/hub/voice/google_pb");
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const GH = __importStar(require("../google-voice-utils"));
const HomeUtils = __importStar(require("../../../../../utilities/gateway/home-utils"));
const errors_1 = require("../../../../../errors/errors");
const scene_structures_pb_1 = require("../../../protos/generated/hub/scenes/scene_structures_pb");
const scene_handlers_1 = require("../../scene-handlers");
const zigbee_ac_fan_controller_pb_1 = require("../../../protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const dali_dimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/dali_dimmable_driver_pb");
const zigbee_dimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_dimmable_driver_pb");
const dali_nondimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/dali_nondimmable_driver_pb");
const zigbee_nondimmable_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_nondimmable_driver_pb");
const zigbee_embedded_switch_pb_1 = require("../../../protos/generated/hub/devices/zigbee_embedded_switch_pb");
const group_handlers_1 = require("../../group-handlers");
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const zigbee_curtain_controller_pb_1 = require("../../../protos/generated/hub/devices/zigbee_curtain_controller_pb");
const zigbee_curtain_controller_1 = require("../../device-handlers/zigbee-curtain-controller");
const zigbee_fan_controllers_1 = require("../../device-handlers/zigbee-fan-controllers");
const zigbee_dc_fan_controller_pb_1 = require("../../../protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const smart_console_pb_1 = require("../../../protos/generated/hub/devices/smart_console_pb");
const smart_consoles_1 = require("../../device-handlers/smart-consoles");
const zigbee_ir_blaster_pb_1 = require("../../../protos/generated/hub/devices/zigbee_ir_blaster_pb");
const zigbee_ir_blaster_1 = require("../../device-handlers/zigbee-ir-blaster");
const scene_constants_pb_1 = require("../../../protos/generated/hub/scenes/scene_constants_pb");
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const zigbee_rgbwwa_driver_pb_1 = require("../../../protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const update_rgbwwa_state_1 = __importDefault(require("../../device-handlers/zigbee-rgbwwa-drivers/update-rgbwwa-state"));
const rpc_maker_util_1 = require("../../../../../utilities/gateway/rpc-maker-util");
const zigbee_inline_dimmer_pb_1 = require("../../../protos/generated/hub/devices/zigbee_inline_dimmer_pb");
const keus_ir_remote_1 = __importDefault(require("../../../../../models/database-models/keus-ir-remote"));
const zigbee_embedded_switches_1 = require("../../device-handlers/zigbee-embedded-switches");
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (googleExecReq) => {
    return timed_promise_1.TPromise(function () {
        console.log('Hit Google Home Execute Command');
        return new Promise(async function (resolve, reject) {
            try {
                const user = await keus_user_1.default.getUserByPhone(googleExecReq.getPhone());
                if (!HomeUtils.checkUserIsAdmin(user)) {
                    throw new errors_1.GeneralErrors.InvalidUserAccessError();
                }
                else {
                    const keusDev = GH.getKeusId(googleExecReq.getGoogleDeviceId());
                    const paramsObj = JSON.parse(googleExecReq.getActionParams());
                    switch (keusDev.kDevType) {
                        case GH.kVoiceSceneDevice:
                            if (googleExecReq.getGoogleActionType() == google_pb_1.GH_EXECUTE_ACTIONS.GH_ACTIVATE_SCENE) {
                                const executeSceneReq = new scene_structures_pb_1.ExecuteScene();
                                executeSceneReq.setSceneId(keusDev.sceneId);
                                executeSceneReq.setSceneRoom(keusDev.sceneRoom);
                                const executeSceneResp = rpc_maker_util_1.UnPackFromAny(await scene_handlers_1.ExecuteScene(executeSceneReq, googleExecReq.getPhone()));
                                resolve(response_1.default.getSendResponse(executeSceneResp.getCode(), executeSceneResp.getMessage(), executeSceneResp.getSuccess(), GH.getDeviceStatusObjString(executeSceneResp.getSuccess(), executeSceneResp.getMessage(), googleExecReq.getGoogleDeviceId(), { online: true })));
                            }
                            else {
                                throw new errors_1.GeneralErrors.InvalidParameterSet();
                            }
                            break;
                        case GH.kVoiceGroupDevice:
                            const groupParamValue = getGroupParameterValue(paramsObj, googleExecReq.getGoogleActionType());
                            const execGroup = await keus_group_1.default.getGroupById(keusDev.groupId, keusDev.groupRoom);
                            if (!execGroup) {
                                throw new errors_1.GroupErrors.InvalidGroupId();
                            }
                            else {
                                const updateGroupStateReq = new group_structures_pb_1.UpdateGroupState();
                                updateGroupStateReq.setGroupId(execGroup.groupId);
                                updateGroupStateReq.setGroupRoom(execGroup.groupRoom);
                                switch (execGroup.groupType) {
                                    case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
                                        if (!groupParamValue.successState.hasOwnProperty('brightness')) {
                                            groupParamValue.successState.brightness = groupParamValue.successState.on
                                                ? 100
                                                : 0;
                                        }
                                        const daliDimmableGrpStateReq = new dali_dimmable_driver_pb_1.DaliDimmableDriverState();
                                        daliDimmableGrpStateReq.setDriverState(groupParamValue.value);
                                        updateGroupStateReq.setDdimmableDriverState(daliDimmableGrpStateReq);
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
                                        if (!groupParamValue.successState.hasOwnProperty('brightness')) {
                                            groupParamValue.successState.brightness = groupParamValue.successState.on
                                                ? 100
                                                : 0;
                                        }
                                        const zigbeeDimmableGrpStateReq = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverState();
                                        zigbeeDimmableGrpStateReq.setDriverState(groupParamValue.value);
                                        updateGroupStateReq.setZdimmableDriverState(zigbeeDimmableGrpStateReq);
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
                                        const daliNonDimmableGrpStateReq = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverState();
                                        daliNonDimmableGrpStateReq.setDriverState(groupParamValue.value);
                                        updateGroupStateReq.setDnondimmableDriverState(daliNonDimmableGrpStateReq);
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
                                        const zigbeeNonDimmableGrpStateReq = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverState();
                                        zigbeeNonDimmableGrpStateReq.setDriverState(groupParamValue.value);
                                        updateGroupStateReq.setZnondimmableDriverState(zigbeeNonDimmableGrpStateReq);
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
                                        console.log('THIS IS GROUP PARAM VALUE', groupParamValue);
                                        if (!groupParamValue.successState.hasOwnProperty('brightness')) {
                                            groupParamValue.successState.brightness = groupParamValue.successState.on
                                                ? 100
                                                : 0;
                                        }
                                        const zigbeeInlineGrpStateReq = new zigbee_inline_dimmer_pb_1.ZigbeeInlineDimmerState();
                                        zigbeeInlineGrpStateReq.setDeviceState(groupParamValue.value);
                                        updateGroupStateReq.setZinlineDimmerState(zigbeeInlineGrpStateReq);
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
                                        const applianceOnOffGrpReq = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
                                        applianceOnOffGrpReq.setSwitchState(groupParamValue.value);
                                        updateGroupStateReq.setAppOnffState(applianceOnOffGrpReq);
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                                        if (!groupParamValue.successState.hasOwnProperty('brightness')) {
                                            groupParamValue.successState.brightness = groupParamValue.successState.on
                                                ? 100
                                                : 0;
                                        }
                                        const applianceSDimmerGrpReq = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
                                        applianceSDimmerGrpReq.setSwitchState(groupParamValue.value);
                                        updateGroupStateReq.setAppSingleDimmerState(applianceSDimmerGrpReq);
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                                        if (!groupParamValue.successState.currentFanSpeedSetting &&
                                            groupParamValue.successState.on) {
                                            groupParamValue.successState.currentFanSpeedSetting = GH.fanSpeedMax;
                                        }
                                        const applianceFanGrpReq = new zigbee_embedded_switch_pb_1.FanApplianceState();
                                        applianceFanGrpReq.setFanState(groupParamValue.value);
                                        updateGroupStateReq.setAppFanState(applianceFanGrpReq);
                                        break;
                                    case group_structures_pb_1.GROUP_TYPES.RGBWWA:
                                        const rgbwwaGroupParamValue = getRGBWWAGroupParamValue(paramsObj, googleExecReq.getGoogleActionType(), execGroup);
                                        const rgbwwaGrpReq = new zigbee_rgbwwa_driver_pb_1.GroupZigbeeRgbwwaState();
                                        rgbwwaGrpReq.setDeviceState(rgbwwaGroupParamValue.onValue);
                                        rgbwwaGrpReq.setUpdateType(rgbwwaGroupParamValue.updateType);
                                        switch (rgbwwaGroupParamValue.updateType) {
                                            case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE:
                                                const rgbValue = new zigbee_rgbwwa_driver_pb_1.RGB();
                                                rgbValue.setDeviceState(rgbwwaGroupParamValue.onValue);
                                                rgbValue.setRed(rgbwwaGroupParamValue.redValue);
                                                rgbValue.setBlue(rgbwwaGroupParamValue.blueValue);
                                                rgbValue.setGreen(rgbwwaGroupParamValue.greenValue);
                                                rgbValue.setPattern(rgbwwaGroupParamValue.patternValue);
                                                rgbwwaGrpReq.setRgbState(rgbValue);
                                                break;
                                            case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE:
                                                const wwaValue = new zigbee_rgbwwa_driver_pb_1.WWA();
                                                wwaValue.setDeviceState(rgbwwaGroupParamValue.onValue);
                                                wwaValue.setWarmWhite(rgbwwaGroupParamValue.warmWhiteValue);
                                                wwaValue.setCoolWhite(rgbwwaGroupParamValue.coolWhiteValue);
                                                wwaValue.setAmber(rgbwwaGroupParamValue.amberValue);
                                                rgbwwaGrpReq.setWwaState(wwaValue);
                                                break;
                                        }
                                        updateGroupStateReq.setZrgbwwaState(rgbwwaGrpReq);
                                        break;
                                    // case GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                                    //     break;
                                    default:
                                        throw new errors_1.GroupErrors.InvalidPropertySet();
                                }
                                const updateGroupStateResp = rpc_maker_util_1.UnPackFromAny(await group_handlers_1.UpdateGroupState(updateGroupStateReq, googleExecReq.getPhone()));
                                resolve(response_1.default.getSendResponse(updateGroupStateResp.getCode(), updateGroupStateResp.getMessage(), updateGroupStateResp.getSuccess(), GH.getDeviceStatusObjString(updateGroupStateResp.getSuccess(), updateGroupStateResp.getMessage(), googleExecReq.getGoogleDeviceId(), groupParamValue.successState)));
                            }
                            break;
                        case GH.kVoiceEmbeddedApplianceDevice:
                            const esDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                            if (!esDevice) {
                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                            }
                            else {
                                const esDeviceProps = esDevice.deviceProperties;
                                const appliance = esDeviceProps.appliance.find(function (esAppl) {
                                    return esAppl.applianceId == keusDev.applianceId;
                                });
                                if (!appliance) {
                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                }
                                else {
                                    const applianceParamValue = getApplianceParamValue(paramsObj, googleExecReq.getGoogleActionType());
                                    const updateApplianceStateReq = new zigbee_embedded_switch_pb_1.UpdateApplianceState();
                                    updateApplianceStateReq.setDeviceId(esDevice.deviceId);
                                    updateApplianceStateReq.setApplianceId(appliance.applianceId);
                                    switch (appliance.applianceType) {
                                        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                                            const applianceOnOffReq = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
                                            applianceOnOffReq.setSwitchState(applianceParamValue.value);
                                            updateApplianceStateReq.setOnOffState(applianceOnOffReq);
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                                            if (!applianceParamValue.successState.hasOwnProperty('brightness')) {
                                                applianceParamValue.successState.brightness = groupParamValue.successState.on
                                                    ? 100
                                                    : 0;
                                            }
                                            const applianceSDimmerReq = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
                                            applianceSDimmerReq.setSwitchState(applianceParamValue.value);
                                            updateApplianceStateReq.setSingleDimmerState(applianceSDimmerReq);
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                                            if (!applianceParamValue.successState.currentFanSpeedSetting &&
                                                applianceParamValue.successState.on) {
                                                applianceParamValue.successState.currentFanSpeedSetting = GH.fanSpeedMax;
                                            }
                                            const applianceFanReq = new zigbee_embedded_switch_pb_1.FanApplianceState();
                                            applianceFanReq.setFanState(applianceParamValue.value);
                                            updateApplianceStateReq.setFanState(applianceFanReq);
                                            break;
                                        // case GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                                        //     break;
                                        default:
                                            throw new errors_1.GroupErrors.InvalidPropertySet();
                                    }
                                    const updateApplianceStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_embedded_switches_1.UpdateApplianceState(updateApplianceStateReq, googleExecReq.getPhone()));
                                    resolve(response_1.default.getSendResponse(updateApplianceStateResp.getCode(), updateApplianceStateResp.getMessage(), updateApplianceStateResp.getSuccess(), GH.getDeviceStatusObjString(updateApplianceStateResp.getSuccess(), updateApplianceStateResp.getMessage(), googleExecReq.getGoogleDeviceId(), applianceParamValue.successState)));
                                }
                            }
                            break;
                        case GH.kVoiceCurtainDevice:
                            const crtDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                            if (!crtDevice) {
                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                            }
                            else {
                                const curtainParamValue = getCurtainControllerParamValue(paramsObj, googleExecReq.getGoogleActionType());
                                const updateCurtainStateReq = new zigbee_curtain_controller_pb_1.UpdateZigbeeCurtainControllerState();
                                updateCurtainStateReq.setCurtainState(curtainParamValue.value);
                                updateCurtainStateReq.setDeviceId(crtDevice.deviceId);
                                const updateCurtainStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_curtain_controller_1.UpdateZigbeeCurtainControllerState(updateCurtainStateReq, googleExecReq.getPhone()));
                                resolve(response_1.default.getSendResponse(updateCurtainStateResp.getCode(), updateCurtainStateResp.getMessage(), updateCurtainStateResp.getSuccess(), GH.getDeviceStatusObjString(updateCurtainStateResp.getSuccess(), updateCurtainStateResp.getMessage(), googleExecReq.getGoogleDeviceId(), curtainParamValue.successState)));
                            }
                            break;
                        case GH.kVoiceACFanDevice:
                            const acFanParamValue = getACFanControllerParamValue(paramsObj, googleExecReq.getGoogleActionType());
                            const updateACFCStateReq = new zigbee_ac_fan_controller_pb_1.UpdateZigbeeACFanControllerState();
                            updateACFCStateReq.setDeviceId(keusDev.deviceId);
                            console.log('THIS SI AC FAN PARAM VALUE', acFanParamValue.value);
                            updateACFCStateReq.setFanState(acFanParamValue.value);
                            updateACFCStateReq.setUpdateType(device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_FAN_UPDATE);
                            const updateACFCStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_fan_controllers_1.UpdateZigbeeACFanControllerState(updateACFCStateReq, googleExecReq.getPhone()));
                            resolve(response_1.default.getSendResponse(updateACFCStateResp.getCode(), updateACFCStateResp.getMessage(), updateACFCStateResp.getSuccess(), GH.getDeviceStatusObjString(updateACFCStateResp.getSuccess(), updateACFCStateResp.getMessage(), googleExecReq.getGoogleDeviceId(), acFanParamValue.successState)));
                            break;
                        case GH.kVoiceDCFanDevice:
                            const dcFanParamValue = getDCFanControllerParamValue(paramsObj, googleExecReq.getGoogleActionType());
                            const updateDCFCStateReq = new zigbee_dc_fan_controller_pb_1.UpdateZigbeeDCFanControllerState();
                            updateDCFCStateReq.setDeviceId(keusDev.deviceId);
                            updateDCFCStateReq.setFanState(dcFanParamValue.value);
                            updateDCFCStateReq.setUpdateType(device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_FAN_UPDATE);
                            const updateDCFCStateResp = rpc_maker_util_1.UnPackFromAny(await zigbee_fan_controllers_1.UpdateZigbeeDCFanControllerState(updateDCFCStateReq, googleExecReq.getPhone()));
                            resolve(response_1.default.getSendResponse(updateDCFCStateResp.getCode(), updateDCFCStateResp.getMessage(), updateDCFCStateResp.getSuccess(), GH.getDeviceStatusObjString(updateDCFCStateResp.getSuccess(), updateDCFCStateResp.getMessage(), googleExecReq.getGoogleDeviceId(), dcFanParamValue.successState)));
                            break;
                        case GH.kVoiceSCRelayDevice:
                            const scRelayParamValue = getSCRelayParamValue(paramsObj, googleExecReq.getGoogleActionType());
                            const updateSCRelayStateReq = new smart_console_pb_1.SetConsoleRelayState();
                            updateSCRelayStateReq.setDeviceId(keusDev.deviceId);
                            updateSCRelayStateReq.setRelayId(keusDev.relayId);
                            updateSCRelayStateReq.setRelayState(scRelayParamValue.value);
                            const updateSCRelayStateResp = rpc_maker_util_1.UnPackFromAny(await smart_consoles_1.SetConsoleRelayState(updateSCRelayStateReq, googleExecReq.getPhone()));
                            resolve(response_1.default.getSendResponse(updateSCRelayStateResp.getCode(), updateSCRelayStateResp.getMessage(), updateSCRelayStateResp.getSuccess(), GH.getDeviceStatusObjString(updateSCRelayStateResp.getSuccess(), updateSCRelayStateResp.getMessage(), googleExecReq.getGoogleDeviceId(), scRelayParamValue.successState)));
                            break;
                        case GH.kVoiceIRACDevice:
                            const iracRemoteDevice = await keus_ir_remote_1.default.getIRRemoteById(keusDev.remoteId);
                            if (!iracRemoteDevice) {
                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                            }
                            else {
                                const iracRemoteDeviceState = iracRemoteDevice.remoteState;
                                const irACParamValue = getIRACParamValue(paramsObj, googleExecReq.getGoogleActionType(), iracRemoteDevice);
                                const blastIRCommandReq = new zigbee_ir_blaster_pb_1.BlastIRCommand();
                                blastIRCommandReq.setRemoteId(keusDev.remoteId);
                                blastIRCommandReq.setRemoteType(device_constants_pb_1.IR_REMOTE_TYPES.IR_AC);
                                const irACBlast = new zigbee_ir_blaster_pb_1.IRACBlast();
                                irACBlast.setSwingHLevel(iracRemoteDeviceState.swingHLevel);
                                irACBlast.setSwingVLevel(iracRemoteDeviceState.swingVLevel);
                                irACBlast.setUpdateType(irACParamValue.updateType);
                                switch (irACParamValue.updateType) {
                                    case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_ONOFF:
                                        irACBlast.setPowerOn(irACParamValue.onValue);
                                        irACBlast.setTemperature(iracRemoteDeviceState.temperature);
                                        irACBlast.setMode(iracRemoteDeviceState.mode);
                                        irACBlast.setFanLevel(iracRemoteDeviceState.fanLevel);
                                        break;
                                    case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_TEMPERATURE:
                                        irACBlast.setPowerOn(irACParamValue.onValue);
                                        irACBlast.setTemperature(irACParamValue.temperatureValue);
                                        irACBlast.setMode(iracRemoteDeviceState.mode);
                                        irACBlast.setFanLevel(iracRemoteDeviceState.fanLevel);
                                        break;
                                    case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_MODE:
                                        irACBlast.setPowerOn(irACParamValue.onValue);
                                        irACBlast.setTemperature(iracRemoteDeviceState.temperature);
                                        irACBlast.setMode(irACParamValue.modeValue);
                                        irACBlast.setFanLevel(iracRemoteDeviceState.fanLevel);
                                        break;
                                    case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_FANLVL:
                                        irACBlast.setPowerOn(irACParamValue.onValue);
                                        irACBlast.setTemperature(iracRemoteDeviceState.temperature);
                                        irACBlast.setMode(iracRemoteDeviceState.mode);
                                        irACBlast.setFanLevel(irACParamValue.fanValue);
                                        break;
                                    default:
                                        throw new errors_1.GeneralErrors.InvalidParameterSet();
                                }
                                blastIRCommandReq.setAcBlastInfo(irACBlast);
                                const blastIRCommandResp = rpc_maker_util_1.UnPackFromAny(await zigbee_ir_blaster_1.BlastIRCommand(blastIRCommandReq, googleExecReq.getPhone()));
                                resolve(response_1.default.getSendResponse(blastIRCommandResp.getCode(), blastIRCommandResp.getMessage(), blastIRCommandResp.getSuccess(), GH.getDeviceStatusObjString(blastIRCommandResp.getSuccess(), blastIRCommandResp.getMessage(), googleExecReq.getGoogleDeviceId(), irACParamValue.successState)));
                                resolve(zigbee_ir_blaster_1.BlastIRCommand(blastIRCommandReq, googleExecReq.getPhone()));
                            }
                            break;
                        case GH.kVoiceRoomDevice:
                            const roomParamValue = getRoomParamValue(paramsObj, googleExecReq.getGoogleActionType());
                            const execSceneList = await keus_scene_1.default.getSceneByRoomAndType(keusDev.roomId, roomParamValue.sceneType);
                            if (!execSceneList.length) {
                                throw new errors_1.SceneErrors.InvalidSceneId();
                            }
                            else {
                                const execScene = execSceneList[0];
                                const executeRoomSceneReq = new scene_structures_pb_1.ExecuteScene();
                                executeRoomSceneReq.setSceneId(execScene.sceneId);
                                executeRoomSceneReq.setSceneRoom(execScene.sceneRoom);
                                const executeRoomSceneResp = rpc_maker_util_1.UnPackFromAny(await scene_handlers_1.ExecuteScene(executeRoomSceneReq, googleExecReq.getPhone()));
                                resolve(response_1.default.getSendResponse(executeRoomSceneResp.getCode(), executeRoomSceneResp.getMessage(), executeRoomSceneResp.getSuccess(), GH.getDeviceStatusObjString(executeRoomSceneResp.getSuccess(), executeRoomSceneResp.getMessage(), googleExecReq.getGoogleDeviceId(), roomParamValue.successState)));
                            }
                            break;
                        case GH.kVoiceRGBWWADevice:
                            const rgbwwaDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                            if (!rgbwwaDevice) {
                                throw new errors_1.DeviceErrors.InvalidDeviceId();
                            }
                            else {
                                const rgbwwaParamValue = getRGBWWAParamValue(paramsObj, googleExecReq.getGoogleActionType(), rgbwwaDevice);
                                const updateRGBWWAStateReq = new zigbee_rgbwwa_driver_pb_1.UpdateZigbeeRgbwwaState();
                                updateRGBWWAStateReq.setDeviceId(keusDev.deviceId);
                                updateRGBWWAStateReq.setDeviceState(rgbwwaParamValue.onValue);
                                updateRGBWWAStateReq.setUpdateType(rgbwwaParamValue.updateType);
                                console.log('SETTING PARAM VALUES', rgbwwaParamValue);
                                switch (rgbwwaParamValue.updateType) {
                                    case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE:
                                        const rgbUpdate = new zigbee_rgbwwa_driver_pb_1.RGB();
                                        rgbUpdate.setRed(rgbwwaParamValue.redValue);
                                        rgbUpdate.setGreen(rgbwwaParamValue.greenValue);
                                        rgbUpdate.setBlue(rgbwwaParamValue.blueValue);
                                        updateRGBWWAStateReq.setRgbState(rgbUpdate);
                                        break;
                                    case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE:
                                        const wwaUpdate = new zigbee_rgbwwa_driver_pb_1.WWA();
                                        wwaUpdate.setCoolWhite(rgbwwaParamValue.coolWhiteValue);
                                        wwaUpdate.setWarmWhite(rgbwwaParamValue.warmWhiteValue);
                                        wwaUpdate.setAmber(rgbwwaParamValue.amberValue);
                                        updateRGBWWAStateReq.setWwaState(wwaUpdate);
                                        break;
                                }
                                const updateRgbwwaStateResp = rpc_maker_util_1.UnPackFromAny(await update_rgbwwa_state_1.default(updateRGBWWAStateReq, googleExecReq.getPhone()));
                                resolve(response_1.default.getSendResponse(updateRgbwwaStateResp.getCode(), updateRgbwwaStateResp.getMessage(), updateRgbwwaStateResp.getSuccess(), GH.getDeviceStatusObjString(updateRgbwwaStateResp.getSuccess(), updateRgbwwaStateResp.getMessage(), googleExecReq.getGoogleDeviceId(), rgbwwaParamValue.successState)));
                            }
                            break;
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GroupErrors.InvalidGroupId:
                    case errors_1.SceneErrors.InvalidSceneId:
                    case errors_1.DeviceErrors.InvalidDeviceId:
                        resolve(response_1.default.getInvalidDeviceId(JSON.stringify({
                            ids: [googleExecReq.getGoogleDeviceId()],
                            status: GH.failureString,
                            errorCode: 'Invalid Device ID'
                        })));
                        break;
                    case errors_1.GroupErrors.InvalidPropertySet:
                    case errors_1.GeneralErrors.InvalidParameterSet:
                        resolve(response_1.default.getInvalidParameterSet(JSON.stringify({
                            ids: [googleExecReq.getGoogleDeviceId()],
                            status: GH.failureString,
                            errorCode: 'Invalid Parameter Set'
                        })));
                        break;
                    case errors_1.GeneralErrors.InvalidUserAccessError:
                        resolve(response_1.default.getInsufficientUserAccess(JSON.stringify({
                            ids: [googleExecReq.getGoogleDeviceId()],
                            status: GH.failureString,
                            errorCode: 'Insufficient Permissions for user'
                        })));
                        break;
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError(JSON.stringify({
                            ids: [googleExecReq.getGoogleDeviceId()],
                            status: GH.failureString,
                            errorCode: 'Unable to contact device'
                        })));
                }
            }
        });
    });
};
function getGroupParameterValue(paramsObj, googleActionType) {
    switch (googleActionType) {
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_BRIGHTNESS_ABSOLUTE:
            if (paramsObj.hasOwnProperty('brightness')) {
                return {
                    value: Math.floor((paramsObj.brightness * 255) / 100),
                    successState: {
                        online: true,
                        brightness: paramsObj.brightness
                    }
                };
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_ONOFF:
            if (paramsObj.hasOwnProperty('on')) {
                return {
                    value: paramsObj.on ? 255 : 0,
                    successState: {
                        online: true,
                        on: paramsObj.on
                    }
                };
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_SET_FAN_SPEED:
            if (paramsObj.hasOwnProperty('fanSpeed')) {
                var res = {};
                res.successState = {
                    online: true,
                    currentFanSpeedSetting: paramsObj.fanSpeed
                };
                switch (paramsObj.fanSpeed) {
                    case GH.fanSpeedMax:
                        res.value = 255;
                        break;
                    case GH.fanSpeedHigh:
                        res.value = 195;
                        break;
                    case GH.fanSpeedMedium:
                        res.value = 130;
                        break;
                    case GH.fanSpeedLow:
                        res.value = 65;
                        break;
                    default:
                        throw new errors_1.GeneralErrors.InvalidParameterSet();
                }
                return res;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
        default:
            throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
}
function getApplianceParamValue(paramsObj, googleActionType) {
    switch (googleActionType) {
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_BRIGHTNESS_ABSOLUTE:
            if (paramsObj.hasOwnProperty('brightness')) {
                return {
                    value: Math.floor((paramsObj.brightness * 255) / 100),
                    successState: {
                        online: true,
                        brightness: paramsObj.brightness
                    }
                };
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_ONOFF:
            if (paramsObj.hasOwnProperty('on')) {
                return {
                    value: paramsObj.on ? 255 : 0,
                    successState: {
                        online: true,
                        on: paramsObj.on
                    }
                };
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_SET_FAN_SPEED:
            if (paramsObj.hasOwnProperty('fanSpeed')) {
                var res = {};
                res.successState = {
                    online: true,
                    currentFanSpeedSetting: paramsObj.fanSpeed
                };
                switch (paramsObj.fanSpeed) {
                    case GH.fanSpeedMax:
                        res.value = 255;
                        break;
                    case GH.fanSpeedHigh:
                        res.value = 195;
                        break;
                    case GH.fanSpeedMedium:
                        res.value = 130;
                        break;
                    case GH.fanSpeedLow:
                        res.value = 65;
                        break;
                    default:
                        throw new errors_1.GeneralErrors.InvalidParameterSet();
                }
                return res;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
        default:
            throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
}
function getCurtainControllerParamValue(paramsObj, googleActionType) {
    var curtainVal;
    var successState;
    if (googleActionType != google_pb_1.GH_EXECUTE_ACTIONS.GH_OPENCLOSE) {
        throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
    else {
        if (paramsObj.openDirection) {
            switch (paramsObj.openDirection) {
                case GH.curtainDown:
                case GH.curtainLeft:
                    curtainVal = device_constants_pb_1.CURTAIN_CONTROLLER_ACTION.CC_CLOSE;
                    successState = {
                        online: true,
                        openState: [{ openPercent: 0, openDirection: paramsObj.openDirection }]
                    };
                    break;
                case GH.curtainUp:
                case GH.curtainRight:
                    curtainVal = device_constants_pb_1.CURTAIN_CONTROLLER_ACTION.CC_OPEN;
                    successState = {
                        online: true,
                        openState: [{ openPercent: 100, openDirection: paramsObj.openDirection }]
                    };
                    break;
                default:
                    throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            return {
                value: curtainVal,
                successState: successState
            };
        }
        else if (paramsObj.hasOwnProperty('openPercent')) {
            curtainVal = paramsObj.openPercent
                ? device_constants_pb_1.CURTAIN_CONTROLLER_ACTION.CC_OPEN
                : device_constants_pb_1.CURTAIN_CONTROLLER_ACTION.CC_CLOSE;
            return {
                value: curtainVal,
                successState: {
                    online: true,
                    openPercent: paramsObj.openPercent
                }
            };
        }
        else {
            throw new errors_1.GeneralErrors.InvalidParameterSet();
        }
    }
}
function getACFanControllerParamValue(paramsObj, googleActionType) {
    var acFanSpeedVal;
    switch (googleActionType) {
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_ONOFF:
            if (paramsObj.hasOwnProperty('on')) {
                const returnVal = {
                    value: paramsObj.on ? zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_MAX : zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_OFF,
                    successState: {
                        online: true,
                        on: paramsObj.on
                    }
                };
                if (paramsObj.on) {
                    returnVal.successState.currentFanSpeedSetting = GH.fanSpeedMax;
                }
                return returnVal;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_SET_FAN_SPEED:
            if (paramsObj.hasOwnProperty('fanSpeed')) {
                var res = {};
                res.successState = {
                    online: true,
                    currentFanSpeedSetting: paramsObj.fanSpeed
                };
                switch (paramsObj.fanSpeed) {
                    case GH.fanSpeedMax:
                        res.value = zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_MAX;
                        break;
                    case GH.fanSpeedHigh:
                        res.value = zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_HIGH;
                        break;
                    case GH.fanSpeedMedium:
                        res.value = zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_MED;
                        break;
                    case GH.fanSpeedLow:
                        res.value = zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_LOW;
                        break;
                    default:
                        throw new errors_1.GeneralErrors.InvalidParameterSet();
                }
                return res;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
        default:
            throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
}
function getDCFanControllerParamValue(paramsObj, googleActionType) {
    var dcFanSpeedVal;
    switch (googleActionType) {
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_ONOFF:
            if (paramsObj.hasOwnProperty('on')) {
                const returnVal = {
                    value: paramsObj.on ? zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_MAX : zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_OFF,
                    successState: {
                        online: true,
                        on: paramsObj.on
                    }
                };
                if (paramsObj.on) {
                    returnVal.successState.currentFanSpeedSetting = GH.fanSpeedMax;
                }
                return returnVal;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_SET_FAN_SPEED:
            if (paramsObj.hasOwnProperty('fanSpeed')) {
                var res = {};
                res.successState = {
                    online: true,
                    currentFanSpeedSetting: paramsObj.fanSpeed
                };
                switch (paramsObj.fanSpeed) {
                    case GH.fanSpeedMax:
                        res.value = zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_MAX;
                        break;
                    case GH.fanSpeedHigh:
                        res.value = zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_HIGH;
                        break;
                    case GH.fanSpeedMedium:
                        res.value = zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_MAX;
                        break;
                    case GH.fanSpeedLow:
                        res.value = zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_LOW;
                        break;
                    default:
                        throw new errors_1.GeneralErrors.InvalidParameterSet();
                }
                return res;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        default:
            throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
}
function getSCRelayParamValue(paramsObj, googleActionType) {
    var onValue;
    if (googleActionType != google_pb_1.GH_EXECUTE_ACTIONS.GH_ONOFF) {
        throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
    else {
        if (paramsObj.hasOwnProperty('on')) {
            return {
                value: paramsObj.on ? 255 : 0,
                successState: {
                    online: true,
                    on: paramsObj.on
                }
            };
        }
        else {
            throw new errors_1.GeneralErrors.InvalidParameterSet();
        }
    }
}
function getIRACParamValue(paramsObj, googleActionType, iracRemoteDevice) {
    console.log('THIS IS AC PARAMS', paramsObj);
    const acRemoteProps = iracRemoteDevice.remoteProperties;
    const acRemoteState = iracRemoteDevice.remoteState;
    var returnVal = {};
    if (googleActionType == google_pb_1.GH_EXECUTE_ACTIONS.GH_ONOFF) {
        if (paramsObj.hasOwnProperty('on')) {
            returnVal = {
                onValue: paramsObj.on,
                updateType: zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_ONOFF,
                successState: {
                    online: true,
                    on: paramsObj.on
                }
            };
            if (paramsObj.on) {
                returnVal.successState.thermostatTemperatureSetpoint = acRemoteState.temperature;
                if (acRemoteProps.modeEnabled &&
                    GH.acunitSupportedModeList.indexOf(acRemoteState.mode.toLowerCase()) > -1) {
                    returnVal.successState.thermostatMode = GH.getGoogleAcMode(acRemoteState.mode);
                }
                if (acRemoteProps.fanEnabled) {
                    const fanLevel = GH.getGoogleAcUnitFanSpeed(acRemoteState.fanLevel);
                    if (fanLevel) {
                        returnVal.successState.currentFanSpeedSetting = fanLevel;
                    }
                }
            }
            return returnVal;
        }
        else {
            throw new errors_1.GeneralErrors.InvalidParameterSet();
        }
    }
    else if (googleActionType == google_pb_1.GH_EXECUTE_ACTIONS.GH_TS_TEMPSETPOINT) {
        if (paramsObj.hasOwnProperty('thermostatTemperatureSetpoint')) {
            returnVal = {
                onValue: true,
                updateType: zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_TEMPERATURE,
                temperatureValue: Math.floor(paramsObj.thermostatTemperatureSetpoint),
                successState: {
                    online: true,
                    on: true,
                    thermostatTemperatureSetpoint: Math.floor(paramsObj.thermostatTemperatureSetpoint)
                }
            };
            if (acRemoteProps.modeEnabled &&
                GH.acunitSupportedModeList.indexOf(acRemoteState.mode.toLowerCase()) > -1) {
                returnVal.successState.thermostatMode = GH.getGoogleAcMode(acRemoteState.mode);
            }
            if (acRemoteProps.fanEnabled) {
                const fanLevel = GH.getGoogleAcUnitFanSpeed(acRemoteState.fanLevel);
                if (fanLevel) {
                    returnVal.successState.currentFanSpeedSetting = fanLevel;
                }
            }
            return returnVal;
        }
        else {
            throw new errors_1.GeneralErrors.InvalidParameterSet();
        }
    }
    else if (googleActionType == google_pb_1.GH_EXECUTE_ACTIONS.GH_TS_SETMODE) {
        if (paramsObj.hasOwnProperty('thermostatMode')) {
            returnVal = {
                onValue: true,
                updateType: zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_MODE,
                modeValue: GH.getKeusAcMode(paramsObj.thermostatMode),
                successState: {
                    online: true,
                    on: true,
                    thermostatMode: paramsObj.thermostatMode,
                    thermostatTemperatureSetpoint: acRemoteState.temperature
                }
            };
            if (acRemoteProps.fanEnabled) {
                const fanLevel = GH.getGoogleAcUnitFanSpeed(acRemoteState.fanLevel);
                if (fanLevel) {
                    returnVal.successState.currentFanSpeedSetting = fanLevel;
                }
            }
            return returnVal;
        }
        else {
            throw new errors_1.GeneralErrors.InvalidParameterSet();
        }
    }
    else if (googleActionType == google_pb_1.GH_EXECUTE_ACTIONS.GH_SET_FAN_SPEED) {
        if (paramsObj.hasOwnProperty('fanSpeed')) {
            returnVal = {
                onValue: true,
                updateType: zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_FANLVL,
                successState: {
                    online: true,
                    on: true,
                    thermostatTemperatureSetpoint: acRemoteState.temperature
                }
            };
            const keusAcFanSpeed = GH.getKeusAcUnitFanSpeed(paramsObj.fanSpeed);
            if (keusAcFanSpeed) {
                returnVal.fanValue = keusAcFanSpeed;
                returnVal.successState.currentFanSpeedSetting = paramsObj.fanSpeed;
                if (acRemoteProps.modeEnabled &&
                    GH.acunitSupportedModeList.indexOf(acRemoteState.mode.toLowerCase()) > -1) {
                    returnVal.successState.thermostatMode = GH.getGoogleAcMode(acRemoteState.mode);
                }
                return returnVal;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
        }
        else {
            throw new errors_1.GeneralErrors.InvalidParameterSet();
        }
    }
    else {
        throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
}
function getRoomParamValue(paramsObj, googleActionType) {
    if (googleActionType != google_pb_1.GH_EXECUTE_ACTIONS.GH_ONOFF) {
        throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
    else {
        if (paramsObj.hasOwnProperty('on')) {
            return {
                sceneType: paramsObj.on ? scene_constants_pb_1.SCENE_TYPE.ALLON : scene_constants_pb_1.SCENE_TYPE.ALLOFF,
                successState: {
                    online: true,
                    on: paramsObj.on
                }
            };
        }
        else {
            throw new errors_1.GeneralErrors.InvalidParameterSet();
        }
    }
}
function getRGBWWAParamValue(paramsObj, googleActionType, rgbwwaDevice) {
    const rgbWWAState = rgbwwaDevice.deviceState;
    var res = {};
    switch (googleActionType) {
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_ONOFF:
            if (paramsObj.hasOwnProperty('on')) {
                res.onValue = paramsObj.on ? 255 : 0;
                if (rgbWWAState.defaultUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE;
                    res.redValue = rgbWWAState.lastUpdatedRGBAction.red;
                    res.blueValue = rgbWWAState.lastUpdatedRGBAction.blue;
                    res.greenValue = rgbWWAState.lastUpdatedRGBAction.green;
                    res.patternValue = rgbWWAState.lastUpdatedRGBAction.pattern;
                    res.coolWhiteValue = 0;
                    res.warmWhiteValue = 0;
                    res.amberValue = 0;
                    res.successState = {
                        online: true,
                        on: paramsObj.on
                    };
                }
                else {
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE;
                    res.redValue = 0;
                    res.blueValue = 0;
                    res.greenValue = 0;
                    res.patternValue = 0;
                    res.coolWhiteValue = rgbWWAState.lastUpdatedWWAAction.coolWhite;
                    res.warmWhiteValue = rgbWWAState.lastUpdatedWWAAction.warmWhite;
                    res.amberValue = rgbWWAState.lastUpdatedWWAAction.amber;
                    res.successState = {
                        online: true,
                        on: paramsObj.on
                    };
                }
                return res;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_BRIGHTNESS_ABSOLUTE:
            if (paramsObj.hasOwnProperty('brightness')) {
                res.onValue = 255;
                res.successState = {
                    online: true,
                    brightness: paramsObj.brightness
                };
                if (rgbWWAState.defaultUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE;
                    res.redValue = rgbWWAState.lastUpdatedRGBAction.red
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.blueValue = rgbWWAState.lastUpdatedRGBAction.blue
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.greenValue = rgbWWAState.lastUpdatedRGBAction.green
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.patternValue = rgbWWAState.defaultRgbAction.pattern;
                    res.coolWhiteValue = 0;
                    res.warmWhiteValue = 0;
                    res.amberValue = 0;
                }
                else {
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE;
                    res.redValue = 0;
                    res.blueValue = 0;
                    res.greenValue = 0;
                    res.patternValue = 0;
                    res.coolWhiteValue = rgbWWAState.lastUpdatedWWAAction.coolWhite
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.warmWhiteValue = rgbWWAState.lastUpdatedWWAAction.warmWhite
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.amberValue = rgbWWAState.lastUpdatedWWAAction.amber
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                }
                return res;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_COLOR_ABSOLUTE:
            res.onValue = 255;
            if (paramsObj.hasOwnProperty('color')) {
                if (paramsObj.color.temperature) {
                    const curTemp = paramsObj.color.temperature;
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE;
                    res.redValue = 0;
                    res.blueValue = 0;
                    res.greenValue = 0;
                    res.patternValue = 0;
                    res.amberValue = 0;
                    res.coolWhiteValue = Math.min(255, paramsObj.color.temperature >= GH.rgbwwaMidtemp
                        ? 255
                        : Math.floor(((curTemp - GH.rgbwwaMinTemp) / (GH.rgbwwaMaxTemp + 1 - curTemp)) * 255));
                    res.warmWhiteValue = Math.min(255, paramsObj.color.temperature <= GH.rgbwwaMidtemp
                        ? 255
                        : Math.floor(((GH.rgbwwaMaxTemp - curTemp) / (curTemp + 1 - GH.rgbwwaMinTemp)) * 255));
                    res.successState = {
                        online: true,
                        color: {
                            temperatureK: paramsObj.color.temperature
                        }
                    };
                    return res;
                }
                else if (paramsObj.color.spectrumRGB) {
                    const colorDecimal = paramsObj.color.spectrumRGB;
                    const r = Math.floor(colorDecimal / 65536);
                    const g = Math.floor((colorDecimal - r * 65536) / 256);
                    const b = Math.floor(colorDecimal - r * 65536 - g * 256);
                    const maxRGBVal = r > g ? (r > b ? r : b) : g > b ? g : b;
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE;
                    res.redValue = Math.floor(maxRGBVal ? (255 * r) / maxRGBVal : 0);
                    res.blueValue = Math.floor(maxRGBVal ? (255 * b) / maxRGBVal : 0);
                    res.greenValue = Math.floor(maxRGBVal ? (255 * g) / maxRGBVal : 0);
                    res.patternValue = 0;
                    res.amberValue = 0;
                    res.coolWhiteValue = 0;
                    res.warmWhiteValue = 0;
                    res.successState = {
                        online: true,
                        color: {
                            spectrumRGB: paramsObj.color.spectrumRGB,
                            name: paramsObj.color.name
                        }
                    };
                    return res;
                }
                else {
                    throw new errors_1.GeneralErrors.InvalidParameterSet();
                }
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        default:
            throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
}
function getRGBWWAGroupParamValue(paramsObj, googleActionType, rgbwwaGroup) {
    const rgbWWAState = rgbwwaGroup.groupState;
    var res = {};
    switch (googleActionType) {
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_ONOFF:
            if (paramsObj.hasOwnProperty('on')) {
                res.onValue = paramsObj.on ? 255 : 0;
                if (rgbWWAState.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE;
                    res.redValue = rgbWWAState.rgbState.red;
                    res.blueValue = rgbWWAState.rgbState.blue;
                    res.greenValue = rgbWWAState.rgbState.green;
                    res.patternValue = rgbWWAState.rgbState.pattern;
                    res.coolWhiteValue = 0;
                    res.warmWhiteValue = 0;
                    res.amberValue = 0;
                    res.successState = {
                        online: true,
                        on: paramsObj.on
                    };
                }
                else {
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE;
                    res.redValue = 0;
                    res.blueValue = 0;
                    res.greenValue = 0;
                    res.patternValue = 0;
                    res.coolWhiteValue = rgbWWAState.wwaState.coolWhite;
                    res.warmWhiteValue = rgbWWAState.wwaState.warmWhite;
                    res.amberValue = rgbWWAState.wwaState.amber;
                    res.successState = {
                        online: true,
                        on: paramsObj.on
                    };
                }
                return res;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_BRIGHTNESS_ABSOLUTE:
            if (paramsObj.hasOwnProperty('brightness')) {
                res.onValue = 255;
                res.successState = {
                    online: true,
                    brightness: paramsObj.brightness
                };
                if (rgbWWAState.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE;
                    res.redValue = rgbWWAState.rgbState.red
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.blueValue = rgbWWAState.rgbState.blue
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.greenValue = rgbWWAState.rgbState.green
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.patternValue = rgbWWAState.rgbState.pattern;
                    res.coolWhiteValue = 0;
                    res.warmWhiteValue = 0;
                    res.amberValue = 0;
                }
                else {
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE;
                    res.redValue = 0;
                    res.blueValue = 0;
                    res.greenValue = 0;
                    res.patternValue = 0;
                    res.coolWhiteValue = rgbWWAState.wwaState.coolWhite
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.warmWhiteValue = rgbWWAState.wwaState.warmWhite
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                    res.amberValue = rgbWWAState.wwaState.amber
                        ? Math.floor((paramsObj.brightness * 255) / 100)
                        : 0;
                }
                return res;
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        case google_pb_1.GH_EXECUTE_ACTIONS.GH_COLOR_ABSOLUTE:
            res.onValue = 255;
            if (paramsObj.hasOwnProperty('color')) {
                if (paramsObj.color.temperature) {
                    const curTemp = paramsObj.color.temperature;
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE;
                    res.redValue = 0;
                    res.blueValue = 0;
                    res.greenValue = 0;
                    res.patternValue = 0;
                    res.amberValue = 0;
                    res.coolWhiteValue = Math.min(255, paramsObj.color.temperature >= GH.rgbwwaMidtemp
                        ? 255
                        : Math.floor(((curTemp - GH.rgbwwaMinTemp) / (GH.rgbwwaMaxTemp + 1 - curTemp)) * 255));
                    res.warmWhiteValue = Math.min(255, paramsObj.color.temperature <= GH.rgbwwaMidtemp
                        ? 255
                        : Math.floor(((GH.rgbwwaMaxTemp - curTemp) / (curTemp + 1 - GH.rgbwwaMinTemp)) * 255));
                    res.successState = {
                        online: true,
                        color: {
                            temperatureK: paramsObj.color.temperature
                        }
                    };
                    return res;
                }
                else if (paramsObj.color.spectrumRGB) {
                    const colorDecimal = paramsObj.color.spectrumRGB;
                    const r = Math.floor(colorDecimal / 65536);
                    const g = Math.floor((colorDecimal - r * 65536) / 256);
                    const b = Math.floor(colorDecimal - r * 65536 - g * 256);
                    const maxRGBVal = r > g ? (r > b ? r : b) : g > b ? g : b;
                    res.updateType = device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE;
                    res.redValue = Math.floor(maxRGBVal ? (255 * r) / maxRGBVal : 0);
                    res.blueValue = Math.floor(maxRGBVal ? (255 * b) / maxRGBVal : 0);
                    res.greenValue = Math.floor(maxRGBVal ? (255 * g) / maxRGBVal : 0);
                    res.patternValue = 0;
                    res.amberValue = 0;
                    res.coolWhiteValue = 0;
                    res.warmWhiteValue = 0;
                    res.successState = {
                        online: true,
                        color: {
                            spectrumRGB: paramsObj.color.spectrumRGB,
                            name: paramsObj.color.name
                        }
                    };
                    return res;
                }
                else {
                    throw new errors_1.GeneralErrors.InvalidParameterSet();
                }
            }
            else {
                throw new errors_1.GeneralErrors.InvalidParameterSet();
            }
            break;
        default:
            throw new errors_1.GeneralErrors.InvalidParameterSet();
    }
}
//# sourceMappingURL=index.js.map