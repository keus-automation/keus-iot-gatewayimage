"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const google_pb_1 = require("../../../protos/generated/hub/voice/google_pb");
const response_helper_1 = __importDefault(require("../../../../../utilities/response-helper"));
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class GoogleHomeExecuteCommandResp {
    static getSendResponse(code, message, success, deviceStatus) {
        const resp = new google_pb_1.GoogleHomeExecuteCommandResponse();
        resp.setCode(code);
        resp.setMessage(message);
        resp.setSuccess(success);
        resp.setDeviceStatusResponse(deviceStatus);
        return general_1.PackIntoAny(resp.serializeBinary(), GoogleHomeExecuteCommandResp.responseType);
    }
    static getInvalidDeviceId(deviceStatus) {
        const resp = new google_pb_1.GoogleHomeExecuteCommandResponse();
        resp.setCode(801);
        resp.setMessage('Invalid Google Device Id');
        resp.setSuccess(false);
        resp.setDeviceStatusResponse(deviceStatus);
        return general_1.PackIntoAny(resp.serializeBinary(), GoogleHomeExecuteCommandResp.responseType);
    }
    static getInvalidParameterSet(deviceStatus) {
        const resp = new google_pb_1.GoogleHomeExecuteCommandResponse();
        resp.setCode(802);
        resp.setMessage('Invalid Parameter Set for device');
        resp.setSuccess(false);
        resp.setDeviceStatusResponse(deviceStatus);
        return general_1.PackIntoAny(resp.serializeBinary(), GoogleHomeExecuteCommandResp.responseType);
    }
    static getInsufficientUserAccess(deviceStatus) {
        const resp = new google_pb_1.GoogleHomeExecuteCommandResponse();
        resp.setCode(803);
        resp.setMessage('Get Insufficient User Access');
        resp.setSuccess(false);
        resp.setDeviceStatusResponse(deviceStatus);
        return general_1.PackIntoAny(resp.serializeBinary(), GoogleHomeExecuteCommandResp.responseType);
    }
    static getInternalServerError(deviceState) {
        const resp = new google_pb_1.GoogleHomeExecuteCommandResponse();
        const internalError = response_helper_1.default.getInternalServerError();
        resp.setCode(internalError.code);
        resp.setMessage(internalError.message);
        resp.setSuccess(internalError.success);
        resp.setDeviceStatusResponse(deviceState);
        return general_1.PackIntoAny(resp.serializeBinary(), GoogleHomeExecuteCommandResp.responseType);
    }
}
exports.default = GoogleHomeExecuteCommandResp;
GoogleHomeExecuteCommandResp.responseType = system_constants_1.ProtoPackageName + '.GoogleHomeExecuteCommandResponse';
//# sourceMappingURL=response.js.map