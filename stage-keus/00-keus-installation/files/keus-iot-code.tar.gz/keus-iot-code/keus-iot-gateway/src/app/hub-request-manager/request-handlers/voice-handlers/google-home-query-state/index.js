"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const keus_user_1 = __importDefault(require("../../../../../models/database-models/keus-user"));
const GH = __importStar(require("../google-voice-utils"));
const HomeUtils = __importStar(require("../../../../../utilities/gateway/home-utils"));
const errors_1 = require("../../../../../errors/errors");
const zigbee_ac_fan_controller_pb_1 = require("../../../protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const group_structures_pb_1 = require("../../../protos/generated/hub/groups/group_structures_pb");
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const zigbee_dc_fan_controller_pb_1 = require("../../../protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const keus_ir_remote_1 = __importDefault(require("../../../../../models/database-models/keus-ir-remote"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (googleQueryReq) => {
    return timed_promise_1.TPromise(function () {
        console.log('Hit Google Home Query State');
        return new Promise(async function (resolve, reject) {
            const keusDevList = googleQueryReq.getGoogleDeviceIdList();
            const queryRespList = [];
            for (var k = 0; k < keusDevList.length; k++) {
                try {
                    const user = await keus_user_1.default.getUserByPhone(googleQueryReq.getPhone());
                    if (!HomeUtils.checkUserIsAdmin(user)) {
                        throw new errors_1.GeneralErrors.InvalidUserAccessError();
                    }
                    else {
                        const keusDev = GH.getKeusId(keusDevList[k]);
                        switch (keusDev.kDevType) {
                            case GH.kVoiceSceneDevice:
                                const sceneDeviceStatus = {
                                    status: GH.successString,
                                    online: true,
                                    id: keusDevList[k]
                                };
                                queryRespList.push(JSON.stringify(sceneDeviceStatus));
                                break;
                            case GH.kVoiceGroupDevice:
                                const execGroup = await keus_group_1.default.getGroupById(keusDev.groupId, keusDev.groupRoom);
                                if (!execGroup) {
                                    throw new errors_1.GroupErrors.InvalidGroupId();
                                }
                                else {
                                    const groupDeviceStatus = {
                                        status: GH.successString,
                                        online: true,
                                        id: keusDevList[k]
                                    };
                                    switch (execGroup.groupType) {
                                        case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
                                            const daliDimmableGrpState = execGroup.groupState;
                                            groupDeviceStatus.on = daliDimmableGrpState.driverState ? true : false;
                                            groupDeviceStatus.brightness = Math.floor((daliDimmableGrpState.driverState * 100) / 255);
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
                                            const zigbeeDimmableGrpState = (execGroup.groupState);
                                            groupDeviceStatus.on = zigbeeDimmableGrpState.driverState ? true : false;
                                            groupDeviceStatus.brightness = Math.floor((zigbeeDimmableGrpState.driverState * 100) / 255);
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
                                            const daliNonDimmableGrpState = (execGroup.groupState);
                                            groupDeviceStatus.on = daliNonDimmableGrpState.driverState ? true : false;
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
                                            const zigbeeNonDimmableGrpState = (execGroup.groupState);
                                            groupDeviceStatus.on = zigbeeNonDimmableGrpState.driverState ? true : false;
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
                                            const zigbeeInlineGrpState = execGroup.groupState;
                                            groupDeviceStatus.on = zigbeeInlineGrpState.deviceState ? true : false;
                                            groupDeviceStatus.brightness = Math.floor((zigbeeInlineGrpState.deviceState * 100) / 255);
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
                                            const applianceOnOffGrpState = (execGroup.groupState);
                                            groupDeviceStatus.on = applianceOnOffGrpState.switchState ? true : false;
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
                                            const applianceSingleDimmerGrpState = (execGroup.groupState);
                                            groupDeviceStatus.on = applianceSingleDimmerGrpState.switchState
                                                ? true
                                                : false;
                                            groupDeviceStatus.brightness = Math.floor((100 * applianceSingleDimmerGrpState.switchState) / 255);
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
                                            const applianceFanGrpState = (execGroup.groupState);
                                            groupDeviceStatus.on = applianceFanGrpState.fanState ? true : false;
                                            if (applianceFanGrpState.fanState > 195) {
                                                groupDeviceStatus.currentFanSpeedSetting = GH.fanSpeedMax;
                                            }
                                            else if (applianceFanGrpState.fanState > 130) {
                                                groupDeviceStatus.currentFanSpeedSetting = GH.fanSpeedHigh;
                                            }
                                            else if (applianceFanGrpState.fanState > 65) {
                                                groupDeviceStatus.currentFanSpeedSetting = GH.fanSpeedMedium;
                                            }
                                            else if (applianceFanGrpState.fanState > 0) {
                                                groupDeviceStatus.currentFanSpeedSetting = GH.fanSpeedLow;
                                            }
                                            break;
                                        case group_structures_pb_1.GROUP_TYPES.RGBWWA:
                                            const rgbwwaGrpState = execGroup.groupState;
                                            switch (rgbwwaGrpState.updateType) {
                                                case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE:
                                                    if (rgbwwaGrpState.rgbState.blue == 0 &&
                                                        rgbwwaGrpState.rgbState.red == 0 &&
                                                        rgbwwaGrpState.rgbState.green == 0 &&
                                                        rgbwwaGrpState.rgbState.pattern == 0 &&
                                                        rgbwwaGrpState.rgbState.deviceState == 0) {
                                                        groupDeviceStatus.on = false;
                                                    }
                                                    else {
                                                        groupDeviceStatus.on = true;
                                                    }
                                                    break;
                                                case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE:
                                                    if (rgbwwaGrpState.wwaState.coolWhite == 0 &&
                                                        rgbwwaGrpState.wwaState.warmWhite == 0 &&
                                                        rgbwwaGrpState.wwaState.amber == 0 &&
                                                        rgbwwaGrpState.wwaState.deviceState == 0) {
                                                        groupDeviceStatus.on = false;
                                                    }
                                                    else {
                                                        groupDeviceStatus.on = true;
                                                    }
                                                    break;
                                            }
                                            break;
                                        // case GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
                                        //     break;
                                        default:
                                            throw new errors_1.GroupErrors.InvalidPropertySet();
                                    }
                                    queryRespList.push(JSON.stringify(groupDeviceStatus));
                                }
                                break;
                            case GH.kVoiceEmbeddedApplianceDevice:
                                const esDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                                if (!esDevice) {
                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                }
                                else {
                                    const esDeviceProps = esDevice.deviceProperties;
                                    const appliance = esDeviceProps.appliance.find(function (esAppl) {
                                        return esAppl.applianceId == keusDev.applianceId;
                                    });
                                    if (!appliance) {
                                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                                    }
                                    else {
                                        const applianceDeviceStatus = {
                                            status: GH.successString,
                                            online: true,
                                            id: keusDevList[k]
                                        };
                                        switch (appliance.applianceType) {
                                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                                                const applianceSingleDimmerState = (appliance.applianceState);
                                                applianceDeviceStatus.on = applianceSingleDimmerState.switchState
                                                    ? true
                                                    : false;
                                                applianceDeviceStatus.brightness = Math.floor((100 * applianceSingleDimmerState.switchState) / 255);
                                                break;
                                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                                                const applianceOnOffState = (appliance.applianceState);
                                                applianceDeviceStatus.on = applianceOnOffState.switchState ? true : false;
                                                break;
                                            case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                                                const applianceFanState = (appliance.applianceState);
                                                applianceDeviceStatus.on = applianceFanState.fanState ? true : false;
                                                if (applianceFanState.fanState > 195) {
                                                    applianceDeviceStatus.currentFanSpeedSetting = GH.fanSpeedMax;
                                                }
                                                else if (applianceFanState.fanState > 130) {
                                                    applianceDeviceStatus.currentFanSpeedSetting = GH.fanSpeedHigh;
                                                }
                                                else if (applianceFanState.fanState > 65) {
                                                    applianceDeviceStatus.currentFanSpeedSetting = GH.fanSpeedMedium;
                                                }
                                                else if (applianceFanState.fanState > 0) {
                                                    applianceDeviceStatus.currentFanSpeedSetting = GH.fanSpeedLow;
                                                }
                                                break;
                                            // case EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                                            //     break;
                                            default:
                                                throw new errors_1.GroupErrors.InvalidPropertySet();
                                        }
                                        queryRespList.push(JSON.stringify(applianceDeviceStatus));
                                    }
                                }
                                break;
                            case GH.kVoiceCurtainDevice:
                                const crtDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                                if (!crtDevice) {
                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                }
                                else {
                                    const curtainDeviceStatus = {
                                        status: GH.successString,
                                        online: true,
                                        id: keusDevList[k]
                                    };
                                    const curtainDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                                    const curtainState = curtainDevice.deviceState;
                                    curtainDeviceStatus.openPercent =
                                        curtainState.curtainState == device_constants_pb_1.CURTAIN_CONTROLLER_ACTION.CC_CLOSE ? 0 : 100;
                                    queryRespList.push(JSON.stringify(curtainDeviceStatus));
                                }
                                break;
                            case GH.kVoiceACFanDevice:
                                const acFanDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                                if (!acFanDevice) {
                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                }
                                else {
                                    const acFanDeviceStatus = {
                                        status: GH.successString,
                                        online: true,
                                        id: keusDevList[k]
                                    };
                                    const acFanState = acFanDevice.deviceState;
                                    switch (acFanState.fanState) {
                                        case zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_OFF:
                                            acFanDeviceStatus.on = false;
                                            break;
                                        case zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_MAX:
                                            acFanDeviceStatus.on = true;
                                            acFanDeviceStatus.currentFanSpeedSetting = GH.fanSpeedMax;
                                            break;
                                        case zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_HIGH:
                                            acFanDeviceStatus.on = true;
                                            acFanDeviceStatus.currentFanSpeedSetting = GH.fanSpeedHigh;
                                            break;
                                        case zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_MED:
                                            acFanDeviceStatus.on = true;
                                            acFanDeviceStatus.currentFanSpeedSetting = GH.fanSpeedMedium;
                                            break;
                                        case zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_LOW:
                                            acFanDeviceStatus.on = true;
                                            acFanDeviceStatus.currentFanSpeedSetting = GH.fanSpeedLow;
                                            break;
                                        default:
                                            acFanDeviceStatus.on = false;
                                    }
                                    queryRespList.push(JSON.stringify(acFanDeviceStatus));
                                }
                                break;
                            case GH.kVoiceDCFanDevice:
                                const dcFanDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                                if (!dcFanDevice) {
                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                }
                                else {
                                    const dcFanDeviceStatus = {
                                        status: GH.successString,
                                        online: true,
                                        id: keusDevList[k]
                                    };
                                    const dcFanState = dcFanDevice.deviceState;
                                    switch (dcFanState.fanState) {
                                        case zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_OFF:
                                            dcFanDeviceStatus.on = false;
                                            break;
                                        case zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_MAX:
                                            dcFanDeviceStatus.on = true;
                                            dcFanDeviceStatus.currentFanSpeedSetting = GH.fanSpeedMax;
                                            break;
                                        case zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_HIGH:
                                            dcFanDeviceStatus.on = true;
                                            dcFanDeviceStatus.currentFanSpeedSetting = GH.fanSpeedHigh;
                                            break;
                                        case zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_MED:
                                            dcFanDeviceStatus.on = true;
                                            dcFanDeviceStatus.currentFanSpeedSetting = GH.fanSpeedMedium;
                                            break;
                                        case zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_LOW:
                                            dcFanDeviceStatus.on = true;
                                            dcFanDeviceStatus.currentFanSpeedSetting = GH.fanSpeedLow;
                                            break;
                                        default:
                                            dcFanDeviceStatus.on = false;
                                    }
                                    queryRespList.push(JSON.stringify(dcFanDeviceStatus));
                                }
                                break;
                            case GH.kVoiceSCRelayDevice:
                                const scRelayDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                                if (!scRelayDevice) {
                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                }
                                else {
                                    const scRelayDeviceStatus = {
                                        status: GH.successString,
                                        online: true,
                                        id: keusDevList[k]
                                    };
                                    const scRelayDeviceProperties = (scRelayDevice.deviceProperties);
                                    const relayDevice = scRelayDeviceProperties.relays.find(function (rly) {
                                        return rly.relayId == keusDev.relayId;
                                    });
                                    if (!relayDevice) {
                                        throw new errors_1.DeviceErrors.InvalidDeviceId();
                                    }
                                    else {
                                        scRelayDeviceStatus.on = relayDevice.relayState ? true : false;
                                        queryRespList.push(JSON.stringify(scRelayDeviceStatus));
                                    }
                                }
                                break;
                            case GH.kVoiceIRACDevice:
                                const iracDevice = await keus_ir_remote_1.default.getIRRemoteById(keusDev.remoteId);
                                if (!iracDevice) {
                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                }
                                else {
                                    const iracDeviceStatus = {
                                        status: GH.successString,
                                        online: true,
                                        id: keusDevList[k]
                                    };
                                    const iracDeviceState = iracDevice.remoteState;
                                    const iracDeviceProps = iracDevice.remoteProperties;
                                    if (iracDeviceState.powerOn) {
                                        iracDeviceStatus.on = true;
                                        iracDeviceStatus.thermostatTemperatureSetpoint = iracDeviceState.temperature;
                                        if (iracDeviceProps.modeEnabled &&
                                            GH.acunitSupportedModeList.indexOf(iracDeviceState.mode.toLowerCase()) > -1) {
                                            iracDeviceStatus.thermostatMode = GH.getGoogleAcMode(iracDeviceState.mode);
                                        }
                                        if (iracDeviceProps.fanEnabled) {
                                            const googleACFanSpeed = GH.getGoogleAcUnitFanSpeed(iracDeviceState.fanLevel);
                                            if (googleACFanSpeed) {
                                                iracDeviceStatus.currentFanSpeedSetting = googleACFanSpeed;
                                            }
                                        }
                                    }
                                    else {
                                        iracDeviceStatus.on = false;
                                    }
                                    console.log('THIS SI QUERIED STATE', iracDeviceStatus);
                                    queryRespList.push(JSON.stringify(iracDeviceStatus));
                                }
                                break;
                            case GH.kVoiceRoomDevice:
                                const roomDeviceStatus = {
                                    status: GH.successString,
                                    online: true,
                                    id: keusDevList[k],
                                    on: true
                                };
                                queryRespList.push(JSON.stringify(roomDeviceStatus));
                                break;
                            case GH.kVoiceRGBWWADevice:
                                const rgbwwaDevice = await keus_device_1.default.getDeviceById(keusDev.deviceId);
                                if (!rgbwwaDevice) {
                                    throw new errors_1.DeviceErrors.InvalidDeviceId();
                                }
                                else {
                                    const rgbwwaDeviceStatus = {
                                        status: GH.successString,
                                        online: true,
                                        id: keusDevList[k]
                                    };
                                    const rgbwwaDeviceState = rgbwwaDevice.deviceState;
                                    switch (rgbwwaDeviceState.lastUpdateType) {
                                        case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE:
                                            if (rgbwwaDeviceState.lastUpdatedRGBAction.blue == 0 &&
                                                rgbwwaDeviceState.lastUpdatedRGBAction.red == 0 &&
                                                rgbwwaDeviceState.lastUpdatedRGBAction.green == 0 &&
                                                rgbwwaDeviceState.lastUpdatedRGBAction.pattern == 0 &&
                                                rgbwwaDeviceState.lastUpdatedRGBAction.deviceState == 0) {
                                                rgbwwaDeviceStatus.on = false;
                                            }
                                            else {
                                                rgbwwaDeviceStatus.on = true;
                                            }
                                            break;
                                        case device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE:
                                            if (rgbwwaDeviceState.lastUpdatedWWAAction.coolWhite == 0 &&
                                                rgbwwaDeviceState.lastUpdatedWWAAction.warmWhite == 0 &&
                                                rgbwwaDeviceState.lastUpdatedWWAAction.amber == 0 &&
                                                rgbwwaDeviceState.lastUpdatedWWAAction.deviceState == 0) {
                                                rgbwwaDeviceStatus.on = false;
                                            }
                                            else {
                                                rgbwwaDeviceStatus.on = true;
                                            }
                                            break;
                                    }
                                    queryRespList.push(JSON.stringify(rgbwwaDeviceStatus));
                                    break;
                                }
                        }
                    }
                }
                catch (e) {
                    switch (e.constructor) {
                        case errors_1.GroupErrors.InvalidGroupId:
                        case errors_1.SceneErrors.InvalidSceneId:
                        case errors_1.DeviceErrors.InvalidDeviceId:
                            queryRespList.push(JSON.stringify({
                                status: GH.failureString,
                                online: false,
                                id: keusDevList[k],
                                debugString: 'Invalid Device Id',
                                errorCode: 404
                            }));
                            break;
                        case errors_1.GeneralErrors.InvalidUserAccessError:
                            queryRespList.push(JSON.stringify({
                                status: GH.failureString,
                                online: false,
                                id: keusDevList[k],
                                debugString: 'Insufficient User Permissions',
                                errorCode: 404
                            }));
                            break;
                        default:
                            logInst.log(e);
                            queryRespList.push(JSON.stringify({
                                status: GH.failureString,
                                online: false,
                                id: keusDevList[k],
                                debugString: 'Unable to reach device',
                                errorCode: 404
                            }));
                    }
                }
            }
            resolve(response_1.default.getSendResponse(queryRespList));
        });
    });
};
//# sourceMappingURL=index.js.map