"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const google_pb_1 = require("../../../protos/generated/hub/voice/google_pb");
const general_1 = require("../../../../../utilities/general");
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
class GoogleHomeQueryStateResp {
    static getSendResponse(deviceStatusList) {
        const resp = new google_pb_1.GoogleHomeQueryStateResponse();
        resp.setCode(800);
        resp.setMessage('Query State Succeeded');
        resp.setSuccess(true);
        resp.setDeviceStatusResponseList(deviceStatusList);
        return general_1.PackIntoAny(resp.serializeBinary(), GoogleHomeQueryStateResp.responseType);
    }
}
exports.default = GoogleHomeQueryStateResp;
GoogleHomeQueryStateResp.responseType = system_constants_1.ProtoPackageName + '.GoogleHomeQueryStateResponse';
//# sourceMappingURL=response.js.map