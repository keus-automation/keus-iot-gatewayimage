"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const timed_promise_1 = require("../../../../../utilities/timed-promise");
const logger_service_1 = __importDefault(require("../../../../../services/logger-service"));
const system_constants_1 = require("../../../../../constants/gateway/system-constants");
const response_1 = __importDefault(require("./response"));
const keus_group_1 = __importDefault(require("../../../../../models/database-models/keus-group"));
const GoogleVoiceUtils = __importStar(require("../google-voice-utils"));
const keus_home_1 = __importDefault(require("../../../../../models/database-models/keus-home"));
const keus_scene_1 = __importDefault(require("../../../../../models/database-models/keus-scene"));
const keus_device_1 = __importDefault(require("../../../../../models/database-models/keus-device"));
const device_categories_1 = __importDefault(require("../../../../../constants/device/device-categories"));
const device_constants_pb_1 = require("../../../protos/generated/hub/devices/device_constants_pb");
const keus_ir_remote_1 = __importDefault(require("../../../../../models/database-models/keus-ir-remote"));
const keus_gateway_1 = __importDefault(require("../../../../../models/database-models/keus-gateway"));
const logInst = new logger_service_1.default({ enable: true, namespace: system_constants_1.GatewayLogNamespace });
exports.default = async (googleSyncReq) => {
    return timed_promise_1.TPromise(function () {
        console.log('Hit Google Home Synce Devices');
        return new Promise(async function (resolve, reject) {
            try {
                const googleDeviceList = [];
                const roomList = await keus_home_1.default.getAllRooms();
                //Get Group devices
                const groupList = await keus_group_1.default.getAllGroups();
                groupList.forEach(function (grp) {
                    const grpDevice = GoogleVoiceUtils.getGoogleVoiceGroupDevice(grp, roomList);
                    if (grpDevice) {
                        googleDeviceList.push(JSON.stringify(grpDevice));
                    }
                });
                //Get Scene Devices
                const sceneList = await keus_scene_1.default.getAllScenes();
                sceneList.forEach(function (scn) {
                    const scnDevice = GoogleVoiceUtils.getGoogleVoiceSceneDevice(scn, roomList);
                    if (scnDevice) {
                        googleDeviceList.push(JSON.stringify(scnDevice));
                    }
                });
                const deviceList = await keus_device_1.default.getAllDevices();
                //Get Curtain Devices
                const curtainDevices = deviceList.filter(function (dev) {
                    return (dev.deviceCategory ==
                        device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode && !dev.inGroup);
                });
                curtainDevices.forEach(function (crt) {
                    const crtDevice = GoogleVoiceUtils.getGoogleVoiceCurtainDevice(crt, roomList);
                    if (crtDevice) {
                        googleDeviceList.push(JSON.stringify(crtDevice));
                    }
                });
                //Get AC Fan Controller Devices
                const acFanDevices = deviceList.filter(function (dev) {
                    return (dev.deviceCategory ==
                        device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceCategoryCode && !dev.inGroup);
                });
                acFanDevices.forEach(function (acfan) {
                    const acFanDevice = GoogleVoiceUtils.getGoogleVoiceACFanDevice(acfan, roomList);
                    if (acFanDevice) {
                        googleDeviceList.push(JSON.stringify(acFanDevice));
                    }
                });
                //Get DC Fan Controller Devices
                const dcFanDevices = deviceList.filter(function (dev) {
                    return (dev.deviceCategory ==
                        device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER').deviceCategoryCode && !dev.inGroup);
                });
                dcFanDevices.forEach(function (dcFan) {
                    const dcFanDevice = GoogleVoiceUtils.getGoogleVoiceDCFanDevice(dcFan, roomList);
                    if (dcFanDevice) {
                        googleDeviceList.push(JSON.stringify(dcFanDevice));
                    }
                });
                //Get Embedded Switch Appliances
                const esDevices = deviceList.filter(function (dev) {
                    return dev.deviceCategory == device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode;
                });
                esDevices.forEach(function (es) {
                    const devProps = es.deviceProperties;
                    devProps.appliance.forEach(function (esAppl) {
                        if (!esAppl.inGroup) {
                            const esApplianceDevice = GoogleVoiceUtils.getGoogleVoiceEsApplianceDevice(esAppl, roomList, es);
                            if (esApplianceDevice) {
                                googleDeviceList.push(JSON.stringify(esApplianceDevice));
                            }
                        }
                    });
                });
                //Get Smart Console Relays
                const scDevices = deviceList.filter(function (dev) {
                    return dev.deviceCategory == device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode;
                });
                scDevices.forEach(function (sc) {
                    const devProps = sc.deviceProperties;
                    devProps.buttons.forEach(function (btn) {
                        if (btn.buttonType == device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_RELAYCONTROLLER) {
                            const rlyProps = btn.buttonProperties;
                            const relay = devProps.relays.find(function (rly) {
                                return rly.relayId == rlyProps.relayId;
                            });
                            if (relay) {
                                const scRelayDevice = GoogleVoiceUtils.getGoogleVoiceSCRelayDevice(relay, roomList, sc);
                                if (scRelayDevice) {
                                    googleDeviceList.push(JSON.stringify(scRelayDevice));
                                }
                            }
                        }
                    });
                });
                //Get IR AC Remotes
                const irRemotes = await keus_ir_remote_1.default.getAllIRRemotes();
                const acRemotes = irRemotes.filter(function (rmt) {
                    return rmt.remoteType == device_constants_pb_1.IR_REMOTE_TYPES.IR_AC;
                });
                acRemotes.forEach(function (acRmt) {
                    const irDevice = deviceList.find(function (dev) {
                        return dev.deviceId == acRmt.irDevice;
                    });
                    if (irDevice) {
                        const irACDevice = GoogleVoiceUtils.getGoogleVoiceIRACDevice(acRmt, roomList, irDevice);
                        if (irACDevice) {
                            googleDeviceList.push(JSON.stringify(irACDevice));
                        }
                    }
                });
                //Get Room Lights (All On & All Off map for rooms)
                roomList.forEach(function (room) {
                    room.sectionList.forEach(function (section) {
                        const roomDevice = GoogleVoiceUtils.getGoogleVoiceFullRoomDevice(room, section);
                        if (roomDevice) {
                            googleDeviceList.push(JSON.stringify(roomDevice));
                        }
                    });
                });
                //Get RBGWWA
                const rgbwwaDevices = deviceList.filter(function (device) {
                    return (device.deviceCategory ==
                        device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceCategoryCode && !device.inGroup);
                });
                rgbwwaDevices.forEach(function (rgbwwa) {
                    const rgbwwaDevice = GoogleVoiceUtils.getGoogleVoiceRGBWWADevice(rgbwwa, roomList);
                    if (rgbwwaDevice) {
                        googleDeviceList.push(JSON.stringify(rgbwwaDevice));
                    }
                });
                //Add user to Google linked account list
                const gatewayList = await keus_gateway_1.default.getGateway();
                const mainGateway = gatewayList.find(function (gtw) {
                    return gtw.gatewayMode == system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY;
                });
                const filteredUserList = mainGateway.googleLinkedUserList.filter(function (ph) {
                    return ph != googleSyncReq.getPhone();
                });
                filteredUserList.push(googleSyncReq.getPhone());
                await keus_gateway_1.default.setGoogleHomeLinkStatus(mainGateway.gatewayId, true, filteredUserList);
                resolve(response_1.default.getSyncDevicesSuccessful(googleDeviceList));
            }
            catch (e) {
                switch (e.constructor) {
                    default:
                        logInst.log(e);
                        resolve(response_1.default.getInternalServerError());
                }
            }
        });
    });
};
//# sourceMappingURL=index.js.map