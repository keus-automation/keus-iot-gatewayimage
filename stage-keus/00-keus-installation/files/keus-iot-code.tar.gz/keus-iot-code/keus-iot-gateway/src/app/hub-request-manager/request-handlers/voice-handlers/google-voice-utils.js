"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const home_constants_1 = require("../../../../constants/gateway/home-constants");
const errors_1 = require("../../../../errors/errors");
const device_constants_pb_1 = require("../../protos/generated/hub/devices/device_constants_pb");
const group_structures_pb_1 = require("../../protos/generated/hub/groups/group_structures_pb");
//Groups, Scenes, Full Room lights, Curtains, Fans, IR - AC, RGBWWA, SC Relays
//Constants
const manufacturerName = 'Keus';
const roomLightsTag = 'Lights';
exports.successString = 'SUCCESS';
exports.failureString = 'ERROR';
const deviceOfflineError = 'deviceOffline';
exports.fanSpeedLow = 'low_key';
exports.fanSpeedMedium = 'medium_key';
exports.fanSpeedHigh = 'high_key';
exports.fanSpeedMax = 'max_key';
exports.keusFanSpeedLow = 'LOW';
exports.keusFanSpeedMedium = 'MEDIUM';
exports.keusFanSpeedHigh = 'HIGH';
exports.curtainDown = 'DOWN';
exports.curtainUp = 'UP';
exports.curtainLeft = 'LEFT';
exports.curtainRight = 'RIGHT';
exports.rgbwwaMinTemp = 2000;
exports.rgbwwaMaxTemp = 6000;
exports.rgbwwaMidtemp = (exports.rgbwwaMinTemp + exports.rgbwwaMaxTemp) / 2;
exports.acunitSupportedModeList = [
    'off',
    'heat',
    'cool',
    'on',
    'heatcool',
    'auto',
    'fan-only',
    'purifier',
    'eco',
    'dry',
    'fan'
];
exports.acUnitFanMode = 'fan-only';
exports.keusACFanMode = 'FAN';
//Google Home Device Type Identifier
exports.gLightType = 'action.devices.types.LIGHT';
exports.gSwitchType = 'action.devices.types.SWITCH';
exports.gFanType = 'action.devices.types.FAN';
exports.gSceneType = 'action.devices.types.SCENE';
exports.gCurtainType = 'action.devices.types.CURTAIN';
exports.gACUnitType = 'action.devices.types.AC_UNIT';
//Google Home Device Traits
exports.gOnOffTrait = 'action.devices.traits.OnOff';
exports.gBrightnessTrait = 'action.devices.traits.Brightness';
exports.gFanSpeedTrait = 'action.devices.traits.FanSpeed';
exports.gSceneTrait = 'action.devices.traits.Scene';
exports.gOpenCloseTrait = 'action.devices.traits.OpenClose';
exports.gTemperatureSettingTrait = 'action.devices.traits.TemperatureSetting';
exports.gColorSettingTrait = 'action.devices.traits.ColorSetting';
//Keus Device Type Identifier
exports.kVoiceGroupDevice = 'GRP';
exports.kVoiceSceneDevice = 'SCN';
exports.kVoiceCurtainDevice = 'CC';
exports.kVoiceACFanDevice = 'ACFC';
exports.kVoiceDCFanDevice = 'DCFC';
exports.kVoiceSCRelayDevice = 'SCR';
exports.kVoiceIRACDevice = 'IRAC';
exports.kVoiceRoomDevice = 'RMD';
exports.kVoiceRGBWWADevice = 'RGBWWA';
exports.kVoiceEmbeddedApplianceDevice = 'ESAPPL';
//Attribute Object Constants
const fanSpeedAttributes = {
    availableFanSpeeds: {
        speeds: [
            {
                speed_name: exports.fanSpeedLow,
                speed_values: [
                    {
                        speed_synonym: ['low', 'slow'],
                        lang: 'en'
                    }
                ]
            },
            {
                speed_name: exports.fanSpeedMedium,
                speed_values: [
                    {
                        speed_synonym: ['medium', 'moderate', 'mid'],
                        lang: 'en'
                    }
                ]
            },
            {
                speed_name: exports.fanSpeedHigh,
                speed_values: [
                    {
                        speed_synonym: ['fast', 'high'],
                        lang: 'en'
                    }
                ]
            },
            {
                speed_name: exports.fanSpeedMax,
                speed_values: [
                    {
                        speed_synonym: ['maximum', 'full'],
                        lang: 'en'
                    }
                ]
            }
        ],
        ordered: true
    },
    reversible: false,
    supportsFanSpeedPercent: false
};
function getGoogleVoiceGroupDevice(group, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == group.groupRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (group.groupSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == group.groupSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + group.groupName;
    switch (group.groupType) {
        case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
            deviceObj = {
                id: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                type: exports.gLightType,
                traits: [exports.gOnOffTrait, exports.gBrightnessTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: {},
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceGroupDevice + '-' + group.groupType
                }
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
            deviceObj = {
                id: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                type: exports.gLightType,
                traits: [exports.gOnOffTrait, exports.gBrightnessTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: {},
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceGroupDevice + '-' + group.groupType
                }
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
            deviceObj = {
                id: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                type: exports.gLightType,
                traits: [exports.gOnOffTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: {},
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceGroupDevice + '-' + group.groupType
                }
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
            deviceObj = {
                id: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                type: exports.gLightType,
                traits: [exports.gOnOffTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: {},
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceGroupDevice + '-' + group.groupType
                }
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
            deviceObj = {
                id: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                type: exports.gLightType,
                traits: [exports.gOnOffTrait, exports.gBrightnessTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: {},
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceGroupDevice + '-' + group.groupType
                }
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
            deviceObj = {
                id: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                type: exports.gLightType,
                traits: [exports.gOnOffTrait, exports.gBrightnessTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: {},
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceGroupDevice + '-' + group.groupType
                }
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
            deviceObj = {
                id: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                type: exports.gSwitchType,
                traits: [exports.gOnOffTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: {},
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceGroupDevice + '-' + group.groupType
                }
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
            deviceObj = {
                id: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                type: exports.gFanType,
                traits: [exports.gOnOffTrait, exports.gFanSpeedTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: fanSpeedAttributes,
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceGroupDevice + '-' + group.groupType
                }
            };
            break;
        case group_structures_pb_1.GROUP_TYPES.RGBWWA:
            deviceObj = {
                id: exports.kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
                type: exports.gLightType,
                traits: [exports.gOnOffTrait, exports.gBrightnessTrait, exports.gColorSettingTrait],
                name: {
                    name: fullName
                },
                willReportState: false,
                attributes: {
                    commandOnlyColorSetting: true,
                    colorModel: 'rgb',
                    colorTemperatureRange: {
                        temperatureMinK: exports.rgbwwaMinTemp,
                        temperatureMaxK: exports.rgbwwaMaxTemp
                    }
                },
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceGroupDevice + '-' + group.groupType
                }
            };
            break;
        // To Be Added
        // case GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
        //     deviceObj = {
        //         id: kVoiceGroupDevice + '-' + group.groupRoom + '-' + group.groupId,
        //         type: gFanType,
        //         traits: [gOnOffTrait, gFanSpeedTrait],
        //         name: {
        //             name: fullName
        //         },
        //         willReportState: true,
        //         attributes: fanSpeedAttributes,
        //         deviceInfo: {
        //             manufacturer: manufacturerName,
        //             model: kVoiceGroupDevice + '-' + group.groupType
        //         }
        //     };
    }
    return deviceObj;
}
exports.getGoogleVoiceGroupDevice = getGoogleVoiceGroupDevice;
function getGoogleVoiceSceneDevice(scene, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == scene.sceneRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (scene.sceneSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == scene.sceneSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + scene.sceneName;
    deviceObj = {
        id: exports.kVoiceSceneDevice + '-' + scene.sceneRoom + '-' + scene.sceneId,
        type: exports.gSceneType,
        traits: [exports.gSceneTrait],
        name: {
            name: fullName
        },
        willReportState: false,
        attributes: {
            sceneReversible: false
        },
        deviceInfo: {
            manufacturer: manufacturerName,
            model: exports.kVoiceSceneDevice + '-' + scene.sceneType
        }
    };
    return deviceObj;
}
exports.getGoogleVoiceSceneDevice = getGoogleVoiceSceneDevice;
function getGoogleVoiceEsApplianceDevice(appliance, roomList, esDevice) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == esDevice.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (esDevice.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == esDevice.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + appliance.applianceName;
    switch (appliance.applianceType) {
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
            deviceObj = {
                id: exports.kVoiceEmbeddedApplianceDevice + '-' + esDevice.deviceRoom + '-' + esDevice.deviceId + '-' + appliance.applianceId,
                type: exports.gLightType,
                traits: [exports.gOnOffTrait, exports.gBrightnessTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: {},
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceEmbeddedApplianceDevice + '-' + esDevice.deviceType
                }
            };
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
            deviceObj = {
                id: exports.kVoiceEmbeddedApplianceDevice + '-' + esDevice.deviceRoom + '-' + esDevice.deviceId + '-' + appliance.applianceId,
                type: exports.gSwitchType,
                traits: [exports.gOnOffTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: {},
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceEmbeddedApplianceDevice + '-' + esDevice.deviceType
                }
            };
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
            deviceObj = {
                id: exports.kVoiceEmbeddedApplianceDevice + '-' + esDevice.deviceRoom + '-' + esDevice.deviceId + '-' + appliance.applianceId,
                type: exports.gFanType,
                traits: [exports.gOnOffTrait, exports.gFanSpeedTrait],
                name: {
                    name: fullName
                },
                willReportState: true,
                attributes: fanSpeedAttributes,
                deviceInfo: {
                    manufacturer: manufacturerName,
                    model: exports.kVoiceEmbeddedApplianceDevice + '-' + esDevice.deviceType
                }
            };
            break;
    }
    return deviceObj;
}
exports.getGoogleVoiceEsApplianceDevice = getGoogleVoiceEsApplianceDevice;
function getGoogleVoiceCurtainDevice(device, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + device.deviceName;
    deviceObj = {
        id: exports.kVoiceCurtainDevice + '-' + device.deviceRoom + '-' + device.deviceId,
        type: exports.gCurtainType,
        traits: [exports.gOpenCloseTrait],
        name: {
            name: fullName
        },
        willReportState: true,
        attributes: {
            discreteOnlyOpenClose: true
        },
        deviceInfo: {
            manufacturer: manufacturerName,
            model: exports.kVoiceCurtainDevice + '-' + device.deviceType
        }
    };
    return deviceObj;
}
exports.getGoogleVoiceCurtainDevice = getGoogleVoiceCurtainDevice;
function getGoogleVoiceACFanDevice(device, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + device.deviceName;
    deviceObj = {
        id: exports.kVoiceACFanDevice + '-' + device.deviceRoom + '-' + device.deviceId,
        type: exports.gFanType,
        traits: [exports.gOnOffTrait, exports.gFanSpeedTrait],
        name: {
            name: fullName
        },
        willReportState: true,
        attributes: fanSpeedAttributes,
        deviceInfo: {
            manufacturer: manufacturerName,
            model: exports.kVoiceACFanDevice + '-' + device.deviceType
        }
    };
    return deviceObj;
}
exports.getGoogleVoiceACFanDevice = getGoogleVoiceACFanDevice;
function getGoogleVoiceDCFanDevice(device, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + device.deviceName;
    deviceObj = {
        id: exports.kVoiceDCFanDevice + '-' + device.deviceRoom + '-' + device.deviceId,
        type: exports.gFanType,
        traits: [exports.gOnOffTrait, exports.gFanSpeedTrait],
        name: {
            name: fullName
        },
        willReportState: true,
        attributes: fanSpeedAttributes,
        deviceInfo: {
            manufacturer: manufacturerName,
            model: exports.kVoiceDCFanDevice + '-' + device.deviceType
        }
    };
    return deviceObj;
}
exports.getGoogleVoiceDCFanDevice = getGoogleVoiceDCFanDevice;
function getGoogleVoiceSCRelayDevice(relay, roomList, device) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + relay.relayName;
    deviceObj = {
        id: exports.kVoiceSCRelayDevice + '-' + device.deviceRoom + '-' + device.deviceId + '-' + relay.relayId,
        type: exports.gSwitchType,
        traits: [exports.gOnOffTrait],
        name: {
            name: fullName
        },
        willReportState: true,
        attributes: {},
        deviceInfo: {
            manufacturer: manufacturerName,
            model: exports.kVoiceSCRelayDevice + '-' + device.deviceType
        }
    };
    return deviceObj;
}
exports.getGoogleVoiceSCRelayDevice = getGoogleVoiceSCRelayDevice;
function getGoogleVoiceIRACDevice(remote, roomList, device) {
    let deviceObj;
    const acRemoteProps = remote.remoteProperties;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + remote.remoteName;
    const availableModes = [];
    if (acRemoteProps.modeEnabled) {
        acRemoteProps.modeOptions.forEach(function (mode) {
            if (exports.acunitSupportedModeList.indexOf(mode.toLowerCase()) > -1) {
                availableModes.push(getGoogleAcMode(mode));
            }
        });
    }
    deviceObj = {
        id: exports.kVoiceIRACDevice + '-' + device.deviceRoom + '-' + device.deviceId + '-' + remote.remoteId,
        type: exports.gACUnitType,
        traits: [exports.gOnOffTrait, exports.gTemperatureSettingTrait, exports.gFanSpeedTrait],
        name: {
            name: fullName
        },
        willReportState: true,
        attributes: {
            availableThermostatModes: availableModes,
            thermostatTemperatureUnit: 'C',
            minThresholdCelcius: acRemoteProps.temperatureRange[0],
            maxThresholdCelcius: acRemoteProps.temperatureRange[acRemoteProps.temperatureRange.length - 1],
            availableFanSpeeds: getAcUnitAvailableFanSpeeds(remote),
            reversible: false,
            commandOnlyFanSpeed: false
        },
        deviceInfo: {
            manufacturer: manufacturerName,
            model: exports.kVoiceIRACDevice + '-' + device.deviceType
        }
    };
    console.log('THIS SI THE AC REMOTE DEVICE OBJECT', deviceObj);
    return deviceObj;
}
exports.getGoogleVoiceIRACDevice = getGoogleVoiceIRACDevice;
function getGoogleVoiceFullRoomDevice(room, section) {
    let deviceObj;
    var fullName = room.roomName;
    if (section.sectionId != home_constants_1.DefaultSectionId) {
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + roomLightsTag;
    deviceObj = {
        id: exports.kVoiceRoomDevice + '-' + room.roomId,
        type: exports.gLightType,
        traits: [exports.gOnOffTrait],
        name: {
            name: fullName
        },
        willReportState: false,
        attributes: {},
        deviceInfo: {
            manufacturer: manufacturerName,
            model: exports.kVoiceRoomDevice + '-' + room.roomType
        }
    };
    return deviceObj;
}
exports.getGoogleVoiceFullRoomDevice = getGoogleVoiceFullRoomDevice;
function getGoogleVoiceRGBWWADevice(device, roomList) {
    let deviceObj;
    const room = roomList.find(function (room) {
        return room.roomId == device.deviceRoom;
    });
    if (!room) {
        return null;
    }
    var fullName = room.roomName;
    if (device.deviceSection != home_constants_1.DefaultSectionId) {
        const section = room.sectionList.find(function (section) {
            section.sectionId == device.deviceSection;
        });
        if (!section) {
            return null;
        }
        fullName = fullName + ' ' + section.sectionName;
    }
    fullName = fullName + ' ' + device.deviceName;
    deviceObj = {
        id: exports.kVoiceRGBWWADevice + '-' + device.deviceRoom + '-' + device.deviceId,
        type: exports.gLightType,
        traits: [exports.gOnOffTrait, exports.gBrightnessTrait, exports.gColorSettingTrait],
        name: {
            name: fullName
        },
        willReportState: false,
        attributes: {
            commandOnlyColorSetting: true,
            colorModel: 'rgb',
            colorTemperatureRange: {
                temperatureMinK: exports.rgbwwaMinTemp,
                temperatureMaxK: exports.rgbwwaMaxTemp
            }
        },
        deviceInfo: {
            manufacturer: manufacturerName,
            model: exports.kVoiceRGBWWADevice + '-' + device.deviceType
        }
    };
    return deviceObj;
}
exports.getGoogleVoiceRGBWWADevice = getGoogleVoiceRGBWWADevice;
function getKeusId(deviceId) {
    const deviceParams = deviceId.split('-');
    switch (deviceParams[0]) {
        case exports.kVoiceSceneDevice:
            if (deviceParams.length != 3) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    sceneId: parseInt(deviceParams[2]),
                    sceneRoom: deviceParams[1]
                };
            }
            break;
        case exports.kVoiceGroupDevice:
            if (deviceParams.length != 3) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    groupId: parseInt(deviceParams[2]),
                    groupRoom: deviceParams[1]
                };
            }
            break;
        case exports.kVoiceEmbeddedApplianceDevice:
            if (deviceParams.length != 4) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    deviceRoom: deviceParams[1],
                    applianceId: deviceParams[3]
                };
            }
            break;
        case exports.kVoiceCurtainDevice:
        case exports.kVoiceACFanDevice:
        case exports.kVoiceDCFanDevice:
            if (deviceParams.length != 3) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    deviceRoom: deviceParams[1]
                };
            }
            break;
        case exports.kVoiceSCRelayDevice:
            if (deviceParams.length != 4) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    relayId: parseInt(deviceParams[3]),
                    deviceRoom: deviceParams[1]
                };
            }
        case exports.kVoiceIRACDevice:
            if (deviceParams.length != 4) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    remoteId: deviceParams[3],
                    deviceRoom: deviceParams[1]
                };
            }
        case exports.kVoiceRoomDevice:
            if (deviceParams.length != 2) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    roomId: deviceParams[1]
                };
            }
        case exports.kVoiceRGBWWADevice:
            if (deviceParams.length != 3) {
                throw new errors_1.DeviceErrors.InvalidDeviceId();
            }
            else {
                return {
                    kDevType: deviceParams[0],
                    deviceId: deviceParams[2],
                    deviceRoom: deviceParams[1]
                };
            }
            break;
        default:
            throw new errors_1.DeviceErrors.InvalidDeviceType();
    }
}
exports.getKeusId = getKeusId;
function getDeviceStatusObjString(success, message, id, successState) {
    const statusResp = {};
    statusResp.status = success ? exports.successString : exports.failureString;
    statusResp.ids = [id];
    if (success) {
        statusResp.states = successState;
    }
    else {
        statusResp.errorCode = message;
    }
    return JSON.stringify(statusResp);
}
exports.getDeviceStatusObjString = getDeviceStatusObjString;
function getGoogleAcMode(keusAcMode) {
    if (keusAcMode == exports.keusACFanMode) {
        return exports.acUnitFanMode;
    }
    else {
        return keusAcMode.toLowerCase();
    }
}
exports.getGoogleAcMode = getGoogleAcMode;
function getKeusAcMode(googleAcMode) {
    if (googleAcMode == exports.acUnitFanMode) {
        return exports.keusACFanMode;
    }
    else {
        return googleAcMode.toUpperCase();
    }
}
exports.getKeusAcMode = getKeusAcMode;
function getAcUnitAvailableFanSpeeds(acRemote) {
    const fanSpeedsList = [];
    const acRemoteProps = acRemote.remoteProperties;
    if (acRemoteProps.fanEnabled) {
        acRemoteProps.fanOptions.forEach(function (fanSpeed) {
            switch (fanSpeed) {
                case exports.keusFanSpeedLow:
                    fanSpeedsList.push(fanSpeedAttributes.availableFanSpeeds.speeds[0]);
                    break;
                case exports.keusFanSpeedMedium:
                    fanSpeedsList.push(fanSpeedAttributes.availableFanSpeeds.speeds[1]);
                    break;
                case exports.keusFanSpeedHigh:
                    fanSpeedsList.push(fanSpeedAttributes.availableFanSpeeds.speeds[2]);
                    break;
            }
        });
    }
    return {
        availableFanSpeeds: {
            speeds: fanSpeedsList,
            ordered: true
        },
        reversible: false,
        supportsFanSpeedPercent: false
    };
}
exports.getAcUnitAvailableFanSpeeds = getAcUnitAvailableFanSpeeds;
function getGoogleAcUnitFanSpeed(keusAcFanSpeed) {
    switch (keusAcFanSpeed) {
        case exports.keusFanSpeedLow:
            return exports.fanSpeedLow;
            break;
        case exports.keusFanSpeedMedium:
            return exports.fanSpeedMedium;
            break;
        case exports.keusFanSpeedHigh:
            return exports.fanSpeedHigh;
            break;
        default:
            return null;
    }
}
exports.getGoogleAcUnitFanSpeed = getGoogleAcUnitFanSpeed;
function getKeusAcUnitFanSpeed(googleAcFanSpeed) {
    switch (googleAcFanSpeed) {
        case exports.fanSpeedLow:
            return exports.keusFanSpeedLow;
            break;
        case exports.fanSpeedMedium:
            return exports.keusFanSpeedMedium;
            break;
        case exports.fanSpeedHigh:
            return exports.keusFanSpeedHigh;
            break;
        default:
            return null;
    }
}
exports.getKeusAcUnitFanSpeed = getKeusAcUnitFanSpeed;
// {
//     "id": "123",
//     "type": "action.devices.types.LIGHT",
//     "traits": [
//       "action.devices.traits.ColorSetting",
//       "action.devices.traits.Brightness",
//       "action.devices.traits.OnOff"
//     ],
//     "name": {
//       "name": "Simple light"
//     },
//     "willReportState": true,
//     "attributes": {
//       "colorTemperatureRange": {
//         "temperatureMinK": 2000,
//         "temperatureMaxK": 6500
//       }
//     },
//     "deviceInfo": {
//       "manufacturer": "smart-home-inc",
//       "model": "hs1234",
//       "hwVersion": "3.2",
//       "swVersion": "11.4"
//     }
//   }
//# sourceMappingURL=google-voice-utils.js.map