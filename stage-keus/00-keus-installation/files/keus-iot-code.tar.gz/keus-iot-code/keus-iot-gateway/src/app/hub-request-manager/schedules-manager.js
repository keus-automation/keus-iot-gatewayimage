"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jobs_util_1 = require("../../utilities/jobs-util");
const database_utils_1 = require("../../utilities/gateway/database-utils");
const database_service_1 = __importDefault(require("../../configs/database-service"));
const system_constants_1 = require("../../constants/gateway/system-constants");
const keus_schedule_1 = __importDefault(require("../../models/database-models/keus-schedule"));
const schedule_structure_pb_1 = require("./protos/generated/hub/schedules/schedule_structure_pb");
const gateway_request_manager_1 = require("../../models/job-models/gateway-request-manager");
const keus_group_1 = __importDefault(require("../../models/database-models/keus-group"));
const zigbee_ac_fan_controller_pb_1 = require("./protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const zigbee_dc_fan_controller_pb_1 = require("./protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const device_constants_pb_1 = require("./protos/generated/hub/devices/device_constants_pb");
const zigbee_ir_blaster_pb_1 = require("./protos/generated/hub/devices/zigbee_ir_blaster_pb");
const keus_scene_1 = __importDefault(require("../../models/database-models/keus-scene"));
const errors_1 = require("../../errors/errors");
// const sampleSchedule: IKeusSchedule = {
//     repeat: [],
//     scheduleId: 'zjkLscoWRe',
//     scheduleName: 'test final 1111',
//     scheduleRoom: '5jZNpiUt35',
//     scheduleSection: 'Default',
//     scheduleType: 0,
//     scheduleActionType: 6,
//     startTime: Date.now() + 35000,
//     endTime: Date.now() + 180000,
//     scheduleAction: {
//         fanState: 0,
//         deviceId: '0x00124b0021b70834',
//         lightState: 0,
//         updateType: 2
//     },
//     createdBy: '+918374311755',
//     createdByName: 'Chinmay',
//     activeStatus: false
// };
class SchedulesManager {
    static getInstance() {
        if (!SchedulesManager.instance) {
            SchedulesManager.instance = new SchedulesManager();
            SchedulesManager.instance.jobsManager = new jobs_util_1.Jobs({
                mongoUrl: database_utils_1.formMongoDatabaseConnectionUrl(database_service_1.default) + '/' + system_constants_1.DatabaseName,
                instanceIdentifier: 'GRM'
            });
        }
        return SchedulesManager.instance;
    }
    async start() {
        const _this = this;
        await this.jobsManager.start();
        await this.jobsManager.cleanJobs();
        const scheduleList = await keus_schedule_1.default.getAllSchedules();
        scheduleList.forEach(async function (schedule) {
            if (schedule.activeStatus) {
                if (!schedule.repeat.length || schedule.repeat.indexOf('true') < 0) {
                    if (schedule.startTime > Date.now() || (schedule.endTime && schedule.endTime > Date.now())) {
                        console.log("READDING SCHEDULE", schedule.scheduleId);
                        await _this.scheduleJob(schedule);
                    }
                }
                else {
                    await _this.scheduleJob(schedule);
                }
            }
        });
    }
    async defineJob(jobName, jobDef) {
        await this.jobsManager.defineJob(jobName, jobDef);
    }
    async scheduleJob(schedule) {
        try {
            await this.deleteJob(schedule);
            const jobInfo = {};
            var jobName = '';
            console.log('THIS IS SCHEDULE START TIME', schedule.startTime, schedule.endTime);
            jobInfo.startTime = schedule.startTime;
            jobInfo.repeat = schedule.repeat;
            if (schedule.scheduleType == schedule_structure_pb_1.SCHEDULE_TYPE.SCHEDULE) {
                jobInfo.endTime = schedule.endTime;
            }
            switch (schedule.scheduleActionType) {
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_DIMMABLE_DRIVER:
                    const daliDimmableAction = schedule.scheduleAction;
                    const daliDimmableGroupInfo = await keus_group_1.default.getGroupById(daliDimmableAction.groupId, daliDimmableAction.roomId);
                    if (!daliDimmableGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const daliDimmableOffAction = {
                        driverState: 0,
                        groupId: daliDimmableAction.groupId,
                        roomId: daliDimmableAction.roomId
                    };
                    const daliDimmableJobStartData = {
                        groupId: daliDimmableAction.groupId,
                        groupRoom: daliDimmableAction.roomId,
                        groupType: daliDimmableGroupInfo.groupType,
                        groupState: daliDimmableAction
                    };
                    const daliDimmableJobEndData = {
                        groupId: daliDimmableAction.groupId,
                        groupRoom: daliDimmableAction.roomId,
                        groupType: daliDimmableGroupInfo.groupType,
                        groupState: daliDimmableOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = daliDimmableJobStartData;
                    jobInfo.endData = daliDimmableJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_COLOR_TUNABLE_DRIVER:
                    const daliColorTunableAction = schedule.scheduleAction;
                    const daliColorTunableGroupInfo = await keus_group_1.default.getGroupById(daliColorTunableAction.groupId, daliColorTunableAction.roomId);
                    if (!daliColorTunableGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const daliColorTunableOffAction = {
                        driverState: {
                            driverState: 0,
                            colorTemperature: daliColorTunableAction.driverState.colorTemperature,
                            lastUpdateBy: daliColorTunableAction.driverState.lastUpdateBy,
                            lastUpdateSource: daliColorTunableAction.driverState.lastUpdateSource,
                            lastUpdateTime: daliColorTunableAction.driverState.lastUpdateTime,
                            lastUpdateUser: daliColorTunableAction.driverState.lastUpdateUser
                        },
                        groupId: daliColorTunableAction.groupId,
                        roomId: daliColorTunableAction.roomId
                    };
                    const daliColorTunableJobStartData = {
                        groupId: daliColorTunableAction.groupId,
                        groupRoom: daliColorTunableAction.roomId,
                        groupType: daliColorTunableGroupInfo.groupType,
                        groupState: daliColorTunableAction
                    };
                    const daliColorTunableJobEndData = {
                        groupId: daliColorTunableAction.groupId,
                        groupRoom: daliColorTunableAction.roomId,
                        groupType: daliColorTunableGroupInfo.groupType,
                        groupState: daliColorTunableOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = daliColorTunableJobStartData;
                    jobInfo.endData = daliColorTunableJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_NON_DIMMABLE_DRIVER:
                    const daliNonDimmableAction = schedule.scheduleAction;
                    const daliNonDimmableGroupInfo = await keus_group_1.default.getGroupById(daliNonDimmableAction.groupId, daliNonDimmableAction.roomId);
                    if (!daliNonDimmableGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const daliNonDimmableOffAction = {
                        driverState: 0,
                        groupId: daliNonDimmableAction.groupId,
                        roomId: daliNonDimmableAction.roomId
                    };
                    var daliNonDimmableJobStartData = {
                        groupId: daliNonDimmableAction.groupId,
                        groupRoom: daliNonDimmableAction.roomId,
                        groupType: daliNonDimmableGroupInfo.groupType,
                        groupState: daliNonDimmableAction
                    };
                    var daliNonDimmableJobEndData = {
                        groupId: daliNonDimmableAction.groupId,
                        groupRoom: daliNonDimmableAction.roomId,
                        groupType: daliNonDimmableGroupInfo.groupType,
                        groupState: daliNonDimmableOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = daliNonDimmableJobStartData;
                    jobInfo.endData = daliNonDimmableJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DIMMABLE_DRIVER:
                    const zigbeeDimmableAction = schedule.scheduleAction;
                    const zigbeeDimmableGroupInfo = await keus_group_1.default.getGroupById(zigbeeDimmableAction.groupId, zigbeeDimmableAction.roomId);
                    if (!zigbeeDimmableGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const zigbeeDimmableOffAction = {
                        driverState: 0,
                        groupId: zigbeeDimmableAction.groupId,
                        roomId: zigbeeDimmableAction.roomId
                    };
                    var zigbeeDimmableJobStartData = {
                        groupId: zigbeeDimmableAction.groupId,
                        groupRoom: zigbeeDimmableAction.roomId,
                        groupType: zigbeeDimmableGroupInfo.groupType,
                        groupState: zigbeeDimmableAction
                    };
                    var zigbeeDimmableJobEndData = {
                        groupId: zigbeeDimmableAction.groupId,
                        groupRoom: zigbeeDimmableAction.roomId,
                        groupType: zigbeeDimmableGroupInfo.groupType,
                        groupState: zigbeeDimmableOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = zigbeeDimmableJobStartData;
                    jobInfo.endData = zigbeeDimmableJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_NON_DIMMABLE_DRIVER:
                    const zigbeeNonDimmableAction = schedule.scheduleAction;
                    const zigbeeNonDimmableGroupInfo = await keus_group_1.default.getGroupById(zigbeeNonDimmableAction.groupId, zigbeeNonDimmableAction.roomId);
                    if (!zigbeeNonDimmableGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const zigbeeNonDimmableOffAction = {
                        driverState: 0,
                        groupId: zigbeeNonDimmableAction.groupId,
                        roomId: zigbeeNonDimmableAction.roomId
                    };
                    var zigbeeNonDimmableJobStartData = {
                        groupId: zigbeeNonDimmableAction.groupId,
                        groupRoom: zigbeeNonDimmableAction.roomId,
                        groupType: zigbeeNonDimmableGroupInfo.groupType,
                        groupState: zigbeeNonDimmableAction
                    };
                    var zigbeeNonDimmableJobEndData = {
                        groupId: zigbeeNonDimmableAction.groupId,
                        groupRoom: zigbeeNonDimmableAction.roomId,
                        groupType: zigbeeNonDimmableGroupInfo.groupType,
                        groupState: zigbeeNonDimmableOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = zigbeeNonDimmableJobStartData;
                    jobInfo.endData = zigbeeNonDimmableJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_ON0FF:
                    const grpApplianceOnOffAction = schedule.scheduleAction;
                    const eApplianceOnOffGroupInfo = await keus_group_1.default.getGroupById(grpApplianceOnOffAction.groupId, grpApplianceOnOffAction.roomId);
                    if (!eApplianceOnOffGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const grpApplianceOnOffOffAction = {
                        switchState: 0,
                        groupId: grpApplianceOnOffAction.groupId,
                        roomId: grpApplianceOnOffAction.roomId
                    };
                    var grpApplianceOnOffJobStartData = {
                        groupId: grpApplianceOnOffAction.groupId,
                        groupRoom: grpApplianceOnOffAction.roomId,
                        groupType: eApplianceOnOffGroupInfo.groupType,
                        groupState: grpApplianceOnOffAction
                    };
                    var grpApplianceOnOffJobEndData = {
                        groupId: grpApplianceOnOffOffAction.groupId,
                        groupRoom: grpApplianceOnOffOffAction.roomId,
                        groupType: eApplianceOnOffGroupInfo.groupType,
                        groupState: grpApplianceOnOffOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = grpApplianceOnOffJobStartData;
                    jobInfo.endData = grpApplianceOnOffJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_SINGLE_DIMMER:
                    const grpApplianceSDimmerAction = (schedule.scheduleAction);
                    const eApplianceSDimmerGroupInfo = await keus_group_1.default.getGroupById(grpApplianceSDimmerAction.groupId, grpApplianceSDimmerAction.roomId);
                    if (!eApplianceSDimmerGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const grpApplianceSDimmerOffAction = {
                        switchState: 0,
                        groupId: grpApplianceSDimmerAction.groupId,
                        roomId: grpApplianceSDimmerAction.roomId
                    };
                    var grpApplianceSDimmerJobStartData = {
                        groupId: grpApplianceSDimmerAction.groupId,
                        groupRoom: grpApplianceSDimmerAction.roomId,
                        groupType: eApplianceSDimmerGroupInfo.groupType,
                        groupState: grpApplianceSDimmerAction
                    };
                    var grpApplianceSDimmerJobEndData = {
                        groupId: grpApplianceSDimmerOffAction.groupId,
                        groupRoom: grpApplianceSDimmerOffAction.roomId,
                        groupType: eApplianceSDimmerGroupInfo.groupType,
                        groupState: grpApplianceSDimmerOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = grpApplianceSDimmerJobStartData;
                    jobInfo.endData = grpApplianceSDimmerJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_FAN:
                    const grpApplianceFanAction = schedule.scheduleAction;
                    const eApplianceFanGroupInfo = await keus_group_1.default.getGroupById(grpApplianceFanAction.groupId, grpApplianceFanAction.roomId);
                    if (!eApplianceFanGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const grpApplianceFanOffAction = {
                        fanState: 0,
                        groupId: grpApplianceFanAction.groupId,
                        roomId: grpApplianceFanAction.roomId
                    };
                    var grpApplianceFanJobStartData = {
                        groupId: grpApplianceFanAction.groupId,
                        groupRoom: grpApplianceFanAction.roomId,
                        groupType: eApplianceFanGroupInfo.groupType,
                        groupState: grpApplianceFanAction
                    };
                    var grpApplianceFanJobEndData = {
                        groupId: grpApplianceFanOffAction.groupId,
                        groupRoom: grpApplianceFanOffAction.roomId,
                        groupType: eApplianceFanGroupInfo.groupType,
                        groupState: grpApplianceFanOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = grpApplianceFanJobStartData;
                    jobInfo.endData = grpApplianceFanJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_COLOR_TUNABLE:
                    const grpApplianceColorTunableAction = (schedule.scheduleAction);
                    const eApplianceColorTunableGroupInfo = await keus_group_1.default.getGroupById(grpApplianceColorTunableAction.groupId, grpApplianceColorTunableAction.roomId);
                    if (!eApplianceColorTunableGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const grpApplianceColorTunableOffAction = {
                        lightState: 0,
                        coolWhiteState: 0,
                        warmWhiteState: 0,
                        groupId: grpApplianceColorTunableAction.groupId,
                        roomId: grpApplianceColorTunableAction.roomId
                    };
                    var grpApplianceColorTunableJobStartData = {
                        groupId: grpApplianceColorTunableAction.groupId,
                        groupRoom: grpApplianceColorTunableAction.roomId,
                        groupType: eApplianceColorTunableGroupInfo.groupType,
                        groupState: grpApplianceColorTunableAction
                    };
                    var grpApplianceColorTunableJobEndData = {
                        groupId: grpApplianceColorTunableOffAction.groupId,
                        groupRoom: grpApplianceColorTunableOffAction.roomId,
                        groupType: eApplianceColorTunableGroupInfo.groupType,
                        groupState: grpApplianceColorTunableOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = grpApplianceColorTunableJobStartData;
                    jobInfo.endData = grpApplianceColorTunableJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.SCENE_EXECUTION:
                    jobName = gateway_request_manager_1.ExecuteScene.name;
                    const sceneAction = schedule.scheduleAction;
                    const scene = await keus_scene_1.default.getSceneById(sceneAction.sceneId, sceneAction.sceneRoom);
                    if (!scene) {
                        throw new errors_1.SceneErrors.InvalidSceneId();
                    }
                    const executeSceneJobStartData = {
                        sceneId: sceneAction.sceneId,
                        sceneRoom: sceneAction.sceneRoom,
                        sceneType: scene.sceneType
                    };
                    jobInfo.startData = executeSceneJobStartData;
                    delete jobInfo.endTime;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_AC_FAN_CONTROLLER:
                    const zigbeeACFanControllerAction = schedule.scheduleAction;
                    const zigbeeACFanControllerOffAction = {
                        deviceId: zigbeeACFanControllerAction.deviceId,
                        updateType: zigbeeACFanControllerAction.updateType,
                        lightState: 0,
                        fanState: zigbee_ac_fan_controller_pb_1.AC_FAN_CONTROLLER_STATES.AC_OFF
                    };
                    const zigbeeACFanStartData = {
                        deviceId: zigbeeACFanControllerAction.deviceId,
                        deviceState: zigbeeACFanControllerAction
                    };
                    const zigbeeACFanEndData = {
                        deviceId: zigbeeACFanControllerAction.deviceId,
                        deviceState: zigbeeACFanControllerOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateZigbeeACFanControllerState.name;
                    jobInfo.startData = zigbeeACFanStartData;
                    jobInfo.endData = zigbeeACFanEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DC_FAN_CONTROLLER:
                    const zigbeeDCFanControllerAction = schedule.scheduleAction;
                    const zigbeeDCFanControllerOffAction = {
                        deviceId: zigbeeDCFanControllerAction.deviceId,
                        updateType: zigbeeDCFanControllerAction.updateType,
                        fanState: zigbee_dc_fan_controller_pb_1.DC_FAN_CONTROLLER_STATES.DC_OFF,
                        lightState: {
                            lightState: 0,
                            lightTemperature: 0
                        }
                    };
                    const zigbeeDCFanStartData = {
                        deviceId: zigbeeDCFanControllerAction.deviceId,
                        deviceState: zigbeeDCFanControllerAction
                    };
                    const zigbeeDCFanEndData = {
                        deviceId: zigbeeDCFanControllerAction.deviceId,
                        deviceState: zigbeeDCFanControllerOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateZigbeeDCFanControllerState.name;
                    jobInfo.startData = zigbeeDCFanStartData;
                    jobInfo.endData = zigbeeDCFanEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_SMART_CONSOLE_RELAY:
                    const smartConsoleRelayAction = schedule.scheduleAction;
                    const smartConsoleRelayOffAction = {
                        deviceId: smartConsoleRelayAction.deviceId,
                        relayId: smartConsoleRelayAction.relayId,
                        relayState: 0
                    };
                    const smartConsoleRelayStartData = {
                        deviceId: smartConsoleRelayAction.deviceId,
                        relayAction: smartConsoleRelayAction
                    };
                    const smartConsoleRelayEndData = {
                        deviceId: smartConsoleRelayAction.deviceId,
                        relayAction: smartConsoleRelayOffAction
                    };
                    jobName = gateway_request_manager_1.SetConsoleRelayState.name;
                    jobInfo.startData = smartConsoleRelayStartData;
                    jobInfo.endData = smartConsoleRelayEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_RGBWWA:
                    const zigbeeRGBWWAAction = schedule.scheduleAction;
                    const zigbeeRGBWWAOffAction = {
                        deviceId: zigbeeRGBWWAAction.deviceId,
                        updateType: zigbeeRGBWWAAction.updateType,
                        deviceState: zigbeeRGBWWAAction.deviceState,
                        rgbState: {
                            deviceState: 0,
                            blue: 0,
                            red: 0,
                            green: 0,
                            pattern: 0
                        },
                        wwaState: {
                            deviceState: 0,
                            amber: 0,
                            coolWhite: 0,
                            warmWhite: 0
                        }
                    };
                    const zigbeeRGBWWAStartData = {
                        deviceId: zigbeeRGBWWAAction.deviceId,
                        rgbwwaAction: zigbeeRGBWWAAction
                    };
                    const zigbeeRGBWWAEndData = {
                        deviceId: zigbeeRGBWWAAction.deviceId,
                        rgbwwaAction: zigbeeRGBWWAOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateZigbeeRGBWWAState.name;
                    jobInfo.startData = zigbeeRGBWWAStartData;
                    jobInfo.endData = zigbeeRGBWWAEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_ZIGBEE_RGBWWA:
                    const groupRgbwwaAction = schedule.scheduleAction;
                    const rgbwwaGroupInfo = await keus_group_1.default.getGroupById(groupRgbwwaAction.groupId, groupRgbwwaAction.roomId);
                    if (!rgbwwaGroupInfo) {
                        throw new errors_1.GroupErrors.InvalidGroupId();
                    }
                    const rgbGroupOffAction = {
                        deviceState: 0,
                        groupId: groupRgbwwaAction.groupId,
                        roomId: groupRgbwwaAction.roomId,
                        updateType: groupRgbwwaAction.updateType,
                        rgbState: {
                            deviceState: 0,
                            blue: 0,
                            red: 0,
                            green: 0,
                            pattern: 0
                        },
                        wwaState: {
                            deviceState: 0,
                            amber: 0,
                            coolWhite: 0,
                            warmWhite: 0
                        }
                    };
                    var rgbwwaGroupJobStartData = {
                        groupId: groupRgbwwaAction.groupId,
                        groupRoom: groupRgbwwaAction.roomId,
                        groupType: rgbwwaGroupInfo.groupType,
                        groupState: groupRgbwwaAction
                    };
                    var rgbwwaGroupJobEndData = {
                        groupId: groupRgbwwaAction.groupId,
                        groupRoom: groupRgbwwaAction.roomId,
                        groupType: rgbwwaGroupInfo.groupType,
                        groupState: rgbGroupOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateGroupState.name;
                    jobInfo.startData = rgbwwaGroupJobStartData;
                    jobInfo.endData = rgbwwaGroupJobEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_CURTAIN_CONTROLLER:
                    const zigbeeCurtainControllerAction = schedule.scheduleAction;
                    const zigbeeCurtainControllerOffAction = {
                        deviceId: zigbeeCurtainControllerAction.deviceId,
                        curtainState: device_constants_pb_1.CURTAIN_CONTROLLER_ACTION.CC_CLOSE
                    };
                    const zigbeeCurtainControllerStartData = {
                        deviceId: zigbeeCurtainControllerAction.deviceId,
                        curtainAction: zigbeeCurtainControllerAction
                    };
                    const zigbeeCurtainControllerEndData = {
                        deviceId: zigbeeCurtainControllerAction.deviceId,
                        curtainAction: zigbeeCurtainControllerOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateZigbeeCurtainControllerState.name;
                    jobInfo.startData = zigbeeCurtainControllerStartData;
                    jobInfo.endData = zigbeeCurtainControllerEndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_IR_REMOTE:
                    const zigbeeIRAction = schedule.scheduleAction;
                    let zigbeeIROffAction;
                    switch (zigbeeIRAction.remoteType) {
                        case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                            const zigbeeIRACAction = zigbeeIRAction.irBlastAction;
                            const zigbeeIRACOffAction = {
                                powerOn: false,
                                temperature: zigbeeIRACAction.temperature,
                                swingHLevel: zigbeeIRACAction.swingHLevel,
                                swingVLevel: zigbeeIRACAction.swingVLevel,
                                mode: zigbeeIRACAction.mode,
                                fanLevel: zigbeeIRACAction.fanLevel
                            };
                            zigbeeIROffAction = {
                                remoteId: zigbeeIRAction.remoteId,
                                remoteType: zigbeeIRAction.remoteType,
                                irDevice: zigbeeIRAction.irDevice,
                                irBlastAction: zigbeeIRACOffAction
                            };
                            break;
                        case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                            const zigbeeIRTVAction = zigbeeIRAction.irBlastAction;
                            const zigbeeIRTVOffAction = {
                                powerOn: false,
                                updateType: zigbee_ir_blaster_pb_1.TV_BLAST_TYPES.TV_ONOFF
                            };
                            zigbeeIROffAction = {
                                remoteId: zigbeeIRAction.remoteId,
                                remoteType: zigbeeIRAction.remoteType,
                                irDevice: zigbeeIRAction.irDevice,
                                irBlastAction: zigbeeIRTVOffAction
                            };
                            break;
                        case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                            const zigbeeIRAMPAction = zigbeeIRAction.irBlastAction;
                            const zigbeeIRAMPOffAction = {
                                powerOn: false,
                                updateType: zigbee_ir_blaster_pb_1.AMP_BLAST_TYPES.AMP_ONOFF
                            };
                            zigbeeIROffAction = {
                                remoteId: zigbeeIRAction.remoteId,
                                remoteType: zigbeeIRAction.remoteType,
                                irDevice: zigbeeIRAction.irDevice,
                                irBlastAction: zigbeeIRAMPOffAction
                            };
                            break;
                        case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                            const zigbeeIRPRAction = zigbeeIRAction.irBlastAction;
                            const zigbeeIRPROffAction = {
                                powerOn: false,
                                updateType: zigbee_ir_blaster_pb_1.PR_BLAST_TYPES.PR_ONOFF
                            };
                            zigbeeIROffAction = {
                                remoteId: zigbeeIRAction.remoteId,
                                remoteType: zigbeeIRAction.remoteType,
                                irDevice: zigbeeIRAction.irDevice,
                                irBlastAction: zigbeeIRPROffAction
                            };
                            break;
                        case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                            const zigbeeIRFANAction = zigbeeIRAction.irBlastAction;
                            const zigbeeIRFANOffAction = {
                                powerOn: false
                            };
                            zigbeeIROffAction = {
                                remoteId: zigbeeIRAction.remoteId,
                                remoteType: zigbeeIRAction.remoteType,
                                irDevice: zigbeeIRAction.irDevice,
                                irBlastAction: zigbeeIRFANOffAction
                            };
                            break;
                    }
                    const zigbeeIRStartData = {
                        deviceId: zigbeeIRAction.irDevice,
                        irBlastAction: zigbeeIRAction
                    };
                    const zigbeeIREndData = {
                        deviceId: zigbeeIRAction.irDevice,
                        irBlastAction: zigbeeIROffAction
                    };
                    jobName = gateway_request_manager_1.BlastIRCommand.name;
                    jobInfo.startData = zigbeeIRStartData;
                    jobInfo.endData = zigbeeIREndData;
                    break;
                case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_EMBEDDED_SWITCH:
                    const embeddedApplianceAction = schedule.scheduleAction;
                    let embeddedApplianceOffAction;
                    switch (embeddedApplianceAction.applianceType) {
                        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                            const eOnOffApplianceOffAction = {
                                switchState: 0
                            };
                            embeddedApplianceOffAction = {
                                applianceId: embeddedApplianceAction.applianceId,
                                deviceId: embeddedApplianceAction.deviceId,
                                applianceType: embeddedApplianceAction.applianceType,
                                applianceState: eOnOffApplianceOffAction
                            };
                            break;
                        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                            const eSDimmerApplianceOffAction = {
                                switchState: 0
                            };
                            embeddedApplianceOffAction = {
                                applianceId: embeddedApplianceAction.applianceId,
                                deviceId: embeddedApplianceAction.deviceId,
                                applianceType: embeddedApplianceAction.applianceType,
                                applianceState: eSDimmerApplianceOffAction
                            };
                            break;
                        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                            const eFanApplianceOffAction = {
                                fanState: 0
                            };
                            embeddedApplianceOffAction = {
                                applianceId: embeddedApplianceAction.applianceId,
                                deviceId: embeddedApplianceAction.deviceId,
                                applianceType: embeddedApplianceAction.applianceType,
                                applianceState: eFanApplianceOffAction
                            };
                            break;
                        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                            const eColorTunableApplianceOffAction = {
                                lightState: 0,
                                coolWhiteState: 0,
                                warmWhiteState: 0
                            };
                            embeddedApplianceOffAction = {
                                applianceId: embeddedApplianceAction.applianceId,
                                deviceId: embeddedApplianceAction.deviceId,
                                applianceType: embeddedApplianceAction.applianceType,
                                applianceState: eColorTunableApplianceOffAction
                            };
                            break;
                    }
                    const zigbeeEmbeddedStartData = {
                        deviceId: embeddedApplianceAction.deviceId,
                        applianceAction: embeddedApplianceAction
                    };
                    const zigbeeEmbeddedEndData = {
                        deviceId: embeddedApplianceAction.deviceId,
                        applianceAction: embeddedApplianceOffAction
                    };
                    jobName = gateway_request_manager_1.UpdateApplianceState.name;
                    jobInfo.startData = zigbeeEmbeddedStartData;
                    jobInfo.endData = zigbeeEmbeddedEndData;
                    break;
            }
            jobInfo.jobName = jobName;
            await this.jobsManager.scheduleJob(jobName, schedule.scheduleId, jobInfo);
        }
        catch (err) {
            console.log(err);
            throw err;
        }
    }
    async deleteJob(schedule) {
        await this.jobsManager.removeJob(schedule.scheduleId);
    }
}
exports.SchedulesManager = SchedulesManager;
//# sourceMappingURL=schedules-manager.js.map