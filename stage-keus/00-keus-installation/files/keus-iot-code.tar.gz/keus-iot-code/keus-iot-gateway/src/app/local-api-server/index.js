"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http"));
const express_1 = __importDefault(require("express"));
const middleware_handler_1 = require("./middleware-handler");
const app = express_1.default();
// const logInst = new Logger({ enable: true, namespace: 'HUB_CLIENT' });
async function startApiServer() {
    //   console.log('came to start hub');
    try {
        middleware_handler_1.middleware(app);
        console.log('middleware');
        await http_1.default.createServer(app).listen(3500);
        console.log('server created at port 3500');
    }
    catch (e) {
        console.log('api starter error', e);
    }
}
exports.startApiServer = startApiServer;
//# sourceMappingURL=index.js.map