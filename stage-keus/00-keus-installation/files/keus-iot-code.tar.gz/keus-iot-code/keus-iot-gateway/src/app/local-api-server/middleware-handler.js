"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const request_handler_1 = require("./request-handler");
const body_parser_1 = __importDefault(require("body-parser"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const compression_1 = __importDefault(require("compression"));
const cors_1 = __importDefault(require("cors"));
function middleware(app) {
    try {
        app.use(body_parser_1.default.json());
        app.use(body_parser_1.default.urlencoded({
            extended: false
        }));
        app.use(cookie_parser_1.default());
        app.options('*', cors_1.default());
        app.use(cors_1.default());
        app.use(compression_1.default());
        request_handler_1.apiArray.forEach(function (api) {
            app.use('/', api);
        });
        console.log('middleware confiured');
    }
    catch (e) {
        console.log('middleware error', e);
    }
}
exports.middleware = middleware;
//# sourceMappingURL=middleware-handler.js.map