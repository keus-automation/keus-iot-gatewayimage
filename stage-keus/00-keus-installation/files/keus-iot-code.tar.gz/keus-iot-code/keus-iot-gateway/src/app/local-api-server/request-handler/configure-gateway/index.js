"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express = __importStar(require("express"));
const router = express.Router();
const request_1 = require("./request");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../utilities/timed-promise");
const errors_1 = require("../../../../errors/errors");
const general_1 = require("../../../../utilities/general");
const keus_gateway_1 = __importDefault(require("../../../../models/database-models/keus-gateway"));
const keus_home_1 = __importDefault(require("../../../../models/database-models/keus-home"));
const home_utils_1 = require("../../../../utilities/gateway/home-utils");
const HomeConstants = __importStar(require("../../../../constants/gateway/home-constants"));
const SystemConstants = __importStar(require("../../../../constants/gateway/system-constants"));
const ApiUtils = __importStar(require("../../../../utilities/gateway/api-utils"));
const home_structures_pb_1 = require("../../../hub-request-manager/protos/generated/hub/home/home_structures_pb");
const internalIp = require('internal-ip');
exports.configureGateway = router.post('/configuregateway', async function (request, response) {
    return timed_promise_1.TPromise(function () {
        return new Promise(async (resolve, reject) => {
            let final_resp;
            try {
                let reqData = await general_1.verifyRequest(request.body, request_1.ConfigureHubType);
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                let newGatewayObj = await home_utils_1.GenerateGatewayData(reqData);
                if (gatewayDetails.length && !gatewayDetails[0].wronglyConfigured) {
                    final_resp = response_1.default.getGatewayAlreadyConfigured();
                }
                else {
                    if (gatewayDetails.length) {
                        await keus_gateway_1.default.deleteGateway(gatewayDetails[0].gatewayId);
                    }
                    await keus_gateway_1.default.createGateway(newGatewayObj);
                    await keus_home_1.default.addArea({
                        areaId: HomeConstants.DefaultAreaId,
                        areaName: HomeConstants.DefaultAreaName,
                        areaSyncInfo: {
                            syncRequestId: '-',
                            syncRequestParams: {},
                            syncRequestTime: Date.now(),
                            syncRequestType: home_structures_pb_1.AREA_JOB_TYPES.AREA_NONE,
                            syncStatus: home_structures_pb_1.AREA_SYNC_STATES.AREAINSYNC
                        }
                    });
                    await keus_home_1.default.addFloor({
                        floorId: HomeConstants.DefaultFloorId,
                        floorName: HomeConstants.DefaultFloorName
                    });
                    await keus_home_1.default.addRoom({
                        roomId: HomeConstants.DefaultRoomId,
                        roomName: HomeConstants.DefaultRoomName,
                        areaId: HomeConstants.DefaultAreaId,
                        floorId: HomeConstants.DefaultFloorId,
                        roomImageType: HomeConstants.RoomImageTypeList[0],
                        roomType: HomeConstants.RoomTypeMap.DEFAULT,
                        sectionList: [
                            {
                                sectionId: HomeConstants.DefaultSectionId,
                                sectionName: HomeConstants.DefaultSectionName
                            }
                        ]
                    });
                    try {
                        let ipGateway = await internalIp.v4();
                        let registerGatewayToCloudResp = await ApiUtils.makePostRequest(SystemConstants.cloudApiUrl + SystemConstants.cloudEndPointRegisterGatewayToCloud, {
                            gatwayId: newGatewayObj.gatewayId,
                            gatwayKey: newGatewayObj.gatewayKey,
                            gatewayIp: ipGateway
                        });
                        if (registerGatewayToCloudResp.success) {
                            await keus_gateway_1.default.makeRegisterMasterToCloudTrue(newGatewayObj.gatewayId);
                            final_resp = response_1.default.getConfigureGatewaySuccessful();
                        }
                        else if (registerGatewayToCloudResp.code == 802) {
                            await keus_gateway_1.default.setWronglyConfiguredTrue(newGatewayObj.gatewayId);
                            final_resp = response_1.default.GatewayAlreadyUsedInCloud();
                        }
                        else {
                            final_resp = response_1.default.getConfigureGatewaywithoutcloudSuccessful(registerGatewayToCloudResp.message);
                        }
                    }
                    catch (e) {
                        final_resp = response_1.default.getConfigureGatewaySuccessCloudConnectionError();
                    }
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.TypeValidationError:
                        final_resp = response_1.default.getValidationError();
                        break;
                    default:
                        console.log('get gateway status error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(response.send(final_resp));
        });
    });
});
//# sourceMappingURL=index.js.map