"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorCodes = {
    ConfugureGatewaySuccess: 800,
    ConfiguredWithoutCloudRegistration: 801,
    ConfiguredWithoutcloudConnectionError: 802,
    GatewayWronglyConfigured: 803,
    GetInternalServerError: 850,
    ValidationError: 851,
    GatewayAlreadyConfigured: 805
};
class ResponseClass {
    static getConfigureGatewaySuccessful() {
        return {
            success: true,
            code: ErrorCodes.ConfugureGatewaySuccess,
            message: 'gateway configured successful',
        };
    }
    static getConfigureGatewaywithoutcloudSuccessful(e) {
        return {
            success: true,
            code: ErrorCodes.ConfiguredWithoutCloudRegistration,
            message: 'Cloud Api Error' + e,
        };
    }
    static GatewayAlreadyUsedInCloud() {
        return {
            success: false,
            code: ErrorCodes.GatewayWronglyConfigured,
            message: 'gateway already in use please use new gateway details',
        };
    }
    static getConfigureGatewaySuccessCloudConnectionError() {
        return {
            success: true,
            code: ErrorCodes.ConfiguredWithoutcloudConnectionError,
            message: 'gateway configured successful cloud connection error',
        };
    }
    static getGatewayAlreadyConfigured() {
        return {
            success: false,
            code: ErrorCodes.GatewayAlreadyConfigured,
            message: 'Gateway Already Configured',
        };
    }
    static getValidationError() {
        return {
            success: false,
            code: ErrorCodes.ValidationError,
            message: 'Validation error'
        };
    }
    static getInternalServerError() {
        return {
            success: false,
            code: ErrorCodes.GetInternalServerError,
            message: 'internal server error',
        };
    }
}
exports.default = ResponseClass;
//# sourceMappingURL=response.js.map