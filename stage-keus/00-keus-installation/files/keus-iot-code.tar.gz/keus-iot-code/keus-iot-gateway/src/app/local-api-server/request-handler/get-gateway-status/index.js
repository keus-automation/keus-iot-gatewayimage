"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express = __importStar(require("express"));
const router = express.Router();
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../utilities/timed-promise");
const errors_1 = require("../../../../errors/errors");
const keus_gateway_1 = __importDefault(require("../../../../models/database-models/keus-gateway"));
const home_utils_1 = require("../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../models/database-models/keus-user"));
exports.getGatewayStatus = router.get('/getgatewaystatus', async function (request, response) {
    return timed_promise_1.TPromise(function () {
        return new Promise(async (resolve, reject) => {
            let final_resp;
            try {
                //let reqData: any = await verifyRequest(request.body, GetGatewayStatusType);
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                let gatewayStatus;
                if (gatewayDetails.length) {
                    let users = await keus_user_1.default.getAllUsers();
                    let gateways = await keus_gateway_1.default.getGateway();
                    gatewayStatus = {
                        isConfigured: gatewayDetails[0].isConfigured,
                        gatewayId: gatewayDetails[0].gatewayId,
                        isSuperUserAssigned: await home_utils_1.checkForSuperUser(users, gateways),
                        iisRegisteredToCloud: gatewayDetails[0].isRegisteredToCloud
                    };
                }
                else {
                    gatewayStatus = {
                        isConfigured: false,
                        isSuperUserAssigned: false,
                        isRegisteredToCloud: false,
                        gatewayId: ''
                    };
                }
                final_resp = response_1.default.getGateWayStatusSuccessful(gatewayStatus);
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.TypeValidationError:
                        final_resp = response_1.default.getValidationError();
                        break;
                    default:
                        console.log('get gateway status error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(response.send(final_resp));
        });
    });
});
//# sourceMappingURL=index.js.map