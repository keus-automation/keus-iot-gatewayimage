"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const router = express_1.default.Router();
const request_1 = require("./request");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../utilities/timed-promise");
const errors_1 = require("../../../../errors/errors");
const general_1 = require("../../../../utilities/general");
const keus_user_1 = __importDefault(require("../../../../models/database-models/keus-user"));
const keus_userdevice_1 = __importDefault(require("../../../../models/database-models/keus-userdevice"));
const keus_gateway_1 = __importDefault(require("../../../../models/database-models/keus-gateway"));
const system_constants_1 = require("../../../../constants/gateway/system-constants");
exports.grpcValidate = router.post('/localgrpcvalidate', async function (request, response) {
    return timed_promise_1.TPromise(function () {
        return new Promise(async (resolve, reject) => {
            console.log('HITTING VALIDATE ----------------------------------------');
            let final_resp;
            try {
                // let queryData = url.parse(request.url, true).query;
                let reqData = await general_1.verifyRequest(request.body, request_1.GrpcValidateType);
                switch (reqData.type) {
                    case system_constants_1.grpcValidateRequestType.user:
                        console.log('Verifying user type');
                        let userDevice = await keus_userdevice_1.default.getUserDevice(reqData.deviceKey);
                        if (!userDevice || userDevice.secretKey != reqData.secretKey) {
                            final_resp = response_1.default.getInvalidAuthKey();
                        }
                        if (userDevice.validity < Date.now()) {
                            final_resp = response_1.default.getValidityExpired();
                        }
                        else {
                            let userDetails = await keus_user_1.default.getUserByPhone(userDevice.phone);
                            let homesList = JSON.parse(userDetails.homesList);
                            let accessHomesList = [];
                            homesList.forEach(function (homeobj) {
                                accessHomesList.push(homeobj.gatewayId);
                            });
                            final_resp = response_1.default.getUserLoginSuccessful({
                                homesList: accessHomesList,
                                clientData: {
                                    phone: userDetails.phone,
                                    phoneVerified: userDetails.phoneVerified,
                                    email: userDetails.email,
                                    emailVerified: userDetails.emailVerified,
                                    homesList: homesList
                                }
                            });
                        }
                        break;
                    case system_constants_1.grpcValidateRequestType.gateway:
                        let gateway_id = reqData.gatewayId;
                        let gateway_key = reqData.gatewayKey;
                        let gatewayDetails = await keus_gateway_1.default.getGatewayById(gateway_id);
                        if (!gatewayDetails || gateway_key != gatewayDetails.gatewayKey) {
                            final_resp = response_1.default.getInvalidAuthKey();
                        }
                        else {
                            const user = await keus_user_1.default.getUserByPhone(system_constants_1.SystemNumber);
                            final_resp = response_1.default.getGatewayLoginSuccessful({
                                homesList: [gateway_id],
                                clientData: {
                                    phone: user.phone,
                                    phoneVerified: user.phoneVerified,
                                    email: user.email,
                                    emailVerified: user.emailVerified,
                                    homesList: user.homesList
                                }
                            });
                        }
                        break;
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.TypeValidationError:
                        final_resp = response_1.default.getValidationError();
                        break;
                    default:
                        console.log('user device auth error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(response.send(final_resp));
        });
    });
});
//# sourceMappingURL=index.js.map