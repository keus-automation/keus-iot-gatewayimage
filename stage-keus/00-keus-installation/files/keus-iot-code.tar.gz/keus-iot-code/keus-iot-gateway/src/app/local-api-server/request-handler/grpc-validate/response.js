"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorCodes = {
    LoginSuccessful: 800,
    InvalidAuthKeys: 801,
    ValidityExpired: 802,
    GatewayNotConfigured: 803,
    GetInternalServerError: 850,
    ValidationError: 851
    //hub not configured
    //service user doesnt have access
    //invalid service password- completed
    //success send with device key and secret key
};
class ResponseClass {
    static getUserLoginSuccessful(data) {
        return {
            success: true,
            code: ErrorCodes.LoginSuccessful,
            message: 'Validated',
            accessServices: data.homesList,
            clientMetadata: data.clientData
        };
    }
    static getGatewayLoginSuccessful(data) {
        return {
            success: true,
            code: ErrorCodes.LoginSuccessful,
            message: 'Validated',
            accessServices: data.homesList,
            clientMetadata: data.clientData
        };
    }
    static getInvalidAuthKey() {
        return {
            success: false,
            code: ErrorCodes.InvalidAuthKeys,
            message: 'invalid auth keys'
        };
    }
    static getValidityExpired() {
        return {
            success: false,
            code: ErrorCodes.ValidityExpired,
            message: 'validity expired'
        };
    }
    static getValidationError() {
        return {
            success: false,
            code: ErrorCodes.ValidationError,
            message: 'Validation error'
        };
    }
    static getInternalServerError() {
        return {
            success: false,
            code: ErrorCodes.GetInternalServerError,
            message: 'internal server error'
        };
    }
}
exports.default = ResponseClass;
//# sourceMappingURL=response.js.map