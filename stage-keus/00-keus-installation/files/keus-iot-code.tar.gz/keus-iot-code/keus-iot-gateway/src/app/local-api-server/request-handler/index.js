"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ping_api_1 = require("./ping-api");
const grpc_validate_1 = require("./grpc-validate");
const get_gateway_status_1 = require("./get-gateway-status");
let apiArray = [];
exports.apiArray = apiArray;
apiArray.push(ping_api_1.pingApi);
apiArray.push(get_gateway_status_1.getGatewayStatus);
apiArray.push(grpc_validate_1.grpcValidate);
//# sourceMappingURL=index.js.map