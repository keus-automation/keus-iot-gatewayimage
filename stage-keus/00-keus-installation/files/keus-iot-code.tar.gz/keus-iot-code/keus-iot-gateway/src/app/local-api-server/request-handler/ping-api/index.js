"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express = __importStar(require("express"));
const router = express.Router();
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../utilities/timed-promise");
const errors_1 = require("../../../../errors/errors");
const keus_gateway_1 = __importDefault(require("../../../../models/database-models/keus-gateway"));
exports.pingApi = router.get('/ping', async function (request, response) {
    return timed_promise_1.TPromise(function () {
        return new Promise(async (resolve, reject) => {
            //   var queryData = url.parse(request.url, true).query;
            console.log('came to ping', request.body);
            let final_resp;
            try {
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                let pingStatus;
                if (gatewayDetails.length) {
                    pingStatus = {
                        gatewayId: gatewayDetails[0].gatewayId,
                        gatewayMode: gatewayDetails[0].gatewayMode
                    };
                }
                else {
                    pingStatus = {
                        gatewayId: '',
                        gatewayMode: ''
                    };
                }
                final_resp = response_1.default.getPingSuccessful(pingStatus);
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.TypeValidationError:
                        final_resp = response_1.default.getValidationError();
                        break;
                    default:
                        console.log('get gateway status error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(response.send(final_resp));
        });
    });
});
//# sourceMappingURL=index.js.map