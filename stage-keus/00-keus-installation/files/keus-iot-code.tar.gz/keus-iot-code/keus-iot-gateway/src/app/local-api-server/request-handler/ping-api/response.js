"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorCodes = {
    GetPingSuccess: 800,
    GetInternalServerError: 850,
    ValidationError: 851
};
class ResponseClass {
    static getPingSuccessful(data) {
        return {
            success: true,
            code: ErrorCodes.GetPingSuccess,
            message: 'fetch hub successful',
            data: data
        };
    }
    static getValidationError() {
        return {
            success: false,
            code: ErrorCodes.ValidationError,
            message: 'Validation error'
        };
    }
    static getInternalServerError() {
        return {
            success: false,
            code: ErrorCodes.GetInternalServerError,
            message: 'internal server error',
        };
    }
}
exports.default = ResponseClass;
//# sourceMappingURL=response.js.map