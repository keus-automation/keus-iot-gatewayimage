"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorCodes = {
    getRegisterGatewayCloud: 800,
    ConfiguredWithoutcloudConnectionError: 803,
    GatewayWronglyConfigured: 802,
    GetInternalServerError: 850,
    ValidationError: 851,
    GatewayAlreadyRegistered: 805,
    InvalidGayewayData: 806,
    CloudApiError: 804
};
class ResponseClass {
    static getRegisterGatewayCloudSuccessful() {
        return {
            success: true,
            code: ErrorCodes.getRegisterGatewayCloud,
            message: 'gateway cloud registration successful',
        };
    }
    static GatewayAlreadyUsedInCloud() {
        return {
            success: false,
            code: ErrorCodes.GatewayWronglyConfigured,
            message: 'gateway already in use please use new gateway details',
        };
    }
    static getGatewayCloudConnectionError() {
        return {
            success: false,
            code: ErrorCodes.ConfiguredWithoutcloudConnectionError,
            message: 'gateway configured successful cloud connection error',
        };
    }
    static getCloudAPiError(e) {
        return {
            success: false,
            code: ErrorCodes.CloudApiError,
            message: 'Cloud Api Error' + e,
        };
    }
    static getGatewayAlreadyRegistered() {
        return {
            success: true,
            code: ErrorCodes.GatewayAlreadyRegistered,
            message: 'Gateway Already registered',
        };
    }
    static getInvalidGatewayData() {
        return {
            success: false,
            code: ErrorCodes.InvalidGayewayData,
            message: 'InvalidGatewayData'
        };
    }
    static getValidationError() {
        return {
            success: false,
            code: ErrorCodes.ValidationError,
            message: 'Validation error'
        };
    }
    static getInternalServerError() {
        return {
            success: false,
            code: ErrorCodes.GetInternalServerError,
            message: 'internal server error',
        };
    }
}
exports.default = ResponseClass;
//# sourceMappingURL=response.js.map