"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express = __importStar(require("express"));
const router = express.Router();
const request_1 = require("./request");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../utilities/timed-promise");
const errors_1 = require("../../../../errors/errors");
const general_1 = require("../../../../utilities/general");
const ApiUtils = __importStar(require("../../../../utilities/gateway/api-utils"));
const SystemConstants = __importStar(require("../../../../constants/gateway/system-constants"));
exports.registerOtp = router.post('/requestotp', async function (request, response) {
    return timed_promise_1.TPromise(function () {
        return new Promise(async (resolve, reject) => {
            let final_resp;
            try {
                let reqData = await general_1.verifyRequest(request.body, request_1.RequestOtpType);
                try {
                    let registerGatewayToCloudResp = await ApiUtils.makePostRequest(SystemConstants.cloudApiUrl + SystemConstants.cloudEndPointRequestOtp, {
                        phone: reqData.phone
                    });
                    if (registerGatewayToCloudResp.success) {
                        final_resp = response_1.default.getRequestOtpSuccess();
                    }
                    else {
                        final_resp = response_1.default.getOtpError(registerGatewayToCloudResp.message);
                    }
                }
                catch (e) {
                    final_resp = response_1.default.getHubNotOnline();
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.TypeValidationError:
                        final_resp = response_1.default.getValidationError();
                        break;
                    default:
                        console.log('get gateway status error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(response.send(final_resp));
        });
    });
});
//# sourceMappingURL=index.js.map