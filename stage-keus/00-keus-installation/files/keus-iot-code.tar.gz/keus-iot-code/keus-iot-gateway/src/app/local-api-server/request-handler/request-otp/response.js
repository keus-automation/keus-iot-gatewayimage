"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorCodes = {
    RequestOtpSuccess: 800,
    InternetConnectionIssue: 801,
    otpError: 802,
    GetInternalServerError: 850,
    ValidationError: 851,
};
class ResponseClass {
    static getRequestOtpSuccess() {
        return {
            success: true,
            code: ErrorCodes.RequestOtpSuccess,
            message: 'Otp sent Successful'
        };
    }
    static getOtpError(e) {
        return {
            success: false,
            code: ErrorCodes.otpError,
            message: 'this is otp error ' + e,
        };
    }
    static getHubNotOnline() {
        return {
            success: false,
            code: ErrorCodes.InternetConnectionIssue,
            message: 'Unable to request otp hub not online',
        };
    }
    static getValidationError() {
        return {
            success: false,
            code: ErrorCodes.ValidationError,
            message: 'Validation error'
        };
    }
    static getInternalServerError() {
        return {
            success: false,
            code: ErrorCodes.GetInternalServerError,
            message: 'internal server error',
        };
    }
}
exports.default = ResponseClass;
//# sourceMappingURL=response.js.map