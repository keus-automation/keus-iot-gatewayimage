"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express = __importStar(require("express"));
const router = express.Router();
const request_1 = require("./request");
const response_1 = __importDefault(require("./response"));
const timed_promise_1 = require("../../../../utilities/timed-promise");
const errors_1 = require("../../../../errors/errors");
const general_1 = require("../../../../utilities/general");
const keus_gateway_1 = __importDefault(require("../../../../models/database-models/keus-gateway"));
const home_utils_1 = require("../../../../utilities/gateway/home-utils");
const keus_user_1 = __importDefault(require("../../../../models/database-models/keus-user"));
const keus_userdevice_1 = __importDefault(require("../../../../models/database-models/keus-userdevice"));
exports.ServiceLogin = router.post('/servicelogin', async function (request, response) {
    return timed_promise_1.TPromise(function () {
        return new Promise(async (resolve, reject) => {
            let final_resp;
            try {
                let reqData = await general_1.verifyRequest(request.body, request_1.ServiceLoginType);
                let gatewayDetails = await keus_gateway_1.default.getGateway();
                if (!gatewayDetails.length) {
                    final_resp = response_1.default.getGatewayNotConfigured();
                }
                let seed = gatewayDetails[0].seed;
                let serviceUser = await home_utils_1.decryptStringWithSeed(reqData.serviceUser, seed);
                let serviceUserPassword = await home_utils_1.decryptStringWithSeed(reqData.serviceUserPassword, seed);
                if (gatewayDetails[0].serviceUser != serviceUser) {
                    final_resp = response_1.default.getServiceUserDoesntHaveAccess();
                }
                if (gatewayDetails[0].serviceUserPassword != serviceUserPassword) {
                    final_resp = response_1.default.getInvalidServiceUserPassword();
                }
                else {
                    let user = await keus_user_1.default.getUserByPhone(serviceUser);
                    if (!user) {
                        let userObj = {
                            phone: serviceUser,
                            email: serviceUserPassword,
                            emailVerified: true,
                            phoneVerified: true,
                            userName: 'demo user',
                            location: 'ops office',
                            lastUpdatedTime: Date.now(),
                            gender: 'any',
                            dateOfBirth: Date.now(),
                            homesList: JSON.stringify([{ gatewayId: gatewayDetails[0].gatewayId, accessLevel: 3, roomsList: [] }]),
                            favoriteHome: gatewayDetails[0].gatewayId
                        };
                        await keus_user_1.default.insertUser(userObj);
                    }
                    ;
                    let userDeviceDetails = await keus_userdevice_1.default.authenticateUserDevice({ deviceId: reqData.deviceId, deviceName: reqData.deviceName, phone: serviceUser, remember: false, deviceType: reqData.deviceType });
                    final_resp = response_1.default.getServiceLoginSuccess({ deviceKey: userDeviceDetails.deviceKey, secretKey: userDeviceDetails.secretKey });
                }
            }
            catch (e) {
                switch (e.constructor) {
                    case errors_1.GeneralErrors.TypeValidationError:
                        final_resp = response_1.default.getValidationError();
                        break;
                    default:
                        console.log('service login error', e);
                        final_resp = response_1.default.getInternalServerError();
                        break;
                }
            }
            resolve(response.send(final_resp));
        });
    });
});
//# sourceMappingURL=index.js.map