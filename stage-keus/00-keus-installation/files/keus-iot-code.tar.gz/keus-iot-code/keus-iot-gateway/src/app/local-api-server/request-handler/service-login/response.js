"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorCodes = {
    ServiceLoginSuccess: 800,
    ServiceUserDoesntHaveAccess: 801,
    InvalidServicePassword: 802,
    GatewayNotConfigured: 803,
    GetInternalServerError: 850,
    ValidationError: 851,
};
class ResponseClass {
    static getServiceLoginSuccess(data) {
        return {
            success: true,
            code: ErrorCodes.ServiceLoginSuccess,
            message: 'Service Login Success',
            data: data
        };
    }
    static getServiceUserDoesntHaveAccess() {
        return {
            success: false,
            code: ErrorCodes.ServiceUserDoesntHaveAccess,
            message: 'Service User Doesnt have access',
        };
    }
    static getInvalidServiceUserPassword() {
        return {
            success: false,
            code: ErrorCodes.InvalidServicePassword,
            message: 'Invalid Service User Password',
        };
    }
    static getGatewayNotConfigured() {
        return {
            success: false,
            code: ErrorCodes.GatewayNotConfigured,
            message: 'Gate way not configured'
        };
    }
    static getValidationError() {
        return {
            success: false,
            code: ErrorCodes.ValidationError,
            message: 'Validation error'
        };
    }
    static getInternalServerError() {
        return {
            success: false,
            code: ErrorCodes.GetInternalServerError,
            message: 'internal server error',
        };
    }
}
exports.default = ResponseClass;
//# sourceMappingURL=response.js.map