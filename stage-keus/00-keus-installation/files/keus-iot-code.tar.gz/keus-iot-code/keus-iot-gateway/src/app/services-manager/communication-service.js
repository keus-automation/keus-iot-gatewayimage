"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("../../services/communication-service/index");
const communication_service_1 = __importDefault(require("../../configs/communication-service"));
console.log(communication_service_1.default, index_1.CommunicationServer);
const communicationServiceInstance = new index_1.CommunicationServer({
    host: communication_service_1.default.serverBindIP,
    port: communication_service_1.default.port,
    configs: {
        authAPILink: communication_service_1.default.localAuthAPILink,
        servicePassword: communication_service_1.default.servicePassword
    }
});
communicationServiceInstance.start();
//# sourceMappingURL=communication-service.js.map