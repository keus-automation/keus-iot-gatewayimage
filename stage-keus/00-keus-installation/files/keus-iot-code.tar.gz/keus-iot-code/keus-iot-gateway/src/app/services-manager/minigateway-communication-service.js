"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("../../services/communication-service/index");
const multigateway_1 = __importDefault(require("../../configs/multigateway"));
const system_constants_1 = require("../../constants/gateway/system-constants");
const communicationServiceInstance = new index_1.CommunicationServer({
    host: multigateway_1.default.minigateway.communicationService.host,
    port: multigateway_1.default.minigateway.communicationService.port,
    configs: {
        servicePassword: multigateway_1.default.minigateway.communicationService.servicePassword,
        customAuthValidator: async function (validationData) {
            try {
                let validationDataJSON = JSON.parse(validationData.getJsonBody());
                console.log('VALIDATING THE REQUEST HERE', validationData.getJsonBody());
                if (validationDataJSON.type === system_constants_1.MultiGateway.GatewayMode.MINI_GATEWAY) {
                    if (system_constants_1.MultiGateway.MinigatewayAuthKeys.username === validationDataJSON.username &&
                        system_constants_1.MultiGateway.MinigatewayAuthKeys.password === validationDataJSON.password) {
                        console.log('this is auth', validationDataJSON);
                        return {
                            code: 200,
                            success: true,
                            message: 'authenticated user',
                            accessServices: [''],
                            clientMetadata: {
                                localgateway: true,
                                master: true
                            }
                        };
                    }
                }
                else {
                    return {
                        code: 400,
                        success: false,
                        message: 'failed authenticated user',
                        accessServices: [''],
                        clientMetadata: {
                            localgateway: true,
                            master: true
                        }
                    };
                }
            }
            catch (error) {
                console.log('THIS IS THE AUTHENTICATION ERROR', error);
                throw error;
            }
        }
    }
});
communicationServiceInstance.start();
//# sourceMappingURL=minigateway-communication-service.js.map