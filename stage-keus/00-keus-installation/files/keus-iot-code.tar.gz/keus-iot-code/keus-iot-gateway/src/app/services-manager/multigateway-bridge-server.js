"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const server_1 = __importDefault(require("../../services/tcp-bridge-service/server"));
const multigateway_1 = __importDefault(require("../../configs/multigateway"));
const database_service_1 = __importDefault(require("../../services/database-service"));
const database_service_2 = __importDefault(require("../../configs/database-service"));
const keus_gateway_1 = __importDefault(require("../../models/database-models/keus-gateway"));
const system_constants_1 = require("../../constants/gateway/system-constants");
(async () => {
    await database_service_1.default.getInstance().connect(database_service_2.default);
    const tcpBridgeServer = new server_1.default(multigateway_1.default.proxyServer.bindIp, multigateway_1.default.proxyServer.port, (authData) => {
        return new Promise(async (resolve, reject) => {
            try {
                let authDataStr = authData.toString();
                let authDataJSON = JSON.parse(authDataStr);
                // authDataJSON
                console.log('this is auth Data', authDataJSON);
                let gatewayList = await keus_gateway_1.default.getGatewaysByMode(system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY);
                if (!gatewayList.length) {
                    throw new Error('Gateway Not Registered');
                }
                let mainGateway = gatewayList[0];
                let miniGateways = mainGateway.miniGateways;
                console.log('minigateways', miniGateways);
                if (authDataJSON.gatewayId === mainGateway.gatewayId &&
                    authDataJSON.gatewayKey === mainGateway.gatewayKey) {
                    let miniGatewayExists = miniGateways.findIndex((miniGateway) => {
                        return miniGateway.gatewayId === authDataJSON.miniGatewayId;
                    });
                    if (miniGatewayExists < 0) {
                        throw new Error('Invalid mini gateway id');
                    }
                }
                resolve({
                    role: authDataJSON.role,
                    pairKey: authDataJSON.miniGatewayId
                });
            }
            catch (err) {
                console.log('auth error', err);
                reject(err);
            }
        });
    });
    tcpBridgeServer.start();
})();
//# sourceMappingURL=multigateway-bridge-server.js.map