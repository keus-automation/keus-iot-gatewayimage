"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const env = process.env.NODE_ENV || 'production';
const USE_TCP_MDNS = process.env.USE_TCP_MDNS === 'true' ? true : false;
const communicationConfig = new Map();
communicationConfig.set('development', {
    serverBindIP: '0.0.0.0',
    host: 'KIOTG_communication_service',
    localAuthAPILink: 'http://KIOTG_hub_app:3500/localgrpcvalidate',
    port: 8989,
    servicePassword: 'LocalService',
    cloud_host: 'kiot-apis.keus.in',
    // cloud_host: 'KIOTC_cloud_broker',
    // cloud_host: 'kiot-voice.keus.in',
    cloud_port: 6020,
    mdns: {
        useTcp: true,
        serverHost: '0.0.0.0',
        serverPort: 5656
    }
});
communicationConfig.set('production', {
    serverBindIP: '0.0.0.0',
    host: 'localhost',
    port: 8989,
    cloud_host: 'kiot-apis.keus.in',
    // cloud_host: 'kiot-voice.keus.in',
    // cloud_host: 'KIOTC_cloud_broker',
    cloud_port: 6020,
    localAuthAPILink: 'http://localhost:3500/localgrpcvalidate',
    servicePassword: 'LocalService',
    mdns: {
        useTcp: true,
        serverHost: '0.0.0.0',
        serverPort: 5656
    }
});
const config = communicationConfig.get(env);
exports.default = config;
//# sourceMappingURL=communication-service.js.map