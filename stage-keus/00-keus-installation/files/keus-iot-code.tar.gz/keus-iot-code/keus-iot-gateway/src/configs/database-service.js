"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const env = process.env.NODE_ENV || 'production';
const databaseConfig = new Map();
databaseConfig.set('development', {
    serverBindIP: '0.0.0.0',
    host: 'KIOTG_mongo_server',
    port: 27017
});
databaseConfig.set('production', {
    serverBindIP: '0.0.0.0',
    host: '0.0.0.0',
    port: 27017
});
exports.default = databaseConfig.get(env);
//# sourceMappingURL=database-service.js.map