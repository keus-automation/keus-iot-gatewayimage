"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const env = process.env.NODE_ENV || 'production';
const modeFilePath = process.env.MODE_FILE_PATH;
const debugTcpPipeHost = process.env.DEBUG_TCP_PIPE_HOST;
const debugTcpPipePort = parseInt(process.env.DEBUG_TCP_PIPE_PORT);
const multigatewayConfig = new Map();
multigatewayConfig.set('development', {
    modeFilePath: modeFilePath ? modeFilePath : '/keus-iot-gateway/development/storage/database/multigatewaymode.json',
    irFilesPath: '/keus-iot-gateway/development/storage/ir-remotes/',
    irFilesExt: 'ts',
    proxyServer: {
        port: 8686,
        bindIp: '0.0.0.0',
        host: 'KIOTG_tcp_bridge_server'
    },
    minigateway: {
        communicationService: {
            host: 'KIOTG_communication_service_minigateway',
            port: 8090,
            servicePassword: 'MinigatewayLocal'
        },
        debugTCPPipe: {
            host: debugTcpPipeHost,
            port: debugTcpPipePort
        }
    }
});
multigatewayConfig.set('production', {
    modeFilePath: modeFilePath ? modeFilePath : '/opt/keus-iot-code/storage/multigatewaymode.json',
    irFilesPath: '/opt/keus-iot-code/keus-iot-gateway/src/remote_files/',
    irFilesExt: 'js',
    proxyServer: {
        port: 8686,
        bindIp: '0.0.0.0',
        host: '0.0.0.0'
    },
    minigateway: {
        communicationService: {
            host: '0.0.0.0',
            port: 8989,
            servicePassword: 'MinigatewayLocal'
        }
    }
});
console.log(multigatewayConfig.get(env));
exports.default = multigatewayConfig.get(env);
//# sourceMappingURL=multigateway.js.map