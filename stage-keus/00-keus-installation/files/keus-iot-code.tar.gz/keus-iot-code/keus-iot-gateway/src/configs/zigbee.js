"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../constants/gateway/system-constants");
const env = process.env.NODE_ENV || 'production';
const MOCK_ZC = process.env.MOCK_ZC === 'true' ? true : false;
const DEPLOYMENT_DEVICE = process.env.DEPLOYMENT_DEVICE;
const ALLOWED_DEVICES = process.env.ALLOWED_DEVICES;
const ZIGBEE_CHANNEL = parseInt(process.env.ZIGBEE_CHANNEL);
let allowedDevices = [];
let deploymentDevice = system_constants_1.DeploymentEnvironment.DESKTOP;
console.log(' Allowed devices ', ALLOWED_DEVICES);
try {
    allowedDevices = JSON.parse(ALLOWED_DEVICES);
    deploymentDevice = parseInt(DEPLOYMENT_DEVICE);
}
catch (err) {
    console.log('allowedDevices have not been defined', err);
}
const zigbeeConfig = new Map();
zigbeeConfig.set('development', (zigbeeConfigParams) => {
    return {
        controllerOptions: {
            network: {
                channelList: [zigbeeConfigParams.channel],
                panID: 0xFFFF
            },
            serialPort: {
                baudRate: 115200,
                rtscts: false,
                path: zigbeeConfigParams.serialPath,
                adapter: 'zstack',
                socketOptions: zigbeeConfigParams.socketOptions
            },
            databasePath: `/keus-iot-gateway/development/storage/database/${zigbeeConfigParams.uniqueId}zigbee.db`,
            databaseBackupPath: `/keus-iot-gateway/development/storage/database/${zigbeeConfigParams.uniqueId}zigbee_bck.db`,
            backupPath: `/keus-iot-gateway/development/storage/database/${zigbeeConfigParams.uniqueId}zigbee_gen_bck.db`,
            adapter: {
                concurrent: 16,
                disableLED: true
            },
            acceptJoiningDeviceHandler: (ieeeAddr) => {
                console.log('This is acceptJoiningDeviceHandler', ieeeAddr, allowedDevices);
                return new Promise((resolve) => {
                    if (allowedDevices.length === 0) {
                        resolve(true);
                    }
                    else {
                        if (allowedDevices.indexOf(ieeeAddr) >= 0) {
                            resolve(true);
                        }
                        else {
                            resolve(false);
                        }
                    }
                });
            },
            instanceUniqueKey: zigbeeConfigParams.uniqueId
        },
        uniqueId: zigbeeConfigParams.uniqueId,
        getTcpAuthData: zigbeeConfigParams.getTcpAuthData,
        zigbeeInfoFile: `/keus-iot-gateway/development/storage/database/${zigbeeConfigParams.uniqueId}zigbee_info.json`,
        mockZC: MOCK_ZC
    };
});
zigbeeConfig.set('production', (zigbeeConfigParams) => {
    return {
        controllerOptions: {
            network: {
                channelList: [zigbeeConfigParams.channel],
                panID: 0xFFFF
            },
            serialPort: {
                baudRate: 115200,
                rtscts: false,
                path: zigbeeConfigParams.serialPath,
                adapter: 'zstack',
                socketOptions: zigbeeConfigParams.socketOptions
            },
            databasePath: `/opt/keus-iot-code/storage/${zigbeeConfigParams.uniqueId}zigbee.db`,
            databaseBackupPath: `/opt/keus-iot-code/storage/${zigbeeConfigParams.uniqueId}zigbee_bck.db`,
            backupPath: `/opt/keus-iot-code/storage/${zigbeeConfigParams.uniqueId}zigbee_gen_bck.db`,
            adapter: {
                concurrent: 16,
                disableLED: true
            },
            acceptJoiningDeviceHandler: (ieeeAddr) => { return new Promise((resolve) => { resolve(true); }); },
            instanceUniqueKey: zigbeeConfigParams.uniqueId
        },
        uniqueId: zigbeeConfigParams.uniqueId,
        getTcpAuthData: zigbeeConfigParams.getTcpAuthData,
        zigbeeInfoFile: `/opt/keus-iot-code/storage/${zigbeeConfigParams.uniqueId}zigbee_info.json`,
        mockZC: MOCK_ZC
    };
});
exports.DEPLOYMENT_ENV = deploymentDevice;
exports.default = zigbeeConfig.get(env);
//# sourceMappingURL=zigbee.js.map