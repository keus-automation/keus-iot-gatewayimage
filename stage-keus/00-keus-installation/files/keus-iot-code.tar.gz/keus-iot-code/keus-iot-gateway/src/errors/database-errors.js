"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class DatabaseError extends Error {
    constructor() {
        const msg = 'Database error';
        super(msg);
        Object.setPrototypeOf(this, DatabaseError.prototype);
        this.name = 'DatabaseError';
    }
}
exports.DatabaseError = DatabaseError;
class DatabaseConnectionError extends Error {
    constructor() {
        const msg = 'Database connection error';
        super(msg);
        Object.setPrototypeOf(this, DatabaseConnectionError.prototype);
        this.name = 'DatabaseConnectionError';
    }
}
exports.DatabaseConnectionError = DatabaseConnectionError;
class DuplicateIdForRecordError extends Error {
    constructor() {
        const msg = 'Duplicate id for record';
        super(msg);
        Object.setPrototypeOf(this, DuplicateIdForRecordError.prototype);
        this.name = 'DuplicateIdForRecordError';
    }
}
exports.DuplicateIdForRecordError = DuplicateIdForRecordError;
exports.DatabaseErrorCodes = {
    DuplicateId: 11000
};
//# sourceMappingURL=database-errors.js.map