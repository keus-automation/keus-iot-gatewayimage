"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class DeviceAlreadyRegistered extends Error {
    constructor() {
        const msg = 'Device already registered';
        super(msg);
        Object.setPrototypeOf(this, DeviceAlreadyRegistered.prototype);
        this.name = 'DeviceAlreadyRegistered';
    }
}
exports.DeviceAlreadyRegistered = DeviceAlreadyRegistered;
class InvalidDeviceType extends Error {
    constructor() {
        const msg = 'Invalid device type';
        super(msg);
        Object.setPrototypeOf(this, InvalidDeviceType.prototype);
        this.name = 'InvalidDeviceType';
    }
}
exports.InvalidDeviceType = InvalidDeviceType;
class InvalidDeviceId extends Error {
    constructor() {
        const msg = 'Invalid device id';
        super(msg);
        Object.setPrototypeOf(this, InvalidDeviceId.prototype);
        this.name = 'InvalidDeviceId';
    }
}
exports.InvalidDeviceId = InvalidDeviceId;
class InvalidDeviceState extends Error {
    constructor() {
        const msg = 'Invalid device state';
        super(msg);
        Object.setPrototypeOf(this, InvalidDeviceState.prototype);
        this.name = 'InvalidDeviceState';
    }
}
exports.InvalidDeviceState = InvalidDeviceState;
class DeviceNotInSameArea extends Error {
    constructor() {
        const msg = 'Device not in same Area';
        super(msg);
        Object.setPrototypeOf(this, DeviceNotInSameArea.prototype);
        this.name = 'DeviceNotInSameArea';
    }
}
exports.DeviceNotInSameArea = DeviceNotInSameArea;
class DeviceZigbeeError extends Error {
    constructor(msg, code) {
        super(msg);
        Object.setPrototypeOf(this, DeviceZigbeeError.prototype);
        this.name = 'DeviceZigbeeError';
        this.code = code;
    }
}
exports.DeviceZigbeeError = DeviceZigbeeError;
class InvalidRelayId extends Error {
    constructor() {
        const msg = 'Invalid Relay Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidRelayId.prototype);
        this.name = 'InvalidRelayId';
    }
}
exports.InvalidRelayId = InvalidRelayId;
class InvalidButtonId extends Error {
    constructor() {
        const msg = 'Invalid Button Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidButtonId.prototype);
        this.name = 'InvalidButtonId';
    }
}
exports.InvalidButtonId = InvalidButtonId;
class InvalidSwitchId extends Error {
    constructor() {
        const msg = 'Invalid Switch Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidSwitchId.prototype);
        this.name = 'InvalidSwitchId';
    }
}
exports.InvalidSwitchId = InvalidSwitchId;
class InvalidButtonType extends Error {
    constructor() {
        const msg = 'Invalid Button Type';
        super(msg);
        Object.setPrototypeOf(this, InvalidButtonType.prototype);
        this.name = 'InvalidButtonType';
    }
}
exports.InvalidButtonType = InvalidButtonType;
class CurtainCountExceeded extends Error {
    constructor() {
        const msg = 'Curtain Count Exceeded';
        super(msg);
        Object.setPrototypeOf(this, CurtainCountExceeded.prototype);
        this.name = 'CurtainCountExceeded';
    }
}
exports.CurtainCountExceeded = CurtainCountExceeded;
class RelayCannotBeHighLoad extends Error {
    constructor() {
        const msg = 'Relay Cannot Be High Load';
        super(msg);
        Object.setPrototypeOf(this, RelayCannotBeHighLoad.prototype);
        this.name = 'RelayCannotBeHighLoad';
    }
}
exports.RelayCannotBeHighLoad = RelayCannotBeHighLoad;
class RelayNotBound extends Error {
    constructor() {
        const msg = 'Relay Not Bound';
        super(msg);
        Object.setPrototypeOf(this, RelayNotBound.prototype);
        this.name = 'RelayNotBound';
    }
}
exports.RelayNotBound = RelayNotBound;
class InvalidRemoteId extends Error {
    constructor() {
        const msg = 'Invalid device id';
        super(msg);
        Object.setPrototypeOf(this, InvalidDeviceId.prototype);
        this.name = 'InvalidDeviceId';
    }
}
exports.InvalidRemoteId = InvalidRemoteId;
class InvalidRemoteType extends Error {
    constructor() {
        const msg = 'Invalid device type';
        super(msg);
        Object.setPrototypeOf(this, InvalidDeviceId.prototype);
        this.name = 'InvalidDeviceType';
    }
}
exports.InvalidRemoteType = InvalidRemoteType;
class RemoteCreationFailed extends Error {
    constructor() {
        const msg = 'Remote Creation Failed';
        super(msg);
        Object.setPrototypeOf(this, InvalidDeviceId.prototype);
        this.name = 'RemoteCreationFailed';
    }
}
exports.RemoteCreationFailed = RemoteCreationFailed;
class PortsNotAvailable extends Error {
    constructor() {
        const msg = 'Ports Not Available';
        super(msg);
        Object.setPrototypeOf(this, PortsNotAvailable.prototype);
        this.name = 'PortsNotAvailable';
    }
}
exports.PortsNotAvailable = PortsNotAvailable;
class InvalidApplianceId extends Error {
    constructor() {
        const msg = 'Invalid Appliance Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidApplianceId.prototype);
        this.name = 'InvalidApplianceId';
    }
}
exports.InvalidApplianceId = InvalidApplianceId;
class InvalidPortId extends Error {
    constructor() {
        const msg = 'Invalid Port Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidPortId.prototype);
        this.name = 'InvalidPortId';
    }
}
exports.InvalidPortId = InvalidPortId;
exports.DeviceManagerErrorCodes = {
    RetryImmediately: 901,
    RetryAfterFewSeconds: 902,
    DontRetry: 903
};
//# sourceMappingURL=device-errors.js.map