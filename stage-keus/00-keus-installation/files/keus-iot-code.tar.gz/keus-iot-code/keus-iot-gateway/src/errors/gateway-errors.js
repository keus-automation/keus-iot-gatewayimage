"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class MainGatewayNotConfigured extends Error {
    constructor() {
        const msg = 'Main Gateway Not Configured';
        super(msg);
        Object.setPrototypeOf(this, MainGatewayNotConfigured.prototype);
        this.name = 'MainGatewayNotConfigured';
    }
}
exports.MainGatewayNotConfigured = MainGatewayNotConfigured;
class DevicesExistOnGateway extends Error {
    constructor() {
        const msg = 'Devices Exist On Gateway';
        super(msg);
        Object.setPrototypeOf(this, DevicesExistOnGateway.prototype);
        this.name = 'DevicesExistOnGateway';
    }
}
exports.DevicesExistOnGateway = DevicesExistOnGateway;
class InvalidMiniGatewayId extends Error {
    constructor() {
        const msg = 'Invalid Mini Gateway Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidMiniGatewayId.prototype);
        this.name = 'InvalidMiniGatewayId';
    }
}
exports.InvalidMiniGatewayId = InvalidMiniGatewayId;
//# sourceMappingURL=gateway-errors.js.map