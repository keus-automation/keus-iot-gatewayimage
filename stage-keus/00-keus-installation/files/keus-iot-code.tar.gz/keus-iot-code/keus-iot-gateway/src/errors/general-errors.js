"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class InternalServerError extends Error {
    constructor() {
        const msg = 'Internal server error';
        super(msg);
        Object.setPrototypeOf(this, InternalServerError.prototype);
        this.name = 'InternalServerError';
    }
}
exports.InternalServerError = InternalServerError;
class CloudClientConnectionError extends Error {
    constructor() {
        const msg = 'Cloud client connection error';
        super(msg);
        Object.setPrototypeOf(this, CloudClientConnectionError.prototype);
        this.name = 'CloudClientConnectionError';
    }
}
exports.CloudClientConnectionError = CloudClientConnectionError;
class InvalidParameterSet extends Error {
    constructor() {
        const msg = 'Invalid Parameter Set';
        super(msg);
        Object.setPrototypeOf(this, InvalidParameterSet.prototype);
        this.name = 'InvalidParameterSet';
    }
}
exports.InvalidParameterSet = InvalidParameterSet;
class InvalidRequestId extends Error {
    constructor() {
        const msg = 'Invalid Request Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidRequestId.prototype);
        this.name = 'InvalidRequestId';
    }
}
exports.InvalidRequestId = InvalidRequestId;
class OperationsNotAllowed extends Error {
    constructor() {
        const msg = 'Operations not allowed';
        super(msg);
        Object.setPrototypeOf(this, OperationsNotAllowed.prototype);
        this.name = 'OperationsNotAllowed';
    }
}
exports.OperationsNotAllowed = OperationsNotAllowed;
class TypeValidationError extends Error {
    constructor(msg) {
        msg = 'Type Validation Error: \n' + msg;
        super(msg);
        Object.setPrototypeOf(this, TypeValidationError.prototype);
        this.name = 'TypeValidationError';
    }
}
exports.TypeValidationError = TypeValidationError;
class RpcMakerError extends Error {
    constructor(msg) {
        msg = 'Rpc Maker Error: \n' + msg;
        super(msg);
        Object.setPrototypeOf(this, RpcMakerError.prototype);
        this.name = 'RpcMakerError';
    }
}
exports.RpcMakerError = RpcMakerError;
class RpcResponseFalseError extends Error {
    constructor(msg) {
        msg = msg;
        super(msg);
        Object.setPrototypeOf(this, RpcMakerError.prototype);
        this.name = 'RpcResponseFalseError';
    }
}
exports.RpcResponseFalseError = RpcResponseFalseError;
class UserNotAdminError extends Error {
    constructor() {
        const msg = 'Restricted for only Admin';
        super(msg);
        Object.setPrototypeOf(this, UserNotAdminError.prototype);
        this.name = 'User Not Admin Error';
    }
}
exports.UserNotAdminError = UserNotAdminError;
class InvalidUserAccessError extends Error {
    constructor() {
        const msg = 'Insufficient permissions';
        super(msg);
        Object.setPrototypeOf(this, InvalidUserAccessError.prototype);
        this.name = 'Invalid Access Error';
    }
}
exports.InvalidUserAccessError = InvalidUserAccessError;
//# sourceMappingURL=general-errors.js.map