"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class InvalidGroupId extends Error {
    constructor() {
        const msg = 'Invalid Group Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidGroupId.prototype);
        this.name = 'InvalidGroupId';
    }
}
exports.InvalidGroupId = InvalidGroupId;
class InvalidGroupName extends Error {
    constructor() {
        const msg = 'Invalid Group Name';
        super(msg);
        Object.setPrototypeOf(this, InvalidGroupName.prototype);
        this.name = 'InvalidGroupName';
    }
}
exports.InvalidGroupName = InvalidGroupName;
class DuplicateGroupName extends Error {
    constructor() {
        const msg = 'Duplicate Group Name';
        super(msg);
        Object.setPrototypeOf(this, DuplicateGroupName.prototype);
        this.name = 'DuplicateGroupName';
    }
}
exports.DuplicateGroupName = DuplicateGroupName;
class GroupLimitReached extends Error {
    constructor() {
        const msg = 'Group Limit Reached';
        super(msg);
        Object.setPrototypeOf(this, GroupLimitReached.prototype);
        this.name = 'GroupLimitReached';
    }
}
exports.GroupLimitReached = GroupLimitReached;
class DeviceIncompatibleWithGroup extends Error {
    constructor() {
        const msg = 'Device Incompatible With Group';
        super(msg);
        Object.setPrototypeOf(this, DeviceIncompatibleWithGroup.prototype);
        this.name = 'DeviceIncompatibleWithGroup';
    }
}
exports.DeviceIncompatibleWithGroup = DeviceIncompatibleWithGroup;
class DeviceInAnotherGroup extends Error {
    constructor() {
        const msg = 'Device In Another Group';
        super(msg);
        Object.setPrototypeOf(this, DeviceInAnotherGroup.prototype);
        this.name = 'DeviceInAnotherGroup';
    }
}
exports.DeviceInAnotherGroup = DeviceInAnotherGroup;
class InvalidPropertySet extends Error {
    constructor() {
        const msg = 'Invalid Property Set';
        super(msg);
        Object.setPrototypeOf(this, InvalidPropertySet.prototype);
        this.name = 'InvalidPropertySet';
    }
}
exports.InvalidPropertySet = InvalidPropertySet;
//# sourceMappingURL=group-errors.js.map