"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class DuplicateFloorName extends Error {
    constructor() {
        const msg = 'Duplicate Floor Name';
        super(msg);
        Object.setPrototypeOf(this, DuplicateFloorName.prototype);
        this.name = 'DuplicateFloorName';
    }
}
exports.DuplicateFloorName = DuplicateFloorName;
class MasterExistsInArea extends Error {
    constructor() {
        const msg = 'Master Exists In Area';
        super(msg);
        Object.setPrototypeOf(this, MasterExistsInArea.prototype);
        this.name = 'MasterExistsInArea';
    }
}
exports.MasterExistsInArea = MasterExistsInArea;
class InvalidRoomId extends Error {
    constructor() {
        const msg = 'Invalid Room Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidRoomId.prototype);
        this.name = 'InvalidRoomId';
    }
}
exports.InvalidRoomId = InvalidRoomId;
class InvalidAreaId extends Error {
    constructor() {
        const msg = 'Invalid Area Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidAreaId.prototype);
        this.name = 'InvalidAreaId';
    }
}
exports.InvalidAreaId = InvalidAreaId;
class InvalidSectionId extends Error {
    constructor() {
        const msg = 'Invalid Section Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidSectionId.prototype);
        this.name = 'InvalidSectionId';
    }
}
exports.InvalidSectionId = InvalidSectionId;
class GatewayAlreadyExists extends Error {
    constructor() {
        const msg = 'Gateway Already Exists';
        super(msg);
        Object.setPrototypeOf(this, GatewayAlreadyExists.prototype);
        this.name = 'GatewayAlreadyExists';
    }
}
exports.GatewayAlreadyExists = GatewayAlreadyExists;
class ParentNotInTargetArea extends Error {
    constructor() {
        const msg = 'Parent Not In Target Area';
        super(msg);
        Object.setPrototypeOf(this, ParentNotInTargetArea.prototype);
        this.name = 'ParentNotInTargetArea';
    }
}
exports.ParentNotInTargetArea = ParentNotInTargetArea;
//# sourceMappingURL=home-errors.js.map