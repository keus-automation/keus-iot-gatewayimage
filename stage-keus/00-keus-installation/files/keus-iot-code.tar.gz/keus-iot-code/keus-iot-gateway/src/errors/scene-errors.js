"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable import/prefer-default-export */
class InvalidSceneId extends Error {
    constructor() {
        const msg = 'Invalid Scene Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidSceneId.prototype);
        this.name = 'InvalidSceneId';
    }
}
exports.InvalidSceneId = InvalidSceneId;
class InvalidTimeslotId extends Error {
    constructor() {
        const msg = 'Invalid Timeslot Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidTimeslotId.prototype);
        this.name = 'InvalidTimeslotId';
    }
}
exports.InvalidTimeslotId = InvalidTimeslotId;
class InvalidActionId extends Error {
    constructor() {
        const msg = 'Invalid Action Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidActionId.prototype);
        this.name = 'InvalidActionId';
    }
}
exports.InvalidActionId = InvalidActionId;
class InvalidSceneType extends Error {
    constructor() {
        const msg = 'Invalid Scene Type';
        super(msg);
        Object.setPrototypeOf(this, InvalidSceneType.prototype);
        this.name = 'InvalidSceneType';
    }
}
exports.InvalidSceneType = InvalidSceneType;
class TimeslotIdGenerationFailed extends Error {
    constructor() {
        const msg = 'Timeslot Id Generation Failed';
        super(msg);
        Object.setPrototypeOf(this, TimeslotIdGenerationFailed.prototype);
        this.name = 'TimeslotIdGenerationFailed';
    }
}
exports.TimeslotIdGenerationFailed = TimeslotIdGenerationFailed;
class InvalidSceneName extends Error {
    constructor() {
        const msg = 'Invalid Scene Name';
        super(msg);
        Object.setPrototypeOf(this, InvalidSceneName.prototype);
        this.name = 'InvalidSceneName';
    }
}
exports.InvalidSceneName = InvalidSceneName;
class DuplicateSceneName extends Error {
    constructor() {
        const msg = 'Duplicate Scene Name';
        super(msg);
        Object.setPrototypeOf(this, DuplicateSceneName.prototype);
        this.name = 'DuplicateSceneName';
    }
}
exports.DuplicateSceneName = DuplicateSceneName;
class SceneLimitReached extends Error {
    constructor() {
        const msg = 'Scene Limit Reached';
        super(msg);
        Object.setPrototypeOf(this, SceneLimitReached.prototype);
        this.name = 'SceneLimitReached';
    }
}
exports.SceneLimitReached = SceneLimitReached;
class SceneActionLimitReached extends Error {
    constructor() {
        const msg = 'Scene Action Limit Reached';
        super(msg);
        Object.setPrototypeOf(this, SceneActionLimitReached.prototype);
        this.name = 'SceneActionLimitReached';
    }
}
exports.SceneActionLimitReached = SceneActionLimitReached;
class CannotMoveGlobalScene extends Error {
    constructor() {
        const msg = 'Cannot Move Global Scene';
        super(msg);
        Object.setPrototypeOf(this, CannotMoveGlobalScene.prototype);
        this.name = 'CannotMoveGlobalScene';
    }
}
exports.CannotMoveGlobalScene = CannotMoveGlobalScene;
class CannotMoveToDifferentArea extends Error {
    constructor() {
        const msg = 'Cannot Move To Different Area';
        super(msg);
        Object.setPrototypeOf(this, CannotMoveToDifferentArea.prototype);
        this.name = 'CannotMoveToDifferentArea';
    }
}
exports.CannotMoveToDifferentArea = CannotMoveToDifferentArea;
class SceneIsNotGlobal extends Error {
    constructor() {
        const msg = 'Scene Is Not Global';
        super(msg);
        Object.setPrototypeOf(this, SceneIsNotGlobal.prototype);
        this.name = 'SceneIsNotGlobal';
    }
}
exports.SceneIsNotGlobal = SceneIsNotGlobal;
//# sourceMappingURL=scene-errors.js.map