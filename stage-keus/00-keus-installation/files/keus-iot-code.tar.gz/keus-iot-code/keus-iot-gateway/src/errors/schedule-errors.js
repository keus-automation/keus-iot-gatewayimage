"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable import/prefer-default-export */
class InvalidScheduleId extends Error {
    constructor() {
        const msg = 'Invalid Schedule Id';
        super(msg);
        Object.setPrototypeOf(this, InvalidScheduleId.prototype);
        this.name = 'InvalidScheduleId';
    }
}
exports.InvalidScheduleId = InvalidScheduleId;
//# sourceMappingURL=schedule-errors.js.map