"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ControllerInitError extends Error {
    constructor(ErrorMsg) {
        const msg = ErrorMsg ? ErrorMsg : 'ControllerInitError';
        super(msg);
        Object.setPrototypeOf(this, ControllerInitError.prototype);
        this.name = 'ControllerInitError';
    }
}
exports.ControllerInitError = ControllerInitError;
class DaliDiscoveryError extends Error {
    constructor(ErrorMsg) {
        const msg = ErrorMsg ? ErrorMsg : 'DaliDiscoveryError';
        super(msg);
        Object.setPrototypeOf(this, DaliDiscoveryError.prototype);
        this.name = 'DaliDiscoveryError';
    }
}
exports.DaliDiscoveryError = DaliDiscoveryError;
class AreaGenerationError extends Error {
    constructor(ErrorMsg) {
        const msg = ErrorMsg ? ErrorMsg : 'AreaGenerationError';
        super(msg);
        Object.setPrototypeOf(this, AreaGenerationError.prototype);
        this.name = 'AreaGenerationError';
    }
}
exports.AreaGenerationError = AreaGenerationError;
//# sourceMappingURL=zigbee-errors.js.map