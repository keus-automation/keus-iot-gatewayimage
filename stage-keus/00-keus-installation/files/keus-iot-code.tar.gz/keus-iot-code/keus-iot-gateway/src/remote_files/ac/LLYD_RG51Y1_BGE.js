"use strict";
/*
LLoyd AC

Google drive link : https://drive.google.com/drive/u/0/folders/1T2WSZuhtZtYy2f-u3dsuPde24GdbTdoL
Clients :

Developer: Santhoshi Raj

Created : 23-08-21
Last modified : 23-08-21

Notes :
ELECTROLUX96_192AC

*/
Object.defineProperty(exports, "__esModule", { value: true });
const env = process.env.NODE_ENV || 'testing';
var Utils, IrBlaster, irUtils;
if (env == 'testing') {
    Utils = require('../utils');
    IrBlaster = require('../metadata');
}
else {
    Utils = require('../../utilities/device-manager/ir-utils');
    IrBlaster = require('../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-irblaster/metadata');
}
irUtils = new Utils.IRUtils();
exports.GenInfo = {
    [Utils.GenProps.BRAND]: "Lloyd",
    [Utils.GenProps.MODEL]: "RG51Y1_BGE",
    [Utils.GenProps.PROTOCOL]: "ELECTROLUX96_192AC",
    [Utils.GenProps.TYPE]: Utils.IrTypes.AC,
    [Utils.GenProps.IMAGE]: "https://drive.google.com/drive/u/0/folders/1T2WSZuhtZtYy2f-u3dsuPde24GdbTdoL",
    [Utils.GenProps.VERSION]: 1,
    //no of configurations needed by remote, requires as many remote Ids
    [Utils.GenProps.CONFIG_COUNT]: 1,
};
exports.RemoteInfo = {
    [Utils.AcProps.TEMP_MIN]: 17,
    [Utils.AcProps.TEMP_MAX]: 30,
    [Utils.AcProps.MODE_LIST]: [
        Utils.AcModes.COOL,
        Utils.AcModes.DRY,
        Utils.AcModes.FAN,
        Utils.AcModes.HEAT,
        Utils.AcModes.AUTO,
    ],
    [Utils.AcProps.FAN_LIST]: [
        Utils.AcFanOptions.OFF,
        Utils.AcFanOptions.LOW,
        Utils.AcFanOptions.MED,
        Utils.AcFanOptions.HIGH,
    ],
    [Utils.AcProps.VSWING_BUTTON]: 1,
    [Utils.AcProps.HSWING_BUTTON]: 1
};
exports.ConfigInfo = [
    {
        blastType: IrBlaster.IrConfigTypes.DEFAULT,
        configFormat: [0x02, 0x10, 0x30, 0x00, 0x03],
        bitFormat: IrBlaster.IrBitFormats.HL1_HL0,
        duty: 35,
        frequency: 38000,
        repeatCount: 2,
        timings: [
            { lowTime: 514, highTime: 566 },
            { lowTime: 1604, highTime: 568 },
            { lowTime: 4344, highTime: 4404 },
            { lowTime: 5200, highTime: 568 },
        ]
    }
];
/* Local constants */
//indexes for below listed config
var ConfigType;
(function (ConfigType) {
    ConfigType[ConfigType["NORMAL"] = 0] = "NORMAL";
})(ConfigType || (ConfigType = {}));
;
//5th byte
const tempOptions = [
    0x00,
    0x10,
    0x30,
    0x20,
    0x60,
    0x70,
    0x50,
    0x40,
    0xC0,
    0xD0,
    0x90,
    0x80,
    0xA0,
    0xB0,
];
var minTemp = exports.RemoteInfo[Utils.AcProps.TEMP_MIN];
//3th byte
const fanOptions = {
    [Utils.AcFanOptions.OFF]: 0xB0,
    [Utils.AcFanOptions.LOW]: 0x90,
    [Utils.AcFanOptions.MED]: 0x50,
    [Utils.AcFanOptions.HIGH]: 0x30
};
//7th byte
const modeOptions = {
    [Utils.AcModes.COOL]: {
        "mode": 0x00,
        "temp": null,
        "fan": null
    },
    [Utils.AcModes.DRY]: {
        "mode": 0x04,
        "temp": null,
        "fan": 0x10
    },
    [Utils.AcModes.FAN]: {
        "mode": 0x04,
        "temp": 0xE0,
        "fan": null
    },
    [Utils.AcModes.HEAT]: {
        "mode": 0x0C,
        "temp": null,
        "fan": null
    },
    [Utils.AcModes.AUTO]: {
        "mode": 0x08,
        "temp": null,
        "fan": 0x10
    },
};
const powerOptions = {
    0: [0xB2, 0x7B, 0xE0],
};
const vSwingOptions = [0xB2, 0x6B, 0xE0];
const hSwingOptions = [0xB5, 0xF5, 0xB2];
const updateTypesAvailable = [
    Utils.AcUpdateTypes.ON_OFF, Utils.AcUpdateTypes.VSWING_SELECT, Utils.AcUpdateTypes.HSWING_SELECT
];
const stateTypesAvailable = [
    Utils.AcUpdateTypes.ON_OFF
];
class IrService {
    getConfigs() { return exports.ConfigInfo; }
    getGenInfo() { return exports.GenInfo; }
    getRemoteInfo() { return exports.RemoteInfo; }
    generateSignal(req) {
        var irData = [], i = 0, j = 0, buffer = 0;
        console.log('\nIncoming Request : \n');
        console.log(req);
        var irSignal = [];
        console.log('\nFormed data');
        while (j < req.noOfSignals) {
            i = 0;
            buffer = 0;
            irSignal[j] = {};
            irSignal[j].repeatCount = 0;
            irSignal[j].dataFormat = [];
            irSignal[j].data = [];
            if (req.updateType == Utils.AcUpdateTypes.VSWING_SELECT) {
                buffer = irSignal[j].data[i++] = vSwingOptions[0];
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: vSwingOptions[0], pow: 8 });
                buffer = irSignal[j].data[i++] = vSwingOptions[1];
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: vSwingOptions[1], pow: 8 });
                buffer = irSignal[j].data[i++] = vSwingOptions[2];
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: vSwingOptions[2], pow: 8 });
            }
            else if (req.updateType == Utils.AcUpdateTypes.HSWING_SELECT) {
                buffer = irSignal[j].data[i++] = hSwingOptions[0];
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: hSwingOptions[0], pow: 8 });
                buffer = irSignal[j].data[i++] = hSwingOptions[1];
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: hSwingOptions[1], pow: 8 });
                buffer = irSignal[j].data[i++] = hSwingOptions[2];
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: hSwingOptions[2], pow: 8 });
            }
            else if (req.updateType == Utils.AcUpdateTypes.ON_OFF && !req.power) {
                buffer = irSignal[j].data[i++] = powerOptions[0][0];
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: powerOptions[0][0], pow: 8 });
                buffer = irSignal[j].data[i++] = powerOptions[0][1];
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: powerOptions[0][1], pow: 8 });
                buffer = irSignal[j].data[i++] = powerOptions[0][2];
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: powerOptions[0][2], pow: 8 });
            }
            else {
                buffer = irSignal[j].data[i++] = 0xB2;
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: buffer, pow: 8 });
                buffer = irSignal[j].data[i++] = ((modeOptions[req.mode]['fan'] == null ? fanOptions[req.fanLevel] : modeOptions[req.mode]['fan']) | 0x0F);
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: buffer, pow: 8 });
                buffer = irSignal[j].data[i++] = ((modeOptions[req.mode]['temp'] == null ? tempOptions[req.temperature - minTemp] : modeOptions[req.mode]['temp']) | modeOptions[req.mode]['mode']);
                irSignal[j].data[i++] = irUtils.binaryCompliment({ number: buffer, pow: 8 });
            }
            //update config id to match
            irSignal[j].id = req.remote_ids[ConfigType.NORMAL];
            var stringer = "";
            irSignal[j].data.forEach(function (element) {
                stringer += (('0' + element.toString(16)).slice(-2) + " ");
            });
            console.log('Signal ', +j + " : " + 'Remote ', +irSignal[j].id + " : Data - " + stringer);
            j++;
        }
        console.log('\n -- End --\n');
        return irSignal;
    }
    getSignalArray(req) {
        if (req.updateType === undefined)
            return []; //throw error
        if (updateTypesAvailable.indexOf(req.updateType[0]) < 0) {
            req.updateType = [Utils.AcUpdateTypes.ON_OFF];
        }
        req.noOfSignals = 1;
        return this.generateSignal(req);
    }
    getStateArray(req) {
        //set request types for state setting
        if (!req.power) {
            req.updateType = [Utils.AcUpdateTypes.ON_OFF];
            req.noOfSignals = 1;
        }
        else {
            req.updateType = stateTypesAvailable;
            req.noOfSignals = stateTypesAvailable.length;
        }
        return this.generateSignal(req);
    }
}
exports.default = IrService;
//# sourceMappingURL=LLYD_RG51Y1_BGE.js.map