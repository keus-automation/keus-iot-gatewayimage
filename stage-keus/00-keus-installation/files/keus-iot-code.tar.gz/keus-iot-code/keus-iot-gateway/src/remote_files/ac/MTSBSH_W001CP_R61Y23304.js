"use strict";
/*
Mitshubishi AC

Google drive link : https://drive.google.com/drive/u/0/folders/1zfCfmyD5_IuShW9OPJVf0oTQo_ieccuS
Clients : Brijesh Sir

Developer: Santhoshi Raj

Created : 23-08-21
Last modified : 23-08-21

Notes :
OLIMPIA136AC
Checksum = No checksum

*/
Object.defineProperty(exports, "__esModule", { value: true });
const env = process.env.NODE_ENV || 'testing';
var Utils, IrBlaster, irUtils;
if (env == 'testing') {
    Utils = require('../utils');
    IrBlaster = require('../metadata');
}
else {
    Utils = require('../../utilities/device-manager/ir-utils');
    IrBlaster = require('../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-irblaster/metadata');
}
irUtils = new Utils.IRUtils();
exports.GenInfo = {
    [Utils.GenProps.BRAND]: "Mitshubishi",
    [Utils.GenProps.MODEL]: "W001CP R61Y23304",
    [Utils.GenProps.PROTOCOL]: "OLIMPIA136AC",
    [Utils.GenProps.TYPE]: Utils.IrTypes.AC,
    [Utils.GenProps.IMAGE]: "https://drive.google.com/drive/u/0/folders/1jjxuVQfGgGyswYJW1y_rE2dudpK-w9eJ",
    [Utils.GenProps.VERSION]: 1,
    //no of configurations needed by remote, requires as many remote Ids
    [Utils.GenProps.CONFIG_COUNT]: 1,
};
exports.RemoteInfo = {
    [Utils.AcProps.TEMP_MIN]: 19,
    [Utils.AcProps.TEMP_MAX]: 30,
    [Utils.AcProps.MODE_LIST]: [
        Utils.AcModes.COOL,
        Utils.AcModes.DRY,
        Utils.AcModes.FAN,
        Utils.AcModes.HEAT,
        Utils.AcModes.AUTO
    ],
    [Utils.AcProps.FAN_LIST]: [
        Utils.AcFanOptions.LOW,
        Utils.AcFanOptions.MED,
        Utils.AcFanOptions.HIGH,
        Utils.AcFanOptions.AUTO
    ],
    [Utils.AcProps.VSWING_LIST]: [
        Utils.AcSwingOptions.OFF,
        Utils.AcSwingOptions.AUTO
    ],
};
exports.ConfigInfo = [
    {
        blastType: IrBlaster.IrConfigTypes.DEFAULT,
        configFormat: [0x02, 0x10, 0x88, 0x00, 0x03],
        bitFormat: IrBlaster.IrBitFormats.HL1_HL0,
        duty: 35,
        frequency: 38000,
        repeatCount: 1,
        timings: [
            { lowTime: 1166, highTime: 446 },
            { lowTime: 350, highTime: 444 },
            { lowTime: 1560, highTime: 3248 },
            { lowTime: 1000, highTime: 446 } //stop
        ]
    }
];
/* Local constants */
//indexes for below listed config
var ConfigType;
(function (ConfigType) {
    ConfigType[ConfigType["NORMAL"] = 0] = "NORMAL";
})(ConfigType || (ConfigType = {}));
;
const tempOptions = [
    0x03,
    0x0D,
    0x05,
    0x09,
    0x01,
    0x0E,
    0x06,
    0x0A,
    0x02,
    0x0C,
    0x04,
    0x08 //30
];
var minTemp = exports.RemoteInfo[Utils.AcProps.TEMP_MIN];
const fanOptions = {
    [Utils.AcFanOptions.LOW]: 0x30,
    [Utils.AcFanOptions.MED]: 0x50,
    [Utils.AcFanOptions.HIGH]: 0x10,
    [Utils.AcFanOptions.AUTO]: 0x70
};
const modeOptions = {
    [Utils.AcModes.COOL]: {
        "mode": 0x70,
        "temp": null,
        "fan": null
    },
    [Utils.AcModes.DRY]: {
        "mode": 0x50,
        "temp": null,
        "fan": null
    },
    [Utils.AcModes.FAN]: {
        "mode": 0xF0,
        "temp": 0X50,
        "fan": null
    },
    [Utils.AcModes.HEAT]: {
        "mode": 0xB0,
        "temp": null,
        "fan": null
    },
    [Utils.AcModes.AUTO]: {
        "mode": 0x30,
        "temp": null,
        "fan": null
    }
};
const vSwingOptions = {
    [Utils.AcSwingOptions.AUTO]: 0x0C,
    [Utils.AcSwingOptions.OFF]: 0x03
};
const powerOptions = {
    0: 0x0F,
    1: 0x0D
};
const updateTypesAvailable = [
    Utils.AcUpdateTypes.ON_OFF
];
const stateTypesAvailable = [
    Utils.AcUpdateTypes.ON_OFF
];
class IrService {
    getConfigs() { return exports.ConfigInfo; }
    getGenInfo() { return exports.GenInfo; }
    getRemoteInfo() { return exports.RemoteInfo; }
    generateSignal(req) {
        var irData = [], i = 0, j = 0, checkSum = 0;
        console.log('\nIncoming Request : \n');
        console.log(req);
        var irSignal = [];
        console.log('\nFormed data');
        while (j < req.noOfSignals) {
            i = 0;
            checkSum = 0;
            irSignal[j] = {};
            irSignal[j].repeatCount = 0;
            irSignal[j].dataFormat = [];
            irSignal[j].data = [];
            irSignal[j].data[i++] = 0x3b;
            irSignal[j].data[i++] = 0x2c;
            irSignal[j].data[i++] = 0x9b;
            irSignal[j].data[i++] = 0x7b;
            irSignal[j].data[i++] = 0xff;
            irSignal[j].data[i++] = (req.power) ? powerOptions[1] | 0xf0 : powerOptions[0] | 0xf0;
            console.log(req.mode);
            irSignal[j].data[i++] = (modeOptions[req.mode]["temp"] == null ? tempOptions[req.temperature - minTemp] : modeOptions[req.mode]["temp"]) | modeOptions[req.mode]["mode"];
            irSignal[j].data[i++] = fanOptions[req.fanLevel] | (req.v_swingLevel == Utils.AcSwingOptions.AUTO ? vSwingOptions[Utils.AcSwingOptions.AUTO] : vSwingOptions[Utils.AcSwingOptions.OFF]);
            irSignal[j].data[i++] = 0xdf;
            irSignal[j].data[i++] = 0xff;
            irSignal[j].data[i++] = 0xff;
            irSignal[j].data[i++] = 0x02;
            irSignal[j].data[i] = irUtils.binaryCompliment({ number: irSignal[j].data[i - 6], pow: 8 });
            i++;
            irSignal[j].data[i] = irUtils.binaryCompliment({ number: irSignal[j].data[i - 6], pow: 8 });
            i++;
            irSignal[j].data[i] = irUtils.binaryCompliment({ number: irSignal[j].data[i - 6], pow: 8 });
            i++;
            irSignal[j].data[i] = irUtils.binaryCompliment({ number: irSignal[j].data[i - 6], pow: 8 });
            i++;
            irSignal[j].data[i] = irUtils.binaryCompliment({ number: irSignal[j].data[i - 6], pow: 8 });
            i++;
            //update config id to match
            irSignal[j].id = req.remote_ids[ConfigType.NORMAL];
            var stringer = "";
            irSignal[j].data.forEach(function (element) {
                stringer += (('0' + element.toString(16)).slice(-2) + " ");
            });
            console.log('Signal ', +j + " : " + 'Remote ', +irSignal[j].id + " : Data - " + stringer);
            j++;
        }
        console.log('\n -- End --\n');
        return irSignal;
    }
    getSignalArray(req) {
        if (req.updateType === undefined)
            return []; //throw error
        if (updateTypesAvailable.indexOf(req.updateType[0]) < 0) {
            req.updateType = [Utils.AcUpdateTypes.ON_OFF];
        }
        req.noOfSignals = 1;
        return this.generateSignal(req);
    }
    getStateArray(req) {
        //set request types for state setting
        if (!req.power) {
            req.updateType = [Utils.AcUpdateTypes.ON_OFF];
            req.noOfSignals = 1;
        }
        else {
            req.updateType = stateTypesAvailable;
            req.noOfSignals = stateTypesAvailable.length;
        }
        return this.generateSignal(req);
    }
}
exports.default = IrService;
//# sourceMappingURL=MTSBSH_W001CP_R61Y23304.js.map