"use strict";
/*
LG TV

Google drive link : https://drive.google.com/drive/u/0/folders/1NccRWT-VmqxsOpjTkZT23Xh2UtysA0-G
Clients : 5120 - Vivaswath

Developer: Santhoshi Raj

Created : 30-08-21
Last modified : 30-08-21

Notes:
NEC, blasts twice

*/
Object.defineProperty(exports, "__esModule", { value: true });
const env = process.env.NODE_ENV || 'testing';
var Utils, IrBlaster, irUtils;
if (env == 'testing') {
    Utils = require('../utils');
    IrBlaster = require('../metadata');
}
else {
    Utils = require('../../utilities/device-manager/ir-utils');
    IrBlaster = require('../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-irblaster/metadata');
}
irUtils = new Utils.IRUtils();
exports.GenInfo = {
    [Utils.GenProps.BRAND]: "LG",
    [Utils.GenProps.MODEL]: "",
    [Utils.GenProps.PROTOCOL]: "NEC",
    [Utils.GenProps.TYPE]: Utils.IrTypes.TV,
    [Utils.GenProps.IMAGE]: "https://drive.google.com/drive/u/0/folders/1NccRWT-VmqxsOpjTkZT23Xh2UtysA0-G",
    [Utils.GenProps.VERSION]: 1,
    //no of configurations needed by remote, requires as many remote Ids
    [Utils.GenProps.CONFIG_COUNT]: 1,
};
/* Local constants */
//indexes for configs
var ConfigType;
(function (ConfigType) {
    ConfigType[ConfigType["NEC"] = 0] = "NEC";
})(ConfigType || (ConfigType = {}));
;
const blastOptions = {
    [Utils.TvUpdateTypes.ON_OFF]: { data: [0x20, 0xDF, 0x10, 0xEF] },
    [Utils.TvUpdateTypes.SOURCE]: { data: [0x20, 0xDF, 0xD0, 0x2F] },
    [Utils.TvUpdateTypes.VOLUME_INC]: { data: [0x20, 0xDF, 0x40, 0xBF] },
    [Utils.TvUpdateTypes.VOLUME_DEC]: { data: [0x20, 0xDF, 0xC0, 0x3F] },
    [Utils.TvUpdateTypes.VOLUME_MUTE]: { data: [0x20, 0xDF, 0x90, 0x6F] },
    [Utils.TvUpdateTypes.CHANNEL_INC]: { data: [0x20, 0xDF, 0x00, 0xFF] },
    [Utils.TvUpdateTypes.CHANNEL_DEC]: { data: [0x20, 0xDF, 0x80, 0x7F] },
    [Utils.TvUpdateTypes.NUM_PAD]: {
        0: { data: [0x20, 0xDF, 0x08, 0xF7] },
        1: { data: [0x20, 0xDF, 0x88, 0x77] },
        2: { data: [0x20, 0xDF, 0x48, 0xB7] },
        3: { data: [0x20, 0xDF, 0xC8, 0x37] },
        4: { data: [0x20, 0xDF, 0x28, 0xD7] },
        5: { data: [0x20, 0xDF, 0xA8, 0x57] },
        6: { data: [0x20, 0xDF, 0x68, 0x97] },
        7: { data: [0x20, 0xDF, 0xE8, 0x17] },
        8: { data: [0x20, 0xDF, 0x18, 0xE7] },
        9: { data: [0x20, 0xDF, 0x98, 0x67] },
    },
    [Utils.TvUpdateTypes.MENU_OK]: { data: [0x20, 0xDF, 0x3E, 0xC1] },
};
/* Exporting Remote Info */
exports.RemoteInfo = {
    [Utils.TvProps.ON_OFF_COMBINED]: 1,
    [Utils.TvProps.SOURCE_BUTTON]: 1,
    [Utils.TvProps.VOLUME_CONTROLS]: 1,
    [Utils.TvProps.CHANNEL_CONTROLS]: 1,
    [Utils.TvProps.NUM_PAD]: 1,
    [Utils.TvProps.MENU]: 1,
};
exports.ConfigInfo = [
    {
        blastType: IrBlaster.IrConfigTypes.DEFAULT,
        configFormat: [0x02, 0x10, 0x20, 0x00, 0x03, 0x02, 0x03],
        bitFormat: IrBlaster.IrBitFormats.HL1_HL0,
        duty: 35,
        frequency: 38000,
        repeatCount: 1,
        timings: [
            { lowTime: 580, highTime: 500 },
            { lowTime: 1550, highTime: 500 },
            { lowTime: 4350, highTime: 8950 },
            { lowTime: 40000, highTime: 500 },
        ]
    }
];
/* Local variables */
class IrService {
    getConfigs() { return exports.ConfigInfo; }
    getGenInfo() { return exports.GenInfo; }
    getRemoteInfo() { return exports.RemoteInfo; }
    generateSignal(req) {
        var i = 0, j = 0;
        console.log('\nIncoming Request : \n');
        console.log(req);
        var irSignal = [];
        console.log('\nFormed data');
        {
            i = 0;
            irSignal[j] = {};
            irSignal[j].repeatCount = 0;
            irSignal[j].dataFormat = [];
            irSignal[j].data = [];
            let blastObject = {};
            if (req.updateType[j] == Utils.TvUpdateTypes.NUM_PAD) {
                blastObject = blastOptions[req.updateType[j]][req.channel];
            }
            else {
                blastObject = blastOptions[req.updateType[j]];
            }
            //update config id to match
            irSignal[j].id = req.remote_ids[ConfigType.NEC];
            irSignal[j].data = blastObject.data;
            var stringer = "";
            irSignal[j].data.forEach(function (element) {
                stringer += (('0' + element.toString(16)).slice(-2) + " ");
            });
            console.log('Signal ', +j + " : " + 'Remote ', +irSignal[j].id + " : Data - " + stringer);
            j++;
        }
        console.log('\n -- End --\n');
        return irSignal;
    }
    getSignalArray(req) {
        if (req.updateType === undefined)
            return []; //throw error
        if (Object.keys(blastOptions).indexOf(req.updateType[0].toString()) < 0) {
            console.log('Update Type not found');
            return [];
        }
        return this.generateSignal(req);
    }
}
exports.default = IrService;
//# sourceMappingURL=LG_5120.js.map