"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
// eslint-disable-next-line import/no-unresolved
const RootPath = '../../';
const Logger = require(RootPath + 'services/logger-service/index').default;
const logInst = new Logger({ enable: true, namespace: 'KIOTT_Client' });
const kiott_nodeclient_1 = __importStar(require("kiott-nodeclient"));
const client_interface_1 = require("./client-interface");
const broker_pb_1 = require("kiott-broker/dist/generated/broker_pb");
class CommunicationClient extends client_interface_1.ClientInterface {
    constructor(options) {
        super();
        this.host = options.host;
        this.port = options.port;
        this.clientInst = new kiott_nodeclient_1.default(this.host, this.port);
    }
    registerTypes(TypeRegistry) {
        kiott_nodeclient_1.TypeConversionUtils.getInstance().buildRegistry(TypeRegistry);
    }
    getTypeConversionUtils() {
        return kiott_nodeclient_1.TypeConversionUtils.getInstance();
    }
    login(loginDetails) {
        logInst.log('Logging into client');
        const _this = this;
        return new Promise(async (resolve, reject) => {
            try {
                const validation = new broker_pb_1.ValidationRequest();
                validation.setJsonBody(loginDetails);
                let res = await _this.clientInst.start(validation);
                if (res && res.success) {
                    resolve(res);
                }
                else {
                    reject(res);
                }
            }
            catch (e) {
                reject(e);
            }
        });
    }
    async registerService(serviceName, cb) {
        const _this = this;
        return new Promise(async (resolve, reject) => {
            try {
                await _this.clientInst.registerService(serviceName, cb);
                resolve();
            }
            catch (e) {
                reject(e);
            }
        });
    }
    registerDefaultService(defaultServiceName, defaultServicePwd, servicecb) {
        const _this = this;
        return new Promise(async (resolve, reject) => {
            try {
                const defaultServiceReq = new broker_pb_1.DefaultServiceRequest();
                defaultServiceReq.setDefaultServiceName(defaultServiceName);
                defaultServiceReq.setServicePassword(defaultServicePwd);
                let res = await _this.clientInst.registerDefaultService(defaultServiceReq, servicecb);
                if (res && res.success) {
                    resolve(res);
                }
                else {
                    reject(res);
                }
            }
            catch (e) {
                reject(e);
            }
        });
    }
    unregisterService(serviceName) {
        this.clientInst.unregisterService(serviceName);
    }
    unregisterDefaultService() {
        this.clientInst.unregisterDefaultService();
    }
    makeRPC(serviceName, arg) {
        return new Promise((resolve, reject) => {
            this.clientInst.makeRPC(serviceName, arg, (err, res) => {
                if (err) {
                    reject(err);
                }
                else {
                    resolve(res);
                }
            });
        });
    }
    publishEvent(eventName, arg) {
        try {
            this.clientInst.publish(eventName, arg);
        }
        catch (e) {
            logInst.log('Publish Event Error', e);
        }
    }
    async subscribe(eventName, cb) {
        try {
            await this.clientInst.subscribeToEvent(eventName, cb);
        }
        catch (e) {
            logInst.log('Subscribe Event Error', e);
        }
    }
    unsubscribe(eventName) {
        try {
            this.clientInst.unsubscribeFromEvent(eventName);
        }
        catch (e) {
            logInst.log('Unsubscribe Event Error', e);
        }
    }
}
exports.default = CommunicationClient;
//# sourceMappingURL=KIOTT-client-impl.js.map