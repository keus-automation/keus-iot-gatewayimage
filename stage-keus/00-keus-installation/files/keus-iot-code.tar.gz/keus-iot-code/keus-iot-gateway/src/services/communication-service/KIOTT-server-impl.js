"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = __importDefault(require("../logger-service/index"));
const logInst = new index_1.default({ enable: true, namespace: 'KIOTT_Client' });
const kiott_broker_1 = __importDefault(require("kiott-broker"));
const server_interface_1 = require("./server-interface");
class CommunicationServer extends server_interface_1.ServerInterface {
    constructor(options) {
        super(options);
        this.defaultConfigs = {
            ackTimeOut: 3000,
            authAPILink: '',
            customAuthValidator: null,
            logLevel: 1,
            responseTimeOut: 10000,
            serverUUID: 'KIIOT_LocalServer',
            servicePassword: 'ABCDE'
        };
        this.host = options.host;
        this.port = options.port;
        this.configs = Object.assign(this.defaultConfigs, options.configs);
        this.serverInst = new kiott_broker_1.default(this.host, this.port, this.configs);
    }
    start() {
        this.serverInst.start();
    }
}
exports.default = CommunicationServer;
//# sourceMappingURL=KIOTT-server-impl.js.map