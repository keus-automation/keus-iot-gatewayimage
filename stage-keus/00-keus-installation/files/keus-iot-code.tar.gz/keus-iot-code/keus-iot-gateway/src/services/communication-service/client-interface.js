"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const rootPath = '../../';
class ClientInterface {
}
exports.ClientInterface = ClientInterface;
//# sourceMappingURL=client-interface.js.map