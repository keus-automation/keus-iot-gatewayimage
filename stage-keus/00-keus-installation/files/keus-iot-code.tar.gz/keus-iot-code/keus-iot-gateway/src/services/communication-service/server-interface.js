"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const kiott_broker_1 = require("kiott-broker");
exports.ValidationRequest = kiott_broker_1.ValidationRequest;
exports.IValidationResponse = kiott_broker_1.IValidationResponse;
class ServerInterface {
    constructor(ServerOptions) { }
}
exports.ServerInterface = ServerInterface;
//# sourceMappingURL=server-interface.js.map