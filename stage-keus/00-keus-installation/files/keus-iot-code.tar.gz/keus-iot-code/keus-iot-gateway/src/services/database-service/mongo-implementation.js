"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importDefault(require("mongoose"));
const errors_1 = require("../../errors/errors");
const logger_service_1 = __importDefault(require("../logger-service"));
const system_constants_1 = require("../../constants/gateway/system-constants");
const database_utils_1 = require("../../utilities/gateway/database-utils");
const logInst = new logger_service_1.default({ enable: true, namespace: 'HUB_CLIENT' });
class MongoImpl {
    constructor() {
        if (MongoImpl.instance) {
            throw new Error('Database Singleton Instance Error');
        }
        MongoImpl.instance = this;
    }
    static getInstance() {
        return MongoImpl.instance;
    }
    async connect(options) {
        MongoImpl.serverUrl = database_utils_1.formMongoDatabaseConnectionUrl(options);
        try {
            logInst.log('Connecting to Database');
            this.databaseConnection = await mongoose_1.default.connect(MongoImpl.serverUrl + '/' + system_constants_1.DatabaseName, {
                useNewUrlParser: true,
                useUnifiedTopology: true,
                useFindAndModify: true,
                autoIndex: false
            });
            return;
        }
        catch (e) {
            console.log(e);
            throw new errors_1.DatabaseErrors.DatabaseConnectionError();
        }
    }
}
exports.default = MongoImpl;
MongoImpl.instance = new MongoImpl();
//# sourceMappingURL=mongo-implementation.js.map