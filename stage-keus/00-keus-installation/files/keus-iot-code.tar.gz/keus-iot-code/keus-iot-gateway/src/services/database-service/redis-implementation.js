"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const ioredis_1 = __importDefault(require("ioredis"));
const database_service_1 = __importDefault(require("../../configs/database-service"));
// import { GeneralErrors } from '../../errors/errors';
// import { GeneralErrors } from '../../errors/errors';
const GeneralErrors = {};
class RedisImpl {
    constructor() {
        this.redisConn = new ioredis_1.default(database_service_1.default.port, database_service_1.default.host);
        if (RedisImpl.instance) {
            throw new Error('Singleton Instance Error');
        }
        RedisImpl.instance = this;
    }
    static getInstance() {
        return RedisImpl.instance;
    }
    async putItem(tableName, primaryKey, item) {
        try {
            const itemKey = `${tableName}:${primaryKey}`;
            const itemObj = JSON.stringify(item);
            const res = await this.redisConn.set(itemKey, itemObj);
            return res;
        }
        catch (e) {
            // throw new GeneralErrors.DatabaseError();
        }
    }
    async getItem(tableName, primaryKey) {
        try {
            const itemKey = `${tableName}:${primaryKey}`;
            const res = await this.redisConn.get(itemKey);
            return JSON.parse(res);
        }
        catch (e) {
            // throw new GeneralErrors.DatabaseError();
        }
    }
    async deleteItem(tableName, primaryKey) {
        return this.redisConn.hdel(tableName, primaryKey);
    }
    async updateItem(tableName, primaryKey, item) {
        const getItem = await this.redisConn.hget(tableName, primaryKey);
        console.log(item);
        return getItem;
        // const finalItem = {};
        // Object.assign(finalItem, getItem, item);
        // return this.redisConn.hset(tableName, primaryKey, finalItem);
    }
    async scan(tableName) {
        return this.redisConn.hscan(tableName);
    }
}
exports.default = RedisImpl;
RedisImpl.instance = new RedisImpl();
//# sourceMappingURL=redis-implementation.js.map