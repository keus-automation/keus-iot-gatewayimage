"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class LoggerInterface {
    constructor() { }
}
exports.LoggerInterface = LoggerInterface;
//# sourceMappingURL=interface.js.map