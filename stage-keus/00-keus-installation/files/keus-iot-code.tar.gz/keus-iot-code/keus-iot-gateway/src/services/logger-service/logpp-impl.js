"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const interface_1 = require("./interface");
const LogPP = require('logpp');
class LoggerService extends interface_1.LoggerInterface {
    constructor(options) {
        super();
        this.enableLogs();
        this._loggerInst = LogPP(this._namespace || 'KIOTG', { memoryLevel: 'INFO' });
    }
    enableLogs() { }
    disableLogs() { }
    log(logValue) {
        this._loggerInst.info(logValue);
    }
    warn(warnValue) {
        this._loggerInst.warn(this._loggerInst.$Clock, warnValue);
    }
    error(errValue) {
        this._loggerInst.error(this._loggerInst.$Clock, errValue);
    }
}
exports.default = LoggerService;
//# sourceMappingURL=logpp-impl.js.map