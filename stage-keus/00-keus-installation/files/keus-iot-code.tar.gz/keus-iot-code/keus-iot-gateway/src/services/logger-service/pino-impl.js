"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const interface_1 = require("./interface");
const pino = require('pino');
const parentLogger = pino({
    prettyPrint: {
        ignore: 'ns,hostname,pid,level',
        translateTime: 'h:MM:ss TT Z'
    }
});
class LoggerService extends interface_1.LoggerInterface {
    constructor(options) {
        super();
        this._namespace = options.namespace;
        this._loggerInst = parentLogger.child({ ns: this._namespace });
        if (options.enable) {
            this.enableLogs();
        }
        else {
            this.disableLogs();
        }
    }
    enableLogs() {
        this._loggerInst.level = 'info';
    }
    disableLogs() {
        this._loggerInst.level = 'silent';
    }
    log(...args) {
        this._loggerInst.info.apply(this._loggerInst, arguments);
    }
    warn(...args) {
        this._loggerInst.warn.apply(this._loggerInst, arguments);
    }
    error(...args) {
        this._loggerInst.error.apply(this._loggerInst, arguments);
    }
}
exports.default = LoggerService;
//# sourceMappingURL=pino-impl.js.map