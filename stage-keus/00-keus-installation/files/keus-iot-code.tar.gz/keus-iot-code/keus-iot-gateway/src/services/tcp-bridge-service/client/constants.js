"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CbkKeys = {
    StatusCbk: 'StatusCbk',
    AuthCbk: 'AuthCbk'
};
//# sourceMappingURL=constants.js.map