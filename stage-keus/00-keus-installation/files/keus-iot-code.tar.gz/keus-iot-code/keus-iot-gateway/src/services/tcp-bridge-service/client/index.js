"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const shared_1 = require("../shared");
const frame_stream_1 = __importDefault(require("frame-stream"));
const net = __importStar(require("net"));
const constants_1 = require("./constants");
const DefaultClientOptions = {
    onClientConnected: () => { },
    onClientDisconnected: () => { },
    onData: () => { return Buffer.from([]); },
    onError: (error) => { },
    onClientRestart: () => { console.log('Client Restarted'); },
    onServerRestart: () => { console.log('Server Restarted'); }
};
class BridgeClient {
    constructor(host, port, options) {
        this.fnCbks = {};
        this.reqTimers = {};
        this.host = host;
        this.port = port;
        this.options = Object.assign(DefaultClientOptions, options);
        this.bridgeClient = new net.Socket();
        this.messageEncoder = frame_stream_1.default.encode(shared_1.FrameStreamOptions);
        this.messageEncoder.pipe(this.bridgeClient);
        this.bridgeClient.on('error', this.onClientError.bind(this));
        this.bridgeClient
            .pipe(frame_stream_1.default.decode(shared_1.FrameStreamOptions))
            .on('data', this.onDataReceived.bind(this));
        this.bridgeClient
            .on('connect', this.onClientConnected.bind(this));
        this.bridgeClient
            .on('close', this.onClientDisconnected.bind(this));
    }
    async authenticateClient(authData) {
        this.reqTimers[constants_1.CbkKeys.AuthCbk] = setTimeout(() => {
            throw new Error('Request Timeout');
        }, 2000);
        this.fnCbks[constants_1.CbkKeys.AuthCbk] = (authStatus) => {
            console.log('this is ', authStatus);
            clearTimeout(this.reqTimers[constants_1.CbkKeys.AuthCbk]);
            console.log('cleared timer', this.reqTimers);
            if (authStatus === shared_1.AuthStatus.SUCCESS) {
                this.status = shared_1.ConnectionStatus.AUTHENTICATED;
            }
            else {
                throw new Error('Authentication Failed');
            }
        };
        this.messageEncoder.write(Buffer.concat([
            Buffer.from([shared_1.MessageType.AUTH]),
            authData
        ]));
    }
    checkBridgeStatus() {
        return new Promise((resolve, reject) => {
            if (!this.fnCbks[constants_1.CbkKeys.StatusCbk]) {
                this.reqTimers[constants_1.CbkKeys.StatusCbk] = setTimeout(() => {
                    reject(new Error('Request Timeout'));
                }, 3000);
                this.fnCbks[constants_1.CbkKeys.StatusCbk] = (statusInfo) => {
                    clearTimeout(this.reqTimers[constants_1.CbkKeys.StatusCbk]);
                    resolve(statusInfo);
                };
                this.messageEncoder.write(Buffer.from([shared_1.MessageType.STATUS]));
            }
            else {
                reject(new Error('status check in progress'));
            }
        });
    }
    async onClientError(err) {
        console.log('client error', err, err.code);
        this.options.onError(err);
    }
    onClientConnected() {
        console.log('connected');
        this.status = shared_1.ConnectionStatus.CONNECTED;
        this.options.onClientConnected();
    }
    onClientDisconnected() {
        console.log('disconnected');
        this.status = shared_1.ConnectionStatus.DISCONNECTED;
        this.options.onClientDisconnected();
    }
    onDataReceived(data) {
        let messageType = data[0];
        let messageData = data.slice(1, data.length);
        console.log(messageType, messageData);
        switch (messageType) {
            case shared_1.MessageType.AUTH:
                this.fnCbks[constants_1.CbkKeys.AuthCbk](messageData[0]);
                break;
            case shared_1.MessageType.DATA:
                this.options.onData(messageData);
                break;
            case shared_1.MessageType.STATUS:
                this.fnCbks[constants_1.CbkKeys.StatusCbk](messageData[0]);
                break;
            case shared_1.MessageType.CLIENT_RESTART:
                this.options.onClientRestart();
                break;
            case shared_1.MessageType.SERVER_RESTART:
                this.options.onServerRestart();
                break;
        }
    }
    writeData(data) {
        this.messageEncoder.write(Buffer.concat([
            Buffer.from([shared_1.MessageType.DATA]),
            data
        ]));
    }
    setHost(host) {
        this.host = host;
    }
    start() {
        this.bridgeClient.connect({
            host: this.host,
            port: this.port
        });
    }
    async end() {
        return new Promise(function (resolve, reject) {
            this.bridgeClient.end(resolve);
        });
    }
}
exports.default = BridgeClient;
//# sourceMappingURL=index.js.map