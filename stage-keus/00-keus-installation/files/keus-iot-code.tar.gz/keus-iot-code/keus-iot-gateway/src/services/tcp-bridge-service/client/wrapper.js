"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const frame_stream_1 = __importDefault(require("frame-stream"));
const shared_1 = require("../shared");
const constants_1 = require("./constants");
class BridgeWrapper {
    constructor() {
        this.reqTimers = {};
        this.fnCbks = {};
        this.status = shared_1.ConnectionStatus.INTIALISED;
        this.bridgeStatus = shared_1.BridgeStatus.UNKNOWN;
        this.messageEncoder = frame_stream_1.default.encode(shared_1.FrameStreamOptions);
        this.messageDecoder = frame_stream_1.default.decode(shared_1.FrameStreamOptions);
    }
    async authenticateClient(authData) {
        this.reqTimers[constants_1.CbkKeys.AuthCbk] = setTimeout(() => {
            throw new Error('Request Timeout');
        }, 2000);
        this.fnCbks[constants_1.CbkKeys.AuthCbk] = (authStatus) => {
            console.log('this is ', authStatus);
            clearTimeout(this.reqTimers[constants_1.CbkKeys.AuthCbk]);
            console.log('cleared timer', this.reqTimers);
            if (authStatus === shared_1.AuthStatus.SUCCESS) {
                this.status = shared_1.ConnectionStatus.AUTHENTICATED;
            }
            else {
                throw new Error('Authentication Failed');
            }
        };
        this.messageEncoder.write(Buffer.concat([
            Buffer.from([shared_1.MessageType.AUTH]),
            authData
        ]));
    }
    updateBridgeStatus() {
        return new Promise((resolve, reject) => {
            this.reqTimers[constants_1.CbkKeys.StatusCbk] = setTimeout(() => {
                console.log('Bridge Status Req Timeout');
                reject('Timeout Error');
            }, 1500);
            this.fnCbks[constants_1.CbkKeys.StatusCbk] = (bridgeStatus) => {
                console.log('this is bridge Status', bridgeStatus);
                clearTimeout(this.reqTimers[constants_1.CbkKeys.StatusCbk]);
                this.bridgeStatus = bridgeStatus;
                resolve(bridgeStatus);
            };
            this.messageEncoder.write(Buffer.concat([
                Buffer.from([shared_1.MessageType.STATUS])
            ]));
        });
    }
    getCustomParser() {
        return this.messageDecoder;
    }
    getCustomWriter() {
        return this.messageEncoder;
    }
    onWrite(data) {
        let transformedData = Buffer.concat([Buffer.from([shared_1.MessageType.DATA]), data]);
        return transformedData;
    }
    onClose() {
        console.log('disconnected');
        this.status = shared_1.ConnectionStatus.DISCONNECTED;
    }
    onConnect(client) {
        console.log('this is wrapper client connected');
        // this.messageEncoder.pipe(client);
    }
    onData(data) {
        let messageType = data[0];
        let messageData = data.slice(1, data.length);
        switch (messageType) {
            case shared_1.MessageType.AUTH:
                this.fnCbks[constants_1.CbkKeys.AuthCbk](messageData[0]);
                break;
            case shared_1.MessageType.DATA:
                return messageData;
            case shared_1.MessageType.STATUS:
                this.fnCbks[constants_1.CbkKeys.StatusCbk](messageData[0]);
                break;
            case shared_1.MessageType.CLIENT_RESTART:
                this.onClientRestart();
                break;
            case shared_1.MessageType.SERVER_RESTART:
                this.onServerRestart();
                break;
        }
    }
    onError(error) {
        console.log('Error ', error);
    }
    onReady() {
        return new Promise((resolve, reject) => {
            let readyCheckTimer = setInterval(async () => {
                if (this.status === shared_1.ConnectionStatus.AUTHENTICATED) {
                    if (this.bridgeStatus !== shared_1.BridgeStatus.ACTIVE) {
                        this.updateBridgeStatus();
                    }
                    else {
                        console.log('Ready');
                        clearInterval(readyCheckTimer);
                        resolve({});
                    }
                }
            }, 3000);
        });
    }
    onClientRestart() {
        console.log('Client Restarted');
    }
    onServerRestart() {
        console.log('Server Restarted');
    }
}
exports.default = BridgeWrapper;
//# sourceMappingURL=wrapper.js.map