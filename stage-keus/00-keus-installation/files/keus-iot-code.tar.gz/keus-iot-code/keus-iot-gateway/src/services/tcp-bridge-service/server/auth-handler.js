"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const shared_1 = require("../shared");
async function default_1(client, authData) {
    let that = this;
    try {
        let pairInfo = await that.authHandlerFn(authData);
        let bridgePairInfo = that.bridgePairs.get(pairInfo.pairKey);
        if (!bridgePairInfo) {
            that.bridgePairs.set(pairInfo.pairKey, {
                server: (pairInfo.role === shared_1.BridgeRole.SERVER) ? client : null,
                client: (pairInfo.role === shared_1.BridgeRole.CLIENT) ? client : null,
                status: shared_1.BridgeStatus.WAITING
            });
        }
        else {
            if (pairInfo.role === shared_1.BridgeRole.SERVER) {
                // if server is connected then its a restart event else its not a restart
                if (bridgePairInfo.client && bridgePairInfo.client.encodedWriter) {
                    bridgePairInfo.client.encodedWriter.write(Buffer.from([shared_1.MessageType.SERVER_RESTART]));
                }
                bridgePairInfo.server = client;
            }
            else if (pairInfo.role === shared_1.BridgeRole.CLIENT) {
                // if client is connected then its a restart event else its not a restart
                if (bridgePairInfo.server && bridgePairInfo.server.encodedWriter) {
                    bridgePairInfo.server.encodedWriter.write(Buffer.from([shared_1.MessageType.CLIENT_RESTART]));
                }
                bridgePairInfo.client = client;
            }
            if (bridgePairInfo.client && bridgePairInfo.server) {
                bridgePairInfo.status = shared_1.BridgeStatus.ACTIVE;
            }
            else {
                bridgePairInfo.status = shared_1.BridgeStatus.WAITING;
            }
        }
        client.bridgeRole = pairInfo.role;
        client.bridgeId = pairInfo.pairKey;
        client.encodedWriter.write(Buffer.from([shared_1.MessageType.AUTH, shared_1.AuthStatus.SUCCESS]));
        console.log('Written auth response', pairInfo);
    }
    catch (err) {
        console.log('this is auth response error', err);
        client.encodedWriter.write(Buffer.from([shared_1.MessageType.AUTH, shared_1.AuthStatus.FAILED]));
        client.end();
    }
}
exports.default = default_1;
//# sourceMappingURL=auth-handler.js.map