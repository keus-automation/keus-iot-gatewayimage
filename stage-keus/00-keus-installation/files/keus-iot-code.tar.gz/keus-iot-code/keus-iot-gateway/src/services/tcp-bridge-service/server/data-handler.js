"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const shared_1 = require("../shared");
function default_1(client, data, rawData) {
    let that = this;
    try {
        let bridgePairInfo = that.bridgePairs.get(client.bridgeId);
        if (bridgePairInfo && bridgePairInfo.status === shared_1.BridgeStatus.ACTIVE) {
            let bridgePairSocket = (client.bridgeRole === shared_1.BridgeRole.SERVER) ?
                bridgePairInfo.client :
                bridgePairInfo.server;
            bridgePairSocket.encodedWriter.write(rawData);
        }
        else {
            throw new Error('Bridge not ready');
        }
    }
    catch (err) {
        console.log(err);
    }
}
exports.default = default_1;
//# sourceMappingURL=data-handler.js.map