"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const net = __importStar(require("net"));
const shared_1 = require("../shared");
const frame_stream_1 = __importDefault(require("frame-stream"));
const auth_handler_1 = __importDefault(require("./auth-handler"));
const data_handler_1 = __importDefault(require("./data-handler"));
const status_handler_1 = __importDefault(require("./status-handler"));
class BridgeServer {
    constructor(host, port, authHandlerFn) {
        this.sockets = [];
        this.bridgePairs = new Map();
        this.config = {
            host: host,
            port: port
        };
        this.bridgeServer = net.createServer();
        this.authHandlerFn = authHandlerFn;
        this.bridgeServer.on('connection', this.onClientConnection.bind(this));
    }
    onClientConnection(socket) {
        console.log('CONNECTED: ' + socket.remoteAddress + ':' + socket.remotePort);
        this.sockets.push(socket);
        socket.encodedWriter = frame_stream_1.default.encode(shared_1.FrameStreamOptions);
        socket.encodedWriter.pipe(socket);
        socket.pipe(frame_stream_1.default.decode(shared_1.FrameStreamOptions)).on('data', (data) => {
            // console.log('DATA ' + sock.remoteAddress + ': ' + data);
            // Write the data back to all the connected, the client will receive it as data from the server
            let messageType = data[0];
            let messageData = data.slice(1, data.length);
            switch (messageType) {
                case shared_1.MessageType.AUTH:
                    auth_handler_1.default.call(this, socket, messageData);
                    break;
                case shared_1.MessageType.DATA:
                    data_handler_1.default.call(this, socket, messageData, data);
                    break;
                case shared_1.MessageType.STATUS:
                    status_handler_1.default.call(this, socket, messageData);
                    break;
            }
        });
        // Add a 'close' event handler to this instance of socket
        socket.on('close', (data) => {
            let index = this.sockets.findIndex(function (o) {
                return o.remoteAddress === socket.remoteAddress && o.remotePort === socket.remotePort;
            });
            let foundSocket = this.sockets[index];
            let bridgePairInfo = this.bridgePairs.get(foundSocket.bridgeId);
            if (bridgePairInfo) {
                if (foundSocket.bridgeRole === shared_1.BridgeRole.SERVER) {
                    bridgePairInfo.server = null;
                }
                else {
                    bridgePairInfo.client = null;
                }
                bridgePairInfo.status = shared_1.BridgeStatus.WAITING;
            }
            if (index !== -1)
                this.sockets.splice(index, 1);
            console.log('CLOSED: ' + socket.remoteAddress + ' ' + socket.remotePort);
        });
    }
    start() {
        console.log('starting tcp bridge server');
        this.bridgeServer.listen(this.config.port, this.config.host, () => {
            console.log('TCP Server is running on port ' +
                this.config.port);
        });
    }
}
exports.default = BridgeServer;
//# sourceMappingURL=index.js.map