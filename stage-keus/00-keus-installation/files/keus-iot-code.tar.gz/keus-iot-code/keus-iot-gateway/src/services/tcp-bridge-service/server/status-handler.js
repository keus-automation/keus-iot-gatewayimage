"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const shared_1 = require("../shared");
async function default_1(client, statusData) {
    let that = this;
    try {
        let bridgePairInfo = that.bridgePairs.get(client.bridgeId);
        if (bridgePairInfo) {
            client.encodedWriter.write(Buffer.from([shared_1.MessageType.STATUS, bridgePairInfo.status]));
        }
        else {
            client.encodedWriter.write(Buffer.from([shared_1.MessageType.STATUS, shared_1.BridgeStatus.UNKNOWN]));
        }
    }
    catch (err) {
        console.log(err);
        client.encodedWriter.write(Buffer.from([shared_1.MessageType.STATUS, shared_1.BridgeStatus.UNKNOWN]));
    }
}
exports.default = default_1;
//# sourceMappingURL=status-handler.js.map