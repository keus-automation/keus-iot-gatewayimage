"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const net = __importStar(require("net"));
var MessageType;
(function (MessageType) {
    MessageType[MessageType["PING"] = 1] = "PING";
    MessageType[MessageType["AUTH"] = 2] = "AUTH";
    MessageType[MessageType["DATA"] = 3] = "DATA";
    MessageType[MessageType["STATUS"] = 4] = "STATUS";
    MessageType[MessageType["CLIENT_RESTART"] = 5] = "CLIENT_RESTART";
    MessageType[MessageType["SERVER_RESTART"] = 6] = "SERVER_RESTART";
})(MessageType = exports.MessageType || (exports.MessageType = {}));
var AuthStatus;
(function (AuthStatus) {
    AuthStatus[AuthStatus["SUCCESS"] = 1] = "SUCCESS";
    AuthStatus[AuthStatus["FAILED"] = 0] = "FAILED";
    AuthStatus[AuthStatus["FAILED_RETRY"] = 2] = "FAILED_RETRY";
})(AuthStatus = exports.AuthStatus || (exports.AuthStatus = {}));
var ConnectionStatus;
(function (ConnectionStatus) {
    ConnectionStatus[ConnectionStatus["INTIALISED"] = 0] = "INTIALISED";
    ConnectionStatus[ConnectionStatus["CONNECTED"] = 1] = "CONNECTED";
    ConnectionStatus[ConnectionStatus["AUTHENTICATED"] = 2] = "AUTHENTICATED";
    ConnectionStatus[ConnectionStatus["DISCONNECTED"] = 3] = "DISCONNECTED";
})(ConnectionStatus = exports.ConnectionStatus || (exports.ConnectionStatus = {}));
var BridgeStatus;
(function (BridgeStatus) {
    BridgeStatus[BridgeStatus["ACTIVE"] = 1] = "ACTIVE";
    BridgeStatus[BridgeStatus["WAITING"] = 2] = "WAITING";
    BridgeStatus[BridgeStatus["CLOSED"] = 3] = "CLOSED";
    BridgeStatus[BridgeStatus["UNKNOWN"] = 4] = "UNKNOWN";
})(BridgeStatus = exports.BridgeStatus || (exports.BridgeStatus = {}));
var BridgeRole;
(function (BridgeRole) {
    BridgeRole[BridgeRole["SERVER"] = 1] = "SERVER";
    BridgeRole[BridgeRole["CLIENT"] = 2] = "CLIENT";
})(BridgeRole = exports.BridgeRole || (exports.BridgeRole = {}));
class BridgeMessage {
}
exports.BridgeMessage = BridgeMessage;
exports.FrameStreamOptions = {
    lengthSize: 2
};
class KeusSocket extends net.Socket {
}
exports.KeusSocket = KeusSocket;
//# sourceMappingURL=shared.js.map