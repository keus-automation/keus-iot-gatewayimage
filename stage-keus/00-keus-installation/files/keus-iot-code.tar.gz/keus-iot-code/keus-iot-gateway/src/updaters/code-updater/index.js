"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RootPath = '../../../';
exports.default = {};
//# sourceMappingURL=index.js.map