"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generatedAreaIdsStartIndex = 10;
exports.generateAreaId = function (availableAreaIds) {
    let newAreaId = null;
    for (let i = exports.generatedAreaIdsStartIndex; i < 200; i++) {
        if (availableAreaIds.indexOf(i) < 0) {
            newAreaId = i;
            break;
        }
    }
    return newAreaId;
};
//# sourceMappingURL=area.js.map