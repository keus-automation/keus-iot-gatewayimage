"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../constants/gateway/system-constants");
const any_pb_1 = require("google-protobuf/google/protobuf/any_pb");
exports.generateGatewayDeviceManagerInteractionResponse = (response, responseConstructorName) => {
    let responseObj = new any_pb_1.Any();
    responseObj.pack(response.serializeBinary(), system_constants_1.DeviceManager.ProtoPackageName + '.' + responseConstructorName);
    return responseObj;
};
//# sourceMappingURL=communication.js.map