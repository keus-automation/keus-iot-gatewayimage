"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dm_model_constants_1 = require("../../constants/gateway/dm-model-constants");
const device_constants_pb_1 = require("../../app/device-manager/providers/generated/devices/device_constants_pb");
const device_constants_pb_2 = require("../../app/hub-request-manager/protos/generated/hub/devices/device_constants_pb");
const zigbee_ac_fan_controller_pb_1 = require("../../app/device-manager/providers/generated/devices/zigbee_ac_fan_controller_pb");
const zigbee_dc_fan_controller_pb_1 = require("../../app/device-manager/providers/generated/devices/zigbee_dc_fan_controller_pb");
const multigateway_1 = __importDefault(require("../../configs/multigateway"));
const SmartConsole = __importStar(require("../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-smartconsole/metadata"));
const SceneWizard = __importStar(require("../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-scenewizard/metadata"));
const Dali = __importStar(require("../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-dali/metadata"));
const Curtains = __importStar(require("../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-curtains/metadata"));
const Fans = __importStar(require("../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-fans/metadata"));
const Embedded = __importStar(require("../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-embedded/metadata"));
const SceneSwitch = __importStar(require("../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-sceneswitch/metadata"));
const keus_dm_device_zigbee_1 = __importDefault(require("../../models/database-models/keus-dm-device-zigbee"));
const system_constants_1 = require("../../constants/gateway/system-constants");
const zigbee_globals_1 = require("../../constants/gateway/zigbee-globals");
const device_types_1 = require("../../constants/device/device-types");
const DALIPrefix = 'DALI-';
exports.getDeviceShortAddrArr = (shortAddr) => {
    let shortAddrArr = new Uint16Array([shortAddr]);
    let uint8Arr = new Uint8Array(shortAddrArr.buffer);
    return [uint8Arr[0], uint8Arr[1]];
};
exports.getDeviceLongAddrArr = (longAddr) => {
    let longAddrArr = [];
    let longAddrLen = longAddr.length - 2;
    for (let i = longAddrLen; i >= 2; i = i - 2) {
        let ele = parseInt('0x' + longAddr[i] + longAddr[i + 1]);
        longAddrArr.push(ele);
    }
    return longAddrArr;
};
exports.getConstructedDaliDeviceId = (zigbeeBridgeAddr, daliAddr) => {
    return DALIPrefix + zigbeeBridgeAddr + '-' + daliAddr;
};
exports.identifyDaliDevice = (deviceId) => {
    if (deviceId.indexOf(DALIPrefix) < 0) {
        return false;
    }
    else {
        return true;
    }
};
exports.getDeconstructedDaliDeviceId = (daliDeviceId) => {
    let prefixIndex = daliDeviceId.indexOf(DALIPrefix);
    let strippedDaliId = daliDeviceId.substr((prefixIndex + DALIPrefix.length), daliDeviceId.length);
    let splitIdArr = strippedDaliId.split('-');
    return {
        zigbeeBridgeAddr: splitIdArr[0],
        daliAddr: parseInt(splitIdArr[1])
    };
};
exports.convertDaliTempToMIREK = (temp) => {
    let mirekTemp = 1000000 / temp;
    return {
        loByte: (mirekTemp & 0xFF),
        hiByte: ((mirekTemp >> 8) & 0xFF)
    };
};
exports.getGatewayKeyByGId = (gatewayId) => {
    return (gatewayId ? gatewayId : system_constants_1.MultiGateway.MAIN_GATEWAY_ID);
};
exports.getGatewayKeyByZDeviceId = async (deviceId) => {
    let deviceInfo = await keus_dm_device_zigbee_1.default.getDeviceById(deviceId);
    let gatewayKey = exports.getGatewayKeyByGId(deviceInfo.minigatewayId);
    return gatewayKey;
};
exports.getRemappedSmartConsoleButtonType = (buttonType) => {
    switch (buttonType) {
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_CURTAINCONTROLLER:
            return SmartConsole.ButtonTypes.CURTAIN;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_DEC:
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_INC:
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_LIGHTDEC:
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_LIGHTINC:
            return SmartConsole.ButtonTypes.INCDEC;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_FANCONTROLLER:
            return SmartConsole.ButtonTypes.FAN;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_GROUP:
            return SmartConsole.ButtonTypes.GROUP;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_RELAYCONTROLLER:
            return SmartConsole.ButtonTypes.RELAY;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_REMOTERELAY:
            return SmartConsole.ButtonTypes.GROUP;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_SCENE:
            return SmartConsole.ButtonTypes.SCENE;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_UNCONFIGURED:
            return SmartConsole.ButtonTypes.UNCONFIGURED;
    }
};
exports.getRemappedSceneWizardButtonType = (buttonType) => {
    switch (buttonType) {
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_CURTAINCONTROLLER:
            return SceneWizard.ButtonTypes.CURTAIN;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_DEC:
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_INC:
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_LIGHTDEC:
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_LIGHTINC:
            return SceneWizard.ButtonTypes.INCDEC;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_FANCONTROLLER:
            return SceneWizard.ButtonTypes.FAN;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_GROUP:
            return SceneWizard.ButtonTypes.GROUP;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_REMOTERELAY:
            return SceneWizard.ButtonTypes.GROUP;
        case device_constants_pb_1.DMSMART_CONSOLE_BUTTON_TYPES.SC_SCENE:
            return SceneWizard.ButtonTypes.SCENE;
    }
};
exports.getRemappedCurtainAction = (curtainAction) => {
    switch (curtainAction) {
        case device_constants_pb_1.DMCURTAIN_CONTROLLER_ACTION.CC_NONE:
            return Curtains.Action.PAUSE;
        case device_constants_pb_1.DMCURTAIN_CONTROLLER_ACTION.CC_OPEN:
            return Curtains.Action.OPEN;
        case device_constants_pb_1.DMCURTAIN_CONTROLLER_ACTION.CC_CLOSE:
            return Curtains.Action.CLOSE;
        case device_constants_pb_1.DMCURTAIN_CONTROLLER_ACTION.CC_PAUSE:
            return Curtains.Action.PAUSE;
    }
};
exports.getRemappedAcFanAction = (fanAction) => {
    switch (fanAction) {
        case zigbee_ac_fan_controller_pb_1.DMAC_FAN_CONTROLLER_STATES.AC_OFF:
            return Fans.Levels.OFF;
        case zigbee_ac_fan_controller_pb_1.DMAC_FAN_CONTROLLER_STATES.AC_LOW:
            return Fans.Levels.LOW;
        case zigbee_ac_fan_controller_pb_1.DMAC_FAN_CONTROLLER_STATES.AC_MED:
            return Fans.Levels.MED;
        case zigbee_ac_fan_controller_pb_1.DMAC_FAN_CONTROLLER_STATES.AC_HIGH:
            return Fans.Levels.HIGH;
        case zigbee_ac_fan_controller_pb_1.DMAC_FAN_CONTROLLER_STATES.AC_MAX:
            return Fans.Levels.MAX;
    }
};
exports.getRemappedDcFanAction = (fanAction) => {
    switch (fanAction) {
        case zigbee_dc_fan_controller_pb_1.DMDC_FAN_CONTROLLER_STATES.DC_OFF:
            return { actionType: Fans.Types.LEVEL, level: Fans.Levels.OFF };
        case zigbee_dc_fan_controller_pb_1.DMDC_FAN_CONTROLLER_STATES.DC_LOW:
            return { actionType: Fans.Types.LEVEL, level: Fans.Levels.LOW };
        case zigbee_dc_fan_controller_pb_1.DMDC_FAN_CONTROLLER_STATES.DC_MED:
            return { actionType: Fans.Types.LEVEL, level: Fans.Levels.MED };
        case zigbee_dc_fan_controller_pb_1.DMDC_FAN_CONTROLLER_STATES.DC_HIGH:
            return { actionType: Fans.Types.LEVEL, level: Fans.Levels.HIGH };
        case zigbee_dc_fan_controller_pb_1.DMDC_FAN_CONTROLLER_STATES.DC_MAX:
            return { actionType: Fans.Types.LEVEL, level: Fans.Levels.MAX };
        case zigbee_dc_fan_controller_pb_1.DMDC_FAN_CONTROLLER_STATES.DC_NW:
            return { actionType: Fans.Types.MODE, mode: Fans.Modes.NATURE_WIND };
        case (zigbee_dc_fan_controller_pb_1.DMDC_FAN_CONTROLLER_STATES.DC_REVERSE_OFF):
            return { actionType: Fans.Types.MODE, mode: Fans.Modes.FORWARD };
        case (zigbee_dc_fan_controller_pb_1.DMDC_FAN_CONTROLLER_STATES.DC_REVERSE_ON):
            return { actionType: Fans.Types.MODE, mode: Fans.Modes.REVERSE };
    }
};
exports.getRemappedDaliFadeRate = (timeInMilliSeconds) => {
    let timeInCentiSeconds = timeInMilliSeconds / 10;
    if (timeInCentiSeconds == 0) {
        return Dali.DaliFadeTimes.MIN;
    }
    else if (timeInCentiSeconds > 0 && timeInCentiSeconds <= 70) {
        return Dali.DaliFadeTimes.TIME0_7;
    }
    else if (timeInCentiSeconds > 70 && timeInCentiSeconds <= 100) {
        return Dali.DaliFadeTimes.TIME1_0;
    }
    else if (timeInCentiSeconds > 100 && timeInCentiSeconds <= 140) {
        return Dali.DaliFadeTimes.TIME1_4;
    }
    else if (timeInCentiSeconds > 140 && timeInCentiSeconds <= 200) {
        return Dali.DaliFadeTimes.TIME2_0;
    }
    else if (timeInCentiSeconds > 200 && timeInCentiSeconds <= 280) {
        return Dali.DaliFadeTimes.TIME2_8;
    }
    else if (timeInCentiSeconds > 280 && timeInCentiSeconds <= 400) {
        return Dali.DaliFadeTimes.TIME4_0;
    }
    else if (timeInCentiSeconds > 400 && timeInCentiSeconds <= 560) {
        return Dali.DaliFadeTimes.TIME5_6;
    }
    else if (timeInCentiSeconds > 560 && timeInCentiSeconds <= 800) {
        return Dali.DaliFadeTimes.TIME8_0;
    }
    else if (timeInCentiSeconds > 800 && timeInCentiSeconds <= 1130) {
        return Dali.DaliFadeTimes.TIME11_3;
    }
    else if (timeInCentiSeconds > 1130 && timeInCentiSeconds <= 1600) {
        return Dali.DaliFadeTimes.TIME16_0;
    }
    else if (timeInCentiSeconds > 1600 && timeInCentiSeconds <= 2260) {
        return Dali.DaliFadeTimes.TIME22_6;
    }
    else if (timeInCentiSeconds > 2260 && timeInCentiSeconds <= 3200) {
        return Dali.DaliFadeTimes.TIME32_0;
    }
    else if (timeInCentiSeconds > 3200 && timeInCentiSeconds <= 4520) {
        return Dali.DaliFadeTimes.TIME45_2;
    }
    else if (timeInCentiSeconds > 4520 && timeInCentiSeconds <= 6400) {
        return Dali.DaliFadeTimes.TIME64_0;
    }
    else if (timeInCentiSeconds > 6400 && timeInCentiSeconds <= 9050) {
        return Dali.DaliFadeTimes.TIME90_5;
    }
    else {
        return Dali.DaliFadeTimes.TIME1_0;
    }
};
exports.getUint8Mask = (bitNo) => {
    let Mask = 0b00000000;
    Mask |= 1 << bitNo;
    return Mask;
};
exports.getRelayIdsMask = (relayIds) => {
    let finalIdMask = 0b00000000;
    for (let i = 0; i < relayIds.length; i++) {
        finalIdMask |= (1 << relayIds[i]);
    }
    return finalIdMask;
};
exports.getRelaysStateMask = (relayIds, areOn) => {
    let finalStateMask = 0b00000000;
    for (let i = 0; i < relayIds.length; i++) {
        if (areOn[i]) {
            finalStateMask |= (1 << relayIds[i]);
        }
    }
    return finalStateMask;
};
// Currently only dali and zigbee devices are implemented
exports.categoriseDeviceById = (deviceId) => {
    let isDaliDevice = exports.identifyDaliDevice(deviceId);
    if (isDaliDevice) {
        return dm_model_constants_1.DMBaseDeviceType.DALI_DEVICE;
    }
    else {
        return dm_model_constants_1.DMBaseDeviceType.ZIGBEE_DEVICE;
    }
};
const IRRemoteTypeFolderName = {};
exports.IRRemoteTypeFolderName = IRRemoteTypeFolderName;
IRRemoteTypeFolderName[device_constants_pb_2.IR_REMOTE_TYPES.IR_AC] = 'ac';
IRRemoteTypeFolderName[device_constants_pb_2.IR_REMOTE_TYPES.IR_AMP] = 'amp';
IRRemoteTypeFolderName[device_constants_pb_2.IR_REMOTE_TYPES.IR_FAN] = 'fan';
IRRemoteTypeFolderName[device_constants_pb_2.IR_REMOTE_TYPES.IR_PR] = 'pr';
IRRemoteTypeFolderName[device_constants_pb_2.IR_REMOTE_TYPES.IR_TV] = 'tv';
exports.getIRRemoteFileName = (remoteCompanyId, remoteModelId, remoteType) => {
    return multigateway_1.default.irFilesPath + IRRemoteTypeFolderName[remoteType] + '/' + remoteCompanyId + '_' + remoteModelId;
};
exports.generateApplianceId = (appliances) => {
    let applianceId = null;
    let applianceIds = [];
    appliances.forEach((appliance) => {
        applianceIds.push(appliance.id);
    });
    // general appliance id
    for (let i = 0; i < 20; i++) {
        if (applianceIds.indexOf(i) < 0) {
            applianceId = i;
            break;
        }
    }
    return applianceId;
};
exports.getMappedDeviceType = (zigbeeDeviceCategory, zigbeeDeviceType) => {
    console.log(zigbee_globals_1.DEVICE_META_INFO);
    let deviceMetadata = zigbee_globals_1.DEVICE_CATEGORIES_REVERSE_MAP[zigbeeDeviceCategory];
    return deviceMetadata.types[zigbeeDeviceType];
};
exports.getDefaultEmbeddedConfiguration = (deviceCategory, deviceType) => {
    let outputChannels = zigbee_globals_1.DEVICE_META_INFO
        .deviceCategories
        .EMBEDDEDSWITCH
        .outputChannels[exports.getMappedDeviceType(deviceCategory, deviceType)];
    let appliances = [];
    let switches = [];
    for (let i = 0; i < outputChannels; i++) {
        appliances.push({
            id: i,
            type: Embedded.EmbeddedSwitchTypes.ON_OFF,
            gType: device_constants_pb_1.DMEMBEDDED_APPLIANCE_TYPES.ON_OFF,
            gid: i.toString(),
            outputIds: [i],
            state: [0]
        });
        switches.push({
            id: i,
            type: Embedded.EmbeddedPropTargets.APPLIANCE,
            gType: device_constants_pb_1.DMEMBEDDED_SWITCH_TYPES.APPLIANCE,
            typeTarget: {
                applianceId: i
            },
            state: 0
        });
    }
    return {
        appliances: appliances,
        switches: switches
    };
};
exports.getDefaultRGBWWAConfiguration = (deviceCategory, deviceType) => {
    return {
        appliances: [{
                id: 1,
                channels: [0, 1, 2, 3, 4, 5]
            }]
    };
};
exports.getDefaultSceneSwitchConfiguration = (deviceCategory, deviceType) => {
    if (deviceType === zigbee_globals_1.DEVICE_META_INFO.deviceCategories.SCENESWITCH.types[device_types_1.TypeMap.KZESS01]) {
        return {
            executionType: SceneSwitch.ExecutionTypes.LOCAL,
            batteryLevel: 0,
            sceneMap: [0xFF, 0xFF, 0xFF, 0xFF]
        };
    }
    else if (deviceType === zigbee_globals_1.DEVICE_META_INFO.deviceCategories.SCENESWITCH.types[device_types_1.TypeMap.KZESS10]) {
        return {
            executionType: SceneSwitch.ExecutionTypes.HUB,
            batteryLevel: 0,
            sceneMap: [0xFF, 0xFF, 0xFF, 0xFF]
        };
    }
};
exports.getRGBWWAStatesArray = function (updateType, deviceState, channelStates) {
    if (updateType === device_constants_pb_1.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
        return [
            deviceState[0] > 0 ? channelStates[0] : 0,
            deviceState[0] > 0 ? channelStates[1] : 0,
            deviceState[0] > 0 ? channelStates[2] : 0,
            0, 0, 0
        ];
    }
    else if (updateType === device_constants_pb_1.DMRGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
        return [
            0, 0, 0,
            deviceState[1] > 0 ? channelStates[3] : 0,
            deviceState[1] > 0 ? channelStates[4] : 0,
            deviceState[1] > 0 ? channelStates[5] : 0
        ];
    }
};
//# sourceMappingURL=device.js.map