"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const general_1 = require("../general");
const metadata_1 = require("../../app/device-manager/zigbee-device-manager/keus-communication/cluster-declarations/cluster-groups/metadata");
exports.GlobalGroupAreaId = 0x01;
exports.MinGroupId = 20;
exports.MaxGroupId = 125;
exports.NumGroupIds = exports.MaxGroupId - exports.MinGroupId;
exports.MinDaliGroupId = 0;
exports.MaxDaliGroupId = 15;
exports.formGroupId = (areaId, areaGroupId) => {
    return parseInt(new Uint16Array(new Uint8Array([areaGroupId, areaId]).buffer).toString());
};
exports.getAreaGroupIdFromGroupId = (groupId) => {
    return general_1.GetUint16LowByte(groupId);
};
exports.getAreaIdFromGroupId = (groupId) => {
    return general_1.GetUint16HighByte(groupId);
};
// export const getGroupMember = (groupDevices: KeusDM) => {
// }
exports.generateAreaGroupId = (existingGroupIds, areaId) => {
    if (existingGroupIds.length == 0) {
        return {
            areaId: areaId,
            areaGroupId: exports.MinGroupId,
            groupId: exports.formGroupId(areaId, exports.MinGroupId)
        };
    }
    let maxGroupId = Math.max(...existingGroupIds);
    let newAreaGroupId = maxGroupId + 1;
    if (newAreaGroupId > exports.MaxGroupId) {
        for (let i = exports.MinGroupId; i < exports.MaxGroupId; i++) {
            if (existingGroupIds.indexOf(i) < 0) {
                newAreaGroupId = i;
                break;
            }
        }
    }
    else if (newAreaGroupId < exports.MinGroupId) {
        newAreaGroupId = exports.MinGroupId;
    }
    let newGroupId = exports.formGroupId(areaId, newAreaGroupId);
    return {
        areaId: areaId,
        areaGroupId: newAreaGroupId,
        groupId: newGroupId
    };
};
exports.generateDaliGroupId = (existingGroupIds) => {
    let groupId = null;
    for (let i = exports.MinDaliGroupId; i <= exports.MaxDaliGroupId; i++) {
        if (existingGroupIds.indexOf(i) < 0) {
            groupId = i;
            break;
        }
    }
    if (groupId == null) {
        throw new Error("No Dali Groups left on this master");
    }
    return groupId;
};
const getCategoryDefaultGroup = (areaId, deviceCategory, deviceType) => {
    let mappedId = 'C' + deviceCategory + '' + deviceType;
    switch (mappedId) {
        // SMART CONSOLE
        case 'C41':
        case 'C42':
            return [{
                    groupId: exports.formGroupId(areaId, 0x07),
                    groupType: 0x00,
                    mode: metadata_1.GroupModes.SELF,
                    areaGroupId: 0x07,
                    areaId: areaId
                }, {
                    groupId: exports.formGroupId(areaId, 0x05),
                    groupType: 0x00,
                    mode: metadata_1.GroupModes.SELF,
                    areaGroupId: 0x05,
                    areaId: areaId
                }];
        // BLINDS
        case 'C21':
        case 'C22':
        case 'C2242':
            return [{
                    groupId: exports.formGroupId(areaId, 0x04),
                    groupType: 0x00,
                    mode: metadata_1.GroupModes.SELF,
                    areaGroupId: 0x04,
                    areaId: areaId
                }];
        // LED DRIVERS
        case 'C51':
        case 'C52':
        case 'C53':
        case 'C54':
            return [{
                    groupId: exports.formGroupId(areaId, 0x08),
                    groupType: 0x00,
                    mode: metadata_1.GroupModes.SELF,
                    areaGroupId: 0x08,
                    areaId: areaId
                }];
        // FANS
        case 'C61':
        case 'C62':
            return [{
                    groupId: exports.formGroupId(areaId, 0x05),
                    groupType: 0x00,
                    mode: metadata_1.GroupModes.SELF,
                    areaGroupId: 0x05,
                    areaId: areaId
                }];
    }
};
/**
 * Global Group - 0x0101
 * Area Group Id - 0x (Area Id) (0x01)
 * Device Category Group Id - 0x (AreaId) (CategoryDefaultId)
 *
 * @param deviceInfo
 */
exports.getDefaultGroupsInfo = (areaId, deviceCategory, deviceType) => {
    let groupInfoArr = [{
            groupId: exports.formGroupId(exports.GlobalGroupAreaId, 0x01),
            groupType: 0x00,
            mode: metadata_1.GroupModes.SELF,
            areaGroupId: 0x01,
            areaId: exports.GlobalGroupAreaId
        }, {
            groupId: exports.formGroupId(areaId, 0x01),
            groupType: 0x00,
            mode: metadata_1.GroupModes.SELF,
            areaGroupId: 0x01,
            areaId: areaId
        }];
    let catergoryDefaultGroups = getCategoryDefaultGroup(areaId, deviceCategory, deviceType);
    if (catergoryDefaultGroups) {
        groupInfoArr = groupInfoArr.concat(catergoryDefaultGroups);
    }
    return groupInfoArr;
};
//# sourceMappingURL=group.js.map