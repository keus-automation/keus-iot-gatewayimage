"use strict";
// IR utility methods
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_ir_blaster_pb_1 = require("../../app/hub-request-manager/protos/generated/hub/devices/zigbee_ir_blaster_pb");
/*

changes required in generated proto

export enum TV_BLAST_TYPES {
    TV_MENU_EXT = 16,
}

export enum PR_BLAST_TYPES {
    PR_VOL_INC = 3,
    PR_VOL_DEC = 4,
    PR_VOL_MUTE = 7,
}

export enum FAN_BLAST_TYPES {
    FAN_SPEED_OPTIONS = 5,
    FAN_SWING = 6,
}

*/
//types of remotes
var IrTypes;
(function (IrTypes) {
    IrTypes[IrTypes["AC"] = 1] = "AC";
    IrTypes[IrTypes["TV"] = 2] = "TV";
    IrTypes[IrTypes["PRJ"] = 3] = "PRJ";
    IrTypes[IrTypes["FAN"] = 4] = "FAN";
    IrTypes[IrTypes["AMP"] = 5] = "AMP";
})(IrTypes = exports.IrTypes || (exports.IrTypes = {}));
;
var GenProps;
(function (GenProps) {
    GenProps[GenProps["BRAND"] = 1] = "BRAND";
    GenProps[GenProps["MODEL"] = 2] = "MODEL";
    GenProps[GenProps["PROTOCOL"] = 3] = "PROTOCOL";
    GenProps[GenProps["TYPE"] = 4] = "TYPE";
    GenProps[GenProps["IMAGE"] = 5] = "IMAGE";
    GenProps[GenProps["VERSION"] = 6] = "VERSION";
    GenProps[GenProps["CONFIG_COUNT"] = 7] = "CONFIG_COUNT";
})(GenProps = exports.GenProps || (exports.GenProps = {}));
;
exports.generateConfigIds = (configIds, numConfigs) => {
    let newConfigIds = [];
    for (let i = 0; i < numConfigs; i++) {
        for (let j = 1; j < 100; j++) {
            console.log('try', i, j);
            if (configIds.indexOf(j) < 0 && newConfigIds.indexOf(j) < 0) {
                newConfigIds.push(j);
                break;
            }
        }
    }
    return newConfigIds;
};
/***********************************
 * Utility functions
 */
class IRUtils {
    binaryReverse(data) {
        var revNum = 0, i = 0, num = data.number, pow = data.pow;
        for (i = 0; i < pow; i++) {
            revNum = revNum | (num >> i & 1);
            revNum = revNum << 1;
        }
        revNum = revNum >> 1;
        return revNum;
    }
    binaryCompliment(data) {
        var revNum = 0, i = 0, num = data.number, pow = data.pow;
        //revNum = num ^ (Math.pow(2,pow) -1); //wont work for pow!=8
        revNum = (~num) & (Math.pow(2, pow) - 1);
        return revNum;
    }
}
exports.IRUtils = IRUtils;
/***********************************
 * AC Defines
 */
//modes usually available for ac remotes
var AcModes;
(function (AcModes) {
    AcModes["COOL"] = "COOL";
    AcModes["DRY"] = "DRY";
    AcModes["FAN"] = "FAN";
    AcModes["HEAT"] = "HEAT";
    AcModes["AUTO"] = "AUTO";
})(AcModes = exports.AcModes || (exports.AcModes = {}));
;
//fan options usually available for ac remotes 
var AcFanOptions;
(function (AcFanOptions) {
    AcFanOptions["OFF"] = "OFF";
    AcFanOptions["LOW"] = "LOW";
    AcFanOptions["MED"] = "MEDIUM";
    AcFanOptions["HIGH"] = "HIGH";
    AcFanOptions["AUTO"] = "AUTO";
})(AcFanOptions = exports.AcFanOptions || (exports.AcFanOptions = {}));
;
//swing options usually available for ac remotes 
var AcSwingOptions;
(function (AcSwingOptions) {
    AcSwingOptions["OFF"] = "OFF";
    AcSwingOptions["LEVEL_1"] = "LVL 1";
    AcSwingOptions["LEVEL_2"] = "LVL 2";
    AcSwingOptions["LEVEL_3"] = "LVL 3";
    AcSwingOptions["AUTO"] = "AUTO";
})(AcSwingOptions = exports.AcSwingOptions || (exports.AcSwingOptions = {}));
//update types/unique button presses available for AC
var AcUpdateTypes;
(function (AcUpdateTypes) {
    AcUpdateTypes[AcUpdateTypes["ON_OFF"] = 1] = "ON_OFF";
    AcUpdateTypes[AcUpdateTypes["TEMP_INC"] = 2] = "TEMP_INC";
    AcUpdateTypes[AcUpdateTypes["TEMP_DEC"] = 3] = "TEMP_DEC";
    AcUpdateTypes[AcUpdateTypes["MODE_SELECT"] = 4] = "MODE_SELECT";
    AcUpdateTypes[AcUpdateTypes["FAN_SELECT"] = 5] = "FAN_SELECT";
    AcUpdateTypes[AcUpdateTypes["VSWING_SELECT"] = 6] = "VSWING_SELECT";
    AcUpdateTypes[AcUpdateTypes["HSWING_SELECT"] = 7] = "HSWING_SELECT";
})(AcUpdateTypes = exports.AcUpdateTypes || (exports.AcUpdateTypes = {}));
/*
_LIST => will return an array of different modes to be listed in drop down
_OPTIONS => will return an array of different modes that can be selected through differnt buttons
*/
var AcProps;
(function (AcProps) {
    AcProps[AcProps["TEMP_MIN"] = 0] = "TEMP_MIN";
    AcProps[AcProps["TEMP_MAX"] = 1] = "TEMP_MAX";
    AcProps[AcProps["MODE_BUTTON"] = 2] = "MODE_BUTTON";
    AcProps[AcProps["MODE_LIST"] = 3] = "MODE_LIST";
    AcProps[AcProps["MODE_OPTIONS"] = 4] = "MODE_OPTIONS";
    AcProps[AcProps["FAN_BUTTON"] = 5] = "FAN_BUTTON";
    AcProps[AcProps["FAN_LIST"] = 6] = "FAN_LIST";
    AcProps[AcProps["FAN_OPTIONS"] = 7] = "FAN_OPTIONS";
    AcProps[AcProps["VSWING_BUTTON"] = 8] = "VSWING_BUTTON";
    AcProps[AcProps["VSWING_LIST"] = 9] = "VSWING_LIST";
    AcProps[AcProps["VSWING_OPTIONS"] = 10] = "VSWING_OPTIONS";
    AcProps[AcProps["HSWING_BUTTON"] = 11] = "HSWING_BUTTON";
    AcProps[AcProps["HSWING_LIST"] = 12] = "HSWING_LIST";
    AcProps[AcProps["HSWING_OPTIONS"] = 13] = "HSWING_OPTIONS";
})(AcProps = exports.AcProps || (exports.AcProps = {}));
exports.generateTemperatureRangeList = (min, max) => {
    let list = [];
    for (let i = min; i <= max; i++) {
        list.push(i);
    }
    return list;
};
exports.getAcRemappedUpdateType = (updateType) => {
    switch (updateType) {
        case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_ONOFF:
            return [AcUpdateTypes.ON_OFF];
        case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_MODE:
            return [AcUpdateTypes.MODE_SELECT];
        case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_FANLVL:
            return [AcUpdateTypes.FAN_SELECT];
        case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_TEMPERATURE:
            return [AcUpdateTypes.TEMP_INC]; //only one update, needs both inc and dec for some cases
        case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_TEMPERATURE:
            return [AcUpdateTypes.TEMP_INC]; //only one update, needs both inc and dec for some cases
        case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_SWINGV:
            return [AcUpdateTypes.VSWING_SELECT];
        case zigbee_ir_blaster_pb_1.AC_BLAST_TYPES.AC_SWINGH:
            return [AcUpdateTypes.HSWING_SELECT];
    }
};
/***********************************
 * TV Defines
 */
//Props need to be defined for UI display
var TvProps;
(function (TvProps) {
    TvProps[TvProps["ON_OFF_COMBINED"] = 1] = "ON_OFF_COMBINED";
    TvProps[TvProps["ON_OFF_SEPARATE"] = 2] = "ON_OFF_SEPARATE";
    TvProps[TvProps["SOURCE_BUTTON"] = 3] = "SOURCE_BUTTON";
    TvProps[TvProps["SOURCE_LIST"] = 4] = "SOURCE_LIST";
    TvProps[TvProps["SOURCE_OPTIONS"] = 5] = "SOURCE_OPTIONS";
    TvProps[TvProps["VOLUME_CONTROLS"] = 6] = "VOLUME_CONTROLS";
    TvProps[TvProps["MENU"] = 7] = "MENU";
    TvProps[TvProps["CHANNEL_CONTROLS"] = 8] = "CHANNEL_CONTROLS";
    TvProps[TvProps["NUM_PAD"] = 9] = "NUM_PAD";
    TvProps[TvProps["EXTENDED_MENU"] = 10] = "EXTENDED_MENU"; //num pad present
})(TvProps = exports.TvProps || (exports.TvProps = {}));
//update types/unique button presses available for TVs
var TvUpdateTypes;
(function (TvUpdateTypes) {
    TvUpdateTypes[TvUpdateTypes["ON_OFF"] = 0] = "ON_OFF";
    TvUpdateTypes[TvUpdateTypes["CHANNEL_INC"] = 1] = "CHANNEL_INC";
    TvUpdateTypes[TvUpdateTypes["CHANNEL_DEC"] = 2] = "CHANNEL_DEC";
    TvUpdateTypes[TvUpdateTypes["VOLUME_INC"] = 3] = "VOLUME_INC";
    TvUpdateTypes[TvUpdateTypes["VOLUME_DEC"] = 4] = "VOLUME_DEC";
    TvUpdateTypes[TvUpdateTypes["VOLUME_MUTE"] = 7] = "VOLUME_MUTE";
    TvUpdateTypes[TvUpdateTypes["NUM_PAD"] = 5] = "NUM_PAD";
    TvUpdateTypes[TvUpdateTypes["SOURCE"] = 6] = "SOURCE";
    TvUpdateTypes[TvUpdateTypes["MENU_OPEN"] = 13] = "MENU_OPEN";
    TvUpdateTypes[TvUpdateTypes["MENU_LEFT"] = 8] = "MENU_LEFT";
    TvUpdateTypes[TvUpdateTypes["MENU_RIGHT"] = 9] = "MENU_RIGHT";
    TvUpdateTypes[TvUpdateTypes["MENU_UP"] = 10] = "MENU_UP";
    TvUpdateTypes[TvUpdateTypes["MENU_DOWN"] = 11] = "MENU_DOWN";
    TvUpdateTypes[TvUpdateTypes["MENU_OK"] = 12] = "MENU_OK";
    TvUpdateTypes[TvUpdateTypes["MENU_CLOSE"] = 14] = "MENU_CLOSE";
    // EXTENDED_MENU = TV_BLAST_TYPES.TV_MENU_EXT
    TvUpdateTypes[TvUpdateTypes["EXTENDED_MENU"] = 16] = "EXTENDED_MENU";
})(TvUpdateTypes = exports.TvUpdateTypes || (exports.TvUpdateTypes = {}));
exports.getTvRemappedUpdateType = (updateType) => {
    return [updateType];
};
/***********************************
 * Amplifier Defines
 */
//Props need to be defined for UI display
var AmpProps;
(function (AmpProps) {
    AmpProps[AmpProps["ON_OFF_COMBINED"] = 1] = "ON_OFF_COMBINED";
    AmpProps[AmpProps["ON_OFF_SEPARATE"] = 2] = "ON_OFF_SEPARATE";
    AmpProps[AmpProps["SOURCE_BUTTON"] = 3] = "SOURCE_BUTTON";
    AmpProps[AmpProps["SOURCE_LIST"] = 4] = "SOURCE_LIST";
    AmpProps[AmpProps["SOURCE_OPTIONS"] = 5] = "SOURCE_OPTIONS";
    AmpProps[AmpProps["VOLUME_CONTROLS"] = 6] = "VOLUME_CONTROLS";
    AmpProps[AmpProps["MENU"] = 7] = "MENU"; //menu available
})(AmpProps = exports.AmpProps || (exports.AmpProps = {}));
//update types/unique button presses available for Amplifiers
var AmpUpdateTypes;
(function (AmpUpdateTypes) {
    AmpUpdateTypes[AmpUpdateTypes["ON_OFF"] = 0] = "ON_OFF";
    AmpUpdateTypes[AmpUpdateTypes["SOURCE"] = 6] = "SOURCE";
    AmpUpdateTypes[AmpUpdateTypes["VOLUME_INC"] = 3] = "VOLUME_INC";
    AmpUpdateTypes[AmpUpdateTypes["VOLUME_DEC"] = 4] = "VOLUME_DEC";
    AmpUpdateTypes[AmpUpdateTypes["VOLUME_MUTE"] = 7] = "VOLUME_MUTE";
    AmpUpdateTypes[AmpUpdateTypes["MENU_OPEN"] = 13] = "MENU_OPEN";
    AmpUpdateTypes[AmpUpdateTypes["MENU_LEFT"] = 8] = "MENU_LEFT";
    AmpUpdateTypes[AmpUpdateTypes["MENU_RIGHT"] = 9] = "MENU_RIGHT";
    AmpUpdateTypes[AmpUpdateTypes["MENU_UP"] = 10] = "MENU_UP";
    AmpUpdateTypes[AmpUpdateTypes["MENU_DOWN"] = 11] = "MENU_DOWN";
    AmpUpdateTypes[AmpUpdateTypes["MENU_OK"] = 12] = "MENU_OK";
    AmpUpdateTypes[AmpUpdateTypes["MENU_CLOSE"] = 14] = "MENU_CLOSE";
})(AmpUpdateTypes = exports.AmpUpdateTypes || (exports.AmpUpdateTypes = {}));
exports.getAmpRemappedUpdateType = (updateType) => {
    return [updateType];
};
/***********************************
 * Projector Defines
 */
//Props need to be defined for UI display
var PrProps;
(function (PrProps) {
    PrProps[PrProps["ON_OFF_COMBINED"] = 1] = "ON_OFF_COMBINED";
    PrProps[PrProps["ON_OFF_SEPARATE"] = 2] = "ON_OFF_SEPARATE";
    PrProps[PrProps["SOURCE_BUTTON"] = 3] = "SOURCE_BUTTON";
    PrProps[PrProps["SOURCE_LIST"] = 4] = "SOURCE_LIST";
    PrProps[PrProps["SOURCE_OPTIONS"] = 5] = "SOURCE_OPTIONS";
    PrProps[PrProps["VOLUME_CONTROLS"] = 6] = "VOLUME_CONTROLS";
    PrProps[PrProps["MENU"] = 7] = "MENU"; //menu available
})(PrProps = exports.PrProps || (exports.PrProps = {}));
//update types/unique button presses available for Projectors
var PrUpdateTypes;
(function (PrUpdateTypes) {
    PrUpdateTypes[PrUpdateTypes["ON_OFF"] = 0] = "ON_OFF";
    PrUpdateTypes[PrUpdateTypes["SOURCE"] = 6] = "SOURCE";
    //VOLUME_INC = PR_BLAST_TYPES.PR_VOL_INC,
    PrUpdateTypes[PrUpdateTypes["VOLUME_INC"] = 3] = "VOLUME_INC";
    //VOLUME_DEC = PR_BLAST_TYPES.PR_VOL_DEC,
    PrUpdateTypes[PrUpdateTypes["VOLUME_DEC"] = 4] = "VOLUME_DEC";
    //VOLUME_MUTE = PR_BLAST_TYPES.PR_VOL_MUTE,
    PrUpdateTypes[PrUpdateTypes["VOLUME_MUTE"] = 7] = "VOLUME_MUTE";
    PrUpdateTypes[PrUpdateTypes["MENU_OPEN"] = 13] = "MENU_OPEN";
    PrUpdateTypes[PrUpdateTypes["MENU_LEFT"] = 8] = "MENU_LEFT";
    PrUpdateTypes[PrUpdateTypes["MENU_RIGHT"] = 9] = "MENU_RIGHT";
    PrUpdateTypes[PrUpdateTypes["MENU_UP"] = 10] = "MENU_UP";
    PrUpdateTypes[PrUpdateTypes["MENU_DOWN"] = 11] = "MENU_DOWN";
    PrUpdateTypes[PrUpdateTypes["MENU_OK"] = 12] = "MENU_OK";
    PrUpdateTypes[PrUpdateTypes["MENU_CLOSE"] = 14] = "MENU_CLOSE";
})(PrUpdateTypes = exports.PrUpdateTypes || (exports.PrUpdateTypes = {}));
exports.getPrRemappedUpdateType = (updateType) => {
    return [updateType];
};
/***********************************
 * Fan Defines
 */
//Props need to be defined for UI display
var FanProps;
(function (FanProps) {
    FanProps[FanProps["ON_OFF_COMBINED"] = 0] = "ON_OFF_COMBINED";
    FanProps[FanProps["ON_OFF_SEPARATE"] = 1] = "ON_OFF_SEPARATE";
    FanProps[FanProps["LEVEL_BUTTON"] = 2] = "LEVEL_BUTTON";
    FanProps[FanProps["LEVEL_OPTIONS"] = 3] = "LEVEL_OPTIONS";
    FanProps[FanProps["LEVEL_INCDEC"] = 4] = "LEVEL_INCDEC";
    FanProps[FanProps["LIGHT"] = 5] = "LIGHT";
    FanProps[FanProps["BOOST"] = 6] = "BOOST";
    FanProps[FanProps["SWING_BUTTON"] = 7] = "SWING_BUTTON";
    FanProps[FanProps["SWING_LIST"] = 8] = "SWING_LIST";
    FanProps[FanProps["SWING_OPTIONS"] = 9] = "SWING_OPTIONS";
})(FanProps = exports.FanProps || (exports.FanProps = {}));
//update types/unique button presses available for Fans
var FanUpdateTypes;
(function (FanUpdateTypes) {
    FanUpdateTypes[FanUpdateTypes["ON_OFF"] = 0] = "ON_OFF";
    FanUpdateTypes[FanUpdateTypes["LEVEL_INC"] = 1] = "LEVEL_INC";
    FanUpdateTypes[FanUpdateTypes["LEVEL_DEC"] = 2] = "LEVEL_DEC";
    // LEVEL_OPTIONS = FAN_BLAST_TYPES.FAN_SPEED_OPTIONS,
    FanUpdateTypes[FanUpdateTypes["LEVEL"] = 5] = "LEVEL";
    FanUpdateTypes[FanUpdateTypes["LIGHT_CONTROL"] = 4] = "LIGHT_CONTROL";
    FanUpdateTypes[FanUpdateTypes["BOOST"] = 3] = "BOOST";
    // SWING = FAN_BLAST_TYPES.FAN_SWING,
    FanUpdateTypes[FanUpdateTypes["SWING"] = 6] = "SWING";
})(FanUpdateTypes = exports.FanUpdateTypes || (exports.FanUpdateTypes = {}));
exports.getFanRemappedUpdateType = (updateType) => {
    return [updateType];
};
//# sourceMappingURL=ir-utils.js.map