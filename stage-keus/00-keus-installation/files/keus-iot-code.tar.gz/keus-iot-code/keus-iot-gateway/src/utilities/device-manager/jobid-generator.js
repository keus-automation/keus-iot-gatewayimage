"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateDiscoverDALIJobId = (daliMasterId) => {
    return daliMasterId;
};
//# sourceMappingURL=jobid-generator.js.map