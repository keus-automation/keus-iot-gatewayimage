"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const general_1 = require("../general");
exports.GlobalSceneAreaId = 0x02;
exports.MinAreaSceneId = 150;
exports.MaxAreaSceneId = 225;
exports.NumSceneIds = exports.MaxAreaSceneId - exports.MinAreaSceneId;
exports.MinDaliSceneId = 0;
exports.MaxDaliSceneId = 15;
exports.formSceneId = (areaId, areaSceneId) => {
    return parseInt(new Uint16Array(new Uint8Array([areaSceneId, areaId]).buffer).toString());
};
exports.generateAreaSceneId = (existingSceneIds, areaId) => {
    if (existingSceneIds.length == 0) {
        return {
            areaId: areaId,
            areaSceneId: exports.MinAreaSceneId,
            sceneId: exports.formSceneId(areaId, exports.MinAreaSceneId)
        };
    }
    let maxAreaSceneId = Math.max(...existingSceneIds);
    let newAreaSceneId = maxAreaSceneId + 1;
    if (newAreaSceneId > exports.MaxAreaSceneId) {
        for (let i = exports.MinAreaSceneId; i < exports.MaxAreaSceneId; i++) {
            if (existingSceneIds.indexOf(i) < 0) {
                newAreaSceneId = i;
                break;
            }
        }
    }
    let newSceneId = exports.formSceneId(areaId, newAreaSceneId);
    return {
        areaId: areaId,
        areaSceneId: newAreaSceneId,
        sceneId: newSceneId
    };
};
exports.getAreaSceneIdFromSceneId = (sceneId) => {
    return general_1.GetUint16LowByte(sceneId);
};
exports.getAreaIdFromSceneId = (sceneId) => {
    return general_1.GetUint16HighByte(sceneId);
};
exports.generateDaliSceneId = (existingSceneIds) => {
    let sceneId = null;
    for (let i = exports.MinDaliSceneId; i <= exports.MaxDaliSceneId; i++) {
        if (existingSceneIds.indexOf(i) < 0) {
            sceneId = i;
            break;
        }
    }
    if (sceneId == null) {
        throw new Error("No Dali Scenes left on this master");
    }
    return sceneId;
};
exports.getGroupIdKeyForSceneStore = (groupId) => {
    return 'G' + groupId;
};
exports.getGroupIdFromSceneGroupIdKey = (groupKey) => {
    return parseInt(groupKey.substring(1, groupKey.legnth));
};
//# sourceMappingURL=scene.js.map