"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const rs = __importStar(require("randomstring"));
const device_categories_1 = __importDefault(require("../../constants/device/device-categories"));
const device_constants_pb_1 = require("../../app/hub-request-manager/protos/generated/hub/devices/device_constants_pb");
const zigbee_rgbwwa_driver_pb_1 = require("../../app/hub-request-manager/protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const activity_structures_pb_1 = require("../../app/hub-request-manager/protos/generated/hub/activity/activity_structures_pb");
const group_structures_pb_1 = require("../../app/hub-request-manager/protos/generated/hub/groups/group_structures_pb");
function generateActivityId() {
    let activityId = rs.generate(8);
    console.log('THIS IS GENERATED ID', activityId);
    return activityId;
}
exports.generateActivityId = generateActivityId;
async function getDeviceActivityObj(userDetails, deviceObj, roomDetails, updateStateData, optionalData) {
    let sectionDetails = roomDetails.sectionList.find(section => section.sectionId == deviceObj.deviceSection);
    function getDeviceAction(deviceData, updateStateData, optionalData) {
        switch (deviceData.deviceCategory) {
            case device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceCategoryCode:
                switch (updateStateData.getUpdateType()) {
                    case device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_FAN_UPDATE:
                        let zigbeeACFanActivityAction = {
                            fanState: updateStateData.getFanState()
                        };
                        return zigbeeACFanActivityAction;
                        break;
                    case device_constants_pb_1.AC_FAN_CONTROLLER_UPDATE_TYPE.AC_LIGHT_UPDATE:
                        let zigbeeACLightActivityAction = {
                            lightState: updateStateData.getLightState()
                        };
                        return zigbeeACLightActivityAction;
                        break;
                    default:
                        return {};
                        break;
                }
                break;
            case device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER').deviceCategoryCode:
                switch (updateStateData.getUpdateType()) {
                    case device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_FAN_UPDATE:
                        let zigbeeDCFanActivityAction = {
                            fanState: updateStateData.getFanState()
                        };
                        return zigbeeDCFanActivityAction;
                        break;
                    case device_constants_pb_1.DC_FAN_CONTROLLER_UPDATE_TYPE.DC_LIGHT_UPDATE:
                        let zigbeeDCLightActivityAction = {
                            lightState: updateStateData.getLightState(),
                            lightTemperature: updateStateData.getLightTemperature()
                        };
                        return zigbeeDCLightActivityAction;
                        break;
                    default:
                        return {};
                        break;
                }
                break;
            case device_categories_1.default.get('KEUS_ZIGBEE_DIMMABLE_DRIVER').deviceCategoryCode:
                let driverActivityObj = {
                    driverState: updateStateData.getDriverState()
                };
                return driverActivityObj;
                break;
            case device_categories_1.default.get('KEUS_ZIGBEE_NONDIMMABLE_DRIVER').deviceCategoryCode:
                let driverndActivityObj = {
                    driverState: updateStateData.getDriverState()
                };
                return driverndActivityObj;
                break;
            case device_categories_1.default.get('KEUS_DALI_DIMMABLE_DRIVER').deviceCategoryCode:
                let driverdddActivityObj = {
                    driverState: updateStateData.getDriverState()
                };
                return driverdddActivityObj;
                break;
            case device_categories_1.default.get('KEUS_DALI_NONDIMMABLE_DRIVER').deviceCategoryCode:
                let driverdndActivityObj = {
                    driverState: updateStateData.getDriverState()
                };
                return driverdndActivityObj;
                break;
            case device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode:
                let zigbeeCCActivityAction = {
                    curtainState: updateStateData.getCurtainState()
                };
                return zigbeeCCActivityAction;
                break;
            case device_categories_1.default.get('KEUS_ZIGBEE_CONTACT_SENSOR').deviceCategoryCode:
                let zigbeecontactSensorAction = {
                    deviceState: updateStateData.getDeviceState()
                };
                return zigbeecontactSensorAction;
                break;
            case device_categories_1.default.get('KEUS_ZIGBEE_INLINE_DIMMER').deviceCategoryCode:
                let zigbeeInlineDimmerAction = {
                    deviceState: updateStateData.getDeviceState()
                };
                return zigbeeInlineDimmerAction;
                break;
            case device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode:
                let embeddedActivityAction = {
                    switchId: updateStateData.getSwitchId(),
                    switchName: optionalData.switchName,
                    switchState: 0
                };
                // switch (optionalData.switchType) {
                //     case EMBEDDED_SWITCH_TYPES.NON_DIMMABLE:
                //         embeddedActivityAction.switchState = updateStateData.getSwitchState();
                //         break;
                //     case EMBEDDED_SWITCH_TYPES.FAN:
                //         embeddedActivityAction.switchState = updateStateData.getFanState();
                //         break;
                //     case EMBEDDED_SWITCH_TYPES.DIMMABLE:
                //         embeddedActivityAction.switchState = updateStateData.getSwitchState();
                //         break;
                //     default:
                // }
                return embeddedActivityAction;
                break;
            case device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceCategoryCode:
                let rgbwwaActivityAction = {
                    deviceState: 0,
                    red: 0,
                    green: 0,
                    blue: 0,
                    pattern: 0,
                    warmWhite: 0
                };
                switch (updateStateData.getUpdateStateCase()) {
                    case zigbee_rgbwwa_driver_pb_1.UpdateZigbeeRgbwwaState.UpdateStateCase.RGB_STATE:
                        rgbwwaActivityAction.deviceState = updateStateData.getDeviceState();
                        rgbwwaActivityAction.red = updateStateData.getRgbState().getRed();
                        rgbwwaActivityAction.green = updateStateData.getRgbState().getGreen();
                        rgbwwaActivityAction.blue = updateStateData.getRgbState().getBlue();
                        rgbwwaActivityAction.pattern = updateStateData.getRgbState().getPattern();
                        delete rgbwwaActivityAction.warmWhite;
                        delete rgbwwaActivityAction.coolWhite;
                        delete rgbwwaActivityAction.amber;
                        break;
                    case zigbee_rgbwwa_driver_pb_1.UpdateZigbeeRgbwwaState.UpdateStateCase.WWA_STATE:
                        rgbwwaActivityAction.deviceState = updateStateData.getDeviceState();
                        rgbwwaActivityAction.warmWhite = updateStateData.getWwaState().getWarmWhite();
                        rgbwwaActivityAction.coolWhite = updateStateData.getWwaState().getCoolWhite();
                        rgbwwaActivityAction.amber = updateStateData.getWwaState().getAmber();
                        delete rgbwwaActivityAction.red;
                        delete rgbwwaActivityAction.green;
                        delete rgbwwaActivityAction.blue;
                        delete rgbwwaActivityAction.pattern;
                        break;
                    default:
                        break;
                }
                if (updateStateData.getDeviceState() == 0) {
                    delete rgbwwaActivityAction.red;
                    delete rgbwwaActivityAction.green;
                    delete rgbwwaActivityAction.blue;
                    delete rgbwwaActivityAction.pattern;
                    delete rgbwwaActivityAction.warmWhite;
                    delete rgbwwaActivityAction.coolWhite;
                    delete rgbwwaActivityAction.amber;
                }
                return rgbwwaActivityAction;
                break;
            default:
                break;
        }
    }
    let activityAction = {
        deviceId: deviceObj.deviceId,
        deviceName: deviceObj.deviceName,
        deviceRoom: roomDetails.roomId,
        deviceRoomName: roomDetails.roomName,
        deviceArea: roomDetails.areaId,
        deviceSectionName: sectionDetails.sectionName,
        deviceSection: sectionDetails.sectionId,
        deviceCategory: deviceObj.deviceCategory,
        deviceAction: getDeviceAction(deviceObj, updateStateData, optionalData)
    };
    let activityObject = {
        activityId: generateActivityId(),
        activityBy: userDetails.phone,
        activityAction: activityAction,
        activitySource: optionalData.activitySource,
        activityTime: Date.now(),
        activityUsername: userDetails.userName,
        activityType: activity_structures_pb_1.ACTIVITY_TYPES.DEVICE
    };
    return activityObject;
}
exports.getDeviceActivityObj = getDeviceActivityObj;
async function getSceneActivityObj(userDetails, sceneDetails, roomDetails, optionalData) {
    let sectionDetails = roomDetails.sectionList.find(section => section.sectionId == sceneDetails.sceneSection);
    let activityAction = {
        sceneId: sceneDetails.sceneId,
        sceneArea: roomDetails.areaId,
        sceneName: sceneDetails.sceneName,
        sceneRoom: sceneDetails.sceneRoom,
        sceneRoomName: roomDetails.roomName,
        sceneSection: sectionDetails.sectionId,
        sceneSectionName: sectionDetails.sectionName,
        sceneType: sceneDetails.sceneType
    };
    let activityObject = {
        activityId: generateActivityId(),
        activityBy: userDetails.phone,
        activityAction: activityAction,
        activitySource: optionalData.activitySource,
        activityTime: Date.now(),
        activityUsername: userDetails.userName,
        activityType: activity_structures_pb_1.ACTIVITY_TYPES.SCENE
    };
    return activityObject;
}
exports.getSceneActivityObj = getSceneActivityObj;
async function getGroupActivityObj(userDetails, groupDetails, roomDetails, updateStateData, optionalData) {
    function getGroupeAction(groupdData, updateStateData, optionalData) {
        switch (groupdData.groupType) {
            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
                let driverActivityObj = {
                    driverState: updateStateData.getZdimmableDriverState().getDriverState()
                };
                return driverActivityObj;
                break;
            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
                let driveActivityObj = {
                    driverState: updateStateData.getZnondimmableDriverState().getDriverState()
                };
                return driveActivityObj;
                break;
            case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
                let drivActivityObj = {
                    driverState: updateStateData.getDnondimmableDriverState().getDriverState()
                };
                return drivActivityObj;
                break;
            case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
                let driActivityObj = {
                    driverState: updateStateData.getZnondimmableDriverState().getDriverState()
                };
                return driActivityObj;
                break;
                break;
            case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
                let drActivityObj = {
                    driverState: updateStateData.getZinlineDimmerState().getDeviceState()
                };
                return drActivityObj;
                break;
            default:
                return;
                break;
        }
    }
    let sectionDetails = roomDetails.sectionList.find(section => section.sectionId == groupDetails.groupSection);
    let activityAction = {
        groupId: groupDetails.groupId,
        groupArea: roomDetails.areaId,
        groupName: groupDetails.groupName,
        groupType: groupDetails.groupType,
        groupRoom: roomDetails.roomId,
        groupRoomName: roomDetails.roomName,
        groupSection: sectionDetails.sectionId,
        groupSectionName: sectionDetails.sectionName,
        groupState: getGroupeAction(groupDetails, updateStateData, optionalData)
    };
    let activityObject = {
        activityId: generateActivityId(),
        activityBy: userDetails.phone,
        activityAction: activityAction,
        activitySource: optionalData.activitySource,
        activityTime: Date.now(),
        activityUsername: userDetails.userName,
        activityType: activity_structures_pb_1.ACTIVITY_TYPES.GROUP
    };
    return activityObject;
}
exports.getGroupActivityObj = getGroupActivityObj;
//# sourceMappingURL=activity-utils.js.map