"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const axios = require('axios');
async function makeGetRequest(url, paramsObj) {
    return new Promise(async function (resolve, reject) {
        try {
            let res = await axios.get(url, { params: paramsObj });
            resolve(res.data);
        }
        catch (e) {
            reject(e);
        }
    });
}
exports.makeGetRequest = makeGetRequest;
async function makePostRequest(url, bodyObj) {
    return new Promise(async function (resolve, reject) {
        try {
            let res = await axios.post(url, bodyObj);
            resolve(res.data);
        }
        catch (e) {
            reject(e);
        }
    });
}
exports.makePostRequest = makePostRequest;
// axios.post('http://127.0.0.1:3500/ping', { body: { todo: 'Buy the milk' } }).then(function (result: any) {
//      console.log(result);
//  }).catch(function (e:any) {
//      console.log(e);
// });
//# sourceMappingURL=api-utils.js.map