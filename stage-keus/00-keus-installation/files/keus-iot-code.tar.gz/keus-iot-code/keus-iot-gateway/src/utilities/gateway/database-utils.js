"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function convertDatabaseResultToObject(res) {
    if (!res) {
        return res;
    }
    else if (res instanceof Array) {
        const convertedArray = new Array();
        res.forEach(function (obj) {
            convertedArray.push(obj.toObject());
        });
        return convertedArray;
    }
    else {
        return res.toObject();
    }
}
exports.convertDatabaseResultToObject = convertDatabaseResultToObject;
function formMongoDatabaseConnectionUrl(options) {
    return 'mongodb://' + options.host + ':' + options.port;
}
exports.formMongoDatabaseConnectionUrl = formMongoDatabaseConnectionUrl;
//# sourceMappingURL=database-utils.js.map