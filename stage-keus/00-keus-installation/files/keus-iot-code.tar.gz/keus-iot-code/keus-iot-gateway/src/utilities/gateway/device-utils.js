"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const rs = __importStar(require("randomstring"));
function generateIRRemoteId() {
    let remoteId = rs.generate(10);
    return remoteId;
}
exports.generateIRRemoteId = generateIRRemoteId;
//# sourceMappingURL=device-utils.js.map