"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../constants/gateway/system-constants");
const randomstring_1 = __importDefault(require("randomstring"));
exports.GetGatewayId = (gatewayMode) => {
    if (gatewayMode == system_constants_1.MultiGateway.GatewayMode.MAIN_GATEWAY) {
        return 'MAIN_GATEWAY_ID';
    }
    else {
        return 'MINI_GATEWAY_ID';
    }
};
exports.GenerateMiniGatewayId = () => {
    return randomstring_1.default.generate(8);
};
//# sourceMappingURL=gateway-utils.js.map