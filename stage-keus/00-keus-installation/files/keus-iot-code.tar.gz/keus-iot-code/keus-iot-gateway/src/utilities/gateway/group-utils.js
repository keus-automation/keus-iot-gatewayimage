"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const group_constants_1 = require("../../constants/group/group-constants");
const DeviceConfigurationConstants = __importStar(require("../../constants/device/default-configuration-constants"));
const group_structures_pb_1 = require("../../app/hub-request-manager/protos/generated/hub/groups/group_structures_pb");
const system_constants_1 = require("../../constants/gateway/system-constants");
function generateGroupIdForArea(groupList) {
    var i = group_constants_1.GroupStartId;
    while (i <= group_constants_1.GroupEndId) {
        var filteredGroupList = groupList.filter(function (group) {
            return group.groupId == i;
        });
        if (!filteredGroupList.length) {
            return i;
        }
        i++;
    }
    return -1;
}
exports.generateGroupIdForArea = generateGroupIdForArea;
function getDefaultGroupProperties(groupType) {
    switch (groupType) {
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
            const zddProps = {
                fadeTime: DeviceConfigurationConstants.DimmableDriverFadeTime,
                minValue: DeviceConfigurationConstants.DimmableDriverMinValue,
                maxValue: DeviceConfigurationConstants.DimmableDriverMaxValue,
                defaultState: DeviceConfigurationConstants.DimmableDriverDefaultState
            };
            return zddProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
            const zndProps = {
                fadeTime: DeviceConfigurationConstants.NonDimmableDriverFadeTime
            };
            return zndProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
            const dddProps = {
                fadeTime: DeviceConfigurationConstants.DimmableDriverFadeTime,
                minValue: DeviceConfigurationConstants.DimmableDriverMinValue,
                maxValue: DeviceConfigurationConstants.DaliDimmableDriverMaxValue,
                defaultState: DeviceConfigurationConstants.DimmableDriverDefaultState,
                isDriverPropertyUpdated: true
            };
            return dddProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
            const dctdProps = {
                fadeTime: DeviceConfigurationConstants.DaliColorTunableFadeTime,
                minValue: DeviceConfigurationConstants.DaliColorTunableMinValue,
                maxValue: DeviceConfigurationConstants.DaliColorTunableMaxValue,
                minTemperature: DeviceConfigurationConstants.DaliColorTunableMinTemperature,
                maxTemperature: DeviceConfigurationConstants.DaliColorTunableMaxTemperature,
                deviceVoiceName: "",
                defaultState: {
                    driverState: 0,
                    colorTemperature: DeviceConfigurationConstants.DaliColorTunableMinTemperature,
                    lastUpdateBy: system_constants_1.SystemNumber,
                    lastUpdateSource: system_constants_1.UpdateSourceMapping.SYSTEM,
                    lastUpdateUser: system_constants_1.SystemUser,
                    lastUpdateTime: Date.now()
                }
            };
            return dctdProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
            const dndProps = {
                fadeTime: DeviceConfigurationConstants.NonDimmableDriverFadeTime,
                isDriverPropertyUpdated: true
            };
            return dndProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
            const zidState = {
                fadeTime: DeviceConfigurationConstants.InlineDimmerFadeTime,
                maxValue: DeviceConfigurationConstants.InlineDimmerMaxValue,
                minValue: DeviceConfigurationConstants.InlineDimmerMinValue,
                powerOnState: DeviceConfigurationConstants.InlineDimmerPowerOnState
            };
            return zidState;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
            const aofProp = {
                deviceList: []
            };
            return aofProp;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
            const asdProp = {
                deviceList: []
            };
            return asdProp;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
            const afProp = {
                deviceList: []
            };
            return afProp;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
            const actProp = {
                deviceList: []
            };
            return actProp;
            break;
        case group_structures_pb_1.GROUP_TYPES.RGBWWA:
            const zrgbProps = {
                fadeTime: DeviceConfigurationConstants.DimmableDriverFadeTime,
                outputChannels: 6,
                amberEnabled: true,
                rgbEnabled: true,
                warmWhiteEnabled: true,
                coolWhiteEnabled: true,
                defaultRgbAction: {
                    red: 0,
                    green: 0,
                    blue: 0,
                    pattern: 0,
                    deviceState: 0
                },
                defaultUpdateType: 0,
                defaultWwaAction: {
                    warmWhite: 0,
                    coolWhite: 0,
                    amber: 0,
                    deviceState: 0
                }
            };
            return zrgbProps;
            break;
        default:
            return null;
    }
}
exports.getDefaultGroupProperties = getDefaultGroupProperties;
function getDefaultGroupState(groupType) {
    switch (groupType) {
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
            const zddState = {
                driverState: 0
            };
            return zddState;
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
            const zndState = {
                driverState: 0
            };
            return zndState;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
            const dddState = {
                driverState: 0
            };
            return dddState;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
            const dctdState = {
                driverState: 0,
                colorTemperature: DeviceConfigurationConstants.DaliColorTunableMinTemperature,
                lastUpdateBy: system_constants_1.SystemNumber,
                lastUpdateSource: system_constants_1.UpdateSourceMapping.SYSTEM,
                lastUpdateUser: system_constants_1.SystemUser,
                lastUpdateTime: Date.now()
            };
            return dctdState;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
            const dndState = {
                driverState: 0
            };
            return dndState;
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
            const zidState = {
                deviceState: 0
            };
            return zidState;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
            const aofState = {
                switchState: 0
            };
            return aofState;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
            const asdState = {
                switchState: 0
            };
            return asdState;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
            const afState = {
                fanState: 0
            };
            return afState;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
            const actState = {
                lightState: 0,
                warmWhiteState: 0,
                coolWhiteState: 0
            };
            return actState;
            break;
        case group_structures_pb_1.GROUP_TYPES.RGBWWA:
            const zrgbState = {
                deviceState: 0,
                rgbState: {
                    red: 0,
                    green: 0,
                    blue: 0,
                    pattern: 0,
                    deviceState: 0
                },
                wwaState: {
                    warmWhite: 0,
                    coolWhite: 0,
                    amber: 0,
                    deviceState: 0
                },
                updateType: 0
            };
            return zrgbState;
            break;
        default:
            return null;
    }
}
exports.getDefaultGroupState = getDefaultGroupState;
//# sourceMappingURL=group-utils.js.map