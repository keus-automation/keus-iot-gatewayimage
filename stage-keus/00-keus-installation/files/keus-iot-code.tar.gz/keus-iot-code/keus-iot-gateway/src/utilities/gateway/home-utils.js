"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const rs = __importStar(require("randomstring"));
const home_constants_1 = require("../../constants/gateway/home-constants");
const systemConstants = __importStar(require("../../constants/gateway/system-constants"));
const errors_1 = require("../../errors/errors");
function generateFloorId() {
    let floorId = rs.generate(10);
    return floorId;
}
exports.generateFloorId = generateFloorId;
function generateRoomId() {
    let roomId = rs.generate(10);
    return roomId;
}
exports.generateRoomId = generateRoomId;
function generateAreaId(areaList) {
    var i = home_constants_1.AreaStartId;
    while (i <= home_constants_1.AreaEndId) {
        var filteredAreaList = areaList.filter(function (area) {
            return area.areaId == i;
        });
        if (!filteredAreaList.length) {
            return i;
        }
        i++;
    }
    return -1;
}
exports.generateAreaId = generateAreaId;
function generateSectionId() {
    let sectionId = rs.generate(10);
    return sectionId;
}
exports.generateSectionId = generateSectionId;
function getRoomIdsFromRoomList(roomList) {
    const roomIdList = new Array();
    roomList.forEach(function (room) {
        roomIdList.push(room.roomId);
    });
    return roomIdList;
}
exports.getRoomIdsFromRoomList = getRoomIdsFromRoomList;
function getDeviceIdsFromDeviceList(deviceList) {
    const deviceIdList = new Array();
    deviceList.forEach(function (device) {
        deviceIdList.push(device.deviceId);
    });
    return deviceIdList;
}
exports.getDeviceIdsFromDeviceList = getDeviceIdsFromDeviceList;
function checkRoomsInSameArea(roomList) {
    var sameArea = true;
    if (roomList.length) {
        const roomArea = roomList[0].areaId;
        roomList.forEach(function (room) {
            if (room.areaId != roomArea) {
                sameArea = false;
            }
        });
    }
    return sameArea;
}
exports.checkRoomsInSameArea = checkRoomsInSameArea;
async function getSuperUser(users, gateway) {
    let superUser;
    if (gateway.length) {
        users.forEach(function (user) {
            if (user.homesList) {
                let homes = JSON.parse(user.homesList);
                if (homes.length) {
                    if (homes[0].gatewayId == gateway[0].gatewayId &&
                        homes[0].accessLevel == systemConstants.UserRoles.SuperAdmin) {
                        superUser = user.phone;
                    }
                }
            }
        });
    }
    return superUser;
}
exports.getSuperUser = getSuperUser;
async function GenerateGatewayData(gatewayData) {
    var decryptedMasterKey = await decryptGatewayKeyandSeed(gatewayData.gatewayKey);
    let data = {
        gatewayId: gatewayData.gatewayId,
        gatewayKey: decryptedMasterKey.gateway_key,
        seed: decryptedMasterKey.seed,
        gatewayMode: systemConstants.MultiGateway.GatewayMode.MAIN_GATEWAY,
        serviceUser: await decryptStringWithSeed(gatewayData.serviceUser, decryptedMasterKey.seed),
        serviceUserPassword: await decryptStringWithSeed(gatewayData.serviceUserPassword, decryptedMasterKey.seed),
        isRegisteredToCloud: false,
        isConfigured: true,
        wronglyConfigured: false,
        alexaLinked: false,
        alexaLinkedUserList: [],
        googleLinked: false,
        googleLinkedUserList: [],
        siriLinked: false,
        siriLinkedUserList: [],
        hubVersion: gatewayData.hubVersion,
        miniGateways: []
    };
    return data;
}
exports.GenerateGatewayData = GenerateGatewayData;
async function decryptGatewayKeyandSeed(masterKey) {
    var dencryptedStr = '';
    var seed = masterKey.substring(systemConstants.keyPartition, masterKey.length);
    for (var i = 0; i < masterKey.substring(0, systemConstants.keyPartition).length; i++) {
        dencryptedStr += String.fromCharCode(masterKey.charCodeAt(i) - (seed % 26));
    }
    return {
        gateway_key: dencryptedStr,
        seed: seed
    };
}
exports.decryptGatewayKeyandSeed = decryptGatewayKeyandSeed;
async function decryptStringWithSeed(str, seed) {
    var decryptedStr = '';
    for (var i = 0; i < str.length; i++) {
        decryptedStr += String.fromCharCode(str.charCodeAt(i) - (seed % 26));
    }
    return decryptedStr;
}
exports.decryptStringWithSeed = decryptStringWithSeed;
// permission utils
async function checkForSuperUser(users, gateway) {
    let superUser = false;
    // let users = await KeusUserModel.getAllUsers();
    // let gateway = await KeusGatewayModel.getGateway();
    users = users.filter(function (usr) {
        return usr.phone != gateway[0].serviceUser;
    });
    if (gateway.length) {
        users.forEach(function (user) {
            if (user.homesList) {
                let homes = JSON.parse(user.homesList);
                if (homes.length) {
                    superUser =
                        superUser ||
                            (homes[0].gatewayId == gateway[0].gatewayId &&
                                homes[0].accessLevel == systemConstants.UserRoles.SuperAdmin);
                }
            }
        });
    }
    return superUser;
}
exports.checkForSuperUser = checkForSuperUser;
async function getAccessLevel(user) {
    if (!user || !user.homesList) {
        return -1;
    }
    var userHomesArray = JSON.parse(user.homesList);
    if (!userHomesArray.length) {
        return -1;
    }
    else {
        var userAccessLevel = userHomesArray[0].accessLevel;
        return userAccessLevel;
    }
}
exports.getAccessLevel = getAccessLevel;
async function checkUserIsAdmin(user) {
    let userAccess = await getAccessLevel(user);
    if (userAccess >= systemConstants.UserRoles.Admin) {
        return true;
    }
    else {
        throw new errors_1.GeneralErrors.UserNotAdminError();
    }
}
exports.checkUserIsAdmin = checkUserIsAdmin;
async function checkAccessForUser(user, Room) {
    let userHomesArray = JSON.parse(user.homesList);
    if (!user || !user.homesList || !userHomesArray.length) {
        throw new errors_1.GeneralErrors.InvalidUserAccessError();
    }
    if (userHomesArray[0].accessLevel >= systemConstants.UserRoles.Admin) {
        return true;
    }
    else {
        if (userHomesArray[0].roomsList.includes(Room)) {
            return true;
        }
        else {
            throw new errors_1.GeneralErrors.InvalidUserAccessError();
        }
    }
}
exports.checkAccessForUser = checkAccessForUser;
//# sourceMappingURL=home-utils.js.map