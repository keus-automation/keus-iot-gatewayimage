"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const device_categories_1 = __importDefault(require("../../../constants/device/device-categories"));
const activity_structures_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/activity/activity_structures_pb");
// export function(){}
function getAcFanControllerActivityProto(device) {
    const acActivity = new activity_structures_pb_1.AcFancontrollerActivityAction();
    device.fanState ? acActivity.setFanState(device.fanState) : null;
    device.lightState ? acActivity.setLightState(device.lightState) : null;
    return acActivity;
}
exports.getAcFanControllerActivityProto = getAcFanControllerActivityProto;
function getDcFanControllerActivityProto(device) {
    const dcActivity = new activity_structures_pb_1.DcFancontrollerActivityAction();
    device.fanState ? dcActivity.setFanState(device.fanState) : null;
    device.lightState ? dcActivity.setLightState(device.lightState) : null;
    device.lightTemperature ? dcActivity.setLightTemperature(device.lightTemperature) : null;
    return dcActivity;
}
exports.getDcFanControllerActivityProto = getDcFanControllerActivityProto;
function getContactSensorActivityProto(device) {
    const csActivity = new activity_structures_pb_1.ContactSensorActivityAction();
    csActivity.setDeviceState(device.deviceState);
    return csActivity;
}
exports.getContactSensorActivityProto = getContactSensorActivityProto;
function getCurtainControllerActivityProto(device) {
    const curtainActivity = new activity_structures_pb_1.CurtainActivityAction();
    curtainActivity.setCurtainState(device.curtainState);
    return curtainActivity;
}
exports.getCurtainControllerActivityProto = getCurtainControllerActivityProto;
function getDriverActivityProto(device) {
    const driverActivity = new activity_structures_pb_1.DriverActivityAction();
    driverActivity.setDriverState(device.driverState);
    return driverActivity;
}
exports.getDriverActivityProto = getDriverActivityProto;
function getEmbeddedSwitchActivityProto(device) {
    const esActivity = new activity_structures_pb_1.EmbeddedSwitchActivityAction();
    esActivity.setSwitchId(device.switchId);
    esActivity.setSwitchState(device.switchState);
    esActivity.setSwitchName(device.switchName);
    return esActivity;
}
exports.getEmbeddedSwitchActivityProto = getEmbeddedSwitchActivityProto;
function getInlineDimmerActivityProto(device) {
    const idActivity = new activity_structures_pb_1.InlineDimmerActivityAction();
    idActivity.setDeviceState(device.deviceState);
    return idActivity;
}
exports.getInlineDimmerActivityProto = getInlineDimmerActivityProto;
function getRgbwwaActivityProto(device) {
    const rgbActivity = new activity_structures_pb_1.RgbwwaActivityAction();
    rgbActivity.setDeviceState(device.deviceState);
    device.amber ? rgbActivity.setAmber(device.amber) : null;
    device.blue ? rgbActivity.setBlue(device.blue) : null;
    device.red ? rgbActivity.setRed(device.red) : null;
    device.green ? rgbActivity.setGreen(device.green) : null;
    device.coolWhite ? rgbActivity.setCoolWhite(device.coolWhite) : null;
    device.warmWhite ? rgbActivity.setWarmWhite(device.warmWhite) : null;
    device.pattern ? rgbActivity.setPattern(device.pattern) : null;
    return rgbActivity;
}
exports.getRgbwwaActivityProto = getRgbwwaActivityProto;
function getGroupStateActivityProto(device) {
    const groupStateActivity = new activity_structures_pb_1.GroupStateActivity();
    groupStateActivity.setDriverState(device.driverState);
    device.amber ? groupStateActivity.setAmber(device.amber) : null;
    device.blue ? groupStateActivity.setBlue(device.blue) : null;
    device.red ? groupStateActivity.setRed(device.red) : null;
    device.green ? groupStateActivity.setGreen(device.green) : null;
    device.coolWhite ? groupStateActivity.setCoolWhite(device.coolWhite) : null;
    device.warmWhite ? groupStateActivity.setWarmWhite(device.warmWhite) : null;
    device.pattern ? groupStateActivity.setPattern(device.pattern) : null;
    return groupStateActivity;
}
exports.getGroupStateActivityProto = getGroupStateActivityProto;
function getDeviceActionProto(deviceAction) {
    const deviceActivity = new activity_structures_pb_1.DeviceActivityAction();
    deviceActivity.setDeviceId(deviceAction.deviceId);
    deviceActivity.setDeviceSection(deviceAction.deviceSection);
    deviceActivity.setDeviceName(deviceAction.deviceName);
    deviceActivity.setDeviceCategory(deviceAction.deviceCategory);
    deviceActivity.setDeviceRoom(deviceAction.deviceRoom);
    deviceActivity.setDeviceRoomName(deviceAction.deviceRoomName);
    deviceActivity.setDeviceSectionName(deviceAction.deviceSectionName);
    deviceActivity.setDeviceArea(deviceAction.deviceArea);
    switch (deviceAction.deviceCategory) {
        case device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceCategoryCode:
            deviceActivity.setAcFanActivity(getAcFanControllerActivityProto(deviceAction.deviceAction));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER').deviceCategoryCode:
            deviceActivity.setDcFanActivity(getDcFanControllerActivityProto(deviceAction.deviceAction));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_DIMMABLE_DRIVER').deviceCategoryCode ||
            device_categories_1.default.get('KEUS_ZIGBEE_NONDIMMABLE_DRIVER').deviceCategoryCode ||
            device_categories_1.default.get('KEUS_DALI_DIMMABLE_DRIVER').deviceCategoryCode ||
            device_categories_1.default.get('KEUS_DALI_NONDIMMABLE_DRIVER').deviceCategoryCode:
            deviceActivity.setDriverCommonActivity(getDriverActivityProto(deviceAction.deviceAction));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode:
            deviceActivity.setCurtainActivity(getCurtainControllerActivityProto(deviceAction.deviceAction));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_CONTACT_SENSOR').deviceCategoryCode:
            deviceActivity.setContactSensorActivity(getContactSensorActivityProto(deviceAction.deviceAction));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_INLINE_DIMMER').deviceCategoryCode:
            deviceActivity.setInlineDimmerActivity(getInlineDimmerActivityProto(deviceAction.deviceAction));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode:
            deviceActivity.setEsActivity(getEmbeddedSwitchActivityProto(deviceAction.deviceAction));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceCategoryCode:
            deviceActivity.setRgbwwaActivity(getRgbwwaActivityProto(deviceAction.deviceAction));
            break;
        default:
            break;
    }
    return deviceActivity;
}
exports.getDeviceActionProto = getDeviceActionProto;
function getGroupActionProto(groupAction) {
    const groupActivity = new activity_structures_pb_1.GroupActivityAction();
    groupActivity.setGroupId(groupAction.groupId);
    groupActivity.setGroupName(groupAction.groupName);
    groupActivity.setGroupRoom(groupAction.groupRoom);
    groupActivity.setGroupSection(groupAction.groupSection);
    groupActivity.setGroupType(groupAction.groupType);
    groupActivity.setGroupRoomName(groupAction.groupRoomName);
    groupActivity.setGroupSectionName(groupAction.groupSectionName);
    groupActivity.setGroupArea(groupAction.groupArea);
    let groupState = getGroupStateActivityProto(groupAction.groupState);
    groupActivity.setGroupState(groupState);
    return groupActivity;
}
exports.getGroupActionProto = getGroupActionProto;
function getSceneActionProto(sceneAction) {
    const sceneActivity = new activity_structures_pb_1.SceneActivityAction();
    sceneActivity.setSceneId(sceneAction.sceneId);
    sceneActivity.setSceneName(sceneAction.sceneName);
    sceneActivity.setSceneRoom(sceneAction.sceneRoom);
    sceneActivity.setSceneSection(sceneAction.sceneSection);
    sceneActivity.setSceneType(sceneAction.sceneType);
    sceneActivity.setSceneArea(sceneAction.sceneArea);
    sceneActivity.setSceneRoomName(sceneAction.sceneRoomName);
    sceneActivity.setSceneSectionName(sceneAction.sceneSectionName);
    return sceneActivity;
}
exports.getSceneActionProto = getSceneActionProto;
function getActivityProto(activity) {
    const activityProto = new activity_structures_pb_1.Activity();
    activityProto.setActivityId(activity.activityId);
    activityProto.setActivitySource(activity.activitySource);
    activityProto.setActivityTime(activity.activityTime);
    activityProto.setActivityType(activity.activityType);
    activityProto.setActivityUsername(activity.activityUsername);
    activityProto.setActivityBy(activity.activityBy);
    switch (activity.activityType) {
        case activity_structures_pb_1.ACTIVITY_TYPES.DEVICE:
            activityProto.setDeviceAction(getDeviceActionProto(activity.activityAction));
            break;
        case activity_structures_pb_1.ACTIVITY_TYPES.GROUP:
            activityProto.setGroupAction(getGroupActionProto(activity.activityAction));
            break;
        case activity_structures_pb_1.ACTIVITY_TYPES.SCENE:
            activityProto.setSceneAction(getSceneActionProto(activity.activityAction));
            break;
    }
    return activityProto;
}
exports.getActivityProto = getActivityProto;
function getActivityProtoList(activityList) {
    const activityProtoList = new Array();
    activityList.forEach(function (activity) {
        activityProtoList.push(getActivityProto(activity));
    });
    return activityProtoList;
}
exports.getActivityProtoList = getActivityProtoList;
//# sourceMappingURL=activity-utils.js.map