"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const device_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/device_pb");
const device_categories_1 = __importDefault(require("../../../constants/device/device-categories"));
const zigbee_dimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_dimmable_driver_pb");
const zigbee_nondimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_nondimmable_driver_pb");
const dali_dimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_dimmable_driver_pb");
const dali_nondimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_nondimmable_driver_pb");
const zigbee_curtain_controller_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_curtain_controller_pb");
const scene_wizard_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/scene_wizard_pb");
const smart_console_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/smart_console_pb");
const zigbee_ac_fan_controller_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const zigbee_dc_fan_controller_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const zigbee_rgbwwa_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const zigbee_embedded_scene_switch_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_embedded_scene_switch_pb");
const device_constants_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/device_constants_pb");
const zigbee_ir_blaster_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_ir_blaster_pb");
const zigbee_embedded_switch_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_embedded_switch_pb");
const dali_color_tunable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_color_tunable_driver_pb");
//Device properties protos
function getDevicePropertyProto(deviceCategoryCode, deviceProperties) {
    switch (deviceCategoryCode) {
        case device_categories_1.default.get('KEUS_ZIGBEE_DIMMABLE_DRIVER').deviceCategoryCode:
            const zddProps = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverProperties();
            zddProps.setFadeTime(deviceProperties.fadeTime);
            zddProps.setMinValue(deviceProperties.minValue);
            zddProps.setMaxValue(deviceProperties.maxValue);
            zddProps.setDefaultState(deviceProperties.defaultState);
            return zddProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_NONDIMMABLE_DRIVER').deviceCategoryCode:
            const zndProps = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverProperties();
            zndProps.setFadeTime(deviceProperties.fadeTime);
            return zndProps;
            break;
        case device_categories_1.default.get('KEUS_DALI_DIMMABLE_DRIVER').deviceCategoryCode:
            const dddProps = new dali_dimmable_driver_pb_1.DaliDimmableDriverProperties();
            dddProps.setFadeTime(deviceProperties.fadeTime);
            dddProps.setMinValue(deviceProperties.minValue);
            dddProps.setMaxValue(deviceProperties.maxValue);
            dddProps.setDefaultState(deviceProperties.defaultState);
            dddProps.setIsDriverPropertyUpdated(deviceProperties.isDriverPropertyUpdated);
            return dddProps;
            break;
        case device_categories_1.default.get('KEUS_DALI_COLOR_TUNABLE_DRIVER').deviceCategoryCode:
            const dctdProps = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverProperties();
            dctdProps.setFadeTime(deviceProperties.fadeTime);
            dctdProps.setMinValue(deviceProperties.minValue);
            dctdProps.setMaxValue(deviceProperties.maxValue);
            dctdProps.setMaxTemperature(deviceProperties.maxTemperature);
            dctdProps.setMinTemperature(deviceProperties.minTemperature);
            dctdProps.setIsDriverPropertyUpdated(deviceProperties.isDriverPropertyUpdated);
            let dctdDefState = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverState();
            dctdDefState.setColorTemperature(deviceProperties.defaultState.colorTemperature);
            dctdDefState.setDriverState(deviceProperties.defaultState.driverState);
            dctdDefState.setLastUpdateBy(deviceProperties.defaultState.lastUpdateBy);
            dctdDefState.setLastUpdateSource(deviceProperties.defaultState.lastUpdateSource);
            dctdDefState.setLastUpdateTime(deviceProperties.defaultState.lastUpdateTime);
            dctdDefState.setLastUpdateUser(deviceProperties.defaultState.lastUpdateUser);
            dctdProps.setDefaultState(dctdDefState);
            return dctdProps;
            break;
        case device_categories_1.default.get('KEUS_DALI_NONDIMMABLE_DRIVER').deviceCategoryCode:
            const dndProps = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverProperties();
            dndProps.setFadeTime(deviceProperties.fadeTime);
            // dndProps.setIsDriverPropertyUpdated(deviceProperties.isDriverPropertyUpdated);
            return dndProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode:
            const zccProps = new zigbee_curtain_controller_pb_1.ZigbeeCurtainControllerProperties();
            zccProps.setInvertSignal(deviceProperties.invertSignal);
            zccProps.setActionTriggerTime(deviceProperties.actionTriggerTime);
            zccProps.setCurtainType(deviceProperties.curtainType);
            zccProps.setMotorCalibrationTime(deviceProperties.motorCalibrationTime);
            zccProps.setRfremoteEnabled(deviceProperties.rfremoteEnabled);
            return zccProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode:
            const zscProps = new smart_console_pb_1.SmartConsoleProperties();
            zscProps.setButtonList(getSmartConsoleButtonProtoList(deviceProperties.buttons));
            zscProps.setRelayList(getSmartConsoleRelayProtoList(deviceProperties.relays));
            zscProps.setDefaultFan(deviceProperties.defaultFan);
            zscProps.setDefaultSceneId(deviceProperties.defaultSceneId);
            zscProps.setDefaultSceneRoom(deviceProperties.defaultSceneRoom);
            zscProps.setSceneStepSize(deviceProperties.sceneStepSize);
            zscProps.setIsAreaMaster(deviceProperties.isAreaMaster);
            zscProps.setIsDaliMaster(deviceProperties.isDaliMaster);
            return zscProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_SCENE_WIZARD').deviceCategoryCode:
            const zswProps = new scene_wizard_pb_1.SceneWizardProperties();
            zswProps.setButtonList(getSmartConsoleButtonProtoList(deviceProperties.buttons));
            zswProps.setSceneStepSize(deviceProperties.sceneStepSize);
            return zswProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode:
            const zesProps = new zigbee_embedded_switch_pb_1.EmbeddedSwitchProperties();
            zesProps.setOutputPortsList(getEmbeddedSwitchOutputPortProtoList(deviceProperties.outputPorts));
            zesProps.setApplianceList(getEmbeddedApplianceList(deviceProperties.appliance));
            zesProps.setSwitchList(getEmbeddedSwitchProtoList(deviceProperties.switch));
            return zesProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceCategoryCode:
            const zacfcProps = new zigbee_ac_fan_controller_pb_1.ZigbeeACFanControllerProperties();
            zacfcProps.setHasLight(deviceProperties.hasLight);
            return zacfcProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER').deviceCategoryCode:
            const zdcfcProps = new zigbee_dc_fan_controller_pb_1.ZigbeeDCFanControllerProperties();
            zdcfcProps.setFadeTime(deviceProperties.fadeTime);
            zdcfcProps.setIsAntiTheft(deviceProperties.isAntiTheft);
            zdcfcProps.setIsReverse(deviceProperties.isReverse);
            return zdcfcProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceCategoryCode:
            const zrgbwwaProps = new zigbee_rgbwwa_driver_pb_1.ZigbeeRgbwwaProperties();
            zrgbwwaProps.setOutputChannels(deviceProperties.outputChannels);
            zrgbwwaProps.setFadeTime(deviceProperties.fadeTime);
            zrgbwwaProps.setRgbEnabled(deviceProperties.rgbEnabled);
            zrgbwwaProps.setWarmWhiteEnabled(deviceProperties.warmWhiteEnabled);
            zrgbwwaProps.setCoolWhiteEnabled(deviceProperties.coolWhiteEnabled);
            zrgbwwaProps.setAmberEnabled(deviceProperties.amberEnabled);
            return zrgbwwaProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SCENE_SWITCH').deviceCategoryCode:
            const zessProps = new zigbee_embedded_scene_switch_pb_1.ZigbeeEmbeddedSceneSwitchProperties();
            zessProps.setNumberOfSwitches(deviceProperties.numberOfSwitches);
            zessProps.setSwitchesList(getEmbeddedSceneSwitchPropertyProtoList(deviceProperties.switches));
            return zessProps;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_IR_BLASTER').deviceCategoryCode:
            const zirbProps = new zigbee_ir_blaster_pb_1.ZigbeeIRBlasterProperties();
            zirbProps.setBlastSignalDelay(deviceProperties.blastSignalDelay);
            return zirbProps;
            break;
        default:
            return null;
    }
}
exports.getDevicePropertyProto = getDevicePropertyProto;
//Device state protos
function getDeviceStateProto(deviceCategoryCode, deviceState) {
    switch (deviceCategoryCode) {
        case device_categories_1.default.get('KEUS_ZIGBEE_DIMMABLE_DRIVER').deviceCategoryCode:
            const zddState = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverState();
            zddState.setDriverState(deviceState.driverState);
            return zddState;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_NONDIMMABLE_DRIVER').deviceCategoryCode:
            const zndState = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverState();
            zndState.setDriverState(deviceState.driverState);
            return zndState;
            break;
        case device_categories_1.default.get('KEUS_DALI_DIMMABLE_DRIVER').deviceCategoryCode:
            const dddState = new dali_dimmable_driver_pb_1.DaliDimmableDriverState();
            dddState.setDriverState(deviceState.driverState);
            return dddState;
            break;
        case device_categories_1.default.get('KEUS_DALI_COLOR_TUNABLE_DRIVER').deviceCategoryCode:
            const dctdState = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverState();
            dctdState.setColorTemperature(deviceState.colorTemperature);
            dctdState.setDriverState(deviceState.driverState);
            dctdState.setLastUpdateBy(deviceState.lastUpdateBy);
            dctdState.setLastUpdateSource(deviceState.lastUpdateSource);
            dctdState.setLastUpdateTime(deviceState.lastUpdateTime);
            dctdState.setLastUpdateUser(deviceState.lastUpdateUser);
            return dctdState;
            break;
        case device_categories_1.default.get('KEUS_DALI_NONDIMMABLE_DRIVER').deviceCategoryCode:
            const dndState = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverState();
            dndState.setDriverState(deviceState.driverState);
            return dndState;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode:
            const zccState = new zigbee_curtain_controller_pb_1.ZigbeeCurtainControllerState();
            zccState.setCurtainState(deviceState.curtainState);
            return zccState;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode:
            const zscState = new smart_console_pb_1.SmartConsoleState();
            return zscState;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_SCENE_WIZARD').deviceCategoryCode:
            const zswState = new scene_wizard_pb_1.SceneWizardState();
            return zswState;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode:
            const zesState = new zigbee_embedded_switch_pb_1.EmbeddedSwitchState();
            return zesState;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceCategoryCode:
            const zacfcState = new zigbee_ac_fan_controller_pb_1.ZigbeeACFanControllerState();
            zacfcState.setFanState(deviceState.fanState);
            zacfcState.setLightState(deviceState.lightState);
            return zacfcState;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER').deviceCategoryCode:
            const zdcfcState = new zigbee_dc_fan_controller_pb_1.ZigbeeDCFanControllerState();
            const lightState = new zigbee_dc_fan_controller_pb_1.DCFanControllerLightState();
            zdcfcState.setFanState(deviceState.fanState);
            lightState.setLightState(deviceState.lightState);
            lightState.setLightTemperature(deviceState.lightTemperature);
            zdcfcState.setLightState(lightState);
            return zdcfcState;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceCategoryCode:
            const zrgbwwaState = new zigbee_rgbwwa_driver_pb_1.ZigbeeRgbwwaState();
            zrgbwwaState.setDefaultUpdateType(deviceState.defaultUpdateType);
            zrgbwwaState.setLastUpdateType(deviceState.lastUpdateType);
            const lastRgbState = new zigbee_rgbwwa_driver_pb_1.RGB();
            lastRgbState.setGreen(deviceState.lastUpdatedRGBAction.green);
            lastRgbState.setBlue(deviceState.lastUpdatedRGBAction.blue);
            lastRgbState.setRed(deviceState.lastUpdatedRGBAction.red);
            lastRgbState.setPattern(deviceState.lastUpdatedRGBAction.pattern);
            lastRgbState.setDeviceState(deviceState.deviceState);
            zrgbwwaState.setLastUpdatedRgbAction(lastRgbState);
            if (deviceState.lastUpdatedWWAAction) {
                const lastWwaState = new zigbee_rgbwwa_driver_pb_1.WWA();
                lastWwaState.setAmber(deviceState.lastUpdatedWWAAction.amber);
                lastWwaState.setCoolWhite(deviceState.lastUpdatedWWAAction.coolWhite);
                lastWwaState.setWarmWhite(deviceState.lastUpdatedWWAAction.warmWhite);
                lastWwaState.setDeviceState(deviceState.deviceState);
                zrgbwwaState.setLastUpdatedWwaAction(lastWwaState);
            }
            if (deviceState.defaultAction) {
                if (deviceState.defaultUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                    const defaultRgb = new zigbee_rgbwwa_driver_pb_1.RGB();
                    defaultRgb.setGreen(deviceState.defaultAction.green);
                    defaultRgb.setBlue(deviceState.defaultAction.blue);
                    defaultRgb.setRed(deviceState.defaultAction.red);
                    defaultRgb.setPattern(deviceState.defaultAction.pattern);
                    zrgbwwaState.setDefaultRgbAction(defaultRgb);
                }
                else if (deviceState.defaultUpdateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                    const defaultWwa = new zigbee_rgbwwa_driver_pb_1.WWA();
                    defaultWwa.setAmber(deviceState.defaultAction.amber);
                    defaultWwa.setCoolWhite(deviceState.defaultAction.coolWhite);
                    defaultWwa.setWarmWhite(deviceState.defaultAction.warmWhite);
                    zrgbwwaState.setDefaultWwaAction(defaultWwa);
                }
            }
            return zrgbwwaState;
        case device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SCENE_SWITCH').deviceCategoryCode:
            const zessState = new zigbee_embedded_scene_switch_pb_1.ZigbeeEmbeddedSceneSwitchState();
            return zessState;
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_IR_BLASTER').deviceCategoryCode:
            const zirbState = new zigbee_ir_blaster_pb_1.ZigbeeIRBlasterState();
            return zirbState;
            break;
        default:
            return null;
    }
}
exports.getDeviceStateProto = getDeviceStateProto;
function getDeviceProto(device) {
    const deviceProto = new device_pb_1.Device();
    deviceProto.setDeviceId(device.deviceId);
    deviceProto.setMasterId(device.masterId);
    deviceProto.setDeviceType(device.deviceType);
    deviceProto.setDeviceCategory(device.deviceCategory);
    deviceProto.setDeviceName(device.deviceName);
    deviceProto.setDeviceSection(device.deviceSection);
    deviceProto.setDeviceRoom(device.deviceRoom);
    deviceProto.setDeviceLocation(device.deviceLocation);
    deviceProto.setDeviceControlType(device.deviceControlType);
    deviceProto.setDeviceParent(device.deviceParent);
    deviceProto.setFirmwareVersion(device.firmwareVersion);
    deviceProto.setIsHidden(device.isHidden);
    deviceProto.setIsConfigured(device.isConfigured);
    deviceProto.setManufacturerName(device.manufacturerName);
    deviceProto.setDeviceTypeDisplayName(device.deviceTypeDisplayName);
    deviceProto.setDeviceTypeName(device.deviceTypeName);
    deviceProto.setInGroup(device.inGroup);
    deviceProto.setDeviceGroup(device.deviceGroup);
    deviceProto.setGroupRoom(device.groupRoom);
    deviceProto.setLastUpdateTime(device.lastUpdateTime);
    deviceProto.setLastUpdateBy(device.lastUpdateBy);
    deviceProto.setLastUpdateSource(device.lastUpdateSource);
    deviceProto.setLastUpdateUser(device.lastUpdateUser);
    switch (device.deviceCategory) {
        case device_categories_1.default.get('KEUS_ZIGBEE_DIMMABLE_DRIVER').deviceCategoryCode:
            deviceProto.setZdimmableDriverState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setZdimmableDriverProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_NONDIMMABLE_DRIVER').deviceCategoryCode:
            deviceProto.setZnondimmableDriverState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setZnondimmableDriverProperties((getDevicePropertyProto(device.deviceCategory, device.deviceProperties)));
            break;
        case device_categories_1.default.get('KEUS_DALI_DIMMABLE_DRIVER').deviceCategoryCode:
            deviceProto.setDdimmableDriverState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setDdimmableDriverProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_DALI_COLOR_TUNABLE_DRIVER').deviceCategoryCode:
            deviceProto.setDcolortunableDriverState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setDcolortunableDriverProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_DALI_NONDIMMABLE_DRIVER').deviceCategoryCode:
            deviceProto.setDnondimmableDriverState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setDnondimmableDriverProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_CURTAIN_CONTROLLER').deviceCategoryCode:
            deviceProto.setZcurtainContollerState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setZcurtainControllerProperties((getDevicePropertyProto(device.deviceCategory, device.deviceProperties)));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_SMART_CONSOLE').deviceCategoryCode:
            deviceProto.setSmartConsoleState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setSmartConsoleProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_SCENE_WIZARD').deviceCategoryCode:
            deviceProto.setSceneWizardState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setSceneWizardProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SWITCH').deviceCategoryCode:
            deviceProto.setEmbeddedSwitchState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setEmbeddedSwitchProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_AC_FAN_CONTROLLER').deviceCategoryCode:
            deviceProto.setAcFanControllerState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setAcFanControllerProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_DC_FAN_CONTROLLER').deviceCategoryCode:
            deviceProto.setDcFanControllerState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setDcFanControllerProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_RGBWWA_DRIVER').deviceCategoryCode:
            deviceProto.setRgbwwaState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setRgbwwaProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_EMBEDDED_SCENE_SWITCH').deviceCategoryCode:
            deviceProto.setEmbeddedSceneswitchState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setEmbeddedSceneswitchProperties((getDevicePropertyProto(device.deviceCategory, device.deviceProperties)));
            break;
        case device_categories_1.default.get('KEUS_ZIGBEE_IR_BLASTER').deviceCategoryCode:
            deviceProto.setZirBlasterState(getDeviceStateProto(device.deviceCategory, device.deviceState));
            deviceProto.setZirBlasterProperties(getDevicePropertyProto(device.deviceCategory, device.deviceProperties));
            break;
        default:
    }
    return deviceProto;
}
exports.getDeviceProto = getDeviceProto;
function getDeviceProtoList(deviceList) {
    const deviceProtoList = new Array();
    deviceList.forEach(function (device) {
        deviceProtoList.push(getDeviceProto(device));
    });
    return deviceProtoList;
}
exports.getDeviceProtoList = getDeviceProtoList;
function getSmartConsoleButtonProtoList(buttonList) {
    const smartConsoleButtonProtoList = new Array();
    buttonList.forEach(function (button) {
        smartConsoleButtonProtoList.push(getSmartConsoleButtonProto(button));
    });
    return smartConsoleButtonProtoList;
}
exports.getSmartConsoleButtonProtoList = getSmartConsoleButtonProtoList;
function getSmartConsoleRelayProtoList(relayList) {
    const smartConsoleRelayProtoList = new Array();
    relayList.forEach(function (relay) {
        smartConsoleRelayProtoList.push(getSmartConsoleRelayProto(relay));
    });
    return smartConsoleRelayProtoList;
}
exports.getSmartConsoleRelayProtoList = getSmartConsoleRelayProtoList;
function getSmartConsoleButtonProto(button) {
    const smartConsoleButtonProto = new smart_console_pb_1.SmartConsoleButton();
    smartConsoleButtonProto.setButtonId(button.buttonId);
    smartConsoleButtonProto.setButtonType(button.buttonType);
    switch (button.buttonType) {
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_GROUP:
            var groupProperties = new smart_console_pb_1.SmartConsoleGroupButtonProperties();
            var gbuttonProps = button.buttonProperties;
            groupProperties.setGroupId(gbuttonProps.groupId);
            groupProperties.setRoomId(gbuttonProps.roomId);
            smartConsoleButtonProto.setGroupButtonProperties(groupProperties);
            break;
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_SCENE:
            var sceneProperties = new smart_console_pb_1.SmartConsoleSceneButtonProperties();
            var sbuttonProps = button.buttonProperties;
            sceneProperties.setSceneId(sbuttonProps.sceneId);
            sceneProperties.setRoomId(sbuttonProps.roomId);
            smartConsoleButtonProto.setSceneButtonProperties(sceneProperties);
            break;
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_FANCONTROLLER:
            var fanProperties = new smart_console_pb_1.SmartConsoleFanButtonProperties();
            var fbuttonProps = button.buttonProperties;
            fanProperties.setDeviceId(fbuttonProps.deviceId);
            smartConsoleButtonProto.setFanButtonProperties(fanProperties);
            break;
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_CURTAINCONTROLLER:
            var curtainProperties = new smart_console_pb_1.SmartConsoleCurtainButtonProperties();
            var cbuttonProps = button.buttonProperties;
            curtainProperties.setDeviceIdList(cbuttonProps.deviceIds);
            smartConsoleButtonProto.setCurtainButtonProperties(curtainProperties);
            break;
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_RELAYCONTROLLER:
            var relayProperties = new smart_console_pb_1.SmartConsoleRelayButtonProperties();
            var rbuttonProps = button.buttonProperties;
            relayProperties.setRelayId(rbuttonProps.relayId);
            smartConsoleButtonProto.setRelayButtonProperties(relayProperties);
            break;
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_REMOTERELAY:
            var remoteRelayProperties = new smart_console_pb_1.SmartConsoleRemoteRelayButtonProperties();
            var rrbuttonProps = button.buttonProperties;
            remoteRelayProperties.setDeviceId(rrbuttonProps.deviceId);
            remoteRelayProperties.setRelayId(rrbuttonProps.relayId);
            smartConsoleButtonProto.setRemoteRelayButtonProperties(remoteRelayProperties);
            break;
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_INC:
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_DEC:
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_UNCONFIGURED:
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_LIGHTINC:
        case device_constants_pb_1.SMART_CONSOLE_BUTTON_TYPES.SC_LIGHTDEC:
        default:
            var noProperties = new smart_console_pb_1.SmartConsoleNoPropsButtonProperties();
            smartConsoleButtonProto.setNopropsButtonProperties(noProperties);
    }
    return smartConsoleButtonProto;
}
exports.getSmartConsoleButtonProto = getSmartConsoleButtonProto;
function getSmartConsoleRelayProto(relay) {
    const smartConsoleRelayProto = new smart_console_pb_1.SmartConsoleRelay();
    smartConsoleRelayProto.setRelayId(relay.relayId);
    smartConsoleRelayProto.setRelayName(relay.relayName);
    smartConsoleRelayProto.setRelayState(relay.relayState);
    smartConsoleRelayProto.setApplianceType(relay.applianceType);
    smartConsoleRelayProto.setIsHighPower(relay.isHighPower);
    smartConsoleRelayProto.setLastUpdateBy(relay.lastUpdateBy);
    smartConsoleRelayProto.setLastUpdateSource(relay.lastUpdateSource);
    smartConsoleRelayProto.setLastUpdateTime(relay.lastUpdateTime);
    smartConsoleRelayProto.setLastUpdateUser(relay.lastUpdateUser);
    return smartConsoleRelayProto;
}
exports.getSmartConsoleRelayProto = getSmartConsoleRelayProto;
function getEmbeddedSceneSwitchPropertyProtoList(switchList) {
    const embeddedSceneSwitchProtoList = new Array();
    switchList.forEach(function (ess) {
        let essProto = new zigbee_embedded_scene_switch_pb_1.SceneSwitchType();
        essProto.setSceneId(ess.sceneId);
        essProto.setSceneRoom(ess.sceneRoom);
        essProto.setSwitchId(ess.switchId);
        embeddedSceneSwitchProtoList.push(essProto);
    });
    return embeddedSceneSwitchProtoList;
}
exports.getEmbeddedSceneSwitchPropertyProtoList = getEmbeddedSceneSwitchPropertyProtoList;
function getEmbeddedSwitchOutputPortProtoList(portList) {
    const embeddedSwitchPortList = new Array();
    if (portList) {
        portList.forEach(function (port) {
            embeddedSwitchPortList.push(getEmbeddedSwitchOutputPort(port));
        });
    }
    return embeddedSwitchPortList;
}
exports.getEmbeddedSwitchOutputPortProtoList = getEmbeddedSwitchOutputPortProtoList;
function getEmbeddedSwitchOutputPort(port) {
    let portObj = new zigbee_embedded_switch_pb_1.EmbeddedSwitchPort();
    portObj.setApplianceId(port.applianceId);
    portObj.setIsInAppliance(port.isInAppliance);
    portObj.setPortId(port.portId);
    portObj.setPortState(port.portState);
    return portObj;
}
exports.getEmbeddedSwitchOutputPort = getEmbeddedSwitchOutputPort;
function getEmbeddedApplianceList(appList) {
    const embeddedApplianceList = new Array();
    if (appList) {
        appList.forEach(function (app) {
            embeddedApplianceList.push(getEmbeddedAppliance(app));
        });
    }
    return embeddedApplianceList;
}
exports.getEmbeddedApplianceList = getEmbeddedApplianceList;
function getEmbeddedAppliance(app) {
    let appObj = new zigbee_embedded_switch_pb_1.EmbeddedAppliance();
    appObj.setApplianceId(app.applianceId);
    appObj.setApplianceName(app.applianceName);
    appObj.setApplianceType(app.applianceType);
    appObj.setGroupId(app.groupId);
    appObj.setInGroup(app.inGroup);
    appObj.setIconType(app.iconType);
    appObj.setLastUpdateBy(app.lastUpdatedBy);
    appObj.setLastUpdateSource(app.lastUpdatedSource);
    appObj.setLastUpdateTime(app.lastUpdatedTime);
    appObj.setLastUpdateUser(app.lastUpdatedUser);
    switch (app.applianceType) {
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
            let onofProp = new zigbee_embedded_switch_pb_1.OnOffApplianceProperties();
            let onofState = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
            let onofDefault = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
            let onofDbProp = app.applianceProperties;
            let onofDbState = app.applianceState;
            let onoffDbDefault = app.defaultState;
            onofProp.setPortId(onofDbProp.portId);
            appObj.setOnOffProperties(onofProp);
            onofState.setSwitchState(onofDbState.switchState);
            appObj.setOnOffState(onofState);
            onofDefault.setSwitchState(onoffDbDefault.switchState);
            appObj.setOnOffDefaultState(onofDefault);
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
            let sdProp = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceProperties();
            let sdState = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
            let sdDefault = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
            let sdDbProp = app.applianceProperties;
            let sdDbState = app.applianceState;
            let sdDbDefault = app.defaultState;
            sdProp.setPortId(sdDbProp.portId);
            appObj.setSingleDimmerProperties(sdProp);
            sdState.setSwitchState(sdDbState.switchState);
            appObj.setSingleDimmerState(sdState);
            sdDefault.setSwitchState(sdDbDefault.switchState);
            appObj.setSingleDimmerDefaultState(sdDefault);
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
            let fanProp = new zigbee_embedded_switch_pb_1.FanApplianceProperties();
            let fanState = new zigbee_embedded_switch_pb_1.FanApplianceState();
            let fanDefault = new zigbee_embedded_switch_pb_1.FanApplianceState();
            let fanDbProp = app.applianceProperties;
            let fanDbState = app.applianceState;
            let fanDbDefault = app.defaultState;
            fanProp.setPortId(fanDbProp.portId);
            fanState.setFanState(fanDbState.fanState);
            fanDefault.setFanState(fanDbDefault.fanState);
            appObj.setFanProperties(fanProp);
            appObj.setFanState(fanState);
            appObj.setFanDefaultState(fanDefault);
            break;
        case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
            let ctProp = new zigbee_embedded_switch_pb_1.ColorTunableApplianceProperties();
            let ctState = new zigbee_embedded_switch_pb_1.ColorTunableApplianceState();
            let ctfDefault = new zigbee_embedded_switch_pb_1.ColorTunableApplianceState();
            let ctDbProp = app.applianceProperties;
            let ctDbState = app.applianceState;
            let ctDbDefault = app.defaultState;
            ctProp.setCoolWhitePort(ctDbProp.coolWhitePort);
            ctProp.setWarmWhitePort(ctDbProp.warmWhitePort);
            appObj.setColorTunableProperties(ctProp);
            ctState.setLightState(ctDbState.lightState);
            ctState.setCoolWhiteState(ctDbState.coolWhiteState);
            ctState.setWarmWhiteState(ctDbState.warmWhiteState);
            appObj.setColorTunableState(ctState);
            ctfDefault.setLightState(ctDbDefault.lightState);
            ctfDefault.setCoolWhiteState(ctDbDefault.coolWhiteState);
            ctfDefault.setWarmWhiteState(ctDbDefault.warmWhiteState);
            appObj.setColorTunableDefaultState(ctfDefault);
            break;
        default:
            break;
    }
    return appObj;
}
exports.getEmbeddedAppliance = getEmbeddedAppliance;
function getEmbeddedSwitchProtoList(switchList) {
    const switchProtoList = new Array();
    if (switchList) {
        switchList.forEach(function (swtch) {
            switchProtoList.push(getEmbeddedSwitchProto(swtch));
        });
    }
    return switchProtoList;
}
exports.getEmbeddedSwitchProtoList = getEmbeddedSwitchProtoList;
function getEmbeddedSwitchProto(swtch) {
    let swt = new zigbee_embedded_switch_pb_1.EmbeddedSwitch();
    swt.setSwitchId(swtch.switchId);
    swt.setSwitchName(swtch.switchName);
    swt.setSwitchType(swtch.switchType);
    switch (swtch.switchType) {
        case device_constants_pb_1.EMBEDDED_SWITCH_TYPES.APPLIANCE:
            let swApProp = new zigbee_embedded_switch_pb_1.SwitchApplianceProperties();
            let swdbAP = swtch.switchProperties;
            swApProp.setApplianceId(swdbAP.applianceId);
            swt.setApplianceProperties(swApProp);
            break;
        case device_constants_pb_1.EMBEDDED_SWITCH_TYPES.GROUP_EXECUTION:
            let grp = new zigbee_embedded_switch_pb_1.SwitchGroupProperties();
            let grpDb = swtch.switchProperties;
            grp.setGroupId(grpDb.groupId);
            grp.setRoomId(grpDb.roomId);
            swt.setGroupProperties(grp);
            break;
        case device_constants_pb_1.EMBEDDED_SWITCH_TYPES.AC_FAN:
            let ac = new zigbee_embedded_switch_pb_1.SwitchAcFanProperties();
            let acDb = swtch.switchProperties;
            ac.setDeviceId(acDb.deviceId);
            swt.setAcFanProperties(ac);
            break;
        case device_constants_pb_1.EMBEDDED_SWITCH_TYPES.DC_FAN:
            let dc = new zigbee_embedded_switch_pb_1.SwitchDcFanProperties();
            let dcDb = swtch.switchProperties;
            dc.setDeviceId(dcDb.deviceId);
            swt.setDcFanProperties(dc);
            break;
        default:
            break;
    }
    return swt;
}
exports.getEmbeddedSwitchProto = getEmbeddedSwitchProto;
// export function getEmbeddedSwitchProto(swtch: IEmbeddedSwitchPort) {
//     const embeddedSwitchProto = new EmbeddedSwitchPort();
//     embeddedSwitchProto.setSwitchId(swtch.switchId);
//     embeddedSwitchProto.setSwitchName(swtch.switchName);
//     embeddedSwitchProto.setSwitchType(swtch.switchType);
//     embeddedSwitchProto.setLastUpdateBy(swtch.lastUpdateBy);
//     embeddedSwitchProto.setLastUpdateSource(swtch.lastUpdateSource);
//     embeddedSwitchProto.setLastUpdateUser(swtch.lastUpdateUser);
//     embeddedSwitchProto.setLastUpdateTime(swtch.lastUpdateTime);
//     embeddedSwitchProto.setSwitchIcon(swtch.switchIcon);
//     switch (swtch.switchType) {
//         case EMBEDDED_SWITCH_TYPES.DIMMABLE:
//             var dimmableProperties = new DimmableSwitchProperties();
//             var dswitchProps = <IDimmableSwitchProperties>swtch.switchProperties;
//             dimmableProperties.setFadeTime(dswitchProps.fadeTime);
//             dimmableProperties.setMaxDimLevel(dswitchProps.maxDimLevel);
//             dimmableProperties.setMinDimLevel(dswitchProps.minDimLevel);
//             dimmableProperties.setDefaultState(dswitchProps.defaultState);
//             dimmableProperties.setSwitchState(dswitchProps.switchState);
//             embeddedSwitchProto.setDimmableSwitchProperties(dimmableProperties);
//             break;
//         case EMBEDDED_SWITCH_TYPES.NON_DIMMABLE:
//             var nonDimmableProperties = new NonDimmableSwitchProperties();
//             var ndswitchProps = <INonDimmableSwitchProperties>swtch.switchProperties;
//             nonDimmableProperties.setSwitchState(ndswitchProps.switchState);
//             embeddedSwitchProto.setNonDimmableSwitchProperties(nonDimmableProperties);
//             break;
//         case EMBEDDED_SWITCH_TYPES.FAN:
//             var fanProperties = new EmbeddedFanControllerProperties();
//             var fanProps = <IEmbeddedFanControllerProperties>swtch.switchProperties;
//             fanProperties.setFanState(fanProps.fanState);
//             embeddedSwitchProto.setFanControllerProperties(fanProperties);
//             break;
//         default:
//     }
//     return embeddedSwitchProto;
// }
function getIRRemoteProto(irRemote) {
    const irRemoteProto = new zigbee_ir_blaster_pb_1.IRRemote();
    irRemoteProto.setRemoteId(irRemote.remoteId);
    irRemoteProto.setRemoteType(irRemote.remoteType);
    irRemoteProto.setRemoteName(irRemote.remoteName);
    irRemoteProto.setCompanyId(irRemote.companyId);
    irRemoteProto.setModelId(irRemote.modelId);
    irRemoteProto.setIrDevice(irRemote.irDevice);
    irRemoteProto.setLastUpdateBy(irRemote.lastUpdateBy);
    irRemoteProto.setLastUpdateSource(irRemote.lastUpdateSource);
    irRemoteProto.setLastUpdateTime(irRemote.lastUpdateTime);
    irRemoteProto.setLastUpdateUser(irRemote.lastUpdateUser);
    switch (irRemote.remoteType) {
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
            irRemoteProto.setAcProperties(getIRRemotePropertiesProto(irRemote.remoteType, irRemote.remoteProperties));
            irRemoteProto.setAcState(getIRRemoteStateProto(irRemote.remoteType, irRemote.remoteState));
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
            irRemoteProto.setTvProperties(getIRRemotePropertiesProto(irRemote.remoteType, irRemote.remoteProperties));
            irRemoteProto.setTvState(getIRRemoteStateProto(irRemote.remoteType, irRemote.remoteState));
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
            irRemoteProto.setPrProperties(getIRRemotePropertiesProto(irRemote.remoteType, irRemote.remoteProperties));
            irRemoteProto.setPrState(getIRRemoteStateProto(irRemote.remoteType, irRemote.remoteState));
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
            irRemoteProto.setAmpProperties(getIRRemotePropertiesProto(irRemote.remoteType, irRemote.remoteProperties));
            irRemoteProto.setAmpState(getIRRemoteStateProto(irRemote.remoteType, irRemote.remoteState));
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
            irRemoteProto.setFanProperties(getIRRemotePropertiesProto(irRemote.remoteType, irRemote.remoteProperties));
            irRemoteProto.setFanState(getIRRemoteStateProto(irRemote.remoteType, irRemote.remoteState));
            break;
    }
    return irRemoteProto;
}
exports.getIRRemoteProto = getIRRemoteProto;
function getIRRemotePropertiesProto(remoteType, remoteProperties) {
    switch (remoteType) {
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
            const acRemoteProps = new zigbee_ir_blaster_pb_1.IRACRemoteProperties();
            const acProps = remoteProperties;
            acRemoteProps.setTemperatureRangeList(acProps.temperatureRange);
            acRemoteProps.setSwingHEnabled(acProps.swingHEnabled);
            acRemoteProps.setSwingHOptionsList(acProps.swingHOptions);
            acRemoteProps.setSwingHSelectType(acProps.swingHSelectType);
            acRemoteProps.setSwingVEnabled(acProps.swingVEnabled);
            acRemoteProps.setSwingVOptionsList(acProps.swingVOptions);
            acRemoteProps.setSwingVSelectType(acProps.swingVSelectType);
            acRemoteProps.setModeEnabled(acProps.modeEnabled);
            acRemoteProps.setModeOptionsList(acProps.modeOptions);
            acRemoteProps.setModeSelectType(acProps.modeSelectType);
            acRemoteProps.setFanEnabled(acProps.fanEnabled);
            acRemoteProps.setFanOptionsList(acProps.fanOptions);
            acRemoteProps.setFanSelectType(acProps.fanSelectType);
            return acRemoteProps;
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
            const tvRemoteProps = new zigbee_ir_blaster_pb_1.IRTVRemoteProperties();
            const tvProps = remoteProperties;
            tvRemoteProps.setSourceEnabled(tvProps.sourceEnabled);
            tvRemoteProps.setSourceOptionsList(tvProps.sourceOptions);
            tvRemoteProps.setSourceSelectType(tvProps.sourceSelectType);
            tvRemoteProps.setModeEnabled(tvProps.modeEnabled);
            tvRemoteProps.setModeOptionsList(tvProps.modeOptions);
            tvRemoteProps.setModeSelectType(tvProps.modeSelectType);
            return tvRemoteProps;
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
            const prRemoteProps = new zigbee_ir_blaster_pb_1.IRPRRemoteProperties();
            const prProps = remoteProperties;
            prRemoteProps.setSourceEnabled(prProps.sourceEnabled);
            prRemoteProps.setSourceOptionsList(prProps.sourceOptions);
            prRemoteProps.setSourceSelectType(prProps.sourceSelectType);
            prRemoteProps.setModeEnabled(prProps.modeEnabled);
            prRemoteProps.setModeOptionsList(prProps.modeOptions);
            prRemoteProps.setModeSelectType(prProps.modeSelectType);
            return prRemoteProps;
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
            const ampRemoteProps = new zigbee_ir_blaster_pb_1.IRAMPRemoteProperties();
            const ampProps = remoteProperties;
            ampRemoteProps.setSourceEnabled(ampProps.sourceEnabled);
            ampRemoteProps.setSourceOptionsList(ampProps.sourceOptions);
            ampRemoteProps.setSourceSelectType(ampProps.sourceSelectType);
            ampRemoteProps.setModeEnabled(ampProps.modeEnabled);
            ampRemoteProps.setModeOptionsList(ampProps.modeOptions);
            ampRemoteProps.setModeSelectType(ampProps.modeSelectType);
            return ampRemoteProps;
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
            const fanRemoteProps = new zigbee_ir_blaster_pb_1.IRFANRemoteProperties();
            const fanProps = remoteProperties;
            fanRemoteProps.setSpeedOptionsList(fanProps.speedOptions);
            fanRemoteProps.setSpeedSelectType(fanProps.speedSelectType);
            fanRemoteProps.setModeEnabled(fanProps.modeEnabled);
            fanRemoteProps.setModeOptionsList(fanProps.modeOptions);
            fanRemoteProps.setModeSelectType(fanProps.modeSelectType);
            fanRemoteProps.setLedEnabled(fanProps.ledEnabled);
            return fanRemoteProps;
            break;
    }
}
exports.getIRRemotePropertiesProto = getIRRemotePropertiesProto;
function getIRRemoteStateProto(remoteType, remoteState) {
    switch (remoteType) {
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
            const acRemoteState = new zigbee_ir_blaster_pb_1.IRACRemoteState();
            const acState = remoteState;
            acRemoteState.setPowerOn(acState.powerOn);
            acRemoteState.setTemperature(acState.temperature);
            acRemoteState.setSwinghlevel(acState.swingHLevel);
            acRemoteState.setSwingvlevel(acState.swingVLevel);
            acRemoteState.setMode(acState.mode);
            acRemoteState.setFanlevel(acState.fanLevel);
            return acRemoteState;
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
            const tvRemoteState = new zigbee_ir_blaster_pb_1.IRTVRemoteState();
            const tvState = remoteState;
            return tvRemoteState;
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
            const prRemoteState = new zigbee_ir_blaster_pb_1.IRPRRemoteState();
            const prState = remoteState;
            return prRemoteState;
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
            const ampRemoteState = new zigbee_ir_blaster_pb_1.IRAMPRemoteState();
            const ampState = remoteState;
            return ampRemoteState;
            break;
        case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
            const fanRemoteState = new zigbee_ir_blaster_pb_1.IRFANRemoteState();
            const fanState = remoteState;
            fanRemoteState.setPowerOn(fanState.powerOn);
            fanRemoteState.setSpeedLevel(fanState.speedLevel);
            fanRemoteState.setMode(fanState.mode);
            fanRemoteState.setLedState(fanState.ledState);
            return fanRemoteState;
            break;
    }
}
exports.getIRRemoteStateProto = getIRRemoteStateProto;
function getIRRemoteProtoList(irRemoteList) {
    const irRemoteProtoList = new Array();
    irRemoteList.forEach(function (irRemote) {
        irRemoteProtoList.push(getIRRemoteProto(irRemote));
    });
    return irRemoteProtoList;
}
exports.getIRRemoteProtoList = getIRRemoteProtoList;
//# sourceMappingURL=device-utils.js.map