"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mini_gateway_setup_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/gatewaysetup/mini-gateway_setup_pb");
function getMiniGatewayProto(miniGateway) {
    const miniGatewayProto = new mini_gateway_setup_pb_1.MiniGateway();
    miniGatewayProto.setGatewayId(miniGateway.gatewayId);
    miniGatewayProto.setGatewayFloor(miniGateway.floor);
    miniGatewayProto.setGatewayLocation(miniGateway.location);
    miniGatewayProto.setGatewayName(miniGateway.name);
    miniGatewayProto.setGatewayIp(miniGateway.ip);
    return miniGatewayProto;
}
exports.getMiniGatewayProto = getMiniGatewayProto;
function getMiniGatewayProtoList(miniGatewayList) {
    const miniGatewayProtoList = new Array();
    miniGatewayList.forEach(function (miniGateway) {
        miniGatewayProtoList.push(getMiniGatewayProto(miniGateway));
    });
    return miniGatewayProtoList;
}
exports.getMiniGatewayProtoList = getMiniGatewayProtoList;
//# sourceMappingURL=gateway-utils.js.map