"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const group_structures_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/groups/group_structures_pb");
const zigbee_dimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_dimmable_driver_pb");
const zigbee_nondimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_nondimmable_driver_pb");
const dali_dimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_dimmable_driver_pb");
const dali_nondimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_nondimmable_driver_pb");
const zigbee_inline_dimmer_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_inline_dimmer_pb");
const zigbee_embedded_switch_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_embedded_switch_pb");
const zigbee_rgbwwa_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const dali_color_tunable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_color_tunable_driver_pb");
//Group properties protos
function getGroupPropertyProto(groupType, groupProperties) {
    switch (groupType) {
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
            const zddProps = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverProperties();
            zddProps.setFadeTime(groupProperties.fadeTime);
            zddProps.setMinValue(groupProperties.minValue);
            zddProps.setMaxValue(groupProperties.maxValue);
            zddProps.setDefaultState(groupProperties.defaultState);
            return zddProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
            const zndProps = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverProperties();
            zndProps.setFadeTime(groupProperties.fadeTime);
            return zndProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
            const dddProps = new dali_dimmable_driver_pb_1.DaliDimmableDriverProperties();
            dddProps.setFadeTime(groupProperties.fadeTime);
            dddProps.setMinValue(groupProperties.minValue);
            dddProps.setMaxValue(groupProperties.maxValue);
            dddProps.setDefaultState(groupProperties.defaultState);
            return dddProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
            const dctdProps = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverGroupProperties();
            dctdProps.setFadeTime(groupProperties.fadeTime);
            dctdProps.setMinValue(groupProperties.minValue);
            dctdProps.setMaxValue(groupProperties.maxValue);
            dctdProps.setMaxTemperature(groupProperties.maxTemperature);
            dctdProps.setMinTemperature(groupProperties.minTemperature);
            dctdProps.setDeviceVoiceName(groupProperties.deviceVoiceName);
            let dctdDefState = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverState();
            dctdDefState.setColorTemperature(groupProperties.defaultState.colorTemperature);
            dctdDefState.setDriverState(groupProperties.defaultState.driverState);
            dctdDefState.setLastUpdateBy(groupProperties.defaultState.lastUpdateBy);
            dctdDefState.setLastUpdateSource(groupProperties.defaultState.lastUpdateSource);
            dctdDefState.setLastUpdateTime(groupProperties.defaultState.lastUpdateTime);
            dctdDefState.setLastUpdateUser(groupProperties.defaultState.lastUpdateUser);
            dctdProps.setDefaultState(dctdDefState);
            return dctdProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
            const dndProps = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverProperties();
            dndProps.setFadeTime(groupProperties.fadeTime);
            return dndProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
            const zidProps = new zigbee_inline_dimmer_pb_1.ZigbeeInlineDimmerProperties();
            zidProps.setFadeTime(groupProperties.fadeTime);
            zidProps.setMinValue(groupProperties.minValue);
            zidProps.setMaxValue(groupProperties.maxValue);
            zidProps.setDefaultState(groupProperties.defaultState);
            return zidProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.RGBWWA:
            const zrgbProps = new zigbee_rgbwwa_driver_pb_1.GroupZigbeeRgbwwaProperties();
            zrgbProps.setOutputChannels(groupProperties.outputChannels);
            zrgbProps.setRgbEnabled(groupProperties.rgbEnabled);
            zrgbProps.setWarmWhiteEnabled(groupProperties.warmWhiteEnabled);
            zrgbProps.setCoolWhiteEnabled(groupProperties.coolWhiteEnabled);
            zrgbProps.setAmberEnabled(groupProperties.amberEnabled);
            zrgbProps.setFadeTime(groupProperties.fadeTime);
            zrgbProps.setDefaultUpdateType(groupProperties.defaultUpdateType);
            let defRgb = new zigbee_rgbwwa_driver_pb_1.RGB();
            defRgb.setRed(groupProperties.defaultRgbAction.red);
            defRgb.setBlue(groupProperties.defaultRgbAction.blue);
            defRgb.setGreen(groupProperties.defaultRgbAction.green);
            defRgb.setPattern(groupProperties.defaultRgbAction.pattern);
            defRgb.setDeviceState(groupProperties.defaultRgbAction.deviceState);
            zrgbProps.setDefaultRgbAction(defRgb);
            let defWwa = new zigbee_rgbwwa_driver_pb_1.WWA();
            defWwa.setWarmWhite(groupProperties.defaultWwaAction.warmWhite);
            defWwa.setCoolWhite(groupProperties.defaultWwaAction.coolWhite);
            defWwa.setAmber(groupProperties.defaultWwaAction.amber);
            defWwa.setDeviceState(groupProperties.defaultWwaAction.deviceState);
            zrgbProps.setDefaultWwaAction(defWwa);
            return zrgbProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
            const onoffprops = new zigbee_embedded_switch_pb_1.OnOffApplianceGroupProperties();
            let appDeviceList = [];
            let onofList = groupProperties.deviceList;
            for (let i = 0; i < onofList.length; i++) {
                let obj = new zigbee_embedded_switch_pb_1.ApplianceidDeviceidDetails();
                obj.setDeviceId(onofList[i].deviceId);
                obj.setApplianceId(onofList[i].applianceId);
                appDeviceList.push(obj);
            }
            onoffprops.setDeviceListList(appDeviceList);
            return onoffprops;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
            console.log('single dimmer group property setting');
            const sdProps = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceGroupProperties();
            let sdDeviceList = [];
            let sdList = groupProperties.deviceList;
            for (let i = 0; i < sdList.length; i++) {
                let obj = new zigbee_embedded_switch_pb_1.ApplianceidDeviceidDetails();
                obj.setDeviceId(sdList[i].deviceId);
                obj.setApplianceId(sdList[i].applianceId);
                sdDeviceList.push(obj);
            }
            sdProps.setDeviceListList(sdDeviceList);
            return sdProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
            const fanProps = new zigbee_embedded_switch_pb_1.FanApplianceGroupProperties();
            let fanDeviceList = [];
            let fanList = groupProperties.deviceList;
            for (let i = 0; i < fanList.length; i++) {
                let obj = new zigbee_embedded_switch_pb_1.ApplianceidDeviceidDetails();
                obj.setDeviceId(fanList[i].deviceId);
                obj.setApplianceId(fanList[i].applianceId);
                fanDeviceList.push(obj);
            }
            fanProps.setDeviceListList(fanDeviceList);
            return fanProps;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
            const ctProps = new zigbee_embedded_switch_pb_1.ColorTunableApplianceGroupProperties();
            let ctDeviceList = [];
            let ctList = groupProperties.deviceList;
            for (let i = 0; i < ctList.length; i++) {
                let obj = new zigbee_embedded_switch_pb_1.ApplianceidDeviceidDetails();
                obj.setDeviceId(ctList[i].deviceId);
                obj.setApplianceId(ctList[i].applianceId);
                ctDeviceList.push(obj);
            }
            ctProps.setDeviceListList(ctDeviceList);
            return ctProps;
            break;
        default:
            return null;
    }
}
exports.getGroupPropertyProto = getGroupPropertyProto;
//Group state protos
function getGroupStateProto(groupType, groupState) {
    switch (groupType) {
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
            const zddState = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverState();
            zddState.setDriverState(groupState.driverState);
            return zddState;
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
            const zndState = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverState();
            zndState.setDriverState(groupState.driverState);
            return zndState;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
            const dctdState = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverState();
            dctdState.setColorTemperature(groupState.colorTemperature);
            dctdState.setDriverState(groupState.driverState);
            dctdState.setLastUpdateBy(groupState.lastUpdateBy);
            dctdState.setLastUpdateSource(groupState.lastUpdateSource);
            dctdState.setLastUpdateTime(groupState.lastUpdateTime);
            dctdState.setLastUpdateUser(groupState.lastUpdateUser);
            return dctdState;
            break;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
            const dddState = new dali_dimmable_driver_pb_1.DaliDimmableDriverState();
            dddState.setDriverState(groupState.driverState);
            return dddState;
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
            const dndState = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverState();
            dndState.setDriverState(groupState.driverState);
            return dndState;
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
            const zidState = new zigbee_inline_dimmer_pb_1.ZigbeeInlineDimmerState();
            zidState.setDeviceState(groupState.deviceState);
            return zidState;
            break;
        case group_structures_pb_1.GROUP_TYPES.RGBWWA:
            const zrgbState = new zigbee_rgbwwa_driver_pb_1.GroupZigbeeRgbwwaState();
            zrgbState.setUpdateType(groupState.updateType);
            zrgbState.setDeviceState(groupState.deviceState);
            let staRgb = new zigbee_rgbwwa_driver_pb_1.RGB();
            staRgb.setRed(groupState.rgbState.red);
            staRgb.setBlue(groupState.rgbState.blue);
            staRgb.setGreen(groupState.rgbState.green);
            staRgb.setPattern(groupState.rgbState.pattern);
            staRgb.setDeviceState(groupState.rgbState.deviceState);
            zrgbState.setRgbState(staRgb);
            let staWwa = new zigbee_rgbwwa_driver_pb_1.WWA();
            staWwa.setWarmWhite(groupState.wwaState.warmWhite);
            staWwa.setCoolWhite(groupState.wwaState.coolWhite);
            staWwa.setAmber(groupState.wwaState.amber);
            staWwa.setDeviceState(groupState.wwaState.deviceState);
            zrgbState.setWwaState(staWwa);
            return zrgbState;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
            const onoffstate = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
            onoffstate.setSwitchState(groupState.switchState);
            return onoffstate;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
            const sdstate = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
            sdstate.setSwitchState(groupState.switchState);
            console.log('single dimmer group state setting', sdstate);
            return sdstate;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
            const fanstate = new zigbee_embedded_switch_pb_1.FanApplianceState();
            fanstate.setFanState(groupState.fanState);
            return fanstate;
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
            const ctState = new zigbee_embedded_switch_pb_1.ColorTunableApplianceState();
            ctState.setLightState(groupState.lightState);
            ctState.setWarmWhiteState(groupState.warmWhiteState);
            ctState.setCoolWhiteState(groupState.coolWhiteState);
            return ctState;
            break;
        default:
            return null;
    }
}
exports.getGroupStateProto = getGroupStateProto;
//Group protos
function getGroupProto(group) {
    const groupProto = new group_structures_pb_1.Group();
    groupProto.setGroupId(group.groupId);
    groupProto.setGroupName(group.groupName);
    groupProto.setGroupType(group.groupType);
    groupProto.setGroupSection(group.groupSection);
    groupProto.setDevicesList(group.deviceList);
    groupProto.setGroupRoom(group.groupRoom);
    groupProto.setIsConfigured(group.isConfigured);
    groupProto.setIsHidden(group.isHidden);
    groupProto.setGroupVoiceName(group.groupVoiceName);
    groupProto.setLastUpdateBy(group.lastUpdateBy);
    groupProto.setLastUpdateSource(group.lastUpdateSource);
    groupProto.setLastUpdateTime(group.lastUpdateTime);
    groupProto.setLastUpdateUser(group.lastUpdateUser);
    switch (group.groupType) {
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_DIMMABLE:
            groupProto.setZdimmableDriverState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setZdimmableDriverProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_NON_DIMMABLE:
            groupProto.setZnondimmableDriverState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setZnondimmableDriverProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_DIMMABLE:
            groupProto.setDdimmableDriverState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setDdimmableDriverProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_COLOR_TUNABLE:
            groupProto.setDcolortunableDriverState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setDcolortunableDriverProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.DALI_NON_DIMMABLE:
            groupProto.setDnondimmableDriverState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setDnondimmableDriverProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.ZIGBEE_INLINE:
            groupProto.setZinlineDimmerState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setZinlineDimmerProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.RGBWWA:
            groupProto.setZrgbwwaState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setZrgbwwaProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_SINGLE_DIMMER:
            console.log('single dimmer group setting');
            groupProto.setAppSingleDimmerState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setSingleDimmerApplianceProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_ON_OFF:
            groupProto.setAppOnffState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setOnoffApplianceProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_FAN:
            groupProto.setAppFanState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setFanApplianceProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        case group_structures_pb_1.GROUP_TYPES.APPLIANCE_COLOR_TUNABLE:
            groupProto.setAppColorTunableState(getGroupStateProto(group.groupType, group.groupState));
            groupProto.setColorTunableApplianceProperties(getGroupPropertyProto(group.groupType, group.groupProperties));
            break;
        default:
    }
    return groupProto;
}
exports.getGroupProto = getGroupProto;
function getGroupProtoList(groupList) {
    const groupProtoList = new Array();
    groupList.forEach(function (group) {
        groupProtoList.push(getGroupProto(group));
    });
    return groupProtoList;
}
exports.getGroupProtoList = getGroupProtoList;
//# sourceMappingURL=group-utils.js.map