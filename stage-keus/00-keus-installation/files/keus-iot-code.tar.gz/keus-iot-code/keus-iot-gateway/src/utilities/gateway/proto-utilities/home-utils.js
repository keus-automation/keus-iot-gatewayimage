"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const home_structures_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/home/home_structures_pb");
const scene_structures_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/scenes/scene_structures_pb");
//Area protos
function getAreaProto(area) {
    const areaProto = new home_structures_pb_1.Area();
    const areaSyncInfoProto = new home_structures_pb_1.AreaSyncInfo();
    areaProto.setAreaId(area.areaId);
    areaProto.setAreaName(area.areaName);
    if (area.areaSyncInfo) {
        areaSyncInfoProto.setSyncRequestId(area.areaSyncInfo.syncRequestId);
        areaSyncInfoProto.setSyncRequestTime(area.areaSyncInfo.syncRequestTime);
        areaSyncInfoProto.setSyncRequestType(area.areaSyncInfo.syncRequestType);
        areaSyncInfoProto.setSyncStatus(area.areaSyncInfo.syncStatus);
        switch (area.areaSyncInfo.syncRequestType) {
            case home_structures_pb_1.AREA_JOB_TYPES.AREA_NONE:
                areaSyncInfoProto.setNullRequestParams(new scene_structures_pb_1.NullRequest());
                break;
            case home_structures_pb_1.AREA_JOB_TYPES.AREA_SYNCSCENEUI:
                areaSyncInfoProto.setSyncAreaSceneUidataParams(new scene_structures_pb_1.SyncAreaSceneUIData());
                break;
        }
        areaProto.setAreaSyncInfo(areaSyncInfoProto);
    }
    return areaProto;
}
exports.getAreaProto = getAreaProto;
function getAreaProtoList(areaList) {
    const areaProtoList = new Array();
    areaList.forEach(function (area) {
        areaProtoList.push(getAreaProto(area));
    });
    return areaProtoList;
}
exports.getAreaProtoList = getAreaProtoList;
//Floor protos
function getFloorProto(floor) {
    const floorProto = new home_structures_pb_1.Floor();
    floorProto.setFloorId(floor.floorId);
    floorProto.setFloorName(floor.floorName);
    return floorProto;
}
exports.getFloorProto = getFloorProto;
function getFloorProtoList(floorList) {
    const floorProtoList = new Array();
    floorList.forEach(function (floor) {
        floorProtoList.push(getFloorProto(floor));
    });
    return floorProtoList;
}
exports.getFloorProtoList = getFloorProtoList;
//Section Protos
function getSectionProto(section) {
    const sectionProto = new home_structures_pb_1.Section();
    sectionProto.setSectionId(section.sectionId);
    sectionProto.setSectionName(section.sectionName);
    return sectionProto;
}
exports.getSectionProto = getSectionProto;
function getSectionProtoList(sectionList) {
    const sectionProtoList = new Array();
    sectionList.forEach(function (section) {
        sectionProtoList.push(getSectionProto(section));
    });
    return sectionProtoList;
}
exports.getSectionProtoList = getSectionProtoList;
//Room protos
function getRoomProto(room) {
    const roomProto = new home_structures_pb_1.Room();
    roomProto.setRoomId(room.roomId);
    roomProto.setRoomType(room.roomType);
    roomProto.setRoomImageType(room.roomImageType);
    roomProto.setRoomName(room.roomName);
    roomProto.setFloorId(room.floorId);
    roomProto.setAreaId(room.areaId);
    roomProto.setSectionsList(getSectionProtoList(room.sectionList));
    return roomProto;
}
exports.getRoomProto = getRoomProto;
function getRoomProtoList(roomList) {
    const roomProtoList = new Array();
    roomList.forEach(function (room) {
        roomProtoList.push(getRoomProto(room));
    });
    return roomProtoList;
}
exports.getRoomProtoList = getRoomProtoList;
//# sourceMappingURL=home-utils.js.map