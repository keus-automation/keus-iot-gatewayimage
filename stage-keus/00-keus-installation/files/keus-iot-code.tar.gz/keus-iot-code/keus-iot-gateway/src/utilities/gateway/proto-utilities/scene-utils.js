"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const scene_structures_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/scenes/scene_structures_pb");
const scene_constants_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/scenes/scene_constants_pb");
const scene_types_1 = require("../../../constants/scene/scene-types");
const zigbee_dimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_dimmable_driver_pb");
const zigbee_nondimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_nondimmable_driver_pb");
const dali_dimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_dimmable_driver_pb");
const dali_nondimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_nondimmable_driver_pb");
const zigbee_embedded_switch_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_embedded_switch_pb");
const zigbee_ac_fan_controller_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const zigbee_dc_fan_controller_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const zigbee_rgbwwa_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const device_constants_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/device_constants_pb");
const zigbee_curtain_controller_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_curtain_controller_pb");
const smart_console_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/smart_console_pb");
const zigbee_ir_blaster_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_ir_blaster_pb");
const dali_color_tunable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_color_tunable_driver_pb");
//Get Scene Action Proto
function getActionItemProto(sceneActionType, sceneAction) {
    switch (sceneActionType) {
        case scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER:
            const dddAction = new dali_dimmable_driver_pb_1.DaliDimmableDriverAction();
            dddAction.setGroupId(sceneAction.groupId);
            dddAction.setRoomId(sceneAction.roomId);
            dddAction.setDriverState(sceneAction.driverState);
            return dddAction;
            break;
        case scene_types_1.SceneActionTypes.DALICOLORTUNABLEDRIVER:
            const dctdAction = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverGroupSceneAction();
            dctdAction.setGroupId(sceneAction.groupId);
            dctdAction.setGroupRoom(sceneAction.roomId);
            let dctDriverState = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverState();
            dctDriverState.setDriverState(sceneAction.driverState.driverState);
            dctDriverState.setColorTemperature(sceneAction.driverState.colorTemperature);
            dctDriverState.setLastUpdateBy(sceneAction.driverState.lastUpdateBy);
            dctDriverState.setLastUpdateSource(sceneAction.driverState.lastUpdateSource);
            dctDriverState.setLastUpdateTime(sceneAction.driverState.lastUpdateTime);
            dctDriverState.setLastUpdateUser(sceneAction.driverState.lastUpdateUser);
            dctdAction.setDriverState(dctDriverState);
            return dctdAction;
            break;
        case scene_types_1.SceneActionTypes.DALINONDIMMABLEDRIVER:
            const dndAction = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverAction();
            dndAction.setGroupId(sceneAction.groupId);
            dndAction.setRoomId(sceneAction.roomId);
            dndAction.setDriverState(sceneAction.driverState);
            return dndAction;
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER:
            const zddAction = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverAction();
            zddAction.setGroupId(sceneAction.groupId);
            zddAction.setRoomId(sceneAction.roomId);
            zddAction.setDriverState(sceneAction.driverState);
            return zddAction;
            break;
        case scene_types_1.SceneActionTypes.ZIGBEENONDIMMABLEDRIVER:
            const zndAction = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverAction();
            zndAction.setGroupId(sceneAction.groupId);
            zndAction.setRoomId(sceneAction.roomId);
            zndAction.setDriverState(sceneAction.driverState);
            return zndAction;
            break;
        case scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER:
            const zccAction = new zigbee_curtain_controller_pb_1.ZigbeeCurtainControllerAction();
            console.log('THIS IS SCENE CURTAIN ACTION', JSON.stringify(sceneAction, null, 4));
            zccAction.setDeviceId(sceneAction.deviceId);
            zccAction.setCurtainState(sceneAction.curtainState);
            return zccAction;
            break;
        case scene_types_1.SceneActionTypes.AREASCENEACTION:
            const zascnAction = new scene_structures_pb_1.AreaSceneAction();
            zascnAction.setRoomId(sceneAction.roomId);
            zascnAction.setSceneId(sceneAction.sceneId);
            return zascnAction;
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH:
            let esaction = new zigbee_embedded_switch_pb_1.EmbeddedApplianceAction();
            esaction.setDeviceId(sceneAction.deviceId);
            esaction.setApplianceId(sceneAction.applianceId);
            esaction.setApplianceType(sceneAction.applianceType);
            switch (sceneAction.applianceType) {
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                    let onState = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
                    let onoffs = sceneAction.applianceState;
                    onState.setSwitchState(onoffs.switchState);
                    esaction.setOnOffState(onState);
                    break;
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                    let sdState = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
                    let sds = sceneAction.applianceState;
                    sdState.setSwitchState(sds.switchState);
                    esaction.setSingleDimmerState(sdState);
                    break;
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.FAN:
                    let fanState = new zigbee_embedded_switch_pb_1.FanApplianceState();
                    let fans = sceneAction.applianceState;
                    fanState.setFanState(fans.fanState);
                    esaction.setFanState(fanState);
                    break;
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.COLOR_TUNABLE:
                    let ctState = new zigbee_embedded_switch_pb_1.ColorTunableApplianceState();
                    let cts = sceneAction.applianceState;
                    ctState.setLightState(cts.lightState);
                    ctState.setWarmWhiteState(cts.warmWhiteState);
                    ctState.setCoolWhiteState(cts.coolWhiteState);
                    esaction.setColorTunableState(ctState);
                    break;
            }
            return esaction;
            break;
        case scene_types_1.SceneActionTypes.GROUPAPPLIANCEONOFF:
            let gaooAction = new zigbee_embedded_switch_pb_1.GroupOnOffApplianceAction();
            let goo = sceneAction;
            gaooAction.setRoomId(goo.roomId);
            gaooAction.setGroupId(goo.groupId);
            gaooAction.setSwitchState(goo.switchState);
            return gaooAction;
            break;
        case scene_types_1.SceneActionTypes.GROUPAPPLIANCESINGLEDIMMER:
            let gasdAction = new zigbee_embedded_switch_pb_1.GroupSingleDimmerApplianceAction();
            let gsd = sceneAction;
            gasdAction.setRoomId(gsd.roomId);
            gasdAction.setGroupId(gsd.groupId);
            gasdAction.setSwitchState(gsd.switchState);
            return gasdAction;
            break;
        case scene_types_1.SceneActionTypes.GROUPAPPLIANCEFAN:
            let gafAction = new zigbee_embedded_switch_pb_1.GroupFanApplianceAction();
            let gf = sceneAction;
            gafAction.setRoomId(gf.roomId);
            gafAction.setGroupId(gf.groupId);
            gafAction.setFanState(gf.fanState);
            return gafAction;
            break;
        case scene_types_1.SceneActionTypes.GROUPAPPLIANCECOLORTUNABLE:
            let gactAction = new zigbee_embedded_switch_pb_1.GroupColorTunableApplianceAction();
            let gct = sceneAction;
            gactAction.setRoomId(gct.roomId);
            gactAction.setGroupId(gct.groupId);
            gactAction.setLightState(gct.lightState);
            gactAction.setWarmWhiteState(gct.warmWhiteState);
            gactAction.setCoolWhiteState(gct.coolWhiteState);
            return gactAction;
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER:
            const zacfcAction = new zigbee_ac_fan_controller_pb_1.ZigbeeACFanControllerAction();
            zacfcAction.setDeviceId(sceneAction.deviceId);
            zacfcAction.setUpdateType(sceneAction.updateType);
            zacfcAction.setFanState(sceneAction.fanState);
            zacfcAction.setLightState(sceneAction.lightState);
            return zacfcAction;
            break;
        case scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE:
            const zscAction = new smart_console_pb_1.SmartConsoleRelayAction();
            zscAction.setDeviceId(sceneAction.deviceId);
            zscAction.setRelayId(sceneAction.relayId);
            zscAction.setRelayState(sceneAction.relayState);
            return zscAction;
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEDCFANCONTROLLER:
            const zdcfcAction = new zigbee_dc_fan_controller_pb_1.ZigbeeDCFanControllerAction();
            const zdcfcLightAction = new zigbee_dc_fan_controller_pb_1.DCFanControllerLightState();
            zdcfcAction.setDeviceId(sceneAction.deviceId);
            zdcfcAction.setUpdateType(sceneAction.updateType);
            zdcfcAction.setFanState(sceneAction.fanState ? sceneAction.fanState : 0);
            zdcfcLightAction.setLightState(sceneAction.lightState ? sceneAction.lightState.lightState : 0);
            zdcfcLightAction.setLightTemperature(sceneAction.lightState ? sceneAction.lightState.lightTemperature : 0);
            zdcfcAction.setLightState(zdcfcLightAction);
            return zdcfcAction;
            break;
        case scene_types_1.SceneActionTypes.ZIGBEERGBWWADRIVER:
            const zrgbwwaAction = new zigbee_rgbwwa_driver_pb_1.ZigbeeRgbwwaAction();
            zrgbwwaAction.setDeviceId(sceneAction.deviceId);
            zrgbwwaAction.setUpdateType(sceneAction.updateType);
            zrgbwwaAction.setDeviceState(sceneAction.deviceState);
            if (sceneAction.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                const zrgbAction = new zigbee_rgbwwa_driver_pb_1.RGB();
                zrgbAction.setRed(sceneAction.rgbState.red);
                zrgbAction.setBlue(sceneAction.rgbState.blue);
                zrgbAction.setGreen(sceneAction.rgbState.green);
                zrgbAction.setPattern(sceneAction.rgbState.pattern);
                zrgbAction.setDeviceState(sceneAction.rgbState.deviceState);
                zrgbwwaAction.setRgbState(zrgbAction);
            }
            else if (sceneAction.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                const zwwaAction = new zigbee_rgbwwa_driver_pb_1.WWA();
                zwwaAction.setAmber(sceneAction.wwaState.amber);
                zwwaAction.setCoolWhite(sceneAction.wwaState.coolWhite);
                zwwaAction.setWarmWhite(sceneAction.wwaState.warmWhite);
                zwwaAction.setDeviceState(sceneAction.wwaState.deviceState);
                zrgbwwaAction.setWwaState(zwwaAction);
            }
            return zrgbwwaAction;
            break;
        case scene_types_1.SceneActionTypes.GROUPRGBWWADRIVER:
            const grgbwwaAction = new zigbee_rgbwwa_driver_pb_1.GroupZigbeeRgbwwaAction();
            grgbwwaAction.setGroupId(sceneAction.groupId);
            grgbwwaAction.setRoomId(sceneAction.roomId);
            grgbwwaAction.setUpdateType(sceneAction.updateType);
            grgbwwaAction.setDeviceState(sceneAction.deviceState);
            if (sceneAction.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                const grgbAction = new zigbee_rgbwwa_driver_pb_1.RGB();
                grgbAction.setRed(sceneAction.rgbState.red);
                grgbAction.setBlue(sceneAction.rgbState.blue);
                grgbAction.setGreen(sceneAction.rgbState.green);
                grgbAction.setPattern(sceneAction.rgbState.pattern);
                grgbAction.setDeviceState(sceneAction.rgbState.deviceState);
                grgbwwaAction.setRgbState(grgbAction);
            }
            else if (sceneAction.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                const gwwaAction = new zigbee_rgbwwa_driver_pb_1.WWA();
                gwwaAction.setAmber(sceneAction.wwaState.amber);
                gwwaAction.setCoolWhite(sceneAction.wwaState.coolWhite);
                gwwaAction.setWarmWhite(sceneAction.wwaState.warmWhite);
                gwwaAction.setDeviceState(sceneAction.wwaState.deviceState);
                grgbwwaAction.setWwaState(gwwaAction);
            }
            return grgbwwaAction;
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEIRBLASTER:
            const zirbAction = new zigbee_ir_blaster_pb_1.ZigbeeIRBlasterAction();
            zirbAction.setRemoteId(sceneAction.remoteId);
            zirbAction.setRemoteType(sceneAction.remoteType);
            zirbAction.setIrDevice(sceneAction.irDevice);
            switch (sceneAction.remoteType) {
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                    const zirAcAction = new zigbee_ir_blaster_pb_1.IRACBlastAction();
                    zirAcAction.setPowerOn(sceneAction.irBlastAction.powerOn);
                    zirAcAction.setMode(sceneAction.irBlastAction.mode);
                    zirAcAction.setTemperature(sceneAction.irBlastAction.temperature);
                    zirAcAction.setSwingHLevel(sceneAction.irBlastAction.swingHLevel);
                    zirAcAction.setSwingVLevel(sceneAction.irBlastAction.swingVLevel);
                    zirAcAction.setFanLevel(sceneAction.irBlastAction.fanLevel);
                    zirbAction.setAcActionInfo(zirAcAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                    const zirTvAction = new zigbee_ir_blaster_pb_1.IRTVBlastAction();
                    zirTvAction.setUpdateType(sceneAction.irBlastAction.updateType);
                    zirTvAction.setPowerOn(sceneAction.irBlastAction.powerOn);
                    zirTvAction.setMode(sceneAction.irBlastAction.mode);
                    zirTvAction.setChannelNumber(sceneAction.irBlastAction.channelNumber);
                    zirTvAction.setSource(sceneAction.irBlastAction.source);
                    zirbAction.setTvActionInfo(zirTvAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                    const zirPrAction = new zigbee_ir_blaster_pb_1.IRPRBlastAction();
                    zirPrAction.setUpdateType(sceneAction.irBlastAction.updateType);
                    zirPrAction.setPowerOn(sceneAction.irBlastAction.powerOn);
                    zirPrAction.setMode(sceneAction.irBlastAction.mode);
                    zirPrAction.setSource(sceneAction.irBlastAction.source);
                    zirbAction.setPrActionInfo(zirPrAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                    const zirAmpAction = new zigbee_ir_blaster_pb_1.IRAMPBlastAction();
                    zirAmpAction.setUpdateType(sceneAction.irBlastAction.updateType);
                    zirAmpAction.setPowerOn(sceneAction.irBlastAction.powerOn);
                    zirAmpAction.setMode(sceneAction.irBlastAction.mode);
                    zirAmpAction.setSource(sceneAction.irBlastAction.source);
                    zirbAction.setAmpActionInfo(zirAmpAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                    const zirFanAction = new zigbee_ir_blaster_pb_1.IRFANBlastAction();
                    zirFanAction.setPowerOn(sceneAction.irBlastAction.powerOn);
                    zirFanAction.setMode(sceneAction.irBlastAction.mode);
                    zirFanAction.setSpeedLevel(sceneAction.irBlastAction.speedLevel);
                    zirFanAction.setLedState(sceneAction.irBlastAction.ledState);
                    zirbAction.setFanActionInfo(zirFanAction);
                    break;
                default:
            }
            return zirbAction;
            break;
        default:
            return null;
    }
}
exports.getActionItemProto = getActionItemProto;
function getSceneActionProto(sceneAction) {
    const sceneActionProto = new scene_structures_pb_1.SceneAction();
    sceneActionProto.setActionType(sceneAction.actionType);
    sceneActionProto.setTimeslotId(sceneAction.timeslotId);
    sceneActionProto.setActionId(sceneAction.actionId);
    sceneActionProto.setSyncStatus(sceneAction.syncStatus);
    switch (sceneAction.actionType) {
        case scene_types_1.SceneActionTypes.DALIDIMMABLEDRIVER:
            sceneActionProto.setDdimmableDriverAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.DALICOLORTUNABLEDRIVER:
            sceneActionProto.setDcolortunableDriverAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.DALINONDIMMABLEDRIVER:
            sceneActionProto.setDnondimmableDriverAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEDIMMABLEDRIVER:
            sceneActionProto.setZdimmableDriverAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.ZIGBEENONDIMMABLEDRIVER:
            sceneActionProto.setZnondimmableDriverAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.ZIGBEECURTAINCONTROLLER:
            sceneActionProto.setZcurtainControllerAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.AREASCENEACTION:
            sceneActionProto.setAreaSceneAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEEMBEDDEDSWITCH:
            sceneActionProto.setEmbeddedApplianceAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.ZIGBEESMARTCONSOLE:
            sceneActionProto.setZscRelayAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEACFANCONTROLLER:
            sceneActionProto.setZacfanControllerAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEDCFANCONTROLLER:
            sceneActionProto.setZdcfanControllerAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.ZIGBEERGBWWADRIVER:
            sceneActionProto.setZrgbwwwaDriverAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.GROUPRGBWWADRIVER:
            sceneActionProto.setGrpZrgbwwaAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.ZIGBEEIRBLASTER:
            sceneActionProto.setZirBlasterAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.GROUPAPPLIANCEONOFF:
            sceneActionProto.setGrpOnoffAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.GROUPAPPLIANCESINGLEDIMMER:
            sceneActionProto.setGrpSingledimmerAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.GROUPAPPLIANCEFAN:
            sceneActionProto.setGrpFanAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        case scene_types_1.SceneActionTypes.GROUPAPPLIANCECOLORTUNABLE:
            sceneActionProto.setGrpColortunableAction(getActionItemProto(sceneAction.actionType, sceneAction.actionItem));
            break;
        default:
    }
    return sceneActionProto;
}
exports.getSceneActionProto = getSceneActionProto;
function getSceneActionListProto(sceneActionList) {
    const sceneActionProtoList = new Array();
    sceneActionList.forEach(function (sceneAction) {
        sceneActionProtoList.push(getSceneActionProto(sceneAction));
    });
    return sceneActionProtoList;
}
exports.getSceneActionListProto = getSceneActionListProto;
//Time slots
function getTimeslotProto(timeSlot) {
    const timeslotProto = new scene_structures_pb_1.Timeslot();
    timeslotProto.setTimeslotId(timeSlot.timeslotId);
    timeslotProto.setTimeslotDelay(timeSlot.timeslotDelay);
    return timeslotProto;
}
exports.getTimeslotProto = getTimeslotProto;
function getTimeslotListProto(timeslotList) {
    const timeslotProtoList = new Array();
    timeslotList.forEach(function (timeslot) {
        timeslotProtoList.push(getTimeslotProto(timeslot));
    });
    return timeslotProtoList;
}
exports.getTimeslotListProto = getTimeslotListProto;
function getSceneSyncInfoProto(scene) {
    const sceneSyncInfoProto = new scene_structures_pb_1.SceneSyncInfo();
    sceneSyncInfoProto.setSyncRequestId(scene.sceneSyncInfo.syncRequestId);
    sceneSyncInfoProto.setSyncRequestType(scene.sceneSyncInfo.syncRequestType);
    sceneSyncInfoProto.setSyncRequestTime(scene.sceneSyncInfo.syncRequestTime);
    sceneSyncInfoProto.setSyncStatus(scene.sceneSyncInfo.syncStatus);
    switch (scene.sceneSyncInfo.syncRequestType) {
        case scene_constants_pb_1.SCENE_JOB_TYPES.SCENE_NONE:
            const NoReq = new scene_structures_pb_1.NullRequest();
            sceneSyncInfoProto.setNullRequestParams(NoReq);
            break;
        case scene_constants_pb_1.SCENE_JOB_TYPES.SCENE_ADJTSDELAY:
            const adjustTimeslotDelayParams = new scene_structures_pb_1.AdjustTimeslotDelay();
            const adjustTimeslotDelaySyncInfo = scene.sceneSyncInfo.syncRequestParams;
            adjustTimeslotDelayParams.setSceneId(scene.sceneId);
            adjustTimeslotDelayParams.setSceneRoom(scene.sceneRoom);
            adjustTimeslotDelayParams.setTimeslotId(adjustTimeslotDelaySyncInfo.timeslotId);
            adjustTimeslotDelayParams.setTimeslotDelay(adjustTimeslotDelaySyncInfo.timeslotDelay);
            sceneSyncInfoProto.setAdjustTimeslotDelayParams(adjustTimeslotDelayParams);
            break;
        case scene_constants_pb_1.SCENE_JOB_TYPES.SCENE_DELTS:
            const deleteTimeslotParams = new scene_structures_pb_1.RemoveTimeslotFromScene();
            const deleteTimeslotSyncInfo = scene.sceneSyncInfo.syncRequestParams;
            adjustTimeslotDelayParams.setSceneId(scene.sceneId);
            adjustTimeslotDelayParams.setSceneRoom(scene.sceneRoom);
            adjustTimeslotDelayParams.setTimeslotId(deleteTimeslotSyncInfo.timeslotId);
            sceneSyncInfoProto.setRemoveTimeslotParams(deleteTimeslotParams);
            break;
        // case SYNC_REQTYPE.DELSCENE:
        //     const adjustTimeslotDelayParams = new AdjustTimeslotDelay();
        //     const adjustTimeslotDelaySyncInfo = <IAdjustTsDelayParams>scene.sceneSyncInfo.syncRequestParams;
        //     adjustTimeslotDelayParams.setSceneId(scene.sceneId);
        //     adjustTimeslotDelayParams.setSceneRoom(scene.sceneRoom);
        //     adjustTimeslotDelayParams.setTimeslotId(adjustTimeslotDelaySyncInfo.timeslotId);
        //     adjustTimeslotDelayParams.setTimeslotDelay(adjustTimeslotDelaySyncInfo.timeslotDelay);
        //     sceneSyncInfoProto.setAdjustTimeslotDelayParams(adjustTimeslotDelayParams);
        //     break;
        default:
    }
    return sceneSyncInfoProto;
}
exports.getSceneSyncInfoProto = getSceneSyncInfoProto;
//Scene protos
function getSceneProto(scene) {
    const sceneProto = new scene_structures_pb_1.Scene();
    sceneProto.setSceneId(scene.sceneId);
    sceneProto.setSceneName(scene.sceneName);
    sceneProto.setSceneType(scene.sceneType);
    sceneProto.setSceneSection(scene.sceneSection);
    sceneProto.setSceneRoom(scene.sceneRoom);
    sceneProto.setSceneExecutionType(scene.sceneExecutionType);
    sceneProto.setSceneScope(scene.sceneScope);
    sceneProto.setLastUpdateBy(scene.lastUpdateBy);
    sceneProto.setLastUpdateSource(scene.lastUpdateSource);
    sceneProto.setLastUpdateTime(scene.lastUpdateTime);
    sceneProto.setLastUpdateUser(scene.lastUpdateUser);
    sceneProto.setActionList(getSceneActionListProto(scene.actionList));
    sceneProto.setTimeslotList(getTimeslotListProto(scene.timeslotList));
    sceneProto.setSceneSyncInfo(getSceneSyncInfoProto(scene));
    return sceneProto;
}
exports.getSceneProto = getSceneProto;
function getSceneProtoList(sceneList) {
    const sceneProtoList = new Array();
    sceneList.forEach(function (scene) {
        sceneProtoList.push(getSceneProto(scene));
    });
    return sceneProtoList;
}
exports.getSceneProtoList = getSceneProtoList;
//# sourceMappingURL=scene-utils.js.map