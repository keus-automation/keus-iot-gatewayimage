"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const zigbee_dimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_dimmable_driver_pb");
const zigbee_nondimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_nondimmable_driver_pb");
const dali_dimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_dimmable_driver_pb");
const dali_nondimmable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_nondimmable_driver_pb");
const zigbee_curtain_controller_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_curtain_controller_pb");
const zigbee_embedded_switch_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_embedded_switch_pb");
const zigbee_ac_fan_controller_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_ac_fan_controller_pb");
const zigbee_dc_fan_controller_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_dc_fan_controller_pb");
const zigbee_rgbwwa_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_rgbwwa_driver_pb");
const smart_console_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/smart_console_pb");
const zigbee_ir_blaster_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/zigbee_ir_blaster_pb");
const scene_structures_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/scenes/scene_structures_pb");
const schedule_structure_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/schedules/schedule_structure_pb");
const device_constants_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/device_constants_pb");
const dali_color_tunable_driver_pb_1 = require("../../../app/hub-request-manager/protos/generated/hub/devices/dali_color_tunable_driver_pb");
function getScheduleActionProto(scheduleActionType, scheduleAction) {
    switch (scheduleActionType) {
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_DIMMABLE_DRIVER:
            let dbaction = new dali_dimmable_driver_pb_1.DaliDimmableDriverAction();
            dbaction.setGroupId(scheduleAction.groupId);
            dbaction.setRoomId(scheduleAction.roomId);
            dbaction.setDriverState(scheduleAction.driverState);
            return dbaction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_COLOR_TUNABLE_DRIVER:
            const dctdAction = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverGroupScheculeAction();
            dctdAction.setGroupId(scheduleAction.groupId);
            dctdAction.setGroupRoom(scheduleAction.roomId);
            let dctDriverState = new dali_color_tunable_driver_pb_1.DaliColorTunableDriverState();
            dctDriverState.setDriverState(scheduleAction.driverState.driverState);
            dctDriverState.setColorTemperature(scheduleAction.driverState.colorTemperature);
            dctDriverState.setLastUpdateBy(scheduleAction.driverState.lastUpdateBy);
            dctDriverState.setLastUpdateSource(scheduleAction.driverState.lastUpdateSource);
            dctDriverState.setLastUpdateTime(scheduleAction.driverState.lastUpdateTime);
            dctDriverState.setLastUpdateUser(scheduleAction.driverState.lastUpdateUser);
            dctdAction.setDriverState(dctDriverState);
            return dctdAction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_NON_DIMMABLE_DRIVER:
            let dbnddaction = new dali_nondimmable_driver_pb_1.DaliNonDimmableDriverAction();
            dbnddaction.setGroupId(scheduleAction.groupId);
            dbnddaction.setRoomId(scheduleAction.roomId);
            dbnddaction.setDriverState(scheduleAction.driverState);
            return dbnddaction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DIMMABLE_DRIVER:
            let dzddaction = new zigbee_dimmable_driver_pb_1.ZigbeeDimmableDriverAction();
            dzddaction.setGroupId(scheduleAction.groupId);
            dzddaction.setRoomId(scheduleAction.roomId);
            dzddaction.setDriverState(scheduleAction.driverState);
            return dzddaction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_NON_DIMMABLE_DRIVER:
            let dznddaction = new zigbee_nondimmable_driver_pb_1.ZigbeeNonDimmableDriverAction();
            dznddaction.setGroupId(scheduleAction.groupId);
            dznddaction.setRoomId(scheduleAction.roomId);
            dznddaction.setDriverState(scheduleAction.driverState);
            return dznddaction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_CURTAIN_CONTROLLER:
            let ccaction = new zigbee_curtain_controller_pb_1.ZigbeeCurtainControllerAction();
            ccaction.setDeviceId(scheduleAction.deviceId);
            ccaction.setCurtainState(scheduleAction.curtainState);
            return ccaction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_EMBEDDED_SWITCH:
            let esaction = new zigbee_embedded_switch_pb_1.EmbeddedApplianceAction();
            esaction.setDeviceId(scheduleAction.deviceId);
            esaction.setApplianceId(scheduleAction.applianceId);
            esaction.setApplianceType(scheduleAction.applianceType);
            switch (scheduleAction.applianceType) {
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                    let onState = new zigbee_embedded_switch_pb_1.OnOffApplianceState();
                    let onoffs = scheduleAction.applianceState;
                    onState.setSwitchState(onoffs.switchState);
                    esaction.setOnOffState(onState);
                    break;
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.SINGLE_DIMMER:
                    let sdState = new zigbee_embedded_switch_pb_1.SingleDimmerApplianceState();
                    let sds = scheduleAction.applianceState;
                    sdState.setSwitchState(sds.switchState);
                    esaction.setSingleDimmerState(sdState);
                    break;
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                    let fanState = new zigbee_embedded_switch_pb_1.FanApplianceState();
                    let fans = scheduleAction.applianceState;
                    fanState.setFanState(fans.fanState);
                    esaction.setFanState(fanState);
                    break;
                case device_constants_pb_1.EMBEDDED_APPLIANCE_TYPES.ON_OFF:
                    let ctState = new zigbee_embedded_switch_pb_1.ColorTunableApplianceState();
                    let cts = scheduleAction.applianceState;
                    ctState.setLightState(cts.lightState);
                    ctState.setWarmWhiteState(cts.warmWhiteState);
                    ctState.setCoolWhiteState(cts.coolWhiteState);
                    esaction.setColorTunableState(ctState);
                    break;
            }
            return esaction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_ON0FF:
            let gponoff = new zigbee_embedded_switch_pb_1.GroupOnOffApplianceAction();
            let gpon = scheduleAction;
            gponoff.setRoomId(gpon.roomId);
            gponoff.setGroupId(gpon.groupId);
            gponoff.setSwitchState(gpon.switchState);
            return gponoff;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_SINGLE_DIMMER:
            let gpsd = new zigbee_embedded_switch_pb_1.GroupSingleDimmerApplianceAction();
            let gps = scheduleAction;
            gpsd.setRoomId(gps.roomId);
            gpsd.setGroupId(gps.groupId);
            gpsd.setSwitchState(gps.switchState);
            return gpsd;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_FAN:
            let gpfan = new zigbee_embedded_switch_pb_1.GroupFanApplianceAction();
            let gpfn = scheduleAction;
            gpfan.setRoomId(gpfn.roomId);
            gpfan.setGroupId(gpfn.groupId);
            gpfan.setFanState(gpfn.fanState);
            return gpfan;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_COLOR_TUNABLE:
            let gpct = new zigbee_embedded_switch_pb_1.GroupColorTunableApplianceAction();
            let gpc = scheduleAction;
            gpct.setRoomId(gpc.roomId);
            gpct.setGroupId(gpc.groupId);
            gpct.setLightState(gpc.lightState);
            gpct.setCoolWhiteState(gpc.coolWhiteState);
            gpct.setWarmWhiteState(gpc.warmWhiteState);
            return gpct;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_AC_FAN_CONTROLLER:
            let acaction = new zigbee_ac_fan_controller_pb_1.ZigbeeACFanControllerAction();
            acaction.setDeviceId(scheduleAction.deviceId);
            acaction.setFanState(scheduleAction.fanState);
            acaction.setUpdateType(scheduleAction.updateType);
            acaction.setLightState(scheduleAction.lightState);
            return acaction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DC_FAN_CONTROLLER:
            const zdcfcAction = new zigbee_dc_fan_controller_pb_1.ZigbeeDCFanControllerAction();
            const zdcfcLightAction = new zigbee_dc_fan_controller_pb_1.DCFanControllerLightState();
            zdcfcAction.setDeviceId(scheduleAction.deviceId);
            zdcfcAction.setUpdateType(scheduleAction.updateType);
            zdcfcAction.setFanState(scheduleAction.fanState ? scheduleAction.fanState : 0);
            zdcfcLightAction.setLightState(scheduleAction.lightState ? scheduleAction.lightState.lightState : 0);
            zdcfcLightAction.setLightTemperature(scheduleAction.lightState ? scheduleAction.lightState.lightTemperature : 0);
            zdcfcAction.setLightState(zdcfcLightAction);
            return zdcfcAction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_RGBWWA:
            const zrgbwwaAction = new zigbee_rgbwwa_driver_pb_1.ZigbeeRgbwwaAction();
            zrgbwwaAction.setDeviceId(scheduleAction.deviceId);
            zrgbwwaAction.setUpdateType(scheduleAction.updateType);
            zrgbwwaAction.setDeviceState(scheduleAction.deviceState);
            if (scheduleAction.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                const zrgbAction = new zigbee_rgbwwa_driver_pb_1.RGB();
                zrgbAction.setRed(scheduleAction.rgbState.red);
                zrgbAction.setBlue(scheduleAction.rgbState.blue);
                zrgbAction.setGreen(scheduleAction.rgbState.green);
                zrgbAction.setPattern(scheduleAction.rgbState.pattern);
                zrgbAction.setDeviceState(scheduleAction.rgbState.deviceState);
                zrgbwwaAction.setRgbState(zrgbAction);
            }
            else if (scheduleAction.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                const zwwaAction = new zigbee_rgbwwa_driver_pb_1.WWA();
                zwwaAction.setAmber(scheduleAction.wwaState.amber);
                zwwaAction.setCoolWhite(scheduleAction.wwaState.coolWhite);
                zwwaAction.setWarmWhite(scheduleAction.wwaState.warmWhite);
                zwwaAction.setDeviceState(scheduleAction.wwaState.deviceState);
                zrgbwwaAction.setWwaState(zwwaAction);
            }
            return zrgbwwaAction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_SMART_CONSOLE_RELAY:
            const zscAction = new smart_console_pb_1.SmartConsoleRelayAction();
            zscAction.setDeviceId(scheduleAction.deviceId);
            zscAction.setRelayId(scheduleAction.relayId);
            zscAction.setRelayState(scheduleAction.relayState);
            return zscAction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_IR_REMOTE:
            let ziraction = new zigbee_ir_blaster_pb_1.ZigbeeIRBlasterAction();
            let scheduleDbAction = scheduleAction;
            ziraction.setRemoteId(scheduleDbAction.remoteId);
            ziraction.setRemoteType(scheduleDbAction.remoteType);
            ziraction.setIrDevice(scheduleDbAction.irDevice);
            switch (scheduleDbAction.remoteType) {
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_AC:
                    let acAction = new zigbee_ir_blaster_pb_1.IRACBlastAction();
                    let acDbAction = scheduleDbAction.irBlastAction;
                    acAction.setPowerOn(acDbAction.powerOn);
                    acAction.setTemperature(acDbAction.temperature);
                    acAction.setSwingHLevel(acDbAction.swingHLevel);
                    acAction.setSwingVLevel(acDbAction.swingVLevel);
                    acAction.setMode(acDbAction.mode);
                    acAction.setFanLevel(acDbAction.fanLevel);
                    ziraction.setAcActionInfo(acAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_TV:
                    let tvAction = new zigbee_ir_blaster_pb_1.IRTVBlastAction();
                    let tvDbAction = scheduleDbAction.irBlastAction;
                    tvAction.setUpdateType(tvDbAction.updateType);
                    tvAction.setChannelNumber(tvDbAction.channelNumber);
                    tvAction.setMode(tvDbAction.mode);
                    tvAction.setPowerOn(tvDbAction.powerOn);
                    tvAction.setSource(tvDbAction.source);
                    ziraction.setTvActionInfo(tvAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_AMP:
                    let ampAction = new zigbee_ir_blaster_pb_1.IRAMPBlastAction();
                    let ampDbAction = scheduleDbAction.irBlastAction;
                    ampAction.setPowerOn(ampDbAction.powerOn);
                    ampAction.setMode(ampDbAction.mode);
                    ampAction.setSource(ampDbAction.source);
                    ampAction.setUpdateType(ampDbAction.updateType);
                    ziraction.setAmpActionInfo(ampAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_FAN:
                    let fanAction = new zigbee_ir_blaster_pb_1.IRFANBlastAction();
                    let fanDbAction = scheduleDbAction.irBlastAction;
                    fanAction.setLedState(fanDbAction.ledState);
                    fanAction.setMode(fanDbAction.mode);
                    fanAction.setPowerOn(fanDbAction.powerOn);
                    fanAction.setSpeedLevel(fanDbAction.speedLevel);
                    ziraction.setFanActionInfo(fanAction);
                    break;
                case device_constants_pb_1.IR_REMOTE_TYPES.IR_PR:
                    let prAction = new zigbee_ir_blaster_pb_1.IRPRBlastAction();
                    let prDbAction = scheduleDbAction.irBlastAction;
                    prAction.setMode(prDbAction.mode);
                    prAction.setPowerOn(prDbAction.powerOn);
                    prAction.setSource(prDbAction.source);
                    prAction.setUpdateType(prDbAction.updateType);
                    ziraction.setPrActionInfo(prAction);
                    break;
            }
            return ziraction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.SCENE_EXECUTION:
            let saction = new scene_structures_pb_1.ExecuteScene();
            saction.setSceneId(scheduleAction.sceneId);
            saction.setSceneRoom(scheduleAction.sceneRoom);
            return saction;
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_ZIGBEE_RGBWWA:
            const grgbwwaAction = new zigbee_rgbwwa_driver_pb_1.GroupZigbeeRgbwwaAction();
            grgbwwaAction.setGroupId(scheduleAction.groupId);
            grgbwwaAction.setRoomId(scheduleAction.roomId);
            grgbwwaAction.setUpdateType(scheduleAction.updateType);
            grgbwwaAction.setDeviceState(scheduleAction.deviceState);
            if (scheduleAction.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_RGB_UPDATE) {
                const grgbAction = new zigbee_rgbwwa_driver_pb_1.RGB();
                grgbAction.setRed(scheduleAction.rgbState.red);
                grgbAction.setBlue(scheduleAction.rgbState.blue);
                grgbAction.setGreen(scheduleAction.rgbState.green);
                grgbAction.setPattern(scheduleAction.rgbState.pattern);
                grgbAction.setDeviceState(scheduleAction.rgbState.deviceState);
                grgbwwaAction.setRgbState(grgbAction);
            }
            else if (scheduleAction.updateType == device_constants_pb_1.RGBWWA_DRIVER_UPDATE_TYPE.RGBWWA_WWA_UPDATE) {
                const gwwaAction = new zigbee_rgbwwa_driver_pb_1.WWA();
                gwwaAction.setAmber(scheduleAction.wwaState.amber);
                gwwaAction.setCoolWhite(scheduleAction.wwaState.coolWhite);
                gwwaAction.setWarmWhite(scheduleAction.wwaState.warmWhite);
                gwwaAction.setDeviceState(scheduleAction.wwaState.deviceState);
                grgbwwaAction.setWwaState(gwwaAction);
            }
            return grgbwwaAction;
            break;
    }
}
exports.getScheduleActionProto = getScheduleActionProto;
function getScheduleProto(schedule) {
    const scheduleProto = new schedule_structure_pb_1.Schedule();
    scheduleProto.setScheduleId(schedule.scheduleId);
    scheduleProto.setScheduleName(schedule.scheduleName);
    scheduleProto.setScheduleType(schedule.scheduleType);
    scheduleProto.setScheduleSection(schedule.scheduleSection);
    scheduleProto.setScheduleRoom(schedule.scheduleRoom);
    scheduleProto.setStartTime(schedule.startTime);
    scheduleProto.setEndTime(schedule.endTime);
    scheduleProto.setRepeatList(schedule.repeat);
    scheduleProto.setCreatedBy(schedule.createdBy);
    scheduleProto.setCreatedByName(schedule.createdByName);
    scheduleProto.setScheduleActionType(schedule.scheduleActionType);
    scheduleProto.setActiveStatus(schedule.activeStatus);
    switch (schedule.scheduleActionType) {
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_DIMMABLE_DRIVER:
            scheduleProto.setDdimmableDriverAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_COLOR_TUNABLE_DRIVER:
            scheduleProto.setDcolortunableDriverAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.DALI_NON_DIMMABLE_DRIVER:
            scheduleProto.setDnondimmableDriverAction((getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction)));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DIMMABLE_DRIVER:
            scheduleProto.setZdimmableDriverAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_NON_DIMMABLE_DRIVER:
            scheduleProto.setZnondimmableDriverAction((getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction)));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_CURTAIN_CONTROLLER:
            scheduleProto.setZcurtainControllerAction((getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction)));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_AC_FAN_CONTROLLER:
            scheduleProto.setZacfanControllerAction((getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction)));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_DC_FAN_CONTROLLER:
            scheduleProto.setZdcfanControllerAction((getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction)));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_EMBEDDED_SWITCH:
            scheduleProto.setEmbeddedApplianceAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_RGBWWA:
            scheduleProto.setZrgbwwwaDriverAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_SMART_CONSOLE_RELAY:
            scheduleProto.setZscRelayAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.ZIGBEE_IR_REMOTE:
            scheduleProto.setZirBlasterAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.SCENE_EXECUTION:
            scheduleProto.setSceneAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_ON0FF:
            scheduleProto.setGrpOnoffAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_SINGLE_DIMMER:
            scheduleProto.setGrpSingledimmerAction((getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction)));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_FAN:
            scheduleProto.setGrpFanAction(getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_APPLIANCE_COLOR_TUNABLE:
            scheduleProto.setGrpColortunableAction((getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction)));
            break;
        case schedule_structure_pb_1.SCHEDULE_ACTION_TYPE.GROUP_ZIGBEE_RGBWWA:
            scheduleProto.setGrpZrgbwwaAction((getScheduleActionProto(schedule.scheduleActionType, schedule.scheduleAction)));
            break;
        default:
    }
    return scheduleProto;
}
exports.getScheduleProto = getScheduleProto;
function getScheduleProtoList(scheduleList) {
    const scheduleProtoList = new Array();
    scheduleList.forEach(function (schedule) {
        scheduleProtoList.push(getScheduleProto(schedule));
    });
    return scheduleProtoList;
}
exports.getScheduleProtoList = getScheduleProtoList;
//# sourceMappingURL=schedule-utils.js.map