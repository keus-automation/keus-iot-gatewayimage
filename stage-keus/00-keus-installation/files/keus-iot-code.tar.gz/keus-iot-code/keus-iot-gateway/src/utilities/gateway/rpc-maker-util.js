"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../constants/gateway/system-constants");
const messenger_util_singleton_1 = require("../messenger-util-singleton");
const messenger_constants_1 = require("../../constants/gateway/messenger-constants");
const errors_1 = require("../../errors/errors");
const cloud_client_1 = require("../../app/hub-request-manager/cloud-client");
const local_client_1 = require("../../app/hub-request-manager/local-client");
async function MakeAuthCloudRpc(requestMessage) {
    try {
        let resp = await cloud_client_1.CloudProvidersManager.makeRPC(system_constants_1.GrpcCloudAuthServiceName, requestMessage);
        let unpackedObj = cloud_client_1.CloudProvidersManager.getTypeConversionUtils().unpackFromAny(resp);
        return unpackedObj;
    }
    catch (e) {
        console.log('error while making cloud rpc call from hub  - ', e);
        throw new errors_1.GeneralErrors.RpcMakerError(e);
    }
}
exports.MakeAuthCloudRpc = MakeAuthCloudRpc;
function UnPackFromAny(packedMsg) {
    try {
        return local_client_1.GatewayProvidersManager.getTypeConversionUtils().unpackFromAny(packedMsg);
    }
    catch (e) {
        throw e;
    }
}
exports.UnPackFromAny = UnPackFromAny;
async function MakeUnAuthCloudRpc(requestMessage) {
    try {
        let userObj = await messenger_util_singleton_1.memoryMessengerInst.callMethodWithVariableArguments(messenger_constants_1.CLOUD_CONTROLLER, messenger_constants_1.RpcFunctionRequest, system_constants_1.GrpcCloudUnAuthServiceName, requestMessage);
        let unpackedObj = await UnPackFromAny(userObj);
        return unpackedObj;
    }
    catch (e) {
        console.log('error while making cloud rpc call from hub  - ', e);
        throw new errors_1.GeneralErrors.RpcMakerError(e);
    }
}
exports.MakeUnAuthCloudRpc = MakeUnAuthCloudRpc;
async function MakeAuthLocalRpc(requestMessage) {
    try {
        let resp = await local_client_1.GatewayProvidersManager.makeRPC(local_client_1.GatewayProvidersManager.getMainGatewayServiceName(), requestMessage);
        let unpackedObj = local_client_1.GatewayProvidersManager.getTypeConversionUtils().unpackFromAny(resp);
        return unpackedObj;
    }
    catch (e) {
        console.log('error while making cloud rpc call from hub  - ', e);
        throw new errors_1.GeneralErrors.RpcMakerError(e);
    }
}
exports.MakeAuthLocalRpc = MakeAuthLocalRpc;
//# sourceMappingURL=rpc-maker-util.js.map