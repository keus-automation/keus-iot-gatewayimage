"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const system_constants_1 = require("../../constants/gateway/system-constants");
const scene_constants_1 = require("../../constants/scene/scene-constants");
const rs = __importStar(require("randomstring"));
function generateSceneIdForArea(sceneList) {
    var i = scene_constants_1.SceneStartId;
    while (i <= scene_constants_1.SceneEndId) {
        var filteredSceneList = sceneList.filter(function (scene) {
            return scene.sceneId == i;
        });
        if (!filteredSceneList.length) {
            return i;
        }
        i++;
    }
    return -1;
}
exports.generateSceneIdForArea = generateSceneIdForArea;
function generateTimeslotIdForScene() {
    return Math.floor(1 + Math.random() * 100);
}
exports.generateTimeslotIdForScene = generateTimeslotIdForScene;
function generateActionIdForScene() {
    return rs.generate(12);
}
exports.generateActionIdForScene = generateActionIdForScene;
function generateZigbeeActionIdForScene(actionList) {
    var i = 1;
    while (i < system_constants_1.SceneActionLimit) {
        const action = actionList.find(function (action) {
            return action.zigbeeActionId == i;
        });
        if (!action) {
            break;
        }
        i++;
    }
    return i == system_constants_1.SceneActionLimit ? -1 : i;
}
exports.generateZigbeeActionIdForScene = generateZigbeeActionIdForScene;
//# sourceMappingURL=scene-utils.js.map