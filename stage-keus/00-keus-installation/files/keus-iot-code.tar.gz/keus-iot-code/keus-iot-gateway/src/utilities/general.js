"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const any_pb_1 = require("google-protobuf/google/protobuf/any_pb");
const GeneralErrors = __importStar(require("../errors/general-errors"));
const pipeable_1 = require("fp-ts/lib/pipeable");
const Either_1 = require("fp-ts/lib/Either");
const util = __importStar(require("util"));
exports.generateString = length => {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
};
exports.AsyncDelay = delay => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(null);
        }, delay);
    });
};
exports.PackIntoAny = (serializedData, typeUrl) => {
    const anyObj = new any_pb_1.Any();
    anyObj.pack(serializedData, typeUrl);
    return anyObj;
};
// export const UnPackFromAny = obj => {
//     const conversionUtils = memoryMessengerInst.callMethod(CLOUD_CONTROLLER, ConversionUtilsRequest, null);
//     let unPackedObj = conversionUtils.unpackFromAny(obj);
//     return unPackedObj;
// };
exports.GetUint16HighByte = uint16Num => {
    return (uint16Num >> 8) & 0xff;
};
exports.GetUint16LowByte = uint16Num => {
    return uint16Num & 0xff;
};
exports.GetInverseMask = number => {
    var e = number.toString(2).split('');
    if (e.length < 8) {
        let prefixZeros = new Array(8 - e.length).fill('0');
        e = prefixZeros.concat(e);
    }
    for (var i = 0, l = e.length; i < l; i++) {
        e[i] = e[i] === '0' ? '1' : e[i] === '1' ? '0' : e[i];
    }
    return Number('0b' + e.join(''));
};
exports.GetUint8Mask = (bitsArr) => {
    let uint8Arr = new Array(8).fill('0');
    for (let i = 0; i < bitsArr.length; i++) {
        uint8Arr[7 - bitsArr[i]] = '1';
    }
    return Number('0b' + uint8Arr.join(''));
};
exports.findKeyValInArrayOfObjects = (arrayOfObjects, searchKey, searchValue) => {
    let foundIndex = -1;
    for (let i = 0; i < arrayOfObjects.length; i++) {
        if (arrayOfObjects[i][searchKey] == searchValue) {
            foundIndex = i;
            break;
        }
    }
    return foundIndex;
};
exports.verifyRequest = function (item, typeChecker) {
    return new Promise(function (resolve, reject) {
        pipeable_1.pipe(typeChecker.decode(item), Either_1.fold(function (errors) {
            reject(new GeneralErrors.TypeValidationError(getValdiationErrorList(errors)));
        }, async function (data) {
            resolve(data);
        }));
    });
};
function getValdiationErrorList(errors) {
    let finalErr = '';
    errors.forEach(function (error) {
        error.context.forEach(function (context) {
            if (context.key) {
                finalErr += 'Invalid value supplied to ' + context.key + '. Expected: ' + context.type.name + '\n';
            }
        });
    });
    return finalErr;
}
exports.getValdiationErrorList = getValdiationErrorList;
exports.printFullObject = obj => {
    console.log(util.inspect(obj, false, null, true /* enable colors */));
};
exports.generateRandomNumber = (min, max) => {
    return Math.floor(Math.random() * (max - min) + min);
};
exports.WaitAndCheck = async function (waitTime, checkInterval, checkFn) {
    let numChecks = waitTime / checkInterval;
    let checks = 0;
    while (checks <= numChecks) {
        await exports.AsyncDelay(checkInterval);
        if (checkFn()) {
            return true;
        }
        checks += 1;
    }
    return false;
};
exports.buildTcpUrl = (host, port) => {
    return 'tcp://' + host + ':' + port;
};
exports.doesValueExist = (arrayVal, key, value) => {
    let index = -1;
    let exists = arrayVal.find((arrayItem, arrInd) => {
        if (arrayItem[key] === value) {
            index = arrInd;
            return true;
        }
        else {
            return false;
        }
    });
    return {
        object: exists,
        index: index
    };
};
//# sourceMappingURL=general.js.map