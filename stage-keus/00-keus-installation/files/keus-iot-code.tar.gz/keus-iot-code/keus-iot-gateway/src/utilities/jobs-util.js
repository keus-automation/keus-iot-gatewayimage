"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const agenda_1 = __importDefault(require("agenda"));
const system_constants_1 = require("../constants/gateway/system-constants");
const DEFAULT_TIMEOUT = 6000;
const onTag = '-on';
const offTag = '-off';
const cleanJobLimit = 1000;
const DefaultJobOptions = {
    concurrency: 20,
    timeout: DEFAULT_TIMEOUT
};
var StepsExecutionType;
(function (StepsExecutionType) {
    StepsExecutionType[StepsExecutionType["PARALLEL"] = 1] = "PARALLEL";
    StepsExecutionType[StepsExecutionType["SERIES"] = 2] = "SERIES";
})(StepsExecutionType = exports.StepsExecutionType || (exports.StepsExecutionType = {}));
class Jobs {
    constructor(options) {
        this._agendaConfig = {
            db: { address: options.mongoUrl },
            defaultConcurrency: 20,
            maxConcurrency: 20,
            name: options.instanceIdentifier ? options.instanceIdentifier : 'keus_' + Math.random()
        };
        this._jobsMap = new Map();
        this._jobOptionsMap = new Map();
        this._agendaInst = new agenda_1.default(this._agendaConfig);
    }
    async cleanJobs() {
        this._agendaInst = new agenda_1.default(this._agendaConfig);
        let cleanJobsList = await this._agendaInst.jobs({ nextRunAt: null });
        if (cleanJobsList.length > cleanJobLimit) {
            cleanJobsList.sort(function (a, b) {
                return a.attrs.lastRunAt.getTime() - b.attrs.lastRunAt.getTime();
            });
            cleanJobsList = cleanJobsList.slice(0, cleanJobsList.length - cleanJobLimit);
            const cleanJobsIds = cleanJobsList.map(function (job) {
                return job.attrs._id;
            });
            await this._agendaInst.cancel({ _id: { $in: cleanJobsIds } });
        }
        return;
    }
    getJobId(jobName, jobId) {
        return jobName + '-' + jobId;
    }
    async getJobInstances(jobName, jobId) {
        let jobsFilter = { name: jobName, lastFinishedAt: null };
        if (jobId) {
            jobsFilter['data.jobId'] = jobId;
        }
        let jobInsts = await this._agendaInst.jobs(jobsFilter);
        return jobInsts;
    }
    async hasRunningJobs(jobName, jobId) {
        let instances = await this.getJobInstances(jobName);
        if (instances.length > 0) {
            return true;
        }
        else {
            return false;
        }
    }
    getCronString(runTime, daysRepeat) {
        const runTimeDate = new Date(runTime);
        const hoursString = runTimeDate.getHours().toString();
        const minutesString = runTimeDate.getMinutes().toString();
        var daysString = '';
        for (var i = 0; i < daysRepeat.length; i++) {
            if (daysRepeat[i] == 'true') {
                daysString = daysString + i.toString() + ',';
            }
        }
        if (daysString.endsWith(',')) {
            daysString = daysString.substring(0, daysString.length - 1);
        }
        return minutesString + ' ' + hoursString + ' * * ' + daysString;
    }
    defineJob(jobName, jobDef) {
        let that = this;
        let jobOptions = Object.assign(DefaultJobOptions, jobDef.options);
        that._jobOptionsMap.set(jobName, {
            timeout: jobOptions.timeout,
            concurrency: jobOptions.concurrency
        });
        that._agendaInst.define(jobName, {
            concurrency: jobOptions.concurrency
        }, async (job, done) => {
            console.log('--------------------------RUNNING JOB HERE ---------------------', job.attrs.data.jobId);
            try {
                let jobInstanceOptions = that._jobOptionsMap.get(job.attrs.name);
                let jobAttrs = job.attrs.data;
                let timeoutHandle = null;
                let statusUpdateFn = null;
                let onJobInstanceComplete = jobAttrs.onComplete ? jobAttrs.onComplete : function () { };
                jobAttrs.status = jobAttrs.status ? jobAttrs.status : {};
                statusUpdateFn = async (status) => {
                    jobAttrs.status = Object.assign(jobAttrs.status, status);
                    await job.save();
                };
                let jobInstance = {
                    name: jobName,
                    id: jobAttrs.jobId,
                    job: job,
                    done: function () {
                        clearTimeout(timeoutHandle);
                        done();
                        that._jobsMap.delete(jobAttrs.jobId);
                        jobDef.onCompleteCbk(jobInstance);
                        onJobInstanceComplete();
                    },
                    status: jobAttrs.status,
                    statusUpdateFn: statusUpdateFn,
                    data: jobAttrs.data
                };
                that._jobsMap.set(jobAttrs.jobId, jobInstance);
                timeoutHandle = setTimeout(async () => {
                    console.log('\n\n\n\n\n job TImeout', jobInstanceOptions);
                    await jobDef.timeoutHandler(jobInstance);
                    done(new Error('Timeout'));
                    that._jobsMap.delete(jobAttrs.jobId);
                    jobDef.onCompleteCbk(jobInstance);
                    onJobInstanceComplete('timeout');
                }, jobInstanceOptions.timeout);
                console.log('\n\n\n\n\n job TImeout', jobInstanceOptions);
                let result = await jobDef.jobHandler(jobInstance);
                return result;
            }
            catch (err) {
                throw err;
            }
        });
    }
    async start() {
        try {
            await this._agendaInst.start();
            this._agendaInst.on('start', job => {
                console.log('Job %s starting', job.attrs.name);
            });
        }
        catch (err) {
            throw err;
        }
    }
    async runJob(jobName, jobId, data) {
        let transformedJobId = this.getJobId(jobName, jobId);
        try {
            if (this._jobsMap.has(transformedJobId)) {
                throw new Error('Job Already In progress');
            }
            await this._agendaInst.now(jobName, {
                data: data,
                jobId: transformedJobId
            });
        }
        catch (err) {
            console.log(err);
            throw err;
        }
    }
    async runJobToCompletion(jobName, jobId, data) {
        let transformedJobId = this.getJobId(jobName, jobId);
        return new Promise(async (resolve, reject) => {
            try {
                if (this._jobsMap.has(transformedJobId)) {
                    throw new Error('Job Already In progress');
                }
                await this._agendaInst.now(jobName, {
                    data: data,
                    jobId: transformedJobId,
                    onComplete: function (err) {
                        if (err) {
                            reject(err);
                        }
                        else {
                            resolve({});
                        }
                    }
                });
            }
            catch (err) {
                reject(err);
            }
        });
    }
    getJobInstance(jobName, jobId) {
        let transformedJobId = this.getJobId(jobName, jobId);
        console.log('This is transformed Job Id', transformedJobId, this._jobsMap);
        try {
            if (!this._jobsMap.has(transformedJobId)) {
                throw new Error('Job not found');
            }
            return this._jobsMap.get(transformedJobId);
        }
        catch (err) {
            throw err;
        }
    }
    async scheduleJob(jobName, jobId, jobInfo) {
        let _this = this;
        console.log('THIS IS THE JOB NAME------------------------------------', jobName);
        try {
            if (this._jobsMap.has(jobId + onTag)) {
                throw new Error('Job Already In progress');
            }
            var startTime, endTime;
            // Check repeat
            if (!jobInfo.repeat.length || jobInfo.repeat.indexOf('true') < 0) {
                console.log('THIS IS JOBS DATA', jobInfo.startData);
                await _this._agendaInst.schedule(jobInfo.startTime, jobName, {
                    data: jobInfo.startData,
                    id: jobId + onTag,
                    on: true
                });
                console.log('HITTIGN HERE', jobInfo.endTime, jobInfo.endData);
                if (jobInfo.endTime) {
                    console.log('THIS IS JOBS END DATA', jobInfo.endData);
                    await _this._agendaInst.schedule(jobInfo.endTime, jobName, {
                        data: jobInfo.endData,
                        id: jobId + offTag,
                        on: false
                    });
                }
            }
            else {
                startTime = _this.getCronString(jobInfo.startTime, jobInfo.repeat);
                await _this._agendaInst.every(startTime, jobName, { data: jobInfo.startData, id: jobId + onTag, on: true }, { timezone: system_constants_1.LocalTimezone, skipImmediate: true });
                if (jobInfo.endTime) {
                    endTime = _this.getCronString(jobInfo.endTime, jobInfo.repeat);
                    await _this._agendaInst.every(endTime, jobName, { data: jobInfo.endData, id: jobId + offTag, on: false }, { timezone: system_constants_1.LocalTimezone, skipImmediate: true });
                }
            }
            return;
        }
        catch (err) {
            console.log(err);
            throw err;
        }
    }
    async removeJob(jobId) {
        console.log('--------------REMOVING JOB----------------', jobId);
        let _this = this;
        try {
            const startJobId = jobId + onTag;
            const endJobId = jobId + offTag;
            await _this._agendaInst.cancel({
                'data.id': startJobId
            });
            await _this._agendaInst.cancel({
                'data.id': endJobId
            });
            _this._jobsMap.delete(startJobId);
            _this._jobsMap.delete(endJobId);
            return;
        }
        catch (e) {
            console.log(e);
            throw e;
        }
    }
    async addBackgroundJob(cronStr, job) {
        try {
            await this._agendaInst.every(cronStr, job.name, job.data);
        }
        catch (err) {
            throw err;
        }
    }
}
exports.Jobs = Jobs;
//# sourceMappingURL=jobs-util.js.map