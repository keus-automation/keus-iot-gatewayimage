"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const memory_messenger_impl_1 = __importDefault(require("./messenger/memory-messenger-impl"));
const memoryMessengerInst = new memory_messenger_impl_1.default();
exports.memoryMessengerInst = memoryMessengerInst;
//# sourceMappingURL=messenger-util-singleton.js.map