"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RootPath = '../../';
const Logger = require(RootPath + 'services/logger-service/index').default;
const logInst = new Logger({ enable: true, namespace: 'mmi' });
const MessengerInterface = require('./messenger-interface').default;
const ObjectPath = require('object-path');
const CALL_TYPES = {
    SYNC: 0,
    ASYNC: 1
};
class MemoryMessenger extends MessengerInterface {
    constructor() {
        super();
        this._controllers = {};
    }
    registerController(controllerName, controllerObj) {
        this._controllers[controllerName] = controllerObj;
    }
    deregisterController(controllerName) {
        delete this._controllers[controllerName];
    }
    getData(controllerName, dataAccessPath) {
        if (this._controllers[controllerName]) {
            return ObjectPath.withInheritedProps.get(this._controllers[controllerName], dataAccessPath);
        }
        else {
            throw new Error('Controller Not Found');
        }
    }
    callMethod(controllerName, methodAccessPath, methodData) {
        if (!this._controllers[controllerName]) {
            throw new Error('Controller Not Found');
        }
        let method = ObjectPath.withInheritedProps.get(this._controllers[controllerName], methodAccessPath);
        if (method) {
            return method(methodData);
        }
        else {
            throw new Error('Method Not Found');
        }
    }
    callMethodWithVariableArguments(controllerName, methodAccessPath, ...args) {
        console.log('calling', controllerName, methodAccessPath, this._controllers, args);
        if (!this._controllers[controllerName]) {
            console.log('Controller not found');
            throw new Error('Controller Not Found');
        }
        let method = ObjectPath.withInheritedProps.get(this._controllers[controllerName], methodAccessPath);
        if (method) {
            return method(...args);
        }
        else {
            console.log('method not found');
            throw new Error('Method Not Found');
        }
    }
}
exports.default = MemoryMessenger;
//# sourceMappingURL=memory-messenger-impl.js.map