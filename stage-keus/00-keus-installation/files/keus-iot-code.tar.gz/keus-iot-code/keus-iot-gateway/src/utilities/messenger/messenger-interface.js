"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class MessengerInterface {
}
exports.default = MessengerInterface;
//# sourceMappingURL=messenger-interface.js.map