"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RootPath = '../../';
const Logger = require(RootPath + 'services/logger-service/index').default;
const logInst = new Logger({ enable: true, namespace: 'psi' });
const MessengerInterface = require('./messenger-interface').default;
class NetworkMessenger extends MessengerInterface {
    constructor() {
        super();
    }
}
exports.default = NetworkMessenger;
//# sourceMappingURL=network-messenger-impl.js.map