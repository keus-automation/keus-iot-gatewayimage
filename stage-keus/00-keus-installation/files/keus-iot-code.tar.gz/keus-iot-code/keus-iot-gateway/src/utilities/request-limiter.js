"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class RequestLimiter {
    constructor(limit) {
        this.ErrorStr = '208';
        this.limit = limit;
        var buffer = new SharedArrayBuffer(1);
        this.current = new Uint8Array(buffer);
    }
    startRequest() {
        let currentVal = Atomics.load(this.current, 0);
        console.log('this is start request', currentVal, this.limit);
        if (currentVal < this.limit) {
            Atomics.add(this.current, 0, 1);
            return true;
        }
        else {
            throw new Error(this.ErrorStr);
        }
    }
    endRequest(error) {
        if (!error) {
            Atomics.add(this.current, 0, -1);
        }
        else if (error && error.message !== this.ErrorStr) {
            Atomics.add(this.current, 0, -1);
        }
    }
}
exports.default = RequestLimiter;
//# sourceMappingURL=request-limiter.js.map