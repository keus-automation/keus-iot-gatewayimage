"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ResponseHelper {
    static getInternalServerError() {
        let error = {
            code: 500,
            success: false,
            message: 'Server Error'
        };
        return error;
    }
    static getOperationNotAllowed() {
        let error = {
            code: 501,
            success: false,
            message: 'Operation Not Allowed'
        };
        return error;
    }
}
exports.default = ResponseHelper;
//# sourceMappingURL=response-helper.js.map