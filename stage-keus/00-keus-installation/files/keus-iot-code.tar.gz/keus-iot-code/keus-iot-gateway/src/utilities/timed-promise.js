"use strict";
//Timed promise. Takes a function which returns the required promise and an optional timeout
Object.defineProperty(exports, "__esModule", { value: true });
exports.TPromise = (promise, timeoutMs = 5000) => {
    let timeoutHandle;
    const timeoutPromise = new Promise((resolve, reject) => {
        timeoutHandle = setTimeout(function () {
            reject();
        }, timeoutMs);
    });
    return Promise.race([promise(), timeoutPromise])
        .then((result) => {
        clearTimeout(timeoutHandle);
        return result;
    });
};
//# sourceMappingURL=timed-promise.js.map